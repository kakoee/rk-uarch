from pathlib import Path
s=Path('/tmp/u4-c2r-setup.py').read_text().replace('u4-k2-c2r.','u4-k2-c2b.').replace('/tmp/u4-c2r-location','/tmp/u4-c2b-location')
s=s.replace("U4-K2-C2-followup-release-v1/reconciliation.json","U4-K2-C2-blank-field-followup-v1/receipt.json")
s=s.replace("pathlib.Path('/tmp/u4-k2-c2.75eyx6ab')]", "pathlib.Path('/tmp/u4-k2-c2.75eyx6ab'),pathlib.Path('/tmp/u4-k2-c2r.s0udc3ig')]")
exec(compile(s,'reused-verified-isolated-setup','exec'))
import json,hashlib,shutil,gzip,subprocess
N=Path(Path('/tmp/u4-c2b-location').read_text());R=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a');A=R/'docs/reviews/U4-A-K2-C2-compatibility-v1';B=R/'docs/reviews/U4-B-K2-C2-compatibility-review-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','81bab62112469f4b32d1b28fc2076caa5815eece:'+str(B.relative_to(R))],cwd=R)==subprocess.check_output(['git','rev-parse','HEAD:'+str(B.relative_to(R))],cwd=R)
for f,v in json.loads((B/'inventory.json').read_text()).items():
 # B inventory format verified below.
 if isinstance(v,dict) and 'sha256' in v:assert sha(B/f)==v['sha256']
assert sha(A/'probe.rs')=='90d7b36df0aac589ff01f360fe294641586ac1406651b697bb4e97068dc84695'
shutil.copyfile(A/'probe.rs',N/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs')
shutil.copyfile(A/'compare.py',N/'controls/compare.py')
shutil.copyfile(A/'refusals.json',N/'vectors/historical-refusals.json')
for f in ['A-extension','B-extension']:(N/'vectors'/f'{f}.jsonl').write_bytes(gzip.decompress((A/f'{f}.jsonl.gz').read_bytes()))
shutil.copyfile(B/'independent.jsonl',N/'vectors/B-independent.jsonl')
assert sha(N/'vectors/B-independent.jsonl')=='1f469bd7e140783f077ce52d0edad8434087f15cd7179c29988b82e001aa9c18'
for mode,h in json.loads((A/'summary.json').read_text())['binary_sha256'].items():
 src=Path('/tmp/u4-k2-c2r.s0udc3ig/target')/mode/'c2-probe';assert sha(src)==h
 (N/'target/baseline'/mode).mkdir(parents=True);shutil.copy2(src,N/'target/baseline'/mode/'c2-probe')
(N/'receipts/starting-source.json').write_text(json.dumps({'subject':'923face8359e6f7ac017c560d9af207509f173b5','probe_sha256':sha(A/'probe.rs'),'comparator_sha256':sha(A/'compare.py'),'workspace_files':{str(p.relative_to(N/'workspace')):sha(p) for p in sorted((N/'workspace').rglob('*')) if p.is_file()},'B_review':'81bab62112469f4b32d1b28fc2076caa5815eece','historical_vector_hashes':{p.name:sha(p) for p in sorted((N/'vectors').glob('*'))}},indent=2)+'\n')
assert len(list((N/'workspace').rglob('*.rs')))==1
assert len([p for p in (N/'workspace').rglob('*') if p.is_file()])==4
Path('/tmp/u4-c2b-run.py').write_text(Path('/tmp/u4-c2r-run.py').read_text().replace('/tmp/u4-c2r-location','/tmp/u4-c2b-location'))
print('Standalone four-file source and B bindings verified',N)
