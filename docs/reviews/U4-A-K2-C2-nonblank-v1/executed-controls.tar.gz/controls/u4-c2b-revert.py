import pathlib,importlib.util,json,shutil,hashlib,time,subprocess,ast

def load(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
r=load('runner','/tmp/u4-c2b-run.py');c=load('compare',r.N/'controls/compare.py');N=r.N;P=r.P
correct=(N/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs').read_text()
a=correct.index('fn sourced_nonblank(');b=correct.index('\nfn process(',a)
fault=correct[:a]+'fn sourced_nonblank(s: &str) -> bool {\n    !s.trim().is_empty()\n}\n'+correct[b:]
V=N/'reversion';shutil.copytree(N/'workspace',V/'workspace');(V/'target').mkdir()
S=V/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs';S.write_text(fault)
raw=(N/'vectors/B-independent.jsonl').read_bytes()+(N/'vectors/focused.jsonl').read_bytes();(V/'selection.jsonl').write_bytes(raw)
rules=json.loads((N/'vectors/refusals.json').read_text());vectors=c.records(raw)
(P/'reversion-plan.json').write_text(json.dumps({'time_ns':time.time_ns(),'corrected_source_sha256':hashlib.sha256(correct.encode()).hexdigest(),'reverted_source_sha256':r.sha(S),'selection_sha256':hashlib.sha256(raw).hexdigest(),'count':len(vectors),'change':'Only sourced_nonblank body restored to former Rust trim predicate; call sites and all 17 tests retained.','workspace':str(V/'workspace'),'target':str(V/'target')},indent=2)+'\n')
(P/'reverted-probe.rs').write_text(fault)
# Reuse the reviewed exact container recorder; mounts are redirected only to this new variant.
t=ast.parse(pathlib.Path('/tmp/u4-c2r-reverts.py').read_text())
exec(compile(ast.Module(body=[x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='variant_run'],type_ignores=[]),'reused-variant-recorder','exec'))
report={}
for phase in ['reverted','restored']:
 if phase=='restored':S.write_text(correct);assert S.read_bytes()==(N/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs').read_bytes()
 for mode in ['debug','release']:
  tag=phase+'-'+mode;flags=['--release'] if mode=='release' else [];env=['RUSTFLAGS=-C debuginfo=1 -C linker=/controls/linker.sh','RUSTC_WRAPPER=/controls/rustc-wrapper.sh','C2_RUN_TAG='+tag]
  assert len([p for p in (V/'workspace').rglob('*') if p.is_file()])==4
  assert r.sha(V/'workspace/native/Cargo.lock')=='cbe9a580e0c6209abdb34be23965c2fe2f75b5970819d2021c943e2e02d939be'
  p=variant_run(tag+'-build',[r.BIN+'cargo','rustc','--locked','--offline','-p','uarch-engine','--bin','c2-probe','-vv','--message-format=json',*flags,'--','-C','link-arg=-Wl,-Map=/receipts/'+tag+'.map'],V,env);assert p.returncode==0
  p=variant_run(tag+'-unit',[r.BIN+'cargo','test','--locked','--offline','-p','uarch-engine','--bin','c2-probe','-vv',*flags],V,env[:-1]+['C2_RUN_TAG='+tag+'-unit']);assert p.returncode==(101 if phase=='reverted' else 0)
  assert b'17 tests' in p.stdout
  p=variant_run(tag+'-selection',['/target/'+mode+'/c2-probe'],V,stdin=raw);assert p.returncode==0
  result=c.compare(vectors,c.records(p.stdout),rules)
  assert result['mismatch_count']==(35 if phase=='reverted' else 0)
  if phase=='reverted':assert all(m['expected']['status']=='refuse' and m['actual']['status']=='ok' for m in result['mismatches'])
  report[tag]={'comparison':result,'source_sha256':r.sha(S),'binary_sha256':r.sha(V/'target'/mode/'c2-probe'),'matches_corrected_binary':r.sha(V/'target'/mode/'c2-probe')==r.sha(N/'target'/mode/'c2-probe')}
  (P/'reversion-results.json').write_text(json.dumps(report,indent=2)+'\n')
assert S.read_text()==correct
print({k:{'mismatches':v['comparison']['mismatch_count'],'same_corrected_binary':v['matches_corrected_binary']} for k,v in report.items()})
