import pathlib,json,hashlib,shutil,subprocess,time
R=pathlib.Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a');N=pathlib.Path(pathlib.Path('/tmp/u4-c2b-location').read_text());P=N/'receipts'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inv(root):return {str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in sorted(root.rglob('*')) if p.is_file()}
def write(name,obj):(P/name).write_text(json.dumps(obj,indent=2)+'\n')
actual=[]
for p in sorted(P.glob('*.argv')):
 args=p.read_bytes().rstrip(b'\0').decode().split('\0');env=p.with_suffix('.env');environment=dict(x.split('=',1) for x in env.read_bytes().rstrip(b'\0').decode().split('\0'))
 assert not any('no-vectorize' in a or 'target-cpu=native' in a or 'target-feature=+' in a for a in args)
 actual.append({'receipt':p.name,'argv':args,'environment':environment,'argv_sha256':sha(p),'environment_sha256':sha(env)})
write('compiler-linker-commands.json',actual)
builds=[];depinfo=[]
for root in [N/'target',N/'reversion/target']:
 for mode in ['debug','release']:
  for directory in sorted((root/mode/'build').iterdir()):
   files=[]
   for p in sorted(directory.rglob('*')):
    if p.is_file():
     entry={'path':str(p.relative_to(N)),'sha256':sha(p),'bytes':p.stat().st_size}
     if p.name in ['output','stderr','root-output'] or p.suffix=='.d':entry['text']=p.read_text(errors='replace')
     files.append(entry)
   builds.append({'directory':str(directory.relative_to(N)),'files':files})
 for p in sorted(root.rglob('*.d')):depinfo.append({'path':str(p.relative_to(N)),'sha256':sha(p),'text':p.read_text()})
write('build-diagnostics.json',{'builds':builds,'depinfo':depinfo,'limit':'Actual argv/environment, Cargo build-script output and dep-info only. No exhaustive read trace, tracer, authority closure or qualification.'})
before=json.loads((P/'preserved-before.private.json').read_text());after={root:inv(pathlib.Path(root)) for root in before};write('preserved-after.private.json',after);assert before==after
copied=json.loads((P/'copied-before.json').read_text());assert inv(N/'cache')==copied['cache']
starting=json.loads((P/'starting-source.json').read_text())
for name,h in starting['historical_vector_hashes'].items():assert sha(N/'vectors'/name)==h
frozen=json.loads((P/'python-freeze.json').read_text())
for name,d in frozen['datasets'].items():assert sha(N/'vectors'/name)==d['sha256']
oldrules=json.loads((N/'vectors/historical-refusals.json').read_text());rules=json.loads((N/'vectors/refusals.json').read_text());assert all(rules[k]==v for k,v in oldrules.items());assert sha(N/'vectors/refusals.json')==json.loads((P/'refusal-freeze.json').read_text())['combined_sha256']
source=N/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs';restored=N/'reversion/workspace/native/crates/uarch-engine/src/bin/c2-probe.rs';assert source.read_bytes()==restored.read_bytes()
for root in [N/'workspace',N/'reversion/workspace']:
 assert len([p for p in root.rglob('*') if p.is_file()])==4 and len(list(root.rglob('*.rs')))==1
 assert sha(root/'native/Cargo.lock')=='cbe9a580e0c6209abdb34be23965c2fe2f75b5970819d2021c943e2e02d939be'
 assert sha(root/'native/crates/uarch-engine/Cargo.toml')=='60299ba9498e506010a5c908ef8017beb2279d1aedab409a7fc21601d3b35ee0'
assert sha(N/'controls/compare.py')==starting['comparator_sha256']
units={};binary={};baseline_mismatches={}
for mode in ['debug','release']:
 unit=(P/f'build-test-{mode}-package.stdout').read_text();names=[l.split(' ... ')[0] for l in unit.splitlines() if l.startswith('test ') and ' ... ' in l];assert len(names)==17 and '17 passed; 0 failed' in unit;units[mode]=names;binary[mode]=sha(N/'target'/mode/'c2-probe')
 for name in ['vectors','supplement','B-extension','A-extension','B-independent','focused']:
  assert (P/f'corrected-debug-{name}.stdout').read_bytes()==(P/f'corrected-release-{name}.stdout').read_bytes()
  if name not in ['B-independent','focused']:
   old=pathlib.Path('/tmp/u4-k2-c2r.s0udc3ig/receipts')/f'corrected-{mode}-{name}.stdout'
   assert old.read_bytes()==(P/f'baseline-{mode}-{name}.stdout').read_bytes()==(P/f'corrected-{mode}-{name}.stdout').read_bytes()
  a=list(map(json.loads,(P/f'baseline-{mode}-{name}.stdout').read_bytes().split(b'\n')[:-1]));b=list(map(json.loads,(P/f'corrected-{mode}-{name}.stdout').read_bytes().split(b'\n')[:-1]));assert all(x==y for x,y in zip(a,b,strict=True) if x['status']==y['status']=='ok')
 baseline_mismatches[mode]={name:r['mismatch_count'] for name,r in json.loads((P/f'baseline-{mode}-comparison.json').read_text()).items()}
publication=json.loads((R/'docs/reviews/U4-A-K2-C1-publication-v1.json').read_text());assert all(sha(R/p['path'])==p['sha256'] for p in publication['human_semantic_postimages'])
history={}
for folder,commit in [('U4-A-K2-C1-resolution-v1','923face'),('U4-A-K2-C1-precise-v1','923face'),('U4-A-K2-C2-probes-v1','3faa3e9'),('U4-A-K2-C2-compatibility-v1','923face'),('U4-B-K2-C2-compatibility-review-v1','81bab621')]:
 path='docs/reviews/'+folder;tree=subprocess.check_output(['git','rev-parse',commit+':'+path],cwd=R).decode().strip();assert subprocess.check_output(['git','rev-parse','HEAD:'+path],cwd=R).decode().strip()==tree;subprocess.run(['git','diff','--exit-code',commit,'--',path],cwd=R,check=True);history[path]={'commit':commit,'tree':tree}
write('preservation.json',{'private_old_roots':list(before),'private_old_files':sum(map(len,before.values())),'bytes_sizes_mtimes_unchanged':True,'before_sha256':sha(P/'preserved-before.private.json'),'after_sha256':sha(P/'preserved-after.private.json'),'copied_cache_unchanged':len(copied['cache']),'source_inventory':inv(N/'workspace'),'restored_source_sha256':sha(restored),'historical_packages':history,'human_postimages':publication['human_semantic_postimages'],'live_lock_sha256':sha(R/'native/Cargo.lock'),'historical_rules_unchanged':True,'nonblank_positive_outputs_unchanged':True})
write('summary.json',{'status':'Bounded Sourced nonblank correction passes; coordinator/B reconciliation pending','datasets':frozen['datasets'],'cases_per_mode':sum(x['count'] for x in frozen['datasets'].values()),'refusals_per_mode':len(rules),'blank_character_count':29,'Python_unicode':frozen['unicode_version'],'source_sha256':sha(source),'binary_sha256':binary,'unit_names':units,'baseline_mismatches':baseline_mismatches,'corrected_mismatches':0,'reverted_mismatches_per_mode':35,'restored_mismatches':0,'restored_binaries_equal_corrected':True,'compiler_link_records':len(actual),'build_directories':len(builds),'depinfo_files':len(depinfo),'comparator_sha256':sha(N/'controls/compare.py'),'legacy_numeric_adapter_changed':False,'other_carriers_changed':False,'exhaustive_reads':False,'tracer_used':False,'SIMD_work':False,'public_K2_live_installation_C3_authority_qualification':False,'U0024':'deferred'})
for p in pathlib.Path('/tmp').glob('u4-c2b-*.py'):shutil.copyfile(p,N/'controls'/p.name)
shutil.copyfile('/tmp/u4-c2b-units.rs',N/'controls/units-before-correction.rs');shutil.copyfile('/tmp/u4-c2b-python.log',P/'python-derivation.log')
for f in ['u4-c2-setup.py','u4-c2r-setup.py','u4-c2r-reverts.py']:shutil.copyfile('/tmp/'+f,N/'controls'/('inherited-'+f))
write('private-inventory.json',{'root':str(N),'receipts':inv(P),'controls':inv(N/'controls'),'targets':inv(N/'target'),'reversion':inv(N/'reversion')})
print(json.dumps(json.loads((P/'summary.json').read_text()),indent=2))
