from pathlib import Path
import json,hashlib,time
N=Path(Path('/tmp/u4-c2b-location').read_text());S=N/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs';before=S.read_text()
assert hashlib.sha256(before.encode()).hexdigest()=='90d7b36df0aac589ff01f360fe294641586ac1406651b697bb4e97068dc84695'
helper=r'''// Pinned CPython 3.12 / Unicode 15.0 str.strip() emptiness set, independently
// enumerated in python-freeze.json. This predicate never changes stored text and
// is restricted to Sourced unit/rationale/non-stub source; numeric trim is separate.
fn sourced_nonblank(s: &str) -> bool {
    s.chars().any(|c| !matches!(c,
        '\u{0009}'..='\u{000d}' | '\u{001c}'..='\u{0020}' |
        '\u{0085}' | '\u{00a0}' | '\u{1680}' | '\u{2000}'..='\u{200a}' |
        '\u{2028}' | '\u{2029}' | '\u{202f}' | '\u{205f}' | '\u{3000}'
    ))
}

'''
a=before.index('        "sourced" => {');b=before.index('        _ => v,',a);block=before[a:b]
assert block.count('!t.unit.trim().is_empty()')==1 and block.count('|s| !s.trim().is_empty()')==2
block=block.replace('!t.unit.trim().is_empty()','sourced_nonblank(&t.unit)').replace('|s| !s.trim().is_empty()','|s| sourced_nonblank(s)')
after=before[:a]+block+before[b:];after=after.replace('fn process(row: &Value)',helper+'fn process(row: &Value)',1)+Path('/tmp/u4-c2b-units.rs').read_text();S.write_text(after)
(N/'receipts/implementation.json').write_text(json.dumps({'time_ns':time.time_ns(),'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'unformatted_after_sha256':hashlib.sha256(after.encode()).hexdigest(),'changes':'Sourced-only nonblank predicate, three call sites, five bounded unit regressions. Numeric adapter and other carriers unchanged.'},indent=2)+'\n')
