# ruff: noqa: E402
import sys,pathlib,json,hashlib,time,ast,struct,unicodedata
N=pathlib.Path(pathlib.Path('/tmp/u4-c2b-location').read_text());R=pathlib.Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
sys.path[:0]=[str(N/'reference/contract'),str(R/'.venv/lib/python3.12/site-packages')]
import pydantic
from pydantic import TypeAdapter,Field
from typing import Annotated
from uarch_contract import hashing as h,mapped as m
from uarch_contract.common import JsonFloat
from uarch_contract.sourced import SourcedValue
U128=TypeAdapter(Annotated[int,Field(strict=True,ge=0,lt=2**128)])
def sha(b):return hashlib.sha256(b).hexdigest()
t=ast.parse((R/'docs/reviews/U4-B-K2-C2-reconciliation-v1/derive.py').read_text());exec(compile(ast.Module(body=[x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='expected'],type_ignores=[]),'reviewed-python-reference-adapter','exec'))
B=list(map(json.loads,(N/'vectors/B-independent.jsonl').read_bytes().split(b'\n')[:-1]))
for v in B:assert expected(v)==v['expected'],v['id']
blank=[i for i in range(0x110000) if not chr(i).strip()]
assert blank==[9,10,11,12,13,28,29,30,31,32,133,160,5760,*range(8192,8203),8232,8233,8239,8287,12288]
set_bytes=''.join(f'{i:08x}\n' for i in blank).encode()
rows=[]
def add(obj,label,op='sourced'):
 raw=json.dumps(obj,ensure_ascii=True,separators=(',',':')).encode();v={'id':f'A-blank:{len(rows):04d}:{label}','family':'A-nonblank-focused','op':op,'hex':raw.hex()};v['expected']=expected(v);rows.append(v)
def carrier(field,text):
 obj={'value':'1','unit':'Hz'}
 if field=='rationale':obj.update(kind='stipulation',rationale=text)
 elif field=='source':obj.update(provenance='measured',source=text)
 else:obj.update(provenance='stub',unit=text)
 return obj
for field in ['unit','rationale','source']:
 for i in blank:
  for suffix,text in [('single',chr(i)),('mixed-blank',chr(i)+' \t'+chr(i)),('nonblank',chr(i)+'X'+chr(i))]:add(carrier(field,text),f'{field}-U{i:04X}-{suffix}')
 neighbors=sorted({j for i in blank for j in [i-1,i+1] if j>=0 and j not in blank}|{0,0x1b,0x7f,0x180e,0x200b,0x2060,0xfeff})
 for i in neighbors:
  for suffix,text in [('neighbor',chr(i)),('mixed-neighbor','\x1c '+chr(i)+'\u3000\x1f')]:add(carrier(field,text),f'{field}-U{i:04X}-{suffix}')
 for label,text in [('empty',''),('null',None),('all-blanks',''.join(map(chr,blank))),('ascii','text'),('mixed-control','\x1cX\x1f')]:add(carrier(field,text),field+'-'+label)
 obj=carrier(field,'placeholder');del obj[field];add(obj,field+'-absent')
for provenance in ['measured','spec_derived','estimated','stub']:
 for text in [None,'','\x1c','\x1f','\x1cX\x1f']:
  obj={'value':False,'unit':'Hz','provenance':provenance,'source':text};add(obj,'claim-source-'+provenance)
 obj={'value':'1_.0','unit':'Hz','provenance':provenance};add(obj,'claim-source-absent-'+provenance)
for obj in [
 {'value':'1','unit':'Hz'},
 {'value':'1','unit':'Hz','kind':'claim','provenance':'stub','rationale':''},
 {'value':'1','unit':'Hz','kind':'claim','provenance':'measured','source':'s','rationale':'r'},
 *[{'value':'1','unit':'Hz','kind':'stipulation','rationale':'r',field:value} for field,value in [('source',''),('source','\x1c'),('date',''),('provenance','stub')]],
 {'value':'1','unit':'Hz','kind':'stipulation','rationale':'\x1cX','source':None,'date':None,'provenance':None},
 {'value':'1','unit':'Hz','kind':'other'},
]:add(obj,'existing-rules')
for tok in [True,False,'1_.0','1e_2','\u0085.5\u0085','\u001c.5\u001c','\u001d.5\u001d','\u001e.5\u001e','\u001f.5\u001f','\u200b1\u200b','1__0','NaN',None]:
 add({'value':tok,'unit':'\x1cHz\x1f','kind':'stipulation','rationale':'\x1cX\x1f'},'numeric-isolation')
# Separate Python-only carrier audit, no change to NumericLeaf.path or global trim.
other=[]
for cp in [0x1c,0x1d,0x1e,0x1f,0x20,0x85,0x200b]:
 obj={'path':chr(cp),'value':1};v={'op':'leaf','hex':json.dumps(obj).encode().hex()};other.append({'codepoint':f'U+{cp:04X}','Python_strip_empty':not chr(cp).strip(),'NumericLeaf_expected':expected(v)})
(N/'vectors/focused.jsonl').write_text(''.join(json.dumps(v,separators=(',',':'))+'\n' for v in rows))
origin={name:{'path':mod.__file__,'sha256':sha(pathlib.Path(mod.__file__).read_bytes())} for name,mod in sys.modules.items() if (name.startswith('uarch_contract') or name in ['pydantic','pydantic_core','unicodedata']) and getattr(mod,'__file__',None)}
old=json.loads((R/'docs/reviews/U4-A-K2-C2-compatibility-v1/extension-freeze.json').read_text())
for name,v in origin.items():
 if name.startswith('uarch_contract'):
  assert str(N/'reference/contract') in v['path'];assert old['origins'][name]['sha256']==v['sha256']
assert sha(pathlib.Path(sys.executable).read_bytes())==old['executable_sha256'];assert pydantic.__version__==old['pydantic']
report={'time_ns':time.time_ns(),'reference':'ce732f5bedccdde629edcf278fa76ea772d0ea82','python':sys.version,'executable':sys.executable,'executable_sha256':sha(pathlib.Path(sys.executable).read_bytes()),'pydantic':pydantic.__version__,'unicode_version':unicodedata.unidata_version,'origins':origin,'B66_rederived_exact':True,'blank_set':{'tested_codepoints':0x110000,'codepoints':blank,'count':len(blank),'encoding':'each codepoint as lowercase eight hexadecimal ASCII digits plus LF','sha256':sha(set_bytes),'definition':'not chr(codepoint).strip() in the pinned CPython; no surrogate matches'},'other_carrier_python_only':other,'datasets':{p.name:{'sha256':sha(p.read_bytes()),'count':len(p.read_bytes().split(b'\n'))-1} for p in sorted((N/'vectors').glob('*.jsonl'))},'focused_counts':{'total':len(rows),'ok':sum(v['expected']['status']=='ok' for v in rows),'refuse':sum(v['expected']['status']=='refuse' for v in rows)}}
(N/'receipts/python-freeze.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['unicode_version','blank_set','other_carrier_python_only','focused_counts']},indent=2))
