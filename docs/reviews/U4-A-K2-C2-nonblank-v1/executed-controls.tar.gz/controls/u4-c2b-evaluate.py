import importlib.util,json,sys,pathlib

def load(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
r=load('runner','/tmp/u4-c2b-run.py');c=load('comparator',r.N/'controls/compare.py')
phase,mode=sys.argv[1:];datasets=['vectors','supplement','B-extension','A-extension','B-independent','focused'] if phase!='restored' else ['B-independent','focused']
binary='/target/baseline/'+mode+'/c2-probe' if phase=='baseline' else '/target/'+mode+'/c2-probe';rules=json.loads((r.N/'vectors/refusals.json').read_text());report={}
for name in datasets:
 raw=(r.N/'vectors'/f'{name}.jsonl').read_bytes();p=r.run(phase+'-'+mode+'-'+name,[binary],stdin=raw);assert p.returncode==0
 result=c.compare(c.records(raw),c.records(p.stdout),rules);report[name]=result
 if phase!='baseline':assert result['mismatch_count']==0,result['mismatches']
 elif name in ['vectors','supplement','B-extension','A-extension']:assert result['mismatch_count']==0
 else:
  assert result['mismatch_count']>0
  assert all(m['expected']['status']=='refuse' and m['actual']['status']=='ok' for m in result['mismatches'])
 print(phase,mode,name,result['count'],result['mismatch_count'],flush=True)
(r.P/f'{phase}-{mode}-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
