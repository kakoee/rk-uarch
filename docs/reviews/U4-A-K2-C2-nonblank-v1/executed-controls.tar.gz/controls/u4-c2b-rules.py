import pathlib,json,re,hashlib,time
N=pathlib.Path(pathlib.Path('/tmp/u4-c2b-location').read_text())
rules=json.loads((N/'vectors/historical-refusals.json').read_text());new={}
for name in ['B-independent','focused']:
 for v in map(json.loads,(N/'vectors'/f'{name}.jsonl').read_bytes().split(b'\n')[:-1]):
  if v['expected']['status']!='refuse':continue
  i=v['id'];layer='carrier';reason='SourcedValue rules';suffix=False
  if name=='B-independent':
   if 'expected_native_refusal' in v:layer,reason=v['expected_native_refusal'];suffix=reason=='DuplicateJsonKey'
   elif i.startswith('B2:zero:'):
    if i.endswith(('leading-zero','leading-digit')):layer,reason='strict-json','invalid number';suffix=True
    elif i.endswith(('adjacent','suffix')):layer,reason='strict-json','trailing characters';suffix=True
    elif i.endswith('unfinished'):layer,reason='strict-json','EOF while parsing a value';suffix=True
    else:reason='IntegerToken'
   elif i.startswith('B2:legacy:string-'):reason='LegacyFloatFinite' if i.endswith(('-14','-15')) else 'LegacyFloatSyntax';suffix=True
   elif i.startswith('B2:isolation:'):reason='JsonFloatType'
   elif i=='B2:leaf:isolation-decimal':reason='IntegerToken'
  else:
   obj=json.loads(bytes.fromhex(v['hex']))
   if i.endswith('numeric-isolation'):
    reason='LegacyFloatType' if obj['value'] is None else 'LegacyFloatFinite' if obj['value']=='NaN' else 'LegacyFloatSyntax';suffix=True
   elif 'unit' not in obj:reason='missing field `unit`';suffix=True
   elif obj['unit'] is None:reason='invalid type: null, expected a string';suffix=True
  pattern=re.escape(reason)+(r'(?: at line \d+ column \d+)?' if suffix else '')
  new[i]={'layer':layer,'reason_class':reason,'error_pattern':pattern,'condition':{'op':v['op'],'input_sha256':hashlib.sha256(bytes.fromhex(v['hex'])).hexdigest(),'Python_layer':v['expected']['layer']},'mapping':'Existing unchanged parser/type/numeric/rule condition; Sourced nonblank fields now use the pinned strip-empty character set. No arbitrary error accepted.'}
assert not set(rules)&set(new);rules.update(new)
(N/'vectors/refusals.json').write_text(json.dumps(rules,indent=2)+'\n')
(N/'vectors/new-refusals.json').write_text(json.dumps(new,indent=2)+'\n')
(N/'receipts/refusal-freeze.json').write_text(json.dumps({'time_ns':time.time_ns(),'combined_sha256':hashlib.sha256((N/'vectors/refusals.json').read_bytes()).hexdigest(),'new_sha256':hashlib.sha256((N/'vectors/new-refusals.json').read_bytes()).hexdigest(),'historical_rules_unchanged':160,'new_rules':len(new),'before_correction_and_native_execution':True},indent=2)+'\n')
print('Frozen rules',len(rules),len(new))
