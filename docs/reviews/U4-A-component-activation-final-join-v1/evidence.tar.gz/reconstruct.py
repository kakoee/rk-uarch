import difflib,hashlib,json,shutil,subprocess
from pathlib import Path
repo=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
work=Path('/tmp/u4-a-activation-final-join-pPA6FE');source=work/'source'
A='docs/reviews/U4-A-component-activation-readiness-v1'
B='docs/reviews/U4-B-component-activation-final-v1'
package=repo/'docs/reviews/U4-A-component-activation-final-join-v1'
prop=package/'proposals';prop.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Verify B's immutable publication before applying its proposals anywhere.
manifest=json.loads((source/B/'manifest.json').read_bytes())
for name,pin in manifest['files'].items():
 path=source/B/name
 assert h(path)==pin['sha256'] and path.stat().st_size==pin['bytes'],name
rec=json.loads((source/B/'reconstruction.json').read_bytes())
transition=json.loads((source/B/'source-transition.json').read_bytes())
for name,pin in transition['source_files'].items():assert h(source/name)==pin,name
for name,pin in json.loads((source/B/'source-consumer-bindings.json').read_bytes())['files'].items():assert h(source/name)==pin,name
# Reconstruct exactly the original five-postimage A overlay first.
overlay=work/'overlay';overlay.mkdir()
for name in transition['source_files']:
 path=overlay/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/name,path)
# Fixtures need only existing test sources and existing documentation/data inputs.
shutil.copytree(source/'tests',overlay/'tests')
shutil.copytree(source/'docs',overlay/'docs',dirs_exist_ok=True)
shutil.copyfile(source/'pyproject.toml',overlay/'pyproject.toml')
subprocess.run(['git','apply',str(source/A/'proposals/activation-overlay-unapplied.patch')],cwd=overlay,check=True)
for name,pin in transition['A_postimages'].items():assert h(overlay/name)==pin,name
for step in rec['steps']:
 for relative in step.get('apply_B_patches_in_order',[]):
  subprocess.run(['git','apply',str(source/B/relative)],cwd=overlay,check=True)
for name,pin in rec['postimages'].items():assert h(overlay/name)==pin,name
for name,pin in transition['activation_prospective_source_files'].items():assert h(overlay/name)==pin,name
pins=json.loads((overlay/B/'activation-consumer-bindings.json').read_bytes())['files']
assert len(pins)==80
for name,pin in pins.items():assert h(overlay/name)==pin,name
assert h(overlay/B/'activation-consumer-bindings.json')==rec['steps'][-1]['sha256']
# Inventory sets are independently enumerated using the actual preparation rule.
def inventory(root):
 paths=set()
 for parent in ('native','src/rkuarch','contract/uarch_contract','validation'):
  paths.update(p for p in (root/parent).rglob('*') if p.is_file() and p.suffix in ('.rs','.toml','.lock','.py','.json') and 'generated' not in p.parts)
 paths.update(root/p for p in ('pyproject.toml','uv.lock'))
 paths.update(root/'docs/reviews/U4-A-K2-construction-v1/inputs'/p for p in ('rustc-wrapper.sh','linker.sh'))
 paths.update(root/'docs/reviews/U4-B-K2-parallel-first-use-v1'/p for p in ('parallel_core.py','resource_limits.py'))
 return {str(p.relative_to(root)):h(p) for p in sorted(paths)}
assert inventory(source)==transition['source_files']
assert inventory(overlay)==transition['activation_prospective_source_files']
# Additive proposal records preserve every original package byte.
corrected=overlay/'src/rkuarch/engines/native/component_negative.py'
(prop/'component_negative-v7.py.txt').write_bytes(corrected.read_bytes())
old=(source/A/'proposals/component_negative-v6.py.txt').read_text();new=corrected.read_text()
(prop/'D3-v6-to-v7.patch').write_bytes((source/B/'proposals/D3-finalization-unapplied.patch').read_bytes())
(prop/'D3-full-v7.patch').write_text(''.join(difflib.unified_diff([],new.splitlines(True),fromfile='/dev/null',tofile='b/src/rkuarch/engines/native/component_negative.py')))
combined=(source/A/'proposals/activation-overlay-unapplied.patch').read_bytes()+ (source/B/'proposals/D3-finalization-unapplied.patch').read_bytes()+ (source/B/'proposals/preparation-binding-unapplied.patch').read_bytes()
(prop/'joined-activation-overlay-unapplied.patch').write_bytes(combined)
# Complete standalone route on actual B source; no placeholder B files.
route=work/'combined-route';route.mkdir()
for name in set(transition['source_files'])|{'docs/decisions/U0011-the-native-engine-core.md'}:
 p=route/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/name,p)
subprocess.run(['git','apply',str(prop/'joined-activation-overlay-unapplied.patch')],cwd=route,check=True)
for name,pin in transition['activation_prospective_source_files'].items():assert h(route/name)==pin,name
# Both full D3 and exact additive routes must reconstruct the same final bytes.
full=work/'D3-full';full.mkdir()
subprocess.run(['git','apply',str(prop/'D3-full-v7.patch')],cwd=full,check=True)
assert h(full/'src/rkuarch/engines/native/component_negative.py')==rec['postimages']['src/rkuarch/engines/native/component_negative.py']
report={'format':'A-final-B-reconstruction-verification/1','B_commit':'dec263861d8f00f1470d8efff943a5e76aad0145','B_manifest_sha256':h(source/B/'manifest.json'),'B_manifest_leaves':len(manifest['files']),'current_source_count':len(inventory(source)),'current_consumer_count':79,'activation_source_count':len(inventory(overlay)),'activation_consumer_count':len(pins),'postimages':{name:h(overlay/name) for name in transition['A_postimages']},'actual_B_files':rec['steps'][1]['copy_actual_B_files'],'activation_binding_sha256':h(overlay/B/'activation-consumer-bindings.json'),'reconstruction_sha256':h(source/B/'reconstruction.json'),'combined_overlay_sha256':h(prop/'joined-activation-overlay-unapplied.patch'),'route_agreement':True,'installed':False,'new_build_or_engine':None}
(package/'reconstruction-verified.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
