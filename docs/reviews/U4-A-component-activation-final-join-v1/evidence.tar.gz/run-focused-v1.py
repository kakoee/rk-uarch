import hashlib,json,os,sys
from pathlib import Path
work=Path('/tmp/u4-a-activation-final-join-pPA6FE');root=work/'source'
repo=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
mode=sys.argv[1]
sys.path[:0]=[str(root),str(root/'src'),str(root/'contract'),str(repo/'.venv/lib/python3.12/site-packages')]
os.chdir(root)
import pytest
if mode=='baseline':
 os.environ['U4_D3_PROPOSAL']=str(root/'docs/reviews/U4-A-component-activation-readiness-v1/proposals/component_negative-v6.py.txt')
 nodes=['tests/unit/test_component_d3_finalization.py']
else:
 os.environ['U4_D3_PROPOSAL']=str(work/'overlay/src/rkuarch/engines/native/component_negative.py')
 nodes=['tests/unit/test_component_d3_finalization.py',
 'validation/component/test_ordinary_eof_acceptance.py::test_actual_adapter_to_independent_saved_output_consumer',
 'validation/component/test_ordinary_eof_acceptance.py::test_resealed_receipt_discriminators[failed-retained failure]',
 'validation/component/test_ordinary_eof_acceptance.py::test_d3_actual_schema_refusal_and_same_code_discrimination']
code=pytest.main(['-q',*nodes,'--basetemp='+str(work/(mode+'-isolated'))])
origins={}
for name,module in sorted(sys.modules.copy().items()):
 if name.split('.')[0] in ('native','rkuarch','uarch_contract','validation'):
  raw=getattr(module,'__file__',None)
  if raw:
   p=Path(raw).resolve();assert p.is_relative_to(root),(name,p)
   origins[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(work/(mode+'-origins.json')).write_text(json.dumps({'status':int(code),'root':str(root),'nodes':nodes,'proposal':os.environ['U4_D3_PROPOSAL'],'proposal_sha256':hashlib.sha256(Path(os.environ['U4_D3_PROPOSAL']).read_bytes()).hexdigest(),'modules':origins},indent=2)+'\n')
raise SystemExit(code)
