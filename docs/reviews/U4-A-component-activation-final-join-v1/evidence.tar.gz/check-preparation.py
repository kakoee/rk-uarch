import hashlib,json,sys
from pathlib import Path
work=Path('/tmp/u4-a-activation-final-join-pPA6FE');root=work/'overlay';repo=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
sys.path[:0]=[str(root),str(root/'src'),str(root/'contract'),str(repo/'.venv/lib/python3.12/site-packages')]
from native.tools import component_runtime_candidate as recipe
from validation.component.runtime_checks import verify_sources
payload=Path('/tmp/u4-a-runtime-resource-4d447ba/source')
inherited=json.loads((payload/'private-component/prospective-payload.json').read_bytes())
observation=inherited['consumers']['observation_contract']
assert 'sha256:'+hashlib.sha256((payload/observation['path']).read_bytes()).hexdigest()==observation['byte_hash']
value=recipe.imports(root,observation_root=payload)
assert value['independent_binding']=={'path':'docs/reviews/U4-B-component-activation-final-v1/activation-consumer-bindings.json','byte_hash':'sha256:c78e957c5f1de62afdb70f408135771eb72ad1d7b7c7495dd879c2a0ea31b9d0'}
pins=json.loads((root/value['independent_binding']['path']).read_bytes())['files']
verify_sources(root,pins)
assert len(pins)==80
consumer={f['path']:f['byte_hash'].removeprefix('sha256:') for f in value['files']}
assert all(consumer[p]==pin for p,pin in pins.items())
assert 'validation/component/test_ordinary_eof_acceptance.py' in consumer
assert 'validation/component/test_ordinary_eof_acceptance.py' not in pins
assert consumer['native/tools/component_runtime_candidate.py']=='b0addf0b150dead2842d2f53b9aaefacec9481f86b12bdbdefb895f711e1a6b4'
# Any old record remains historical; the generator selected the actual new record explicitly.
origins={}
for name,m in sorted(sys.modules.copy().items()):
 if name.split('.')[0] in ('native','rkuarch','uarch_contract','validation'):
  origin=getattr(m,'__file__',None)
  if origin:
   p=Path(origin).resolve();assert p.is_relative_to(root),(name,p)
   origins[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
record={'format':'A-executed-preparation-transition/1','source':'private exact B overlay','independent_binding':value['independent_binding'],'consumer_pins':len(pins),'consumer_inventory_files':len(consumer),'external_files':len(value['external_files']),'python_executable':value['python_executable'],'test_file_is_inventory_not_runtime_pin':True,'new_BuildInputs_or_engine':None,'origin_checks':origins}
(work/'preparation-checks.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='origin_checks'},indent=2))
