import gzip,hashlib,io,json,tarfile
from pathlib import Path
work=Path('/tmp/u4-a-activation-final-join-pPA6FE');repo=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a');package=repo/'docs/reviews/U4-A-component-activation-final-join-v1'
files={p for p in work.iterdir() if p.is_file() and p.suffix in ('.py','.json','.log') and p.name!='packaging.log'}
for directory in ('baseline','baseline-isolated','corrected-isolated','expired-only-isolated'):
 for p in (work/directory).rglob('attempt.json'):
  files.add(p)
  if p.parent.name in ('attempt','negative'):
   files.update(f for f in p.parent.rglob('*') if f.is_file() and not f.is_symlink())
# Capture explicit baseline/corrected bytes, not any whole source/third-party tree.
files.add(work/'source/docs/reviews/U4-A-component-activation-readiness-v1/proposals/component_negative-v6.py.txt')
files.add(work/'overlay/src/rkuarch/engines/native/component_negative.py')
index={str(p.relative_to(work)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(files)}
(package/'evidence-files.json').write_text(json.dumps(index,indent=2)+'\n')
with (package/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p in sorted(files):
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(work)));info.size=len(data);info.mode=0o444;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(package/'evidence.tar.gz') as tar:
 for member in tar.getmembers():
  data=tar.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==index[member.name]['sha256'] and len(data)==index[member.name]['bytes']
print(json.dumps({'members':len(files),'sha256':hashlib.sha256((package/'evidence.tar.gz').read_bytes()).hexdigest(),'bytes':(package/'evidence.tar.gz').stat().st_size}))
