"""Run a module as __main__ (python -m equivalent) under runner.py: runmod.py MODULE ARGS..."""
import runpy, sys
mod = sys.argv[1]
sys.argv = [mod, *sys.argv[2:]]
runpy.run_module(mod, run_name="__main__", alter_sys=True)
