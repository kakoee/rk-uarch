"""Strip the /3 witness from fresh outputs, reseal, compare with B's v1 draft outputs."""
import hashlib, json, sys
from uarch_contract.hashing import canonical_json, content_hash
for mine, old, recorded in zip(sys.argv[1::3], sys.argv[2::3], sys.argv[3::3]):
    raw_old = open(old, "rb").read()
    assert hashlib.sha256(raw_old).hexdigest() == recorded, "B v1 output hash binding"
    w = json.loads(open(mine).read())
    r = w["result"]
    del r["observations"]["reservation_opportunities"]
    r["result_hash"] = content_hash(r, exclude=("result_hash",))
    o = json.loads(raw_old)
    print(mine.split("/runs/")[1], "stripped == B v1 draft (full wrapper):", canonical_json(w).encode() == raw_old or w == o)
