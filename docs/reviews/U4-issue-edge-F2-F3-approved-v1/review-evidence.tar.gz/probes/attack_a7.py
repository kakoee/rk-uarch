"""A7: post-reservation credit cause. From valid cc0-v3: dispatch r01's inline ack before r02's
issue alignment (event ordinals/seq renumbered positionally), keep r02's grant at the earlier
same-instant cursor (before that release), move r03's opportunity to the ack transition, and add
r01's ack as r02's credit cause so the timestamp law is met. Run under runner.py.

Usage: attack_a7.py VALID_RESULT OUT
"""

import json
import sys

from uarch_contract.hashing import canonical_json, content_hash

r = json.load(open(sys.argv[1]))["result"]
o = r["observations"]
ev = o["events"]["records"]
acts = {a["activity_id"]: a for a in o["activities"]["records"]}
r02a = next(a for a in acts.values() if a["request_id"] == "r02.00"
            and a["subphase"] == "dma_issue" and a["kind"] == "alignment")
ack = next(a for a in acts.values() if a["request_id"] == "r01.00"
           and a["subphase"] == "ack" and a["kind"] == "service")
r00_end = next(a for a in acts.values() if a["request_id"] == "r00.00"
               and a["subphase"] == "read_port" and a["kind"] == "service")
a0, a1 = r02a["dispatch_ordinal"], r02a["completion_ordinal"]
k0, k1 = ack["dispatch_ordinal"], ack["completion_ordinal"]
assert (a0, a1, k0, k1) == (52, 53, 54, 55), (a0, a1, k0, k1)
perm = {a0: k0, a1: k1, k0: a0, k1: a1}  # old ordinal -> new ordinal
seq = [e["event_seq"] for e in ev]
new = [None] * len(ev)
for e in ev:
    n = perm.get(e["observation_ordinal"], e["observation_ordinal"])
    new[n] = dict(e, observation_ordinal=n)
for i, e in enumerate(new):
    e["event_seq"] = seq[i]  # inline sequence stays increasing in dispatch order
o["events"]["records"] = new
for a in acts.values():
    a["dispatch_ordinal"] = perm.get(a["dispatch_ordinal"], a["dispatch_ordinal"])
    a["completion_ordinal"] = perm.get(a["completion_ordinal"], a["completion_ordinal"])
# r02 claims both same-instant releases, including r01's ack that now completes at 53,
# after r02's own grant cursor 52.
r02a["predecessors"] = sorted(
    r02a["predecessors"] + [{"activity_id": ack["activity_id"], "relation": "credit"}],
    key=lambda p: (p["activity_id"], p["relation"]))
opps = o["reservation_opportunities"]["records"]
g02 = next(x for x in opps if x["granted_request_ids"] == ["r02.00"])
g03 = next(x for x in opps if x["granted_request_ids"] == ["r03.00"])
assert g02["event_cursor"] == 52 and g03["event_cursor"] == 56
g03["event_cursor"] = ack["completion_ordinal"] + 1  # 54: the inline ack transition
r["result_hash"] = content_hash(r, exclude=("result_hash",))
open(sys.argv[2], "w").write(canonical_json(r))
print(json.dumps(dict(r02_grant_cursor=g02["event_cursor"], r01_ack_completion=ack["completion_ordinal"],
                      r02_alignment_dispatch=r02a["dispatch_ordinal"], r03_grant_cursor=g03["event_cursor"],
                      r02_credit=[p["activity_id"] for p in r02a["predecessors"]],
                      r00_release=r00_end["completion_ordinal"])))
