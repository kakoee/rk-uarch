"""Rebind a result to another job (identity resealed): rebind.py RESULT JOB OUT"""
import json, sys
from uarch_contract.hashing import canonical_json, content_hash
r = json.load(open(sys.argv[1])); r = r.get("result", r)
j = json.load(open(sys.argv[2]))
r.update(job_hash=j["job_hash"], engine=j["engine"], admission=j["admission"])
r["result_hash"] = content_hash(r, exclude=("result_hash",))
open(sys.argv[3], "w").write(canonical_json(r))
