"""Guard-removal/restoration on a private mutant export copy (never the reconstructed export).

Usage: python -I fault.py MUT_EXPORT PRISTINE_EXPORT FAULT OUT.json CASE=JOB:RESULT ...
Applies one exact textual mutation to validation/component/issue_checks.py, runs the
consumers, restores the pristine bytes (hash-verified) and runs them again.
"""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

mut, pristine, fault, out = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4])
cases = sys.argv[5:]
REL = "validation/component/issue_checks.py"
PY = "/home/jjaff/AI-infra-simulation/rk-uarch/.venv/bin/python"
TOOLS = Path(__file__).resolve().parent
FAULTS = {
    # Remove only the cursor-level dependency-completion predicate.
    "no-dependency-cursor": (
        '                and all(job_ends[p] < cursor for p in dependencies.get(row["job_id"], []))\n',
        "",
    ),
    # Release prior grants by timestamp instead of by terminal ordinal before the cursor.
    "timestamp-release": (
        "            if request_ends[request] >= cursor:\n",
        '            if rows[request]["complete_ps"] > time:\n',
    ),
}


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def consume(tag: str) -> list:
    log = out.with_name(out.stem + f"-{tag}.json")
    proc = subprocess.run([PY, "-I", str(TOOLS / "runner.py"), str(mut), "script",
                           str(TOOLS / "consume.py"), str(mut), str(log), *cases],
                          capture_output=True, text=True, timeout=300)
    assert proc.returncode == 0, proc.stderr[-2000:]
    return [(c["case"], c["structural"][:70], c["independent"][:70])
            for c in json.loads(log.read_text())["cases"]]


target = mut / REL
original = (pristine / REL).read_bytes()
assert target.read_bytes() == original, "mutant copy must start pristine"
old, new = FAULTS[fault]
text = original.decode()
assert text.count(old) == 1, "exact single mutation site"
record = dict(fault=fault, file=REL, pristine_sha256=sha(pristine / REL), removed=old, added=new)
target.write_text(text.replace(old, new))
record["mutant_sha256"] = sha(target)
try:
    record["mutant"] = consume("mutant")
finally:
    target.write_bytes(original)
record["restored_sha256"] = sha(target)
assert record["restored_sha256"] == record["pristine_sha256"]
record["restored"] = consume("restored")
out.write_text(json.dumps(record, indent=1) + "\n")
for phase in ("mutant", "restored"):
    for row in record[phase]:
        print(f"{fault:22s} {phase:9s} {row[0]:12s} structural={row[1]:30s} independent={row[2]}")
