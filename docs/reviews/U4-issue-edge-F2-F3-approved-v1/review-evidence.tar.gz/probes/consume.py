"""Run the private export's structural validator and independent checker on outputs/attacks.

Usage (under runner.py with the export): consume.py EXPORT OUT.json CASE=JOB:RESULT ...
Attacks are generated from valid outputs by attacks.py and passed as further CASE entries.
"""

import hashlib
import importlib
import json
import sys
from pathlib import Path

from uarch_contract.mapped import MappedEngineJob, validate_result

export, out = Path(sys.argv[1]).resolve(), Path(sys.argv[2])
expected = json.loads(
    (export / "docs/reviews/U4-B-component-stage2-v1/first-use-bindings.json").read_text()
)["observation_contract"]


def outcome(fn) -> str:
    try:
        fn()
        return "pass"
    except Exception as error:  # report the refusal class and message
        return f"{type(error).__name__}: {error}"


def checker(version: str):
    name = "validation.component.observations_v3" if version == "3" else \
        "validation.component.observations_v2"
    mod = importlib.import_module(name)
    return getattr(mod, "check_v3" if version == "3" else "check_v2")


report = {"origins": {}, "cases": []}
for name in ("uarch_contract.mapped", "uarch_contract.mapped_issue",
             "validation.component.issue_checks", "validation.component.observations_v3",
             "validation.component.transition_checks_v3", "validation.component.observations_v2"):
    try:
        p = Path(importlib.import_module(name).__file__).resolve()
    except ModuleNotFoundError:  # unpatched base has no /3 modules
        report["origins"][name] = None
        continue
    assert p.is_relative_to(export), p
    report["origins"][name] = hashlib.sha256(p.read_bytes()).hexdigest()
for spec in sys.argv[3:]:
    case, paths = spec.split("=", 1)
    job_path, result_path = paths.split(":")
    j = json.loads(Path(job_path).read_text())
    r = json.loads(Path(result_path).read_text())
    r = r.get("result", r)
    version = "3" if r["observations"]["format"].endswith("/3") else "2"
    job = MappedEngineJob.model_validate(j)
    row = dict(case=case, result_sha256=hashlib.sha256(Path(result_path).read_bytes()).hexdigest(),
               structural=outcome(lambda: validate_result(r, job)),
               independent=outcome(lambda: checker(version)(j, r, expected)))
    report["cases"].append(row)
    print(f"{case:42s} structural={row['structural'][:90]!s:60s} independent={row['independent'][:90]}")
out.write_text(json.dumps(report, indent=1) + "\n")
