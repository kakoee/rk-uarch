"""Reviewer targeted output attacks from fresh valid native outputs (synthetic; no authority).

Usage (under runner.py): attacks.py RUNS INPUTS OUT_DIR
Every attack reseals result_hash (and job binding where stated) so refusals are not
incidental identity failures.
"""

import copy
import hashlib
import json
import sys
from pathlib import Path

from uarch_contract.hashing import canonical_json, content_hash

runs, inputs, out = (Path(a) for a in sys.argv[1:4])
out.mkdir(exist_ok=False)


def load(p: Path):
    v = json.loads(p.read_text())
    return v.get("result", v)


def reseal(r):
    r["result_hash"] = content_hash(r, exclude=("result_hash",))
    return r


def save(name, job_path, r, note):
    (out / f"{name}.json").write_text(canonical_json(r))
    manifest[name] = dict(job=str(job_path), note=note,
                          sha256=hashlib.sha256((out / f"{name}.json").read_bytes()).hexdigest())


manifest: dict = {}
opps = lambda r: r["observations"]["reservation_opportunities"]["records"]  # noqa: E731

# A1: same-instant pre-release grant. sr-v3: move r02 into the earlier 86000 opportunity,
# before engine0's write ack releases its only credit. Times, rows, causes unchanged.
r = load(runs / "sr-v3/debug/result.json")
o = opps(r)
early, late = [x for x in o if x["t_ps"] == 86000]
assert early["granted_request_ids"] == [] and late["granted_request_ids"] == ["r02.00"]
early["granted_request_ids"], late["granted_request_ids"] = ["r02.00"], []
save("A1-same-instant-pre-release-grant", inputs / "syn/sr-v3.json", reseal(r),
     "r02 moved from cursor %d to %d at 86000" % (late["event_cursor"], early["event_cursor"]))

# A2: ineligible-first. Paired-control output rebound to the original r00-dependent graph,
# with r00's now-tight dependency cause repaired and identity resealed.
r = load(runs / "r01-v3/debug/result.json")
j00 = json.loads((inputs / "r00.json").read_text())
r.update(job_hash=j00["job_hash"], admission=j00["admission"], engine=j00["engine"])
acts = {a["activity_id"]: a for a in r["observations"]["activities"]["records"]}
uni = max((a for a in acts.values() if a["job_id"] == "a-unicast"),
          key=lambda a: a["completion_ordinal"])
first = next(a for a in acts.values() if a["request_id"] == "r00.00"
             and a["subphase"] == "dma_issue" and a["kind"] == "alignment")
assert first["start_ps"] == uni["end_ps"] == 0 and uni["completion_ordinal"] < first["dispatch_ordinal"]
first["predecessors"] = sorted(first["predecessors"] + [
    {"activity_id": uni["activity_id"], "relation": "dependency"}],
    key=lambda p: (p["activity_id"], p["relation"]))
save("A2-ineligible-first-rebound", inputs / "r00.json", reseal(r),
     "paired output rebound to r00 graph; dependency cause repaired")

# A3: grant cursor shifted to the issue-alignment dispatch ordinal (r00 case, 60000 grant).
r = load(runs / "r00-v3/debug/result.json")
first = next(a for a in r["observations"]["activities"]["records"]
             if a["request_id"] == "r00.00" and a["subphase"] == "dma_issue" and a["kind"] == "alignment")
o = opps(r)
target = next(x for x in o if x["granted_request_ids"] == ["r00.00"])
before = target["event_cursor"]
target["event_cursor"] = first["dispatch_ordinal"]
save("A3-cursor-at-alignment-dispatch", inputs / "r00.json", reseal(r),
     f"cursor {before} -> {first['dispatch_ordinal']}")

# A4: omit the empty inline-unicast opportunity (cursor 2) and renumber ordinals.
r = load(runs / "r00-v3/debug/result.json")
o = opps(r)
o[:] = [x for x in o if not (x["event_cursor"] == 2 and x["t_ps"] == 0)]
for i, x in enumerate(o):
    x["opportunity_ordinal"] = i
save("A4-omit-inline-empty-opportunity", inputs / "r00.json", reseal(r), "cursor 2 removed")

# A5: producer allocation at issue instead of reservation (issue-gap, 333 ps).
r = load(runs / "issue-gap-v3/debug/result.json")
row = next(a for a in r["observations"]["allocations"]["records"] if a["buffer_id"] == "r00s")
assert row["allocate_ps"] == 26667
row["allocate_ps"] = 27000
save("A5-allocation-at-issue", inputs / "issue-gap.json", reseal(r), "r00s allocate 26667 -> 27000")

# A6: version cross-binding. /3 output bound to a model-1 twin job; /2 output bound to the
# model-2 job. Job/engine/result identities are resealed so only the version pair differs.
for name, job_name, run_name, version in (
    ("A6a-v3-output-model1-job", "r00.json", "r00-v3", "1"),
    ("A6b-v2-output-model2-job", "syn2/cc0-v3.json", "cc0-v1", "2"),
):
    j = json.loads((inputs / job_name).read_text())
    j = copy.deepcopy(j)
    j["engine"]["model"]["version"] = version
    j["job_hash"] = content_hash(j, exclude=("job_hash",))
    (out / f"{name}.job.json").write_text(canonical_json(j))
    r = load(runs / f"{run_name}/debug/result.json")
    r.update(job_hash=j["job_hash"], engine=j["engine"], admission=j["admission"])
    save(name, out / f"{name}.job.json", reseal(r), f"engine model version {version}")

(out / "manifest.json").write_text(json.dumps(manifest, indent=1) + "\n")
print(json.dumps({k: v["note"] for k, v in manifest.items()}, indent=1))
