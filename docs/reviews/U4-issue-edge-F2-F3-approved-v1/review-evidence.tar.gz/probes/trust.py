"""Write a synthetic unit Trust anchor for a job (no authority)."""
import json, sys
v = json.load(open(sys.argv[1]))
json.dump(dict(registry=v["registry"]["registry_hash"], profile=v["profile"]["profile_hash"],
               case=v["admission"]["case_id"], engine=v["engine"]), open(sys.argv[2], "w"))
