"""Reviewer's independent derivation for /3 issue witnesses. Stdlib only; no project imports.

Usage: python -I independent.py JOB.json RESULT.json   (RESULT may be the probe wrapper)
Derives, from the job graph, hardware and the result's events/activities only:
  * per-request phase timeline from hardware parameters (uncontended mechanism replay)
  * the opportunity inventory (initial + terminal-sequence transitions, phase-0 coalescing)
  * the complete earliest grant list per opportunity (cursor-level eligibility/capacity)
  * credit causes under the timestamp law and under the transition (cursor) law
Prints a JSON report; never trusts claimed opportunities, reservation order or causes.
"""

import json
import sys
from fractions import Fraction
from math import ceil

job = json.load(open(sys.argv[1]))
res = json.load(open(sys.argv[2]))
res = res.get("result", res)
obs = res["observations"]
g = job["mapped_point"]["task_graph"]
hw = job["workload_closure"]["hardware_spec"]


def val(x):
    return x["value"]


FREQ = {k: int(v) for k, v in job["freq_hz"].items()}


def edge(hz, t, n):
    # Integer edges ceil(k*P) (U0011 next_edge): smallest k with ceil(k*P) >= t, plus n.
    period = Fraction(10**12, hz)
    k = max(0, ceil(Fraction(t) / period) - 1)
    while ceil(k * period) < t:
        k += 1
    return ceil((k + n) * period)


tasks = {t["id"]: t for t in g["jobs"]}
deps: dict[str, list[str]] = {}
for d in g["dependencies"]:
    deps.setdefault(d["after"], []).append(d["before"])
cap = int(val(hw["cores"]["core_type"]["dma"]["max_outstanding"]))
acts = obs["activities"]["records"]
events = obs["events"]["records"]
assert [e["observation_ordinal"] for e in events] == list(range(len(events)))

# Terminal phase per sequence, from my own phase table (not the validators').
LAST = {"compute": "compute_drain", "barrier": "barrier", "noc_transfer": "unicast_noc",
        "read": "read_port", "write": "ack"}
terminal: dict[tuple[str, str | None], dict] = {}
for a in acts:
    t = tasks[a["job_id"]]
    kind = t["direction"] if t["kind"] == "dma" else t["kind"]
    if a["subphase"] == LAST[kind] and a["kind"] == "service":
        key = (a["job_id"], a["request_id"] if t["kind"] == "dma" else None)
        assert key not in terminal
        terminal[key] = a
seq_count = {tid: (len(t["fragments"]) if t["kind"] == "dma" else 1) for tid, t in tasks.items()}
for tid, n in seq_count.items():
    assert sum(1 for k in terminal if k[0] == tid) == n, tid
job_done_ord = {tid: max(a["completion_ordinal"] for k, a in terminal.items() if k[0] == tid)
                for tid in tasks}
job_end_ps = {tid: max(a["end_ps"] for k, a in terminal.items() if k[0] == tid) for tid in tasks}
job_ready_ps = {tid: max((job_end_ps[p] for p in deps.get(tid, [])), default=0) for tid in tasks}

requests = {f["request_id"]: (tid, t["dma_engine_id"]) for tid, t in tasks.items()
            if t["kind"] == "dma" for f in t["fragments"]}
req_term = {r: terminal[(tid, r)] for r, (tid, _) in requests.items()}

# Opportunity boundaries.
bounds = {(0, 0)}
for a in terminal.values():
    o = a["completion_ordinal"]
    e = events[o]
    c = o + 1
    if e["phase"] == 0:
        while c < len(events) and events[c]["phase"] == 0 and events[c]["t_ps"] == e["t_ps"]:
            c += 1
    bounds.add((c, e["t_ps"]))
opps = sorted(bounds)

granted: dict[str, tuple[int, int, int]] = {}  # request -> (opportunity index, cursor, time)
derived = []
for i, (cursor, t) in enumerate(opps):
    occ: dict[int, int] = {}
    for r in granted:
        if req_term[r]["completion_ordinal"] >= cursor:
            occ[requests[r][1]] = occ.get(requests[r][1], 0) + 1
    elig = [r for r, (tid, _) in requests.items() if r not in granted
            and all(job_done_ord[p] < cursor for p in deps.get(tid, []))]
    elig.sort(key=lambda r: (job_ready_ps[requests[r][0]], requests[r][1], r))
    wanted = []
    for r in elig:
        e = requests[r][1]
        if occ.get(e, 0) < cap:
            occ[e] = occ.get(e, 0) + 1
            wanted.append(r)
            granted[r] = (i, cursor, t)
    derived.append({"ordinal": i, "event_cursor": cursor, "t_ps": t, "granted": wanted})

claimed = [{"ordinal": o["opportunity_ordinal"], "event_cursor": o["event_cursor"],
            "t_ps": o["t_ps"], "granted": o["granted_request_ids"]}
           for o in obs["reservation_opportunities"]["records"]]
rows = {r["request_id"]: r for r in obs["dma"]["records"] if r["direction"] != "unicast"}

# Credit causes under two laws.
firsts = {}
for a in acts:
    if a["request_id"] in requests and a["subphase"] == "dma_issue" and a["kind"] == "alignment":
        firsts[a["request_id"]] = a
claimed_credit = {r: sorted(p["activity_id"] for p in firsts[r]["predecessors"]
                            if p["relation"] == "credit") for r in requests if r in firsts}
ts_law, cursor_law = {}, {}
for r, (tid, e) in requests.items():
    T = granted[r][2]
    old = [x for x, (_, ex) in requests.items() if x != r and ex == e
           and granted[x][2] < T <= req_term[x]["end_ps"]]
    strict = T > job_ready_ps[tid]
    ts_law[r] = sorted(req_term[x]["activity_id"] for x in old
                       if req_term[x]["end_ps"] == T) if strict and len(old) == cap else []
    cur = granted[r][1]
    # Transition law: releases already observed before this pass at this instant.
    cursor_law[r] = sorted(req_term[x]["activity_id"] for x in old
                           if req_term[x]["end_ps"] == T and req_term[x]["completion_ordinal"] < cur
                           ) if strict and len(old) == cap else []

# Uncontended mechanism replay of each request from its derived reservation time.
NOC = Fraction(10**12, FREQ["noc"])
timing = hw["memory"]["dram"]["timing"]
lat = sum(int(val(timing[k])) for k in ("t_cl_cycles", "t_rcd_cycles", "t_rp_cycles"))
dram = hw["memory"]["dram"]
step = (Fraction(256) / (Fraction(int(val(dram["bw_bytes_per_s"]))) / int(val(dram["channels"])))
        * 10**12 * Fraction(int(val(timing["t_refi_cycles"])),
                            int(val(timing["t_refi_cycles"])) - int(val(timing["t_rfc_cycles"]))))
router = int(val(hw["nocs"][0]["router_latency_cycles"]))
routes = {x["id"]: x for x in g["routes"]}
port_cycles = {r: ceil(Fraction(f["payload_bytes"], int(val(hw["cores"]["core_type"]["dma"]["bytes_per_cycle"]))))
               for t in tasks.values() if t["kind"] == "dma" for f in t["fragments"] for r in [f["request_id"]]}
frag = {f["request_id"]: f for t in tasks.values() if t["kind"] == "dma" for f in t["fragments"]}
replay = {}
for r, (tid, e) in requests.items():
    R = granted[r][2]
    I = edge(FREQ["core"], R, 0)
    hops = (len(routes[frag[r]["route_id"]]["core_ids"]) - 1) * router
    t, ph = I, {"reservation": R, "issue": I}
    if tasks[tid]["direction"] == "write":
        s = edge(FREQ["core"], t, 0)
        t = edge(FREQ["core"], s, port_cycles[r])
        ph["write_port"] = (s, t)
    s = edge(FREQ["noc"], t, 0) if hops else t
    t = edge(FREQ["noc"], s, hops) if hops else t
    ph["request_noc"] = (s, t)
    s = edge(FREQ["dram"], t, 0)
    t = edge(FREQ["dram"], s, lat)
    ph["dram_latency"] = (s, t)
    hi = t + step
    ph["channel_service"] = (t, ceil(hi))
    t = ceil(hi)
    s = edge(FREQ["noc"], t, 0) if hops else t
    t = edge(FREQ["noc"], s, hops) if hops else t
    ph["response_noc"] = (s, t)
    if tasks[tid]["direction"] == "write":
        s = edge(FREQ["core"], t, 0)
        ph["ack"] = (s, s)
        t = s
    else:
        s = edge(FREQ["core"], t, 0)
        t = edge(FREQ["core"], s, port_cycles[r])
        ph["read_port"] = (s, t)
    ph["complete"] = t
    replay[r] = ph
observed = {}
for r in requests:
    observed[r] = {a["subphase"]: (a["start_ps"], a["end_ps"]) for a in acts
                   if a["request_id"] == r and a["kind"] == "service"}
replay_match = {r: all(observed[r].get(k) == v for k, v in ph.items() if isinstance(v, tuple))
                and rows[r]["complete_ps"] == ph["complete"] and rows[r]["issue_ps"] == ph["issue"]
                for r, ph in replay.items()}

report = dict(
    opportunities_match=derived == claimed,
    derived=derived,
    claimed=claimed if derived != claimed else "same",
    reservation_match={r: rows[r]["reservation_ps"] == granted[r][2] for r in requests},
    credit_claimed=claimed_credit,
    credit_timestamp_law=ts_law,
    credit_transition_law=cursor_law,
    credit_claimed_equals_timestamp_law=all(claimed_credit[r] == ts_law[r] for r in requests),
    credit_claimed_equals_transition_law=all(claimed_credit[r] == cursor_law[r] for r in requests),
    uncontended_replay_match=replay_match,
    replay={r: {k: v for k, v in ph.items()} for r, ph in replay.items()},
    job_start_ps={t: r["start_ps"] for t, r in ((x["job_id"], x) for x in obs["jobs"]["records"])},
    channel_step_ps=str(step),
)
print(json.dumps(report, indent=1, default=str))
