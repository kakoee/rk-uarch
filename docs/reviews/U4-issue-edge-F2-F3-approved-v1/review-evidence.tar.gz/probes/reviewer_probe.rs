//! Independent reviewer SYNTHETIC unit harness (Stage 1 review of the unapplied issue-edge
//! amendment). Added only to an isolated private build copy under cfg(test). File Trust
//! inputs are artificial unit anchors, never public authority.
use crate::{admission::Trust, component, wire};
use serde_json::{Value, json};
use std::collections::{BTreeMap, BTreeSet};

#[test]
#[ignore = "explicit isolated reviewer job, Trust, version and output paths required"]
fn reviewer_component_probe() {
    let input = std::fs::read_to_string(std::env::var("R_JOB").unwrap()).unwrap();
    let anchor: Value =
        serde_json::from_slice(&std::fs::read(std::env::var("R_TRUST").unwrap()).unwrap())
            .unwrap();
    let trust = Trust {
        registry: anchor["registry"].as_str().unwrap().into(),
        profiles: BTreeMap::from([(
            anchor["profile"].as_str().unwrap().into(),
            BTreeSet::from([anchor["case"].as_str().unwrap().into()]),
        )]),
        engine: anchor["engine"].clone(),
    };
    let output = match std::env::var("R_VERSION").unwrap().as_str() {
        "public" => component::execute(&input, &trust),
        "2" => component::execute_with_observations(&input, &trust, component::ObservationVersion::V2),
        "3" => component::execute_with_observations(&input, &trust, component::ObservationVersion::V3),
        _ => panic!("explicit observation version required"),
    };
    let output = match output {
        Ok(result) => json!({"outcome": "success", "result": result}),
        Err(error) => json!({"outcome": "refusal", "code": error.code,
                            "pointer": error.pointer, "message": error.message}),
    };
    std::fs::write(std::env::var("R_OUTPUT").unwrap(), wire::canonical(&output).unwrap()).unwrap();
}
