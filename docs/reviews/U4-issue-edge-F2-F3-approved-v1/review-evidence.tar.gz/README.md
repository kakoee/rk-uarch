# Unapplied DMA issue-edge amendment — independent review, U-REVIEW Stage 1

Reviewer: a fresh session that authored none of A's amendment, B's reviews or checkers, or
the native candidate. This is evidence, not a verdict. It grants no human semantic approval,
installation, public first use, native qualification, G3a/U4 closure or authority. Nothing was
installed, staged, committed or pushed; no public component job ran; no host was contacted.
Both subject clones were read only through `git archive`/`git show` and are unchanged.

## Subject

| Item | Identity |
| --- | --- |
| A proposal | `7d61d6a02644519d4a7b8b1ce9287e60cd03ca13`, package `docs/reviews/U4-A-issue-edge-amendment-v2/` |
| B bounded recheck | `cd0339bc50aee17d9f40e4748beca4af8f5ab814`, `docs/reviews/U4-B-issue-edge-review-v2/` |
| Reconstruction base | `d4ef3bf00f53c693a9a8188e5edc368862e187f3` (both later commits touch only their packages) |
| contract-and-export.patch | `c0053243d3e96cd25496823ad980742c25b9721850f87f55628b640876fe1b75` |
| checker-and-identity.patch | `ef93116d948f40ab869a080c516bba4576c8803cafa46a4a161bbff5051c29a7` |
| native.patch | `32c2c0452f86cbdf6ce89cee3eb1ba1f1df1f33853ec4391384cd54574ea8ebc` |
| alternative-delta-from-v1.patch | `6541eb4ef01eecccbb887a129e2d8f035d9693233f22b8f0c3aa11a6dbc5d5fa` |
| Live main (context only) | `3b5e030`; installed /2 checker, contract and U0011 there are byte-identical to the base; the native component candidate is not on main |

## Reconstruction (executed)

[probes/reconstruct.py](probes/reconstruct.py) on two fresh `git archive d4ef3bf` exports:

| Check | Result |
| --- | --- |
| Patch and delta SHA256 vs manifest | all 4 match |
| 22 preimages (11 modified, 11 `null`/absent) | 22/22 |
| Full route, manifest order, `--check` then apply | 0/0 for all three |
| 22 postimages | **22/22** |
| Reverse `--check` (reverse order) | all 0 |
| Alternative route: v1's three patches (hash-verified) → v1's 20 postimages → delta only | 20/20, then 22/22 |
| Whole-tree comparison of the two routes | identical, 5377 files each |
| Nine historical byte controls | 9/9 unchanged |

The routes are alternatives; the delta was never applied after the full route.

## Execution environment (executed)

* **Builds.** [probes/build.py](probes/build.py) used the approved bounded monitor (SHA256
  `e81af649…d8115`, same as B), image `sha256:e9f69f41…0523`, toolchain 1.99.0,
  `--offline --locked`, the accepted cache (1719 files verified against the accepted inventory)
  and fresh empty debug/release targets. My only addition is a `cfg(test)` harness,
  [probes/reviewer_probe.rs](probes/reviewer_probe.rs), in the build copy. Unit executables
  (private, not production or authority):
  * patched debug `8a0b44ec1fe17195ef9672d7d6053770bf7484d304528fff41202f271a2d27ba`
  * patched release `1d8a281a192eded6b6e5fc56fbf828eb672239bb94d8fa8544a93b959b2e85aa`
  * unpatched base (public path only) debug `b16a4f3c…6a15`, release `850770a0…1af8`
* **Runs.** [probes/run.py](probes/run.py) runs `--network none`, read-only root, with the binary
  hash re-verified on every run. Each case ran in debug and release, and every one of the 16
  probe cases had byte-identical debug/release output. A 17th run executed A's focused tests.
* **Python.** Existing environment (uv.lock `b6152bd0…`, identical to the base).
  [probes/runner.py](probes/runner.py) strips all three live clones from `sys.path`. It fails if
  any project module, including namespace-package `__path__`, comes from outside the export.
  Every run reported zero live or foreign modules.
* **Not done.** No trace capture and no construction-read audit of my builds.

## Findings

### F1 — BLOCKING (before semantic approval/installation of /3) — same-instant strict-wait credit causes are inconsistent across native, both consumers and the ADR

The amendment makes opportunities cursor-level: several opportunities can occur at one
timestamp. The credit-cause law was carried over unchanged as a timestamp law:

* **Structural validator:** `mapped_issue.py:155-170`.
* **Independent checker:** `issue_checks.py:9-23`. `transition_checks_v3.py:75-77,108-113` adds
  any same-timestamp end with no ordinal check.
* **Native:** computes causes at the reservation pass, from releases already observed
  (`component.rs:828-849`).
* **ADR:** says both "a releasing acquired request … completing at the reservation instant" and
  "All tight eligible releases are included" (U0011 postimage lines 800-808). It also says
  "a zero-duration ack release must precede by observation ordinal a subsequent reservation
  using it" (716-717) and "No later event may be used as an earlier cause" (720).

These conflict when two acquired requests on one engine release at the same instant through
different transitions, and a strictly waiting request is granted between them. A typical
trigger is a read's phase-0 `read_port` terminal followed by a write's inline zero-duration
`ack`. A read and a write issued together naturally complete at the same core edge.

*Reproducer (executed).* [probes/make_inputs.py](probes/make_inputs.py) builds `cc0-v3`
(SHA256 `d8bab0aa…76da`) from B's hash-bound `gap-cap2`. Changes: cap 2; engine 0 holds read
`r00.00` (ch 6) and write `r01.00` (ch 7) from t=0; reads `r02.00` and `r03.00` wait. The input
passes the job carrier, component completeness and native admission. Native output in both
modes:

| Ordinal | Event (all at 60000 ps) |
| --- | --- |
| 50 (phase 0) | r00 `read_port` completes (release) |
| 51 (phase 0) | r01 `ack` alignment completes |
| **52** | opportunity grants r02; r02 issue alignment dispatches, credit cause `{r00.read_port}` |
| 54/55 (phase 2) | r01 `ack` service dispatches and completes (release) |
| **56** | opportunity grants r03, credit causes `{r00.read_port, r01.ack}` |

My stdlib-only derivation ([probes/independent.py](probes/independent.py)) reproduces this
opportunity inventory and every grant. Results:

| Output | Structural | Independent |
| --- | --- | --- |
| native `cc0-v3` (debug = release) | **refused** `AttributionMismatch: strict waiting credit causes` | **refused** `complete eligible causes` |
| native `cc-v3` (same, after the 26667 barrier gap) | refused (same) | refused (same) |
| **A7**: the same history, but r01's `ack` dispatched before r02's alignment (ordinals renumbered), r02 still granted at cursor 52, r01's ack added as r02's credit cause | **pass** | **pass** |

Both consumers require r02's causes to include r01's `ack`, which completes after r02's own
grant cursor. Native's real output can never satisfy that. The only way to satisfy it is a cause
that postdates the reservation transition, which is exactly what A7 does
([probes/attack_a7.py](probes/attack_a7.py)). So the pair both falsely refuses a valid output
and accepts an output that attributes credit to a release that happened after the reservation.
A7 also departs from native's canonical phase-2 dispatch order, and no consumer checks that.
The critical-path tie still selects `r00`, so timings and attribution are unaffected. Separately,
r03's agreed cause set includes `r00`, whose slot r02 had already taken; that is questionable
under "Waiting follows the actual blocking activity".

*Why it escaped.* No control in A's 43 Python tests and 12 native tests, or B's 12 helper
fixtures and four mapped processes, has cap ≥ 2 with two same-engine releases at one instant
through different transitions.

*Owners.* Human: choose the law. A: ADR text, native and structural validator. B: independent
checker. *Class:* semantic/law defect plus implementation disagreement.

*Proposed regression.* State per-cursor credit causes. Either (a1) native's current rule: acquired
same-engine releases at the instant whose terminal ordinal precedes the grant cursor. Or (a2)
only releases in the transition(s) since the previous opportunity cursor, with exhaustion
counted at the cursor including earlier same-instant pending grants; this also changes native
for r03. Then require: native `cc0-v3` accepted by both consumers; A7 refused by both, with
structural requiring every credit predecessor's completion ordinal to be below the grant's
cursor; and a cap-2 mixed read/write same-instant control in both suites.

### F2 — NON-BLOCKING for this amendment; pre-existing in the /2 pair — decide before /2 native first use on such inputs

The same root cause exists with model 1/observations 2. `cc0-v1` (SHA256 `722d0ffb…e253`) runs
through the **unpatched** base public path. Its output is byte-identical to the patched V2 seam
output (`06b9e6ee…`). The installed /2 structural validator passes it. The installed /2 checker
(`transition_checks.py:105-115`, byte-identical on main) refuses it with `complete eligible
causes`: native gives r02 `{r00.read_port}`, the checker wants `{r00, r01.ack}`. Here r01's ack
completes at ordinal 45, before r02's first dispatch at 46, so the checker's set is ordinally
possible. Installed U0011 ("actual blocker eligibility from transitions") supports native: r02
issued into r00's slot before r01 released.

*Owners:* B (/2 checker), A (native candidate `64837be`), human (law). The 106-case selection
and the historical binding are unaffected. Resolve together with F1. The gapped twin `cc-v1`
(barrier ends at 26667) is refused by native V2 itself (`activity requires actual tight
earlier cause`). That is the known /2 limitation this amendment addresses, not a credit-cause
result.

### F3 — NON-BLOCKING — release-before-reservation ordering is enforced only by the independent checker

The structural capacity check is timestamp-granular (`mapped_issue.py:147-154`). Attack A1
starts from the valid `sr-v3` output: engine 0 at cap 1 holds write `r00` while `r02` waits, and
engine 1's read terminal opens an earlier opportunity at the same 86000 ps instant. A1 moves
`r02`'s grant from cursor 54 (after the write's ack release) to cursor 52 (before it); times, rows
and causes are unchanged and the result is resealed. Structural validation **passes**. The
independent checker refuses (`opportunity eligible grants / ready tie`).

Guard fault (executed, [probes/fault.py](probes/fault.py)): in a mutant copy, replace the ordinal
release `request_ends[request] >= cursor` with a timestamp release. Then A1 is **accepted**
(unsafe acceptance) and valid `sr-v3` is falsely refused. Exact restoration (hash-verified)
refuses A1 again and accepts `sr-v3` and `r00`.

This is acceptable under "structural necessary but not sufficient". The ADR states the rule
normatively, though, and a cursor-level capacity join in structural validation would be cheap.
Owner A, optional.

### F4 — NON-BLOCKING — `check_v2` has no engine-model binding

A6c takes a valid /2 output (model-1 twin of B's r00 job through V2) and rebinds it to the
model-2 job, resealing the job, engine, admission and result identities. Structural validation
refuses it (`ResultBindingMismatch: component observation/model version`); `check_v2` **passes**.
`check_v3` does bind model 2 (A6a refused by both consumers). The installed /2 checker is frozen.
Future selections and first-use consumers should bind model → observation version → checker
explicitly, which the ADR already requires of future selections. Owner: coordinator/B at
selection time.

## Assessment of the requested areas

| Area | Result |
| --- | --- |
| Model 2 / observations 3 boundary and historical compatibility | **Native:** model-2 jobs refused before execution at the V2 seam and public `execute`; model-1 jobs refused at the V3 seam (`InvalidCarrier /engine/model/version`). **Python:** A6a and A6b refused structurally (`component observation/model version`). **History:** stripping `reservation_opportunities` from my fresh r00/r01 outputs and resealing reproduces B's hash-bound v1 draft outputs (`98365dc6…`, `88697806…`), so the revision changed only the witness. Historical suites: 418 passed, 2 skipped (absent H-L1-DMA-01/H-L1-GEMM-01). Schema fresh; three snapshot modes pass; nine historical controls unchanged. See F4. |
| Waiting/pending/acquired, capacity, atomic conversion, core-edge alignment, zero-duration endpoints | Code read plus `issue-gap`, independently derived. The barrier ends at 32 NoC cycles = 26667 ps; reservation 26667; issue at core edge 27000 (333 ps); complete 86000. Rows: waiting [26667,26667], pending [26667,27000], inflight [27000,86000]. Credit acquire = issue; release = complete. Issue alignment dispatches in phase 2 and completes in phase 0; zero service; clock witnesses with n=0; no busy row. Attribution memory 333+166+48000+2250+1000 = **51749**, NoC 500+3334+417+3333 = **7584**, sync **26667**, all matching output. `gap-write` is also 26667/27000/86000. Pending counts against capacity until atomic conversion in `service()`. A's 12 native controls (cap1/cap2/independent, 33-issue, boundaries, /2 byte freezes) pass in both of my binaries. |
| Actual opportunities, inline dependency completion, scheduled completion ordering | Native does at most one start/service per inner iteration, so each inline terminal is the last event before the next pass (`cursor = completion + 1`). The phase-0 drain emits no phase-2 events, so the batch coalesces into one opportunity. Wake-only passes never set the dirty flag. My derivation reproduces every claimed inventory, e.g. B's case `[(0,0,[r01]),(2,0,[]),(17,26667,[]),(28,60000,[r00]),(50,120000,[])]`, the paired control, two same-instant opportunities in `sr-v3`/`cc0-v3`, and empty final releases. Fresh r00/r01 outputs equal A's published outputs (full parsed result, same `result_hash`). |
| Independent reconstruction of eligibility and grants | Boundaries come from terminal ordinals; eligibility from predecessor-job terminals before the cursor; occupancy from earlier grants whose terminals are not yet observed. A's ineligible-first forgery, rebuilt independently, is byte-identical to A's (`fb737fff…`); structural passes, independent refuses. The dependency-cursor fault accepts it and falsely refuses valid r00; restoration reverses both. A4 (omitted inline empty opportunity) is refused for inventory. **Strict-wait credit causes: F1/F2.** |
| Job/allocation endpoints, causal completeness, identity bindings | Job start = reservation (r00 60000; issue-gap 26667); producer allocation at reservation. A5 (allocation moved to issue) refused by both consumers. The 12-file overlay matches the manifest postimages, and `test_installation_identity` passes. Native sources and `export_carriers.py` are bound only by the manifest and a future build identity, consistent with the historical binding's CI-only scope (observation, not a finding). |

A3 (grant cursor moved to the issue-alignment dispatch) was a no-op for r00, where both are
ordinal 28, so it is not counted. My first schema-check invocation failed on a relative import
under `run_path`; that was a harness error, and the module invocation passed.

## Executed vs inherited

**Executed here:**
* both reconstruction routes and 22/22 postimages;
* three fresh builds;
* 16 native probe cases × 2 modes: B's r00/r01, `issue-gap`, `gap-write`; my `sr-v3`, `cc-v3`,
  `cc0-v3`, `cc0-v1`; the model-1 r00 twin; seam refusals; base `cc0-v1` and r00;
* A's 12 native focused tests;
* the 43-test affected selection and the 418-test historical suites;
* schema and three snapshot checks;
* A's `verify_consumers.py` (4 accepted, forgery refused);
* attacks A1, A2, A4–A7;
* two guard faults with restoration;
* independent timeline, opportunity, grant and cause derivations.

**Inherited, not rerun:** B's twelve-probe campaign and mechanism literals (d4ef3bf);
A's native fault sweeps; B's 12 helper fixtures; the earlier K2/construction read audits; and
prior installation/selection reviews.

## Trace limitations (separate, not waived)

Unknown syscalls at `debug.trace.450:11` and `debug.trace.452:9`, and unfinished
`release.trace.482:10` `sched_getaffinity`, remain unaccepted construction read-audit gaps.
No trace was captured or rebuilt here, so my builds carry no read-audit claim. Coverage here
is not exhaustive.

## Remaining decisions

1. **Human:** the per-cursor credit-cause law (F1 a1/a2), and the matching /2 decision (F2).
2. **A and B:** after that, new prospective postimages, bindings and the cap-2 mixed-release
   control.
3. **Still open (unchanged):** human semantic approval and protected installation, H-L1 workings,
   runtime/profile/selector/HostRecord authority, public negative transport, public first use,
   and U4/G3a closure.

## Reproduction

Raw outputs and logs are in this session's scratchpad. [receipts.json](receipts.json) binds
every input, output, attack, binary and log by SHA256.

```text
python -I probes/reconstruct.py PKG_V2 PKG_V1 FRESH_FULL FRESH_ALT OUT.json
python -I probes/build.py BASE FULL PKG_V2/manifest.json /tmp/NEW-BUILD
runner.py FULL script probes/make_inputs.py /tmp/u4-b-issue-edge-runs-01/jobs INPUTS
python -I probes/run.py BUILD RUNS probe cc0-v3 INPUTS/cc0-v3.json INPUTS/cc0-v3.trust.json 3
runner.py FULL script probes/consume.py FULL OUT.json cc0-v3=JOB:RESULT
runner.py FULL script probes/attack_a7.py RUNS/cc0-v3/debug/result.json A7.json
python -I probes/fault.py MUT_COPY FULL timestamp-release OUT.json A1=... sr=...
```

---

# Stage 3 adjudication (same reviewer)

The original Stage 1 report above is preserved byte-for-byte: its first 17360 bytes still hash to
`0bcaf93461e43205cb1e580e6944d3ed337e481bccdb6ec783ac6c96cef393e6`, the hash pinned by the human
decision. This section only appends. It adjudicates the pinned proposal, not moving main.
Nothing was installed, staged, committed or pushed; no public component job ran; no authority
changed. Stage 3 probes and receipts are in [stage3/](stage3/); raw outputs stay in the session
scratchpad.

## Subjects (resolved and verified)

| Item | Identity |
| --- | --- |
| A Stage 2 candidate | `ff0bf587bc3774b9cf2175bfdf5d108be3904969`, package `docs/reviews/U4-A-issue-edge-stage2-v1/` |
| A integration | `f7eda287ddfd9d0c5bae96e3e5b24552becd6710` (merge of `ff0bf58`) |
| B final disposition | `e7a1b6092069479a8f424aeaaccf9167868be2b6` (parent `f7eda28`), package `docs/reviews/U4-B-issue-edge-stage2-final-v1/` |
| B integration | `67f36dbebebfe14054ae914d4aafb010c089f518` = merge(`e7a1b60`, main `0d11aee`) |
| Human decision | `docs/reviews/U4-issue-edge-stage2-approved-v1/acceptance.json` (`7f88d7b`): a1 approved; F2 kept as a first-use restriction; F3 needs an explicit disposition; F4 needs a prospective binding |
| Joined manifest | `6d163e1a85cec9ed55f959dc7f13250ea9a6d09e1b25539f69e797bb8ba334f2`, base `d17871ccc31b7624b895e516583c52c4eccf80cf` |

The A package, the decision and the v2 package are byte-identical (same tree objects) at
`ff0bf58`, `f7eda28`, `e7a1b60` and `67f36db`. B's final package is identical at `e7a1b60` and
`67f36db`. Both subject clones were read only through `git archive` and stayed clean.

## Reconstruction (executed)

[stage3/reconstruct2.py](stage3/reconstruct2.py) ran on fresh `git archive d17871c` exports.
`d17871c` differs from `d4ef3bf` only under `docs/reviews`.

* All three patch hashes and the delta hash `9e8ef8c1…` match the manifest.
* 26/26 preimages (11 modified, 15 new).
* Ordered `--check`/apply and reverse checks: exit 0.
* Full route: **26/26 postimages**.
* Alternative route: v2's three patches → v2's 22/22 postimages → delta only → 26/26.
* The two routes produce identical trees (5567 files); 9/9 historical controls unchanged.
* B's frozen 26 postimages equal A's manifest.
* Overlay `06666f9e…` (6 replacements, 7 additions, `authority: null`) equals the manifest pre/postimages.

Outside `docs`, the Stage 2 export differs from v2 in exactly 12 files. Native runtime,
admission, accounting and carriers are byte-identical; only `issue_proposal_tests.rs` and
three fixtures change. The three fixtures are byte-identical to my Stage 1 `cc0-v3`, `cc-v3`
and `sr-v3` inputs.

## Fresh execution (executed)

* **Build.** Fresh empty targets, same approved monitor/image/toolchain and 1719 verified cache
  files: debug `b7cc571e20cdac1321cd4dab74673f4ef396837ea26b1b82fb986290cd5b6513`, release
  `ba14befb2d5e46114174d756f70b5df9d0ed7d41988771a9a4969b6e99264aef`. These are private unit
  executables with my unchanged reviewer harness.
* **Native runs.** Ten cases × debug/release, all with identical debug/release bytes: `cc0-v3`,
  `cc-v3`, `sr-v3`, `r00`, `r01`, `issue-gap`, `cc0-v1` (public /2), and three new probes
  ([stage3/make_inputs3.py](stage3/make_inputs3.py), from the same hash-bound B bases):
  * `ww0-v3` (`b2276246…`) and `ww0-v1` (`effb5beb…`): two writes on one cap-2 engine whose
    inline acks release at the same 60000 ps instant.
  * `sr2-v3` (`32920209…`): `sr-v3` with r02 dependency-tight, so it has an empty credit set.
* **Byte identity.** The six re-run cases are byte-identical to my Stage 1 outputs. `cc0-v1`'s
  /2 output is still byte-identical to the unpatched-base output (`06b9e6ee…`): no historical
  /2 byte changed.
* **Native tests.** A's 15 focused native tests pass in both modes.
* **Python.** The 59-test affected selection passes (A's 6 new, the 7 existing issue tests,
  B's 24, 20 identity tests, selection, legacy shape), with all project modules from the
  export.
* **Independent derivation** (stdlib only) reproduces every opportunity inventory and grant.
  Every /3 credit set equals the a1 law (`cc0-v3`, `cc-v3`, `sr-v3`, `ww0-v3`, `sr2-v3`);
  the old timestamp law disagrees on `cc0-v3`, `cc-v3` and `ww0-v3`.

Consumer outcomes on the Stage 2 export:

| Output | Structural | Independent |
| --- | --- | --- |
| 11 valid /3 outputs (`cc0-v3`, `cc-v3`, `sr-v3` × debug/release; `r00`, `r01`, `issue-gap`, `ww0-v3`, `sr2-v3`) | pass | pass |
| A7 (`58813767…`, regenerated byte-identical to Stage 1 and to A's copy) | `credit predecessor before reservation opportunity` | `complete eligible causes` |
| A7m: r03's a1-required `r01.ack` omitted | `exact per-opportunity credit causes` | `complete eligible causes` |
| A1 (`ac363071…`, byte-identical to Stage 1 and to A's copy) | `reservation cursor capacity` | `opportunity eligible grants / ready tie` |
| A1b: `sr2-v3`, r02 grant moved before the ack release | `reservation cursor capacity` | `opportunity eligible grants / ready tie` |
| Stage 1 A2/A4/A5/A6a/A6c | unchanged from Stage 1 | unchanged |
| `cc0-v1` and `ww0-v1` (/2, public path) | pass | **`complete eligible causes`** |

## Row-by-row adjudication

U-REVIEW Stage 3 checks: (a) every finding has a row; (b) each REJECTED reason addresses the
finding; (c) each APPLIED change has a test that fails without it.

* (a): A's response and B's final disposition each have F1–F4 rows.
* (b): nothing was REJECTED.
* DEFERRED parts state what they wait on and where that is recorded: the /2 repair waits on a
  separate human resolution in B's `first-use-requirements.json` exit condition and the ADR F2
  paragraph.

**Random selection:** the seed is the first 16 hex digits of the joined-manifest hash. Over
{F1-structural, F1-independent, F3, F4} it drew **F1-independent**. I reverted that whole
change and also ran targeted reverts on every other row, each in a scratch copy, restored with
hashes verified. The scratch copy ended byte-identical to the export.

### F1 (BLOCKING) — APPLIED → **ACCEPTED**

Law and text: the ADR delta states a1 exactly as approved — strict wait, prior saturation, and
all acquired same-engine releases at `t` whose terminal ordinal is strictly below the grant
cursor, including those before an earlier same-instant opportunity. The first 48294 ADR bytes
are unchanged. The structural helper (`validate_credit_causes`) and the independent checker
(`credit_predecessors` with `reservation_cursor`/`terminal_ordinals`) implement it. The
cursor the checker uses is itself re-derived by `check_reservation_opportunities`. Native
already implemented a1; Stage 2 adds literal tests only.

Discriminating checks (executed):

| Revert | Effect | Regression tests | After restoration |
| --- | --- | --- | --- |
| Structural helper → v2 | valid `cc0-v3` refused; A7, A1, A1b accepted structurally | A's 6 fail | all as above |
| Independent checker → v2 (random pick) | valid `cc0-v3` refused; A7 accepted | 13 of B's 24 fail | 24 pass |
| Independent terminal-before-cursor predicate only | A7 accepted, valid refused | 4 fail | 24 pass |
| Native mutant (`component.rs:844` cites not-yet-released holders; debug `244ff1aa…`, release `7c856fc1…`) | mutant `cc0-v3` output refused by both consumers | 2 of 3 new native literal tests fail in both modes | pristine build passes 15 |

### F2 (NON-BLOCKING; /2 first-use restriction) — **NOT ACCEPTED (scope)**

**What's accurate:**
* No repair is claimed.
* Historical /2 bytes, checker and selection are unchanged: `cc0-v1` /2 output is identical to
  the unpatched base, `check_v2` still refuses it, and the 9 historical controls hold.
* The restriction is recorded in the ADR, A's `prospective-first-use.json` and B's
  `first-use-requirements.json`.

**The problem:** the affected class is "mixed read/write requests … read completion and inline
write ACK", and only *mixed* unclassified cases are blocked. **`ww0-v1`**, a write-only engine,
reproduces exactly the same divergence: /2 structural passes; native gives r02 `{r00.ack}`;
`check_v2` requires `{r00.ack, r01.ack}` and refuses (`complete eligible causes`). In the /2
output, r01's ack completes at ordinal 49, after r02 issued, before r02's first dispatch at 50.
That case is neither "mixed" nor covered by the unclassified-mixed block, so as written the
restriction would let affected write/write cases into /2 first use.

The narrow wording is mine: my Stage 1 F2 said "engines with mixed read and write traffic",
although F1 identified the cause as two same-engine releases at one instant through different
transitions. A, B and the decision followed my wording faithfully. This is a correction to my
own finding's scope, not a new finding.

**Required correction:**
* Widen the class in the ADR F2 paragraph and both first-use records to any same-engine
  acquired releases at one timestamp where a release is observed after a reservation/issue pass
  at that timestamp, with a strictly waiting request in between. That includes write/write ack
  pairs.
* Block unclassified same-engine same-instant cases regardless of direction.
* Add `ww0-v1` (`effb5beb…`) as a second preserved reproducer.
* Get human re-confirmation, because the approved wording was narrower.

/3 is unaffected: `ww0-v3` passes both consumers under a1.

### F3 (NON-BLOCKING) — APPLIED → **NOT ACCEPTED under (c)**

The capacity join (`validate_reservation_capacity`) is correct and genuinely load-bearing. In
**A1b** the r02 grant is dependency-tight and its credit set is empty, so the F1 checks can't
see it. Removing the join's call from `validate_issue_observations` makes **structural
validation accept A1b**; restoration refuses it. (A1 is not discriminating here: F1's temporal
guard also refuses it.)

But no behavioral test fails without the change:
* A's only F3 test calls the helper directly, so with the call removed **57 of 59 affected
  tests pass**.
* The two failures are installed-postimage hash pins (`installation_identity.py:105`). A
  behavior-neutral comment fails the same two tests.
* A's and B's evidence also says no full-validator kill exists.

Owner A. Remedy: add a `validate_result`-level regression of A1b's shape (a dependency-tight
grant moved before the same-instant release cursor) that fails when the call is removed. The
independent checker already refuses A1b, so this doesn't affect F1 safety. F3 remains optional
strengthening per the decision.

### F4 (NON-BLOCKING; prospective binding) — APPLIED → **ACCEPTED**

B's `first_use.py` (`fcac17bc…`) fixes each model to its (observation format, checker) pair
before either validator runs, and pins A's 48-file consumer closure.

Executed checks ([stage3/f4_check.py](stage3/f4_check.py),
[stage3/f4_isolate.py](stage3/f4_isolate.py)):
* Matching `cc0-v3`/`check_v3` and valid /2 `r00-m1`/`check_v2` pass.
* `cc0-v3` routed to `check_v2`, and A6c routed to either checker, are refused at the route.
* A tampered closure pin is refused.
* With the structural layer stubbed, the exact route refuses A6c, while a route chosen from the
  result's declared format lets the model-2 job obtain `check_v2` acceptance. So the binding
  itself, not only structural validation, denies the evidence.

B's control asserts route refusal on A6c, so it fails without the route. The frozen `check_v2`
is unchanged and still passes A6c in isolation, as recorded.

## Executed vs inherited

**Executed in Stage 3:**
* Commit resolution and lineage; both reconstruction routes; manifest, B-freeze and overlay
  cross-checks.
* One fresh build plus one native-mutant build; 10 native cases × 2 modes; A's 15 native tests.
* The 59-test affected selection and consumer runs on 11 valid /3 outputs, 2 /2 twins and 9
  attacks.
* Four revert/restore experiments, including the random pick, plus the F3 integration and
  neutral-byte controls.
* The F4 route/isolation/tamper checks and the independent derivations.

**Inherited, not rerun:**
* B's six native runs and binaries (`788de13e…`/`bf8c792a…`), its 27-test batch, 56-file
  support closure and literal recipe.
* A's 35/44 receipts, structural double-guard fault and native faults (one independent native
  fault was run here instead).
* Schema freshness and snapshot modes. The schemas, `mapped.py` and `export_carriers.py` are
  byte-identical to v2, which I checked in Stage 1.
* The historical suites (418) and the earlier campaigns. There is no concrete concern, since
  the historical controls and /2 bytes are unchanged.

## Read-audit limitations (retained, not waived)

The unknown syscalls at `debug.trace.450:11` and `debug.trace.452:9`, and the unfinished
`release.trace.482:10` `sched_getaffinity`, remain unaccepted. No trace was captured; my Stage 3
builds carry no read-audit claim. Coverage is not exhaustive.

## Verdict

**NOT ACCEPTED.** Rows at fault, both NON-BLOCKING:

* **F2** — the restriction's affected class is too narrow: write/write same-instant ack releases
  (`ww0-v1`) diverge identically and aren't blocked. This originates in my Stage 1 wording;
  widen the class and get human re-confirmation.
* **F3** — no behavioral test fails when the capacity join is disconnected; add an A1b-shaped
  validator-level regression.

The blocking finding **F1 is ACCEPTED** (a1, in both consumers and native), and **F4 is
ACCEPTED**. No new findings are raised. This adjudication grants no installation, public first
use, authority, qualification or U4/G3a closure.
