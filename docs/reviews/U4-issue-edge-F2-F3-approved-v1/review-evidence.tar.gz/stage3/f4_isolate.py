"""F4 isolation: structural validate_result stubbed in-process, so only the route + checker decide.
Usage (runner.py): f4_isolate.py EXPORT FIRST_USE_PY F4_JSON JOB RESULT"""
import importlib.util, json, sys
from pathlib import Path
import uarch_contract.mapped as mapped
export, fup, f4, job, res = (Path(a) for a in sys.argv[1:6])
spec = importlib.util.spec_from_file_location("b_first_use", fup); fu = importlib.util.module_from_spec(spec); spec.loader.exec_module(fu)
closure = json.loads(f4.read_text())["closure"]
expected = json.loads((export / "docs/reviews/U4-B-component-stage2-v1/first-use-bindings.json").read_text())["observation_contract"]
j = json.loads(job.read_text()); r = json.loads(res.read_text()); r = r.get("result", r)
mapped.validate_result = lambda value, job: None  # isolate: structural layer disabled
V2 = "validation.component.observations_v2:check_v2"
def go(label, route):
    orig = fu.required_route; fu.required_route = route
    try: fu.consume(j, r, V2, expected, export, closure); out = "pass (model2 job obtains check_v2 acceptance)"
    except Exception as e: out = f"{type(e).__name__}: {str(e)[:70]}"
    finally: fu.required_route = orig
    print(f"{label:34s} {out}")
go("exact route, structural stubbed", fu.required_route)
go("reverted route, structural stubbed", lambda job, result, cid: None)
