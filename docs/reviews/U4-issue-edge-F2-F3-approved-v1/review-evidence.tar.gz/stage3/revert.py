"""Stage 3 correction/revert checks on a scratch copy of the Stage 2 export.

Usage: python -I revert.py MUT PRISTINE V2_EXPORT NAME OUT.json CASE=JOB:RESULT ...
Each named revert edits MUT only, runs both consumers on the cases and the change's own
regression tests, restores pristine bytes (hash-verified) and runs everything again.
"""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

mut, pristine, v2 = (Path(a).resolve() for a in sys.argv[1:4])
name, out = sys.argv[4], Path(sys.argv[5]).resolve()
cases = sys.argv[6:]
PY = "/home/jjaff/AI-infra-simulation/rk-uarch/.venv/bin/python"
RUNNER = "/tmp/claude-1000/-home-jjaff-AI-infra-simulation-rk-uarch/31125e8a-4bee-4954-93ba-9ae149f3831c/scratchpad/tools/runner.py"
CONSUME = "/tmp/claude-1000/-home-jjaff-AI-infra-simulation-rk-uarch/31125e8a-4bee-4954-93ba-9ae149f3831c/scratchpad/tools/consume.py"
MI = "contract/uarch_contract/mapped_issue.py"
IC = "validation/component/issue_checks.py"
TC = "validation/component/transition_checks_v3.py"
REVERTS = {
    # Whole F1 structural correction reverted to the v2 timestamp law (also drops F3 helper).
    "F1-structural-full": {"files": [MI], "tests": ["contract/tests/mapped/test_component_credit_cursor_v3.py"]},
    # Whole F1 independent correction reverted to v2 checker files.
    "F1-independent-full": {"files": [IC, TC], "tests": ["validation/component/test_issue_checks.py"]},
    # Single independent predicate: terminal ordinal before the reservation cursor.
    "F1-independent-ordinal": {"edit": (IC, "        and terminal_ordinals[key] < reservation_cursor\n", ""),
                               "tests": ["validation/component/test_issue_checks.py"]},
    # F3 only: drop the structural cursor-capacity join.
    "F3-capacity-call": {"edit": (MI, "    validate_reservation_capacity(requests, lasts, opportunities, limit)\n", ""),
                         "tests": ["contract/tests/mapped/test_component_credit_cursor_v3.py"]},
}


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def consumers(tag):
    log = out.with_name(f"{out.stem}-{tag}.json")
    p = subprocess.run([PY, "-I", RUNNER, str(mut), "script", CONSUME, str(mut), str(log), *cases],
                       capture_output=True, text=True, timeout=600)
    assert p.returncode == 0, p.stderr[-1500:]
    return [(c["case"], c["structural"][:60], c["independent"][:60]) for c in json.loads(log.read_text())["cases"]]


def tests(paths):
    p = subprocess.run([PY, "-I", RUNNER, str(mut), "pytest", "-q", *paths], capture_output=True,
                       text=True, timeout=600)
    tail = [x for x in p.stdout.splitlines() if " passed" in x or " failed" in x or "error" in x.lower()]
    return dict(exit=p.returncode, summary=tail[-1] if tail else p.stdout[-300:])


spec = REVERTS[name]
touched = spec["files"] if "files" in spec else [spec["edit"][0]]
originals = {f: (pristine / f).read_bytes() for f in touched}
assert all((mut / f).read_bytes() == b for f, b in originals.items()), "scratch copy must start pristine"
rec = dict(revert=name, files=touched, pristine={f: sha(pristine / f) for f in touched})
if "files" in spec:
    for f in touched:
        (mut / f).write_bytes((v2 / f).read_bytes())
    rec["reverted_to_v2"] = {f: sha(v2 / f) for f in touched}
else:
    f, old, new = spec["edit"]
    text = originals[f].decode()
    assert text.count(old) == 1, "exact single mutation site"
    (mut / f).write_text(text.replace(old, new))
    rec["removed"] = old
rec["mutant_sha256"] = {f: sha(mut / f) for f in touched}
try:
    rec["mutant_consumers"] = consumers("mutant")
    rec["mutant_tests"] = tests(spec["tests"])
finally:
    for f, b in originals.items():
        (mut / f).write_bytes(b)
assert all(sha(mut / f) == rec["pristine"][f] for f in touched)
rec["restored_consumers"] = consumers("restored")
rec["restored_tests"] = tests(spec["tests"])
out.write_text(json.dumps(rec, indent=1) + "\n")
for phase in ("mutant", "restored"):
    for c in rec[f"{phase}_consumers"]:
        print(f"{name:24s} {phase:8s} {c[0]:8s} structural={c[1]:58s} independent={c[2]}")
    print(f"{name:24s} {phase:8s} tests: exit={rec[phase + '_tests']['exit']} {rec[phase + '_tests']['summary']}")
