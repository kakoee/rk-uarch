"""Reviewer private build of the reconstructed amendment, fresh isolated targets.

Usage: python -I build.py BASE_EXPORT PATCHED_EXPORT MANIFEST OUT
Reuses the approved bounded monitor (loaded from the base export), the pinned image and the
accepted offline cache. Builds unit test executables only; no BuildTrust or public identity.
"""

import hashlib
import importlib.util
import json
import shutil
import sys
from pathlib import Path

base, patched, manifest_path, out = (Path(a).resolve() for a in sys.argv[1:5])
HERE = Path(__file__).resolve().parent
OLD = Path("/tmp/u4-b-candidate04-audit")


def digest(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


manifest = json.loads(manifest_path.read_text())
MUTATED = "native/crates/uarch-engine/src/component.rs"
for row in manifest["files"]:
    if row["path"].startswith("native/") and row["path"] != MUTATED:
        assert digest(patched / row["path"]) == row["postimage_sha256"], row["path"]
assert digest(patched / MUTATED) != [r for r in manifest["files"] if r["path"] == MUTATED][0]["postimage_sha256"]
out.mkdir(exist_ok=False)
for name in ("receipts", "canary", "docker-config", "source", "output"):
    (out / name).mkdir()
shutil.copytree(patched / "native", out / "source/native")
source = out / "source"
preimages = {str(p.relative_to(source)): digest(p) for p in source.rglob("*") if p.is_file()}
for name in ("cache", "controls", "diagnostics"):
    shutil.copytree(OLD / name, out / name, symlinks=True)
preserved = json.loads(
    (base / "docs/reviews/U4-B-K2-candidate-04-audit-v1/preservation.json").read_text()
)
for path, binding in preserved["diagnostics"].items():
    assert "sha256:" + digest(out / "diagnostics" / path) == binding["byte_hash"], path
cache = {str(p.relative_to(out / "cache")): digest(p) for p in (out / "cache").rglob("*") if p.is_file()}
accepted = json.loads((base / "docs/reviews/U4-A-K2-C1-precise-v1/cache-inventory.json").read_text())
assert cache == {p: v["sha256"] for p, v in accepted["files"].items()}, "accepted cache"
lib = source / "native/crates/uarch-engine/src/lib.rs"
lib.write_bytes(lib.read_bytes() + b"\n#[cfg(test)]\nmod reviewer_probe;\n")
shutil.copyfile(HERE / "reviewer_probe.rs", lib.with_name("reviewer_probe.rs"))
postimages = {str(p.relative_to(source)): digest(p) for p in source.rglob("*") if p.is_file()}
monitor_path = base / "docs/reviews/U4-B-K2-construction-audit-v1/trace_monitor.py"
spec = importlib.util.spec_from_file_location("approved_monitor", monitor_path)
assert spec and spec.loader
monitor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(monitor)
record = dict(
    subject="MUTANT: Stage 2 native with credit causes citing not-yet-released holders (component.rs:844)",
    source_preimages=preimages,
    private_postimages=postimages,
    harness_sha256=digest(HERE / "reviewer_probe.rs"),
    cache_files=len(cache),
    monitor_sha256=digest(monitor_path),
    image=monitor.IMAGE,
    controls={p.name: digest(p) for p in (out / "controls").iterdir()},
    public_executable_built=False,
    authority_created=False,
    commands={},
)
for mode in ("debug", "release"):
    cmd = [monitor.TOOL + "cargo", "test", "--offline", "--locked", "-p", "uarch-engine",
           "--lib", "--no-run", "--message-format=json"]
    if mode == "release":
        cmd.append("--release")
    result = monitor.run(out, mode, cmd, trace=False, build=True)
    record["commands"][mode] = result
    (out / "build.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    assert result["exit_code"] == 0 and not result["stop_reason"], result
    recs = [json.loads(x) for x in (out / "receipts" / mode / "stdout").read_text().splitlines()
            if x.startswith("{")]
    exes = [r["executable"] for r in recs if r.get("reason") == "compiler-artifact"
            and r.get("executable") and r["target"]["name"] == "uarch_engine"]
    assert len(exes) == 1, exes
    rel = str(Path(exes[0]).relative_to("/target"))
    result.update(test_executable=rel, test_executable_sha256=digest(out / (mode + "-target") / rel))
    (out / "build.json").write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print(mode, result["test_executable_sha256"], flush=True)
assert all(digest(source / p) == v for p, v in postimages.items())
assert all(digest(out / "cache" / p) == v for p, v in cache.items())
print("cache files", len(cache))
