"""Independent reconstruction of A's v2 amendment (both routes) in private exports.

Usage: python -I reconstruct.py PKG_V2 PKG_V1 FULL_EXPORT ALT_EXPORT OUT_JSON
Exports must be fresh `git archive d4ef3bf` trees. No live tree is touched.
"""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

pkg, pkg_v1, full, alt, out = (Path(a).resolve() for a in sys.argv[1:6])
manifest = json.loads((pkg / "manifest.json").read_text())
v1_manifest = json.loads((pkg_v1 / "manifest.json").read_text())  # prior proposal (v2 here)


def sha(p: Path) -> str | None:
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None


def git_apply(root: Path, patch: Path, *flags: str) -> int:
    r = subprocess.run(
        ["git", "apply", *flags, str(patch)], cwd=root, capture_output=True, text=True
    )
    if r.returncode:
        print(r.stderr, file=sys.stderr)
    return r.returncode


rec: dict = {"patches": [], "preimages": [], "postimages": [], "historical": []}
for p in manifest["patches"]:
    got = sha(pkg / p["path"])
    rec["patches"].append({"path": p["path"], "expected": p["sha256"], "got": got,
                           "ok": got == p["sha256"]})
got = sha(pkg / manifest["alternative_delta"]["path"])
rec["alternative_delta_ok"] = got == manifest["alternative_delta"]["sha256"]

for f in manifest["files"]:
    got = sha(full / f["path"])
    rec["preimages"].append({"path": f["path"], "ok": got == f["preimage_sha256"]})

# Full route: ordered check then apply, each patch exactly once.
steps = []
for p in manifest["patches"]:
    patch = pkg / p["path"]
    c = git_apply(full, patch, "--check")
    a = git_apply(full, patch) if c == 0 else None
    steps.append({"patch": p["path"], "check": c, "apply": a})
rec["full_steps"] = steps
for f in manifest["files"]:
    got = sha(full / f["path"])
    rec["postimages"].append({"path": f["path"], "ok": got == f["postimage_sha256"]})
# Reverse checks in reverse order (check only; the export keeps postimages).
rec["full_reverse_checks"] = [
    {"patch": p["path"], "reverse_check": git_apply(full, pkg / p["path"], "--check", "-R")}
    for p in reversed(manifest["patches"])
]
# Note: reverse --check of earlier patches against the fully patched tree is only valid if
# later patches do not touch the same files; record raw exit codes.
for h in manifest["verification"]["historical_controls"]:
    rec["historical"].append({"path": h["path"], "ok": sha(full / h["path"]) == h["sha256"]})

# Alternative route: v1 three patches (from ddd299c package) then the delta only.
alt_steps = []
for p in v1_manifest["patches"]:
    patch = pkg_v1 / p["path"]
    ok_hash = sha(patch) == p["sha256"]
    c = git_apply(alt, patch, "--check")
    a = git_apply(alt, patch) if c == 0 else None
    alt_steps.append({"patch": "v1/" + p["path"], "hash_ok": ok_hash, "check": c, "apply": a})
v1_post = []
for f in v1_manifest["files"]:
    v1_post.append({"path": f["path"], "ok": sha(alt / f["path"]) == f["postimage_sha256"]})
rec["v1_postimages"] = v1_post
delta = pkg / manifest["alternative_delta"]["path"]
c = git_apply(alt, delta, "--check")
alt_steps.append({"patch": "alternative-delta", "check": c,
                  "apply": git_apply(alt, delta) if c == 0 else None})
rec["alt_steps"] = alt_steps
rec["alt_postimages"] = [
    {"path": f["path"], "ok": sha(alt / f["path"]) == f["postimage_sha256"]}
    for f in manifest["files"]
]
rec["alt_reverse_delta_check"] = git_apply(alt, delta, "--check", "-R")

# Whole-tree equality between the two routes.
def tree(root: Path) -> dict[str, str]:
    return {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob("*")) if p.is_file()}


tf, ta = tree(full), tree(alt)
rec["route_file_counts"] = [len(tf), len(ta)]
rec["route_differences"] = sorted(k for k in set(tf) | set(ta) if tf.get(k) != ta.get(k))
rec["summary"] = {
    "patch_hashes_ok": all(x["ok"] for x in rec["patches"]) and rec["alternative_delta_ok"],
    "preimages_ok": sum(x["ok"] for x in rec["preimages"]),
    "postimages_ok": sum(x["ok"] for x in rec["postimages"]),
    "alt_postimages_ok": sum(x["ok"] for x in rec["alt_postimages"]),
    "v1_postimages_ok": f"{sum(x['ok'] for x in v1_post)}/{len(v1_post)}",
    "historical_ok": sum(x["ok"] for x in rec["historical"]),
    "files": len(manifest["files"]),
}
Path(out).write_text(json.dumps(rec, indent=1, sort_keys=True))
print(json.dumps(rec["summary"], indent=1), json.dumps(rec["full_steps"]),
      json.dumps(rec["full_reverse_checks"]), json.dumps(alt_steps),
      rec["alt_reverse_delta_check"], rec["route_file_counts"], rec["route_differences"][:10])
