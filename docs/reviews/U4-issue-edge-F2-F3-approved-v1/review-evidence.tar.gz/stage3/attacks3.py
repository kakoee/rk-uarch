"""Stage 3 reviewer attacks from fresh Stage 2 outputs (synthetic; no authority). Run under runner.py.

Usage: attacks3.py RUNS OUT_DIR
  A1  : sr-v3, move r02's grant from the post-ack opportunity to the earlier same-instant one
        (byte-identical recipe to Stage 1 A1).
  A1b : sr2-v3 (r02 dependency-tight, empty credit set), same move. Credit-cause checks cannot
        see it; structural refusal must come from the F3 cursor-capacity join alone.
  A7m : cc0-v3 valid output minus r01.ack from r03's credit set (omits an a1-required cause).
"""

import hashlib
import json
import sys
from pathlib import Path

from uarch_contract.hashing import canonical_json, content_hash

runs, out = Path(sys.argv[1]), Path(sys.argv[2])
out.mkdir(exist_ok=False)
report = {}


def load(name):
    return json.loads((runs / name / "debug/result.json").read_text())["result"]


def save(name, r, note):
    r["result_hash"] = content_hash(r, exclude=("result_hash",))
    (out / f"{name}.json").write_text(canonical_json(r))
    report[name] = dict(note=note, sha256=hashlib.sha256((out / f"{name}.json").read_bytes()).hexdigest())


for name, source in (("A1", "sr-v3"), ("A1b", "sr2-v3")):
    r = load(source)
    opps = r["observations"]["reservation_opportunities"]["records"]
    early, late = [x for x in opps if x["t_ps"] == 86000]
    assert early["granted_request_ids"] == [] and late["granted_request_ids"] == ["r02.00"]
    early["granted_request_ids"], late["granted_request_ids"] = ["r02.00"], []
    first = next(a for a in r["observations"]["activities"]["records"]
                 if a["request_id"] == "r02.00" and a["subphase"] == "dma_issue" and a["kind"] == "alignment")
    save(name, r, f"{source}: r02 cursor {late['event_cursor']} -> {early['event_cursor']}; "
         f"r02 causes {[(p['activity_id'], p['relation']) for p in first['predecessors']]}")

r = load("cc0-v3")
acts = {a["activity_id"]: a for a in r["observations"]["activities"]["records"]}
r03 = next(a for a in acts.values() if a["request_id"] == "r03.00"
           and a["subphase"] == "dma_issue" and a["kind"] == "alignment")
ack = next(a for a in acts.values() if a["request_id"] == "r01.00" and a["subphase"] == "ack" and a["kind"] == "service")
r03["predecessors"] = [p for p in r03["predecessors"] if p["activity_id"] != ack["activity_id"]]
save("A7m", r, "cc0-v3: r03 credit set without r01.ack (terminal < cursor 56)")
(out / "manifest.json").write_text(json.dumps(report, indent=1) + "\n")
print(json.dumps(report, indent=1))
