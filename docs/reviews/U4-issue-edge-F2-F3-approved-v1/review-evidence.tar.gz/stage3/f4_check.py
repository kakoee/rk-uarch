"""F4 prospective route checks (run under runner.py with the Stage 2 export).

Usage: f4_check.py EXPORT FIRST_USE_PY F4_JSON OUT CASE=JOB:RESULT:CHECKER ...
Runs B's exact first_use.consume with A's pinned closure, then a reverted route that selects
the checker from the result's declared format (the forbidden pattern), on the same cases.
"""

import importlib.util
import json
import sys
from pathlib import Path

export, first_use_path, f4, out = (Path(a) for a in sys.argv[1:5])
V2 = "validation.component.observations_v2:check_v2"
V3 = "validation.component.observations_v3:check_v3"
spec = importlib.util.spec_from_file_location("b_first_use", first_use_path)
fu = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fu)
closure = json.loads(f4.read_text())["closure"]
expected = json.loads(
    (export / "docs/reviews/U4-B-component-stage2-v1/first-use-bindings.json").read_text()
)["observation_contract"]


def reverted_route(job, result, checker_id):  # forbidden: trust the result's self-declared format
    fmt = result["observations"]["format"]
    return (fmt, V3 if fmt.endswith("/3") else V2)


def run(route_fn, j, r, checker):
    original = fu.required_route
    fu.required_route = route_fn
    try:
        fu.consume(j, r, checker, expected, export, closure)
        return "pass"
    except Exception as e:  # noqa: BLE001
        return f"{type(e).__name__}: {str(e)[:80]}"
    finally:
        fu.required_route = original


rows = []
for spec_ in sys.argv[5:]:
    name, rest = spec_.split("=", 1)
    job_path, result_path, checker = rest.split(":", 2)
    checker = {"v2": V2, "v3": V3}[checker]
    j = json.loads(Path(job_path).read_text())
    r = json.loads(Path(result_path).read_text())
    r = r.get("result", r)
    row = dict(case=name, checker=checker.split(":")[1], route=run(fu.required_route, j, r, checker),
               reverted_route=run(reverted_route, j, r, checker))
    rows.append(row)
    print(f"{name:26s} checker={row['checker']:9s} exact-route={row['route'][:70]:72s} reverted={row['reverted_route'][:60]}")
# Closure tamper control: one pinned file hash altered.
j = json.loads(Path(sys.argv[5].split("=", 1)[1].split(":")[0]).read_text())
bad = dict(closure)
key = "validation/component/issue_checks.py"
bad[key] = "0" * 64
try:
    fu.consume(j, {"observations": {"format": "uarch-native-observations/3"}}, V3, expected, export, bad)
    tamper = "pass"
except Exception as e:  # noqa: BLE001
    tamper = f"{type(e).__name__}: {e}"
print("closure tamper:", tamper[:100])
out.write_text(json.dumps(dict(rows=rows, closure_files=len(closure), tamper=tamper), indent=1) + "\n")
