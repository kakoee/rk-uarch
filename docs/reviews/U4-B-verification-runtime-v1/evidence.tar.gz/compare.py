import collections
import json
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path(__file__).parent

def cases(paths):
    values = {}
    for path in paths:
        for c in ET.parse(root / path).getroot().iter('testcase'):
            key = c.attrib['classname'] + '::' + c.attrib['name']
            assert key not in values, key
            result = {'seconds': float(c.attrib.get('time', 0)), 'outcome': 'passed'}
            for tag in ('skipped', 'failure', 'error'):
                node = c.find(tag)
                if node is not None:
                    result.update(outcome=tag, reason=node.attrib.get('message', ''))
            values[key] = result
    return values

before = cases(['baseline.xml'])
after = cases(['final-python.xml', 'final-contract.xml'])
missing = sorted(before.keys() - after.keys())
added = sorted(after.keys() - before.keys())
drift = {k: [v, after[k]] for k, v in before.items() if k in after and
         (v['outcome'], v.get('reason')) != (after[k]['outcome'], after[k].get('reason'))}
groups = collections.defaultdict(lambda: {'before_s': 0, 'after_s': 0, 'before_n': 0, 'after_n': 0})
for kind, values in [('before', before), ('after', after)]:
    for k, v in values.items():
        group = groups[k.split('::')[0]]
        group[kind + '_s'] += v['seconds']
        group[kind + '_n'] += 1
result = {'baseline_count': len(before), 'final_count': len(after), 'missing': missing,
          'added': added, 'outcome_or_skip_reason_changes': drift,
          'baseline_outcomes': dict(collections.Counter(v['outcome'] for v in before.values())),
          'final_outcomes': dict(collections.Counter(v['outcome'] for v in after.values())),
          'exact_original_outcomes_and_skip_reasons_preserved': not missing and not drift,
          'baseline_test_seconds': sum(v['seconds'] for v in before.values()),
          'final_original_test_seconds': sum(after[k]['seconds'] for k in before if k in after),
          'added_test_seconds': sum(after[k]['seconds'] for k in added)}
(root / 'coverage-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
(root / 'final-groups.json').write_text(json.dumps(dict(sorted(groups.items(),
    key=lambda pair: -pair[1]['after_s'])), indent=2) + '\n')
print(json.dumps(result, indent=2))
assert not missing and not drift
assert all(after[k]['outcome'] == 'passed' for k in added)
