import difflib,hashlib,json,shutil,subprocess
from pathlib import Path
repo=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a');source=Path('/tmp/u4-a-activation-ready-8QayET/source-final');work=Path('/tmp/u4-a-activation-ready-8QayET')
package=repo/'docs/reviews/U4-A-component-activation-readiness-v1';prop=package/'proposals'
recipe=Path('native/tools/component_runtime_candidate.py');old=(source/recipe).read_text();new=old.replace('/ "prospective-consumer-bindings.json"','/ "overlay-consumer-bindings.json"');assert new!=old
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+str(recipe),tofile='b/'+str(recipe)))
(prop/'preparation-overlay-unapplied.patch').write_text(patch)
names=['D3-full-v6.patch','default-route-unapplied.patch','B-closure-unapplied.patch','U0011-activation-unapplied.patch','preparation-overlay-unapplied.patch']
combined=''.join((prop/n).read_text() for n in names);(prop/'activation-overlay-unapplied.patch').write_text(combined)
root=work/'activation-overlay';root.mkdir()
base=json.loads((package/'prospective-consumer-bindings.json').read_bytes())
for name in list(base['files'])+['docs/decisions/U0011-the-native-engine-core.md']:
 dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/name,dest)
run=subprocess.run(['git','apply',str(prop/'activation-overlay-unapplied.patch')],cwd=root,capture_output=True,text=True)
assert run.returncode==0,run.stderr
changed=[str(recipe),'src/rkuarch/engines/native/component_negative.py','src/rkuarch/engines/native/component_runner.py','validation/component/runtime_checks.py','docs/decisions/U0011-the-native-engine-core.md']
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
post={name:h(root/name) for name in changed}
for name in changed:
 if name.endswith('.py'):base['files'][name]=post[name]
base['files']=dict(sorted(base['files'].items()));base['status']='UNAPPLIED joined overlay; B postimage review and separate protected installation pending';base['overlay_patch_sha256']=h(prop/'activation-overlay-unapplied.patch')
(package/'overlay-consumer-bindings.json').write_text(json.dumps(base,indent=2)+'\n')
record={'format':'A-activation-overlay-reconstruction/1','base_source':'1f31669bc355267f7155aeef3dcf8af6796a839f','installed':False,'patches':names,'combined_patch_sha256':h(prop/'activation-overlay-unapplied.patch'),'postimages':post,'consumer_count':len(base['files']),'consumer_sha256':h(package/'overlay-consumer-bindings.json'),'future_missing':['B ordinary_eof_acceptance implementation/tests and actual final consumer review','immutable environment/deployment and A-F3 evidence','exact activation source/build authority and receipts'],'generated_engine':None}
(package/'overlay-bindings.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
