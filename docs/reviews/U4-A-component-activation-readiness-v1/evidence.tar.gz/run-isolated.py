import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve()
site=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a/.venv/lib/python3.12/site-packages')
sys.path[:0]=[str(root),str(root/'src'),str(root/'contract'),str(site)]
import pytest
code=pytest.main(['-q','--basetemp=/tmp/u4-a-activation-ready-8QayET/pytest-final',
 'tests/unit/test_component_image.py','tests/unit/test_component_guard_eof.py',
 'tests/unit/test_component_startup_inventory.py','tests/unit/test_component_image_negative.py',
 'tests/unit/test_component_runtime.py::test_component_public_entry_requires_its_own_authority',
 'tests/unit/test_component_runtime.py::test_complete_private_preparation_and_echo_transport'])
origins={}
for name,module in sorted(sys.modules.copy().items()):
 if name.split('.')[0] in ('rkuarch','uarch_contract','validation','native'):
  raw=getattr(module,'__file__',None)
  if raw:
   path=Path(raw).resolve()
   assert path.is_relative_to(root), (name,str(path))
   origins[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
Path('/tmp/u4-a-activation-ready-8QayET/final-origins.json').write_text(json.dumps({'root':str(root),'status':code,'modules':origins},indent=2)+'\n')
raise SystemExit(code)
