import hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
repo=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a');work=Path('/tmp/u4-a-activation-ready-8QayET');source=work/'source-final';package=repo/'docs/reviews/U4-A-component-activation-readiness-v1'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Original B manifest and additive reply independently preserve their historical bytes.
b=repo/'docs/reviews/U4-B-component-activation-readiness-v1';bm=json.loads((b/'manifest.json').read_bytes())
for name,pin in bm['files'].items():assert h(b/name)==pin['sha256'] and (b/name).stat().st_size==pin['bytes']
br=json.loads((b/'interface-response-bindings.json').read_bytes())
for name,pin in br['files'].items():assert h(repo/name)==pin
# All exact source entries and both independent-consumer proposals reverify.
inputs=json.loads((package/'source-input-delta.json').read_bytes())
for name,pin in inputs['source_files'].items():assert h(source/name)==pin
for name,pin in json.loads((package/'prospective-consumer-bindings.json').read_bytes())['files'].items():assert h(source/name)==pin
root=work/'activation-overlay';pins=json.loads((package/'overlay-consumer-bindings.json').read_bytes())['files']
for name,pin in pins.items():assert h(root/name)==pin
sys.path[:0]=[str(source),str(source/'src'),str(source/'contract'),str(repo/'.venv/lib/python3.12/site-packages')]
spec=importlib.util.spec_from_file_location('final_overlay_checker',root/'validation/component/runtime_checks.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.verify_sources(root,pins)
# Exact startup snapshot bytes/permissions, external original inputs and actual launch observations.
s=work/'startup-package-v2';env=json.loads((s/'package.json').read_bytes());manifest=json.loads((s/'startup-manifest.json').read_bytes())
assert h(s/'startup-manifest.json')==env['manifest_sha256']
assert env['launch_status']==0 and (s/'launch.stderr').read_bytes()==b''
for path,pin in manifest['files'].items():assert h(Path(path))==pin
for row in env['files']+env['bootstrap_tcb']+env['loader_configuration']:
 assert h(Path(row['origin']))==row['sha256']==h(Path(row['snapshot']))
 assert Path(row['snapshot']).stat().st_mode & 0o222==0
for row in env['cache_candidates']:
 assert h(Path(row['snapshot']))==row['sha256'] and row['read_observed'] is False
for row in env['observed_loaded_files']:assert h(Path(row['path']))==row['sha256']
loaded=json.loads((s/'launch.stdout').read_bytes());assert loaded['site'] is False
project_origins={k:v for k,v in loaded['modules'].items() if k.split('.')[0] in ('rkuarch','uarch_contract','validation','native') and v}
assert all(Path(v).is_relative_to(s/'snapshot/project') for v in project_origins.values())
# Inventory is not assurance: no attempt to probe pre-start substitution or authority.
schema=json.loads((package/'attempt-schema.json').read_bytes());attempts=[]
for p in sorted((work/'pytest-final').rglob('attempt.json')):
 v=json.loads(p.read_bytes());assert set(schema['required']) <= set(v);assert set(v)<=set(schema['properties'])
 assert v['runtime_entries'] is None and v['format']=='component-eof-attempt/1'
 attempts.append({'path':str(p.relative_to(work)),'sha256':h(p),'transport_complete':v['transport_complete'],'validation_passed':v['validation_passed'],'status':v['status'],'slot':v['slot']})
assert len(attempts)==12
protected=subprocess.check_output(['git','diff','--name-only','4d447ba','1f31669','--','contract','docs/decisions','native/crates'],cwd=repo,text=True)
assert protected==''
record={'format':'A-activation-preparation-verification/1','source_commit':'1f31669bc355267f7155aeef3dcf8af6796a839f','tests_source':'15736ada9e04bd1bdc7a07b87aed40b39adfad14','tests':'14 passed; synthetic transport/fixtures; no Docker or native Rust execution',
 'final_delta':'typing bootstrap inventory only; final benign launch observed separately; 14 tests not rerun',
 'B_manifest_leaves':len(bm['files']),'B_original_manifest_sha256':h(b/'manifest.json'),'B_interface_commit':'a6f3e6a57abef6b73794003ae76e1dc2e877cd42','B_final_postimage_acceptance':'PENDING',
 'source_inputs':len(inputs['source_files']),'base_consumer_count':78,'overlay_consumer_count':79,'overlay_checker_match':True,
 'startup_manifest_sha256':env['manifest_sha256'],'startup_package_sha256':h(s/'package.json'),'selected_snapshot_files':len(env['files']),'bootstrap_TCB_files':len(env['bootstrap_tcb']),'cache_candidates':len(env['cache_candidates']),'observed_mapped_files':len(env['observed_loaded_files']),'project_loaded_origins':project_origins,
 'startup_limits':'Import-only success; snapshot owner can chmod. External interpreter/bootstrap/stdlib roots not deployed immutable. Missing specs corrected by explicitly binding typing in baseline. A-F3 remains deferred.',
 'private_synthetic_attempts':attempts,'schema_check':'required keys/known fields/null-entry constraints only; no new JSON-schema dependency or public acceptance checker',
 'protected_and_native_sources_unchanged_from_runtime4d':True,'native_builds':0,'docker_commands':0,'public_jobs':0,'read_capture':False,'A_F3_retry':False,
 'incident_result':'no exact matches within bounded own records; impact unknown'}
(package/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
startup={'format':'A-prospective-startup-binding/1','source_commit':record['source_commit'],'execution_authority':False,'manifest_sha256':env['manifest_sha256'],'manifest_archive_member':'startup-package-v2/startup-manifest.json','package_sha256':h(s/'package.json'),'package_archive_member':'startup-package-v2/package.json','argv':env['argv'],'environment':env['environment'],'digest_origin':'generated and supplied by private constructor for benign check; not trusted external deployment authority','required_external_immutable_record':None,'snapshot_root':str(s/'snapshot'),'actual_status':env['launch_status'],'runtime_payload':'not generated; inherited payload is input-inventory provenance only','limitations':env['limitations']}
(package/'startup-binding-proposal.json').write_text(json.dumps(startup,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('private_synthetic_attempts','project_loaded_origins')},indent=2))
