from pathlib import Path
import json,hashlib,subprocess,tarfile
r=Path.cwd();w=Path('/tmp/u4-a-activation-ready-8QayET');incident=json.loads((r/'docs/reviews/U4-component-activation-readiness-coordination-v1/incident-container-removal.json').read_bytes());patterns=[value for row in incident['containers'] for value in (row['container_id'],row['owner'])];(w/'incident-patterns.txt').write_text('\n'.join(patterns)+'\n')
roots=[Path('/tmp')/name for name in ['u4-a-stage2-9gmk3t0h','u4-a-stage2-final-w9APbO','u4-a-resource-join-scbwDm','u4-a-runtime-stage2-46c5abb','u4-a-runtime-resource-4d447ba','u4-a-runtime-build-cc899d2','u4-a-runtime-build-c67d558']];present=[p for p in roots if p.exists()]
argv=['rg','--files-with-matches','--fixed-strings','--file',str(w/'incident-patterns.txt'),'--glob','!**/source/**','--glob','!**/cache/**','--glob','!**/targets/**','--glob','*.json','--glob','*.jsonl','--glob','*.stdout','--glob','*.stderr','--glob','*.log','--glob','*.txt',*[str(p) for p in present]]
p=subprocess.run(argv,capture_output=True);assert p.returncode in (0,1),p.stderr
matches=[]
for name in p.stdout.decode().splitlines():
 data=Path(name).read_bytes();hits=[x for x in patterns if x.encode() in data];matches.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'hits':hits})
archives=[r/'docs/reviews'/name/'evidence.tar.gz' for name in ['U4-A-component-runtime-stage2-v1','U4-A-component-runtime-stage2-v1/final-join-v2','U4-A-component-runtime-resource-join-v1','U4-A-component-runtime-final-integration-v1']];archive_records=[]
for path in archives:
 count=0
 with tarfile.open(path) as tar:
  for item in tar:
   if item.isfile():
    count+=1;data=tar.extractfile(item).read();hits=[x for x in patterns if x.encode() in data]
    if hits:matches.append({'archive':str(path.relative_to(r)),'member':item.name,'sha256':hashlib.sha256(data).hexdigest(),'hits':hits})
 archive_records.append({'path':str(path.relative_to(r)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'regular_members_searched':count})
report={'scope':'only explicitly listed owned Lane A retained runtime scratch/receipts and four owned evidence archives; no other sessions, Docker queries or mutations','searched_roots':[str(p) for p in present],'absent_roots':[str(p) for p in roots if not p.exists()],'rg_argv':argv,'matches':matches,'archives':archive_records,'incident_rows':[{**v,'ownership':'matched retained record' if any(v['container_id'] in x['hits'] or v['owner'] in x['hits'] for x in matches) else 'unknown; no retained match in bounded search'} for v in incident['containers']],'impact':'pending analysis of matches; missing/expired raw scratch cannot be reconstructed','new_containers_created':0}
(w/'incident-search.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'matches':matches,'archive_members':sum(v['regular_members_searched'] for v in archive_records)}))
