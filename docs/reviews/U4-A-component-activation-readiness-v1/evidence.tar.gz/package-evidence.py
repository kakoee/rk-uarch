import gzip,hashlib,io,json,tarfile
from pathlib import Path
work=Path('/tmp/u4-a-activation-ready-8QayET');repo=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a');package=repo/'docs/reviews/U4-A-component-activation-readiness-v1'
files=set()
for p in work.iterdir():
 if p.is_file() and p.name != 'evidence-packaging.log' and p.suffix in ('.py','.json','.stdout','.stderr','.log','.txt'):
  files.add(p)
for name in ('startup-package-draft','startup-package-final','startup-package-v2'):
 folder=work/name
 for p in folder.iterdir():
  if p.is_file():files.add(p)
 for relative in ('snapshot/project/component_inventory_entry.py','snapshot/project/native/tools/component_trusted_start.py'):
  files.add(folder/relative)
base=work/'pytest-final'
for p in base.rglob('*'):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(base)
 if len(rel.parts)==2 and p.suffix=='.json':files.add(p)
 elif len(rel.parts)>=3 and rel.parts[1] in ('attempt','forged','negative-attempt'):
  files.add(p)
 elif len(rel.parts)>=3 and rel.parts[1].startswith('initial-'):
  files.add(p)
# No copied third-party/cache/DSO binaries or full source exports in published archive.
index={str(p.relative_to(work)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(files)}
(package/'evidence-files.json').write_text(json.dumps(index,indent=2)+'\n')
archive=package/'evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p in sorted(files):
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(work)));info.size=len(data);info.mode=0o444;info.mtime=0;tar.addfile(info,io.BytesIO(data))
# Independently reopen every retained member, without modifying original evidence.
with tarfile.open(archive) as tar:
 members=[m for m in tar.getmembers() if m.isfile()]
 assert set(m.name for m in members)==set(index)
 for member in members:
  data=tar.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==index[member.name]['sha256'] and len(data)==index[member.name]['bytes']
print(json.dumps({'members':len(index),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
