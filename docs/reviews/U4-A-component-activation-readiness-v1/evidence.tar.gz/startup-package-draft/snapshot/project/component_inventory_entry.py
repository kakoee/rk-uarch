import json,sys
from pathlib import Path
from rkuarch.engines.native import component_image
from validation.component.observations_v3 import check_v3
print(json.dumps({'adapter':component_image.__file__,'checker':check_v3.__module__,'site':'site' in sys.modules,'modules':{n:getattr(m,'__file__',None) for n,m in sorted(sys.modules.copy().items())},'maps':Path('/proc/self/maps').read_text()},sort_keys=True))
