import hashlib,importlib,importlib.machinery,importlib.util,json,sys,types,typing
from pathlib import Path
modules={}
for name,module in sorted(sys.modules.copy().items()):
 spec=getattr(module,'__spec__',None)
 origin=getattr(spec,'origin',None)
 cached=getattr(module,'__cached__',None)
 modules[name]={'origin':origin,'cache_candidate':cached}
maps=Path('/proc/self/maps').read_text()
print(json.dumps({'modules':modules,'maps':maps,'executable':sys.executable,
 'prefix':sys.prefix,'sys_path':sys.path,'site_loaded':'site' in sys.modules,
 'flags':{'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,
 'dont_write_bytecode':sys.flags.dont_write_bytecode}},sort_keys=True))
