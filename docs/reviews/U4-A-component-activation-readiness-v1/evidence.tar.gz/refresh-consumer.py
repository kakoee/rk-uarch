import hashlib,json
from pathlib import Path
root=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
files=set()
for folder in ('contract/uarch_contract','validation/component','src/rkuarch/engines/native','native/tools'):
    files.update(p for p in (root/folder).glob('*.py') if not p.name.startswith('test_'))
files.update(root/'docs/reviews/U4-B-K2-parallel-first-use-v1'/p for p in ('parallel_core.py','resource_limits.py'))
record={'format':'component-activation-prospective-consumer/1','status':'A proposal; B final postimage review pending','execution_authority':False,'binary_binding':None,'files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}}
(root/'docs/reviews/U4-A-component-activation-readiness-v1/prospective-consumer-bindings.json').write_text(json.dumps(record,indent=2)+'\n')
