import hashlib,importlib.util,json,subprocess,sys,tempfile
from pathlib import Path
source=Path('/tmp/u4-a-activation-ready-8QayET/source-final')
repo=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
work=Path('/tmp/u4-a-activation-ready-8QayET')
site=repo/'.venv/lib/python3.12/site-packages'
sys.path[:0]=[str(source),str(source/'src'),str(source/'contract'),str(site)]
package=repo/'docs/reviews/U4-A-component-activation-readiness-v1'
proposal=package/'proposals'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def apply(label,patch,preimage=None,target=None):
 root=Path(tempfile.mkdtemp(prefix=label+'-',dir=work))
 if preimage is not None:
  path=root/target;path.parent.mkdir(parents=True);path.write_bytes(preimage)
 run=subprocess.run(['git','apply','--unsafe-paths',str(patch)],cwd=root,capture_output=True,text=True)
 assert run.returncode==0,run.stderr
 return root/target
# All paths are fixed proposal targets below fresh task-private directories.
target='src/rkuarch/engines/native/component_negative.py'
old=(source/'docs/reviews/U4-A-component-runtime-stage2-v1/final-join-v2/component_negative-v5.py.txt').read_bytes()
a=apply('D3-full',proposal/'D3-full-v6.patch',target=target)
b=apply('D3-delta',proposal/'D3-v5-to-v6.patch',old,target)
assert a.read_bytes()==b.read_bytes()==(proposal/'component_negative-v6.py.txt').read_bytes()
compile(a.read_bytes(),str(a),'exec')
checks={'D3_full_delta_postimage':h(a)}
for label,target,patch in [('ADR','docs/decisions/U0011-the-native-engine-core.md','U0011-activation-unapplied.patch'),('route','src/rkuarch/engines/native/component_runner.py','default-route-unapplied.patch'),('B-closure','validation/component/runtime_checks.py','B-closure-unapplied.patch')]:
 path=apply(label,proposal/patch,(source/target).read_bytes(),target)
 checks[label]={'preimage_sha256':h(source/target),'postimage_sha256':h(path)}
 if target.endswith('.py'):compile(path.read_bytes(),str(path),'exec')
 if label=='ADR':assert h(path)==json.loads((proposal/'ADR-prepost.json').read_bytes())['postimage_sha256']
 if label=='B-closure':
  spec=importlib.util.spec_from_file_location('proposed_runtime_checks',path)
  module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  pins=json.loads((package/'prospective-consumer-bindings.json').read_bytes())['files']
  module.verify_sources(source,pins)
  reduced=dict(pins);reduced.pop('native/tools/component_container_guard.py')
  try:module.verify_sources(source,reduced)
  except ValueError as e:assert 'complete matching consumer/structural closure' in str(e)
  else:raise AssertionError('missing guardian closure accepted')
  module.verify_sources(source,pins)
  checks['B-closure']['control']='matching78 accepted; guardian omission refused at closure; original78 restored accepted'
# Verify B published preparation leaves; their statements remain attributed to B.
base=source/'docs/reviews/U4-B-component-activation-readiness-v1'
manifest=json.loads((base/'manifest.json').read_bytes())
checks['B_manifest_format']=list(manifest)
# Retain final origins for every loaded project consumer in this proposal audit.
origins={}
for name,m in sorted(sys.modules.copy().items()):
 if name.split('.')[0] in ('rkuarch','uarch_contract','validation','native') and getattr(m,'__file__',None):
  p=Path(m.__file__).resolve();assert p.is_relative_to(source),(name,p)
  origins[name]={'path':str(p),'sha256':h(p)}
checks['origins']=origins
(work/'proposal-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({k:v for k,v in checks.items() if k!='origins'},indent=2))
