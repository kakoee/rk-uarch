import difflib,hashlib,json,subprocess
from pathlib import Path
root=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
source=Path('/tmp/u4-a-activation-ready-8QayET/source-final')
package=root/'docs/reviews/U4-A-component-activation-readiness-v1'
work=Path('/tmp/u4-a-activation-ready-8QayET')
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,value): p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
old=json.loads(Path('/tmp/u4-a-runtime-resource-4d447ba/source/private-component/BuildInputs.json').read_bytes())
paths=set()
for parent in ('native','src/rkuarch','contract/uarch_contract','validation'):
 paths.update(p for p in (source/parent).rglob('*') if p.is_file() and p.suffix in ('.rs','.toml','.lock','.py','.json') and 'generated' not in p.parts)
paths.update(source/n for n in ('pyproject.toml','uv.lock'))
paths.update(source/'docs/reviews/U4-A-K2-construction-v1/inputs'/n for n in ('rustc-wrapper.sh','linker.sh'))
paths.update(source/'docs/reviews/U4-B-K2-parallel-first-use-v1'/n for n in ('parallel_core.py','resource_limits.py'))
current={str(p.relative_to(source)):h(p) for p in sorted(paths)}
previous={r['path']:r['byte_hash'].removeprefix('sha256:') for r in old['source_files']}
changes=[dict(path=p,previous_sha256=previous.get(p),prospective_sha256=current.get(p),kind='added' if p not in previous else 'removed' if p not in current else 'changed') for p in sorted(current.keys()|previous.keys()) if current.get(p)!=previous.get(p)]
consumer=json.loads((package/'prospective-consumer-bindings.json').read_bytes())['files']
oldconsumer=json.loads((source/'docs/reviews/U4-B-component-runtime-stage2-join-v1/prospective-consumer-bindings.json').read_bytes())['files']
consumer_changes=[dict(path=p,previous_sha256=oldconsumer.get(p),prospective_sha256=consumer.get(p)) for p in sorted(consumer.keys()|oldconsumer.keys()) if consumer.get(p)!=oldconsumer.get(p)]
write(package/'source-input-delta.json',dict(format='A-activation-prospective-source-inventory/1',source_commit=commit,
 inherited_source='4d447ba0a75200fec09b07314ca8bee654224a66',build_inputs_generated=False,new_engine_identity=None,new_executables=None,
 source_files=current,previous_count=len(previous),prospective_count=len(current),unchanged_count=sum(previous.get(p)==v for p,v in current.items()),changes=changes,
 consumer_count=len(consumer),old_consumer_count=len(oldconsumer),consumer_changes=consumer_changes,
 runtime_source_changes=[r['path'] for r in changes if not r['path'].startswith('validation/component/test_')],
 validation_test_changes=[r['path'] for r in changes if r['path'].startswith('validation/component/test_')],
 test_only_paths=subprocess.check_output(['git','diff','--name-only','4d447ba',commit,'--','tests'],cwd=root,text=True).splitlines(),
 note='Prospective inventory, not BuildInputs/engine identity; future finalized proposal installations change it again.'))
# Exact unapplied ADR addition; no live protected path is changed.
p=Path('docs/decisions/U0011-the-native-engine-core.md');before=(source/p).read_text()
addition='''

## Prospective component ordinary-image activation amendment

This addition requires exact separate human installation. It creates no execution
permission. Historical component decisions, /2 consumers, selections and receipts
retain their original subjects; K2 authority cannot authorize a component identity.

The component /3 production route shall use the accepted digest-pinned native image
and ordinary debug/release executables with one admitted saved stdin stream and EOF.
Private cfg(test) witnesses shall not supply ordinary-process entry counts. Consume
success through structural validation, the matching /3 checker and independently
frozen literals/input/full-engine anchors. Retain bounded attempts and complete
framing, streams, status, slot, resource and exact-created-ID cleanup evidence before
interpretation. Reopen and independently consume all six bound initial receipts
before replay; preserve failed attempts and the historical 124/1368 schedule.
The 120/1344 proposal remains unapproved. Public acceptance requires a separately
reviewed ordinary-EOF campaign contract and implementation, not private acceptance/1.

The Python bootstrap (including typing's compatibility pseudo-modules), interpreter,
stdlib/cache candidates, extensions, loader/DSOs and configuration require external
immutable bindings. An externally supplied manifest digest is not self-authorizing;
private read-only copies and a benign import launch do not establish immutable
placement, exhaustive loaded-code assurance or A-F3 closure. The stopped real-D11
startup-substitution/defense-revert activity remains deferred and must not be retried,
transferred or replaced with an ordinary positive claim. Required unavailable evidence
continues to block public first use unless separately resolved by the original reviewer
and exact human decisions; this amendment supplies no waiver.

D3 inventory/2, record/2, selector/2 and exact envelope/provenance laws remain separate.
The prospective v6 adapter uses the same ordinary EOF transport but leaves entry/site
observations unobserved. An expected zero-entry value, exact message, null pointer or
source hash does not establish universal guard reach. D3 installation, review and
execution permission require their own exact subject and decision.

Before activation source freeze, reconcile A/B adapter, consumer, preparation,
validation-test, startup and any installed proposal postimages. Then bind actual
BuildInputs, generated identity, accepted tools/lock/cache/features and a reviewed
full-ID capture ledger/monitor. No historical binary inherits later source identities.
Capture/build execution, root placement, immutable public environment, genuine
selector/HostRecord/profile authority and public campaign are separate gates. Missing
construction reads and the three historical candidate-03 gaps remain unresolved.
The /2 same-engine/same-instant acquired-release first-use restriction applies in all
directions, including write/write and unclassified cases; no /2 repair or waiver is
made. Genuine human L1 workings and U0024 remain unchanged; no qualification or U4
closure follows.
'''
after=before+addition
(package/'proposals/U0011-activation-unapplied.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+str(p),tofile='b/'+str(p))))
write(package/'proposals/ADR-prepost.json',dict(path=str(p),preimage_sha256=hashlib.sha256(before.encode()).hexdigest(),postimage_sha256=hashlib.sha256(after.encode()).hexdigest(),installed=False))
# Finite schema for the source-produced record. B campaign admission is separately pending.
stream={'type':['object','null'],'properties':{'path':{'type':'string'},'byte_hash':{'type':'string'},'observed_bytes':{'type':'integer','minimum':0},'retained_bytes':{'type':'integer','minimum':0},'truncated':{'type':'boolean'}},'required':['path','byte_hash','observed_bytes','retained_bytes','truncated']}
properties={k:{} for k in ('engine','mode','payload_byte_hash','executable_byte_hash','raw_input','entry_evidence','argv','timeout_s','resources','started_monotonic','deadline_monotonic','guardian_records','admitted','slot','cleanup','replay_descriptor','expected_envelope','expectation_provenance','case_id','error','zero_dispatch')}
properties.update(format={'const':'component-eof-attempt/1'},transport_kind={'const':'ordinary-eof'},image={'const':'sha256:e9f69f41498334be985ed4d25973fe3fa3f6519e58c73e6a7b8397d871fa0523'},runtime_entries={'const':None},transport_complete={'type':'boolean'},validation_passed={'type':'boolean'},status={'type':['integer','null']},failure_stage={'type':['string','null']},container_id={'type':'string','pattern':'^[0-9a-f]{64}$'},process_identity={'type':'string'},stdout=stream,stderr=stream,ended_monotonic={'type':'number'},deadline_exceeded={'type':'boolean'},transport_error={'type':'string'},validation_error={'type':'string'},finalization_error={'type':'string'})
write(package/'attempt-schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'component-eof-attempt/1','description':'Producer record proposal. Source-labelled observations, not public acceptance or authority. Transport/admission failures may have null/missing observations. B must independently consume blobs and ledger.','type':'object','properties':properties,'additionalProperties':False,'required':['format','transport_kind','engine','image','mode','payload_byte_hash','executable_byte_hash','raw_input','runtime_entries','entry_evidence','transport_complete','validation_passed','status','cleanup','argv','timeout_s','resources','started_monotonic','deadline_monotonic','failure_stage','guardian_records','slot','admitted']})
# Finalize bounded incident conclusion without touching the original reviewer receipt.
j=json.loads((work/'incident-search.json').read_bytes());j['impact']='No exact ownership/token match within the explicitly searched own records. Origin and other impact remain unknown; absent/expired scratch and destroyed container contents cannot be reconstructed.'
write(package/'incident-audit.json',j)
print(json.dumps({'source':commit,'BuildInputs_count':len(current),'changes':changes,'consumer_count':len(consumer),'consumer_changes':consumer_changes},indent=2))
