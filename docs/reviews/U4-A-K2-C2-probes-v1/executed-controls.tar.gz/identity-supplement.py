"""Additional explicit registry self-field coverage; original corpus stays frozen."""
import sys,pathlib
N=pathlib.Path(pathlib.Path('/tmp/u4-c2-location').read_text());R=pathlib.Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
sys.path[:0]=[str(N/'reference/contract'),str(R/'.venv/lib/python3.12/site-packages')]
import hashlib,json,time
from uarch_contract import hashing as h,mapped as m
rows=[]
for rel,cls,field in [('contract/fixtures/mapped/registry.json',m.NativeTestRegistry,'registry_hash'),('docs/reviews/U4-B-K2-first-use-v1/fixtures/registry.json',m.NativeTestRegistry,'registry_hash'),('docs/reviews/U4-B-K2-first-use-v1/fixtures/profile.json',m.NativeTestProfile,'profile_hash')]:
    p=N/'reference'/rel;b=p.read_bytes();v=cls.model_validate(h.strict_json_loads(b)).model_dump(mode='json');h.verify_identity(v,field)
    canonical=h.canonical_json({k:x for k,x in v.items() if k!=field})
    rows.append({'id':'registry-profile-supplement:'+str(len(rows)),'family':'registry-profile-supplement','op':'identity','field':field,'source_path':rel,'source_sha256':hashlib.sha256(b).hexdigest(),'reference_carrier':cls.__name__,'hex':h.canonical_json(v).encode().hex(),'expected':{'status':'ok','canonical':canonical,'sha256':hashlib.sha256(canonical.encode()).hexdigest()}})
data=b''.join((json.dumps(r,ensure_ascii=True,separators=(',',':'))+'\n').encode() for r in rows)
(N/'vectors/identity-supplement.jsonl').write_bytes(data)
(N/'receipts/identity-supplement-freeze.json').write_text(json.dumps({'frozen_at_unix_ns':time.time_ns(),'sha256':hashlib.sha256(data).hexdigest(),'count':len(rows),'source_commit':json.loads((N/'receipts/inputs.json').read_text())['source_commit'],'reason':'Coverage review found registry uses test_only_specs, not profiles; original 20965 cases/outcomes unchanged. Add explicit installed/B registry and B profile self-field checks, frozen before first supplemental execution. No source/formatter/dependency/flag change.'},indent=2)+'\n')
print('Frozen identity supplement:',len(rows),hashlib.sha256(data).hexdigest())
