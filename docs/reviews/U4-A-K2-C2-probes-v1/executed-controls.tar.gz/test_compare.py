import copy
import importlib.util
spec=importlib.util.spec_from_file_location('comparison','/tmp/u4-c2-compare.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
v=[{'id':'x','family':'control','expected':{'status':'ok','canonical':'0.0','sha256':'literal-control-only'},'op':'canonical'}]
a=[{'id':'x','status':'ok','canonical':'0.0','sha256':'literal-control-only'}]
assert m.compare(v,a)['mismatch_count']==0
checks=0
for bad in [[],a+a,[dict(a[0],id='wrong')]]:
    try:m.compare(v,bad)
    except ValueError:checks+=1
    else:raise AssertionError('selection control accepted')
for field,value in [('canonical','-0.0'),('sha256','wrong'),('status','refuse')]:
    bad=copy.deepcopy(a);bad[0][field]=value
    assert m.compare(v,bad)['mismatch_count']==1;checks+=1
assert m.compare(v,a)['mismatch_count']==0
print(f'PASS: {checks} host comparison negative controls; positive restored; no native evidence')
