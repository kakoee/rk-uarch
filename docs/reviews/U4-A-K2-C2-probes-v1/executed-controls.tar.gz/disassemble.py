import importlib.util,json,pathlib
spec=importlib.util.spec_from_file_location('runner','/tmp/u4-c2-run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
for mode in ['debug','release']:
    binary='/target/'+mode+'/c2-probe'
    for tool,args in [('nm',['/usr/bin/nm','-n','-C','--defined-only',binary]),('objdump',['/usr/bin/objdump','-d','-C',binary]),('readelf',['/usr/bin/readelf','-h','-S','-n','-d',binary])]:
        p=r.run(mode+'-'+tool,args)
        assert p.returncode==0
