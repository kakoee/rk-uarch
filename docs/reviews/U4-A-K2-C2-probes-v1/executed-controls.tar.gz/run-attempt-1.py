"""Offline C2 command recorder; explicit operations only, no dependency updates."""
import hashlib,json,pathlib,subprocess,time,sys
R=pathlib.Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a');N=pathlib.Path(pathlib.Path('/tmp/u4-c2-location').read_text());P=N/'receipts'
BIN='/usr/local/rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,extra=(),stdin=None):
    cfg=json.loads((P/'container.json').read_text());argv=cfg['argv'][:]+list(extra)+list(args)
    if stdin is not None:argv.insert(argv.index('--rm')+1,'-i')
    t=time.time();p=subprocess.run(argv,env=cfg['environment'],input=stdin,capture_output=True)
    for ext,b in [('stdout',p.stdout),('stderr',p.stderr)]:(P/f'{name}.{ext}').write_bytes(b)
    commands=json.loads((P/'commands.json').read_text());commands.append({'name':name,'argv':argv,'environment':cfg['environment'],'exit_code':p.returncode,'seconds':round(time.time()-t,3),'stdout_sha256':sha(P/f'{name}.stdout'),'stderr_sha256':sha(P/f'{name}.stderr'),'stdin_sha256':hashlib.sha256(stdin).hexdigest() if stdin is not None else None,'network':'Docker --network none','lock_sha256_after':sha(N/'workspace/native/Cargo.lock')});(P/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(name,p.returncode,'seconds',round(time.time()-t,3),flush=True)
    if p.returncode:print(p.stderr.decode(errors='replace')[-6000:],flush=True)
    return p
if __name__=='__main__':
    action=sys.argv[1]
    if action=='prebuild':
        p=run('probe-rustfmt',[BIN+'rustfmt','--edition','2024','--emit','stdout','/work/native/crates/uarch-engine/src/bin/c2-probe.rs'])
        assert p.returncode==0
        data=p.stdout
        # rustfmt stdout includes a path heading when supplied a file: retain raw receipt, remove only that framing.
        if data.startswith(b'/work/native/'):
            data=data.split(b'\n\n',1)[1]
        (N/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs').write_bytes(data)
        p=run('probe-metadata',[BIN+'cargo','metadata','--locked','--offline','--format-version','1'])
        assert p.returncode==0
        actual=json.loads(p.stdout);accepted=json.loads((R/'docs/reviews/U4-A-K2-C1-precise-v1/metadata-full.stdout').read_text())
        assert actual['resolve']==accepted['resolve']
        assert len(actual['packages'])==36
        root=next(x for x in actual['packages'] if x['name']=='uarch-engine')
        assert len(root['targets'])==1 and root['targets'][0]['name']=='c2-probe' and root['targets'][0]['kind']==['bin']
        for p in actual['packages']:
            old=next(x for x in accepted['packages'] if x['id']==p['id'])
            assert p['features']==old['features'] and p['dependencies']==old['dependencies']
        assert sha(N/'workspace/native/Cargo.lock')=='cbe9a580e0c6209abdb34be23965c2fe2f75b5970819d2021c943e2e02d939be'
        run('compiler-cfg',[BIN+'rustc','--print','cfg','--target','x86_64-unknown-linux-gnu'])
        run('tool-versions',['/bin/sh','-c','/usr/bin/objdump --version; /usr/bin/readelf --version; /usr/bin/nm --version; /usr/bin/cc --version; /usr/bin/ld --version'])
        (P/'build-inputs.json').write_text(json.dumps({'probe_source_sha256':sha(N/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs'),'vectors_sha256':sha(N/'vectors/vectors.jsonl'),'lock_sha256':sha(N/'workspace/native/Cargo.lock'),'crate_manifest_sha256':sha(N/'workspace/native/crates/uarch-engine/Cargo.toml'),'workspace_manifest_sha256':sha(N/'workspace/native/Cargo.toml'),'metadata_resolve_exact_match':True,'only_target':'c2-probe binary; accepted uarch-engine package identity; no original engine source present','RUSTFLAGS':'-C debuginfo=1 -C linker=/controls/linker.sh','RUSTC_WRAPPER':'/controls/rustc-wrapper.sh','network':'none','cache':'read-only verified copy','freeze_precedes_build':True,'timestamp_ns':time.time_ns()},indent=2)+'\n')
    elif action in ['debug','release','test-debug','test-release']:
        release=action.endswith('release');flags=['--release'] if release else []
        extra=['RUSTFLAGS=-C debuginfo=1 -C linker=/controls/linker.sh','RUSTC_WRAPPER=/controls/rustc-wrapper.sh','C2_RUN_TAG='+action]
        if action.startswith('test-'):args=[BIN+'cargo','test','--locked','--offline','--bin','c2-probe','-vv',*flags]
        else:args=[BIN+'cargo','rustc','--locked','--offline','--bin','c2-probe','-vv','--message-format=json',*flags,'--','-C','link-arg=-Wl,-Map=/receipts/'+action+'.map']
        p=run('build-'+action,args,extra)
        raise SystemExit(p.returncode)
    elif action.startswith('execute-'):
        mode=action.removeprefix('execute-');p=run(action,['/target/'+mode+'/c2-probe'],stdin=(N/'vectors/vectors.jsonl').read_bytes());raise SystemExit(p.returncode)
