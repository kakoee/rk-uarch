import collections,hashlib,importlib.util,json,pathlib
N=pathlib.Path(pathlib.Path('/tmp/u4-c2-location').read_text());P=N/'receipts'
spec=importlib.util.spec_from_file_location('compare',N/'controls/compare.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
v=[json.loads(x) for x in (N/'vectors/vectors.jsonl').read_text().splitlines()]
for mode in ['debug','release']:
    results=[json.loads(x) for x in (P/f'execute-{mode}.stdout').read_text().splitlines()]
    analysis=m.compare(v,results)
    (P/f'comparison-{mode}.json').write_text(json.dumps(analysis,indent=2)+'\n')
    print(mode,analysis['count'],'mismatches',analysis['mismatch_count'],dict(collections.Counter(x['family'] for x in analysis['mismatches'])))
    for family in sorted({x['family'] for x in analysis['mismatches']}):
        first=next(x for x in analysis['mismatches'] if x['family']==family)
        vector=next(x for x in v if x['id']==first['id'])
        print(json.dumps({'family':family,'input':{k:x for k,x in vector.items() if k not in ['expected']},'comparison':first},ensure_ascii=True)[:1800])
assert (P/'execute-debug.stdout').read_bytes()==(P/'execute-release.stdout').read_bytes()
print('Debug/release raw outcomes byte-identical')
