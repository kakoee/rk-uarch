import collections,hashlib,importlib.util,json,pathlib,re
N=pathlib.Path(pathlib.Path('/tmp/u4-c2-location').read_text());P=N/'receipts'
spec=importlib.util.spec_from_file_location('runner','/tmp/u4-c2-run.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
for mode in ['debug','release']:
    p=runner.run(mode+'-relocations',['/usr/bin/readelf','-r','-W','/target/'+mode+'/c2-probe']);assert p.returncode==0
    text=(P/f'{mode}-objdump.stdout').read_text(); functions={}; name=None
    for line in text.splitlines():
        match=re.match(r'^([0-9a-f]+) <(.+)>:$',line)
        if match:
            name=match[2];functions[name]={'address':match[1],'lines':[line]}
        elif name:functions[name]['lines'].append(line)
    selected={k:v for k,v in functions.items() if k=='c2_sha256_boundary' or k.startswith('sha2::sha256::')}
    (P/f'{mode}-hash-path.asm').write_text('\n'.join('\n'.join(v['lines']) for v in selected.values())+'\n')
    stats=[]
    for name,record in selected.items():
        xmm=[line for line in record['lines'] if re.search(r'%(?:xmm|ymm|zmm|mm)[0-9]',line)]
        ops=collections.Counter()
        for line in xmm:
            parts=line.split('\t')
            if len(parts)>=3:ops[parts[2].split()[0]]+=1
        stats.append({'symbol':name,'address':record['address'],'simd_register_instruction_count':len(xmm),'simd_mnemonics':dict(ops),'simd_lines':xmm,'calls':[line for line in record['lines'] if re.search(r'\bcall\s',line)]})
    # Relative relocations resolve RIP-relative GOT references independently of symbol spelling.
    relocs={}
    for line in (P/f'{mode}-relocations.stdout').read_text().splitlines():
        match=re.match(r'\s*([0-9a-f]+)\s+[0-9a-f]+\s+R_X86_64_RELATIVE\s+([0-9a-f]+)\s*$',line)
        if match:relocs[int(match[1],16)]=int(match[2],16)
    symbols={int(v['address'],16):k for k,v in functions.items()}
    edges=[]
    for name,record in functions.items():
        for line in record['lines']:
            direct=re.search(r'\b(?:call|jmp)\s+([0-9a-f]+)\s+<',line)
            rip=re.search(r'#\s*([0-9a-f]+)\s+<',line)
            if direct and int(direct[1],16) in symbols:edges.append({'from':name,'to':symbols[int(direct[1],16)],'kind':'direct call/jump','instruction':line})
            elif rip and int(rip[1],16) in relocs and relocs[int(rip[1],16)] in symbols:
                edges.append({'from':name,'to':symbols[relocs[int(rip[1],16)]],'kind':'RIP-relative relocated function pointer reference; call or load','instruction':line,'relocation_slot':rip[1],'relocation_target':f'{relocs[int(rip[1],16)]:x}'})
    reachable={'c2_sha256_boundary'}
    while True:
        new=reachable|{e['to'] for e in edges if e['from'] in reachable}
        if new==reachable:break
        reachable=new
    assert 'sha2::sha256::compress256' in reachable
    local=[e for e in edges if e['from'] in reachable]
    report={'mode':mode,'binary_sha256':hashlib.sha256((N/f'target/{mode}/c2-probe').read_bytes()).hexdigest(),'binary_bytes':(N/f'target/{mode}/c2-probe').stat().st_size,'selected_symbols':stats,'compress256_reachable_by_direct_or_relocated_pointer_edges':True,'reachable_symbol_count':len(reachable),'hash_related_reachable':[s for s in sorted(reachable) if any(x in s for x in ['sha2','digest::','block_buffer','c2_sha256'])],'reachable_edges':local,'limitation':'Conservative static direct-call and relocation-pointer reachability, not dynamic instruction tracing; arbitrary register-indirect targets and libc internals are not exhaustively resolved. Full disassembly/ELF/maps retained privately.'}
    (P/f'{mode}-software-path.json').write_text(json.dumps(report,indent=2)+'\n')
    print(mode,'reachable',len(reachable),'hash symbols',len(selected),'SIMD summaries',[(x['symbol'],x['simd_mnemonics']) for x in stats if x['simd_register_instruction_count']])
