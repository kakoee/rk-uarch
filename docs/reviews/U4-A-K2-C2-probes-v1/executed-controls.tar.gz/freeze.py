"""Freeze C2 inputs/expectations from pinned consumer/reference modules only."""
import sys
from pathlib import Path
N=Path('/tmp/u4-c2-location').read_text(); N=Path(N)
R=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
sys.path[:0]=[str(N/'reference/contract'),str(R/'.venv/lib/python3.12/site-packages')]
import copy,hashlib,importlib.metadata,itertools,json,math,platform,random,struct,time
from pydantic import TypeAdapter, Field
from typing import Annotated
from uarch_contract import hashing as h
from uarch_contract import mapped as m
from uarch_contract.sourced import SourcedValue
P=N/'receipts'; V=N/'vectors'; rows=[]; bindings={}; counts={}
def sha(b):return hashlib.sha256(b).hexdigest()
def emit(family,op,payload,**extra):
    row={'id':f'{family}:{counts.get(family,0):05d}','family':family,'op':op,**payload,**extra}
    counts[family]=counts.get(family,0)+1
    layer='decode'
    try:
        if op=='sha':
            row['expected']={'status':'ok','sha256':sha(bytes.fromhex(row['hex']))}
            rows.append(row);return
        if op=='float': value=struct.unpack('>d',bytes.fromhex(row['bits']))[0]
        else: value=h.strict_json_loads(bytes.fromhex(row['hex']))
        layer='carrier'
        if op=='u128':value=TypeAdapter(Annotated[int,Field(strict=True,ge=0,lt=2**128)]).validate_python(value)
        if op=='rational':value=m.RationalValue.model_validate(value).model_dump(mode='json')
        if op=='leaf':value=m.NumericLeaf.model_validate(value).model_dump(mode='json')
        if op=='sourced':value=SourcedValue.model_validate(value).model_dump(mode='json')
        if op=='marker':
            # Installed generic Python accepts an object; protocol additionally requires reserved-marker refusal.
            row['python_generic']={'canonical':h.canonical_json(value),'meaning':'generic object only; never numeric marker authority'}
            raise ValueError('ReservedNumericMarkerRequiredRefusal')
        if op=='identity':
            layer='identity';h.verify_identity(value,row['field'])
        if op in ['identity','exclude']: value={k:v for k,v in value.items() if k!=row['field']}
        layer='canonical'; canonical=h.canonical_json(value)
        layer='utf8'; data=canonical.encode('utf-8')
        row['expected']={'status':'ok','canonical':canonical,'sha256':sha(data)}
    except Exception as exc:row['expected']={'status':'refuse','layer':layer,'error_type':type(exc).__name__,'message':str(exc)}
    rows.append(row)
def raw(family,op,text,**extra):emit(family,op,{'hex':text.encode('utf-8').hex()},**extra)
def val(family,op,value,**extra):raw(family,op,json.dumps(value,ensure_ascii=True,separators=(',',':'),allow_nan=True),**extra)
# First freeze the installed two known answers without regenerating producer outputs.
cvpath=N/'reference/contract/fixtures/mapped/canonical-vectors.json'; bindings[str(cvpath.relative_to(N/'reference'))]=sha(cvpath.read_bytes())
for known in json.loads(cvpath.read_text()):
    raw('installed-canonical','canonical',known['input_json'])
    assert rows[-1]['expected']['canonical']==known['canonical_utf8']
    assert 'sha256:'+rows[-1]['expected']['sha256']==known['sha256']
models={'component.json':m.MappedBundle,'kernel.json':m.MappedBundle,'resident.json':m.MappedBundle,'transport.json':m.MappedBundle,'component-job.json':m.MappedEngineJob,'kernel-job.json':m.MappedEngineJob,'profile.json':m.NativeTestProfile,'resident-profile.json':m.NativeTestProfile,'transport-profile.json':m.NativeTestProfile,'registry.json':m.NativeTestRegistry}
fixtures=list(sorted((N/'reference/contract/fixtures/mapped').glob('*.json')))
bundles=list(sorted((N/'reference/docs/reviews/U4-B-K2-first-use-v1/fixtures/bundles').glob('*.json')))
assert len(bundles)==113
fixture_normalizations=[]
for file in fixtures+bundles:
    if file.name=='canonical-vectors.json':continue
    path=str(file.relative_to(N/'reference')); data=file.read_bytes(); bindings[path]=sha(data)
    value=h.strict_json_loads(data)
    model=m.MappedBundle if file in bundles else models[file.name]
    normalized=model.model_validate(value).model_dump(mode='json')
    family='B113' if file in bundles else 'installed-M'
    val(family,'canonical',normalized,source_path=path,source_sha256=sha(data),reference_carrier=model.__name__,meaning='canonical probe of Python-validated normalized carrier; not a Rust full-carrier validator')
    fixture_normalizations.append({'path':path,'source_sha256':sha(data),'carrier':model.__name__,'normalized_sha256':sha(h.canonical_json(normalized).encode()),'raw_equals_normalized':h.canonical_json(value)==h.canonical_json(normalized)})
    def identities(v,pointer=''):
        if isinstance(v,dict):
            field=None
            if v.get('format')=='uarch-prepared/3':field='bundle_hash'
            elif v.get('format')=='uarch-mapped-assumptions/1':field='assumptions_hash'
            elif v.get('protocol')=='uarch-engine/3':field='job_hash'
            elif 'payload_hash' in v and 'task_graph' in v:field='payload_hash'
            elif 'graph_hash' in v and 'jobs' in v:field='graph_hash'
            elif 'profile_hash' in v and 'entries' in v:field='profile_hash'
            elif 'registry_hash' in v and 'profiles' in v:field='registry_hash'
            if field:val('fixture-identities','identity',v,field=field,source_path=path,pointer=pointer)
            for k,x in v.items():identities(x,pointer+'/'+k)
        elif isinstance(v,list):
            for i,x in enumerate(v):identities(x,pointer+'/'+str(i))
    identities(normalized)
# Integer/token distinctions, exact u128 and the installed rational union.
integers=[0,1,2**53-1,2**53,2**53+1,2**64-1,2**128-1]
for n in integers:
    val('integer-generic','canonical',n);val('integer-u128','u128',n)
    val('rational','rational',{'numerator':n,'denominator':1})
    val('leaf','leaf',{'path':'test.rational','value':{'numerator':n,'denominator':1}})
for n in [-1,2**128,True,'1',1.0,None]:val('integer-refusal','u128',n)
for token in ['1e0','1.00','-0','-0.0']:raw('integer-token','u128',token)
for v in [{'numerator':1,'denominator':0},{'numerator':2,'denominator':4},{'numerator':1},{'numerator':1,'denominator':2,'extra':0},{'numerator':True,'denominator':1},{'numerator':'1','denominator':1}]:val('rational-refusal','rational',v)
# Explicit binary64 inputs preserve negative zero and avoid textual pre-rounding.
def bits(f):return struct.pack('>d',f).hex()
def floating(family,b):emit(family,'float',{'bits':f'{b:016x}'})
interesting=[0.0,-0.0,1e-4,1e-5,1e15,1e16,1e-7,1e20,sys.float_info.max,sys.float_info.min,math.ulp(0.0),0.1,0.3,1.0000000000000002,1.2345678901234567]
for f in interesting:
    for x in [math.nextafter(f,-math.inf),f,math.nextafter(f,math.inf)]:
        if math.isfinite(x):floating('float-boundary',int(bits(x),16))
# Every finite IEEE binary exponent boundary and adjacent representable mantissas, both signs.
for exponent in range(2047):
    pivot=exponent<<52
    for b in sorted({max(0,pivot-1),pivot,pivot+1}):
        for sign in [0,1<<63]:floating('binary-exponent-boundary',b|sign)
# Decimal exponent boundaries too: avoids treating the word 'exponent' as binary-only.
for e in range(-324,309):
    x=float('1e'+str(e))
    for f in [math.nextafter(x,-math.inf),x,math.nextafter(x,math.inf)]:
        if math.isfinite(f):
            floating('decimal-exponent-boundary',int(bits(f),16));floating('decimal-exponent-boundary',int(bits(-f),16))
seed=0x5534433250524f42;rng=random.Random(seed); seen=set(); rejected=0
while len(seen)<4096:
    b=rng.getrandbits(64)
    if (b>>52)&2047==2047 or b in seen:rejected+=1;continue
    seen.add(b);floating('finite-sweep',b)
for token in ['1.00000000000000011102230246251565404236316680908203125','1.00000000000000033306690738754696212708950042724609375','9007199254740993.0','2.2250738585072012e-308']:
    raw('halfway-decimal','canonical',token)
for token in ['NaN','Infinity','-Infinity','1e999']:raw('nonfinite-token','canonical',token)
for f in [float('nan'),float('inf'),-float('inf')]:floating('nonfinite-bits',int(bits(f),16))
for value in ['μ','😀','\u2028','"','/','\\',*[chr(i) for i in range(32)],'e\u0301','é']:val('strings','canonical',value)
for text in ['"\\ud800"','"\\udfff"','{"\\ud800":1}','"\\ud83d\\ude00"']:raw('unicode-escape','canonical',text)
for b in [b'"\xff"',b'"\xc0\x80"',b'"\xed\xa0\x80"']:emit('invalid-utf8','canonical',{'hex':b.hex()})
for order in itertools.permutations(['z','μ','a']):val('key-permutations','canonical',{k:i for k,i in [(k,{'z':1,'μ':2,'a':3}[k]) for k in order]})
for text in ['{"a":1,"a":2}','{"outer":{"a":1,"a":2}}','{"a":1,"\\u0061":2}']:raw('duplicates','canonical',text)
for text in ['{"$serde_json::private::Number":"1"}','{"$serde_json::private::Number":"340282366920938463463374607431768211455"}','{"\\u0024serde_json::private::Number":"1"}','{"n":{"$serde_json::private::Number":"1"}}']:raw('reserved-marker','marker',text)
for token in ['1','1.0','1e0','0.10','1e-1','-0.0']:
    raw('typed-normalization','sourced','{"value":'+token+',"unit":"Hz","kind":"stipulation","rationale":"C2 test only"}')
for v in [{'value':1,'unit':'Hz','kind':'stipulation','rationale':'C2 test only','extra':1},{'unit':'Hz','kind':'stipulation','rationale':'C2 test only'},{'value':True,'unit':'Hz','kind':'stipulation','rationale':'C2 test only'},{'value':'1.0','unit':'Hz','kind':'stipulation','rationale':'C2 test only'}]:val('typed-normalization-fault','sourced',v)
# Explicit top-level exclusion; nested self hashes remain causal bytes.
body={'format':'synthetic-c2/1','nested':{'own_hash':'sha256:'+'a'*64,'value':1}}
body['own_hash']=h.content_hash(body)
val('closure','identity',body,field='own_hash')
for mutation in ['stale','nested','version','self-reference']:
    bad=copy.deepcopy(body)
    if mutation=='stale':bad['own_hash']='sha256:'+'0'*64
    if mutation=='nested':bad['nested']['own_hash']='sha256:'+'b'*64
    if mutation=='version':bad['format']='synthetic-c2/2'
    if mutation=='self-reference':bad['nested']['own_hash']=bad['own_hash']
    val('closure-refusal','identity',bad,field='own_hash',mutation=mutation)
for value in [b'',b'abc',b'abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq',b'a'*1000000]:emit('SHA-known-answer','sha',{'hex':value.hex()})
# Exact f64/parser disagreements are evidence: no case is removed after execution.
vector_bytes=b''.join((json.dumps(r,ensure_ascii=True,separators=(',',':'))+'\n').encode() for r in rows)
(V/'vectors.jsonl').write_bytes(vector_bytes)
origins={}
for name,module in sorted(sys.modules.items()):
    file=getattr(module,'__file__',None)
    if file and Path(file).is_file():
        file=Path(file).resolve();origins[name]={'path':str(file),'sha256':sha(file.read_bytes())}
        if name.startswith('uarch_contract'):assert file.is_relative_to(N/'reference/contract')
assert not any(name.startswith(('rkuarch.prepare','rkuarch.models','rkuarch.mapper')) for name in sys.modules)
freeze={'frozen_at_unix_ns':time.time_ns(),'source_commit':json.loads((P/'inputs.json').read_text())['source_commit'],'vectors_sha256':sha(vector_bytes),'vector_count':len(rows),'families':counts,'finite_sweep':{'count':4096,'seed_hex':hex(seed),'method':'Python random.Random(seed).getrandbits(64), MT19937; discard exponent2047 and duplicates; binary64 big-endian decoding','discarded':rejected},'reference':{'executable':sys.executable,'executable_realpath':str(Path(sys.executable).resolve()),'executable_sha256':sha(Path(sys.executable).resolve().read_bytes()),'version':sys.version,'platform':platform.platform(),'pydantic':importlib.metadata.version('pydantic'),'uv_lock_sha256':sha((N/'reference/uv.lock').read_bytes()),'import_origins':origins},'fixture_bindings':bindings,'fixture_normalizations':fixture_normalizations,'known_limits':'Full installed carriers normalize in pinned Python; Rust fixture path tests canonical/field-hash bytes only. Standalone Rust small carriers exercise typed numerics/defaults; no native engine DTOs or workload execution. No producer/oracle workflow imported.'}
(P/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps({'vector_count':len(rows),'families':counts,'sha256':sha(vector_bytes),'bytes':len(vector_bytes)},indent=2))
