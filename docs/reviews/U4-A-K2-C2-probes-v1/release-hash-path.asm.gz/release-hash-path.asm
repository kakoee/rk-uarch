0000000000033c20 <c2_sha256_boundary>:
   33c20:	41 57                	push   %r15
   33c22:	41 56                	push   %r14
   33c24:	41 55                	push   %r13
   33c26:	41 54                	push   %r12
   33c28:	53                   	push   %rbx
   33c29:	48 81 ec 20 01 00 00 	sub    $0x120,%rsp
   33c30:	48 89 fb             	mov    %rdi,%rbx
   33c33:	4c 8d 74 24 28       	lea    0x28(%rsp),%r14
   33c38:	0f 57 c0             	xorps  %xmm0,%xmm0
   33c3b:	0f 11 44 24 58       	movups %xmm0,0x58(%rsp)
   33c40:	0f 11 44 24 48       	movups %xmm0,0x48(%rsp)
   33c45:	0f 11 44 24 38       	movups %xmm0,0x38(%rsp)
   33c4a:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
   33c4f:	c6 44 24 68 00       	movb   $0x0,0x68(%rsp)
   33c54:	0f 10 05 25 b7 fd ff 	movups -0x248db(%rip),%xmm0        # f380 <anon.0d7f450e29179d8b2735ef3023d34580.35.llvm.87189211340559906+0x13b>
   33c5b:	0f 29 04 24          	movaps %xmm0,(%rsp)
   33c5f:	0f 10 05 2a b7 fd ff 	movups -0x248d6(%rip),%xmm0        # f390 <anon.0d7f450e29179d8b2735ef3023d34580.35.llvm.87189211340559906+0x14b>
   33c66:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   33c6b:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   33c72:	00 00 
   33c74:	48 83 fa 40          	cmp    $0x40,%rdx
   33c78:	73 08                	jae    33c82 <c2_sha256_boundary+0x62>
   33c7a:	4c 89 f7             	mov    %r14,%rdi
   33c7d:	49 89 d4             	mov    %rdx,%r12
   33c80:	eb 32                	jmp    33cb4 <c2_sha256_boundary+0x94>
   33c82:	49 bf c0 ff ff ff ff 	movabs $0x7fffffffffffffc0,%r15
   33c89:	ff ff 7f 
   33c8c:	49 21 d7             	and    %rdx,%r15
   33c8f:	41 89 d4             	mov    %edx,%r12d
   33c92:	41 83 e4 3f          	and    $0x3f,%r12d
   33c96:	49 01 f7             	add    %rsi,%r15
   33c99:	48 c1 ea 06          	shr    $0x6,%rdx
   33c9d:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
   33ca2:	48 89 e7             	mov    %rsp,%rdi
   33ca5:	ff 15 9d be 06 00    	call   *0x6be9d(%rip)        # 9fb48 <_DYNAMIC+0x3f8>
   33cab:	4c 89 f7             	mov    %r14,%rdi
   33cae:	4c 89 fe             	mov    %r15,%rsi
   33cb1:	4c 89 e2             	mov    %r12,%rdx
   33cb4:	ff 15 26 bd 06 00    	call   *0x6bd26(%rip)        # 9f9e0 <memcpy@GLIBC_2.14>
   33cba:	44 88 64 24 68       	mov    %r12b,0x68(%rsp)
   33cbf:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   33cc4:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   33ccb:	00 
   33ccc:	0f b6 44 24 68       	movzbl 0x68(%rsp),%eax
   33cd1:	88 84 24 d8 00 00 00 	mov    %al,0xd8(%rsp)
   33cd8:	8b 44 24 69          	mov    0x69(%rsp),%eax
   33cdc:	89 84 24 d9 00 00 00 	mov    %eax,0xd9(%rsp)
   33ce3:	0f b7 44 24 6d       	movzwl 0x6d(%rsp),%eax
   33ce8:	66 89 84 24 dd 00 00 	mov    %ax,0xdd(%rsp)
   33cef:	00 
   33cf0:	0f b6 44 24 6f       	movzbl 0x6f(%rsp),%eax
   33cf5:	88 84 24 df 00 00 00 	mov    %al,0xdf(%rsp)
   33cfc:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
   33d01:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
   33d06:	0f 28 54 24 20       	movaps 0x20(%rsp),%xmm2
   33d0b:	0f 28 5c 24 30       	movaps 0x30(%rsp),%xmm3
   33d10:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   33d17:	00 
   33d18:	0f 28 54 24 50       	movaps 0x50(%rsp),%xmm2
   33d1d:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
   33d24:	00 
   33d25:	0f 28 54 24 40       	movaps 0x40(%rsp),%xmm2
   33d2a:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
   33d31:	00 
   33d32:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
   33d39:	00 
   33d3a:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   33d41:	00 
   33d42:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
   33d48:	4c 8d b4 24 98 00 00 	lea    0x98(%rsp),%r14
   33d4f:	00 
   33d50:	44 0f b6 bc 24 d8 00 	movzbl 0xd8(%rsp),%r15d
   33d57:	00 00 
   33d59:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   33d60:	00 
   33d61:	48 c1 e0 09          	shl    $0x9,%rax
   33d65:	46 8d 24 fd 00 00 00 	lea    0x0(,%r15,8),%r12d
   33d6c:	00 
   33d6d:	49 09 c4             	or     %rax,%r12
   33d70:	49 0f cc             	bswap  %r12
   33d73:	42 c6 84 3c 98 00 00 	movb   $0x80,0x98(%rsp,%r15,1)
   33d7a:	00 80 
   33d7c:	41 83 ff 3f          	cmp    $0x3f,%r15d
   33d80:	74 27                	je     33da9 <c2_sha256_boundary+0x189>
   33d82:	4a 8d 3c 3c          	lea    (%rsp,%r15,1),%rdi
   33d86:	48 81 c7 98 00 00 00 	add    $0x98,%rdi
   33d8d:	48 ff c7             	inc    %rdi
   33d90:	4c 89 fa             	mov    %r15,%rdx
   33d93:	48 83 f2 3f          	xor    $0x3f,%rdx
   33d97:	31 f6                	xor    %esi,%esi
   33d99:	ff 15 b1 bd 06 00    	call   *0x6bdb1(%rip)        # 9fb50 <memset@GLIBC_2.2.5>
   33d9f:	41 83 f7 38          	xor    $0x38,%r15d
   33da3:	41 83 ff 07          	cmp    $0x7,%r15d
   33da7:	77 62                	ja     33e0b <c2_sha256_boundary+0x1eb>
   33da9:	4c 8b 2d 98 bd 06 00 	mov    0x6bd98(%rip),%r13        # 9fb48 <_DYNAMIC+0x3f8>
   33db0:	4c 8d 7c 24 70       	lea    0x70(%rsp),%r15
   33db5:	ba 01 00 00 00       	mov    $0x1,%edx
   33dba:	4c 89 ff             	mov    %r15,%rdi
   33dbd:	4c 89 f6             	mov    %r14,%rsi
   33dc0:	41 ff d5             	call   *%r13
   33dc3:	66 0f ef c0          	pxor   %xmm0,%xmm0
   33dc7:	66 0f 7f 84 24 00 01 	movdqa %xmm0,0x100(%rsp)
   33dce:	00 00 
   33dd0:	66 0f 7f 84 24 f0 00 	movdqa %xmm0,0xf0(%rsp)
   33dd7:	00 00 
   33dd9:	66 0f 7f 84 24 e0 00 	movdqa %xmm0,0xe0(%rsp)
   33de0:	00 00 
   33de2:	48 c7 84 24 10 01 00 	movq   $0x0,0x110(%rsp)
   33de9:	00 00 00 00 00 
   33dee:	4c 89 a4 24 18 01 00 	mov    %r12,0x118(%rsp)
   33df5:	00 
   33df6:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   33dfd:	00 
   33dfe:	ba 01 00 00 00       	mov    $0x1,%edx
   33e03:	4c 89 ff             	mov    %r15,%rdi
   33e06:	41 ff d5             	call   *%r13
   33e09:	eb 1b                	jmp    33e26 <c2_sha256_boundary+0x206>
   33e0b:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
   33e12:	00 
   33e13:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   33e18:	ba 01 00 00 00       	mov    $0x1,%edx
   33e1d:	4c 89 f6             	mov    %r14,%rsi
   33e20:	ff 15 22 bd 06 00    	call   *0x6bd22(%rip)        # 9fb48 <_DYNAMIC+0x3f8>
   33e26:	66 0f ef c0          	pxor   %xmm0,%xmm0
   33e2a:	66 0f 6f 4c 24 70    	movdqa 0x70(%rsp),%xmm1
   33e30:	66 0f 6f 94 24 80 00 	movdqa 0x80(%rsp),%xmm2
   33e37:	00 00 
   33e39:	66 0f 6f d9          	movdqa %xmm1,%xmm3
   33e3d:	66 0f 68 d8          	punpckhbw %xmm0,%xmm3
   33e41:	f2 0f 70 db 1b       	pshuflw $0x1b,%xmm3,%xmm3
   33e46:	f3 0f 70 db 1b       	pshufhw $0x1b,%xmm3,%xmm3
   33e4b:	66 0f 60 c8          	punpcklbw %xmm0,%xmm1
   33e4f:	f2 0f 70 c9 1b       	pshuflw $0x1b,%xmm1,%xmm1
   33e54:	f3 0f 70 c9 1b       	pshufhw $0x1b,%xmm1,%xmm1
   33e59:	66 0f 67 cb          	packuswb %xmm3,%xmm1
   33e5d:	66 0f 6f da          	movdqa %xmm2,%xmm3
   33e61:	66 0f 68 d8          	punpckhbw %xmm0,%xmm3
   33e65:	f2 0f 70 db 1b       	pshuflw $0x1b,%xmm3,%xmm3
   33e6a:	f3 0f 70 db 1b       	pshufhw $0x1b,%xmm3,%xmm3
   33e6f:	66 0f 60 d0          	punpcklbw %xmm0,%xmm2
   33e73:	f2 0f 70 c2 1b       	pshuflw $0x1b,%xmm2,%xmm0
   33e78:	f3 0f 70 c0 1b       	pshufhw $0x1b,%xmm0,%xmm0
   33e7d:	66 0f 67 c3          	packuswb %xmm3,%xmm0
   33e81:	f3 0f 7f 0b          	movdqu %xmm1,(%rbx)
   33e85:	f3 0f 7f 43 10       	movdqu %xmm0,0x10(%rbx)
   33e8a:	48 89 d8             	mov    %rbx,%rax
   33e8d:	48 81 c4 20 01 00 00 	add    $0x120,%rsp
   33e94:	5b                   	pop    %rbx
   33e95:	41 5c                	pop    %r12
   33e97:	41 5d                	pop    %r13
   33e99:	41 5e                	pop    %r14
   33e9b:	41 5f                	pop    %r15
   33e9d:	c3                   	ret
   33e9e:	cc                   	int3
   33e9f:	cc                   	int3

000000000004c9a0 <sha2::sha256::compress256>:
   4c9a0:	55                   	push   %rbp
   4c9a1:	41 57                	push   %r15
   4c9a3:	41 56                	push   %r14
   4c9a5:	41 55                	push   %r13
   4c9a7:	41 54                	push   %r12
   4c9a9:	53                   	push   %rbx
   4c9aa:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
   4c9b1:	44 8b 37             	mov    (%rdi),%r14d
   4c9b4:	8b 5f 04             	mov    0x4(%rdi),%ebx
   4c9b7:	44 8b 5f 08          	mov    0x8(%rdi),%r11d
   4c9bb:	8b 47 0c             	mov    0xc(%rdi),%eax
   4c9be:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   4c9c3:	8b 6f 10             	mov    0x10(%rdi),%ebp
   4c9c6:	44 8b 7f 14          	mov    0x14(%rdi),%r15d
   4c9ca:	44 8b 67 18          	mov    0x18(%rdi),%r12d
   4c9ce:	48 89 7c 24 68       	mov    %rdi,0x68(%rsp)
   4c9d3:	44 8b 6f 1c          	mov    0x1c(%rdi),%r13d
   4c9d7:	48 85 d2             	test   %rdx,%rdx
   4c9da:	0f 84 04 29 00 00    	je     4f2e4 <sha2::sha256::compress256+0x2944>
   4c9e0:	48 89 d0             	mov    %rdx,%rax
   4c9e3:	48 c1 e0 06          	shl    $0x6,%rax
   4c9e7:	48 01 f0             	add    %rsi,%rax
   4c9ea:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   4c9ef:	90                   	nop
   4c9f0:	48 89 ac 24 80 00 00 	mov    %rbp,0x80(%rsp)
   4c9f7:	00 
   4c9f8:	4c 89 9c 24 a0 00 00 	mov    %r11,0xa0(%rsp)
   4c9ff:	00 
   4ca00:	48 89 74 24 d8       	mov    %rsi,-0x28(%rsp)
   4ca05:	44 89 ef             	mov    %r13d,%edi
   4ca08:	44 89 6c 24 64       	mov    %r13d,0x64(%rsp)
   4ca0d:	8b 06                	mov    (%rsi),%eax
   4ca0f:	8b 4e 04             	mov    0x4(%rsi),%ecx
   4ca12:	0f c8                	bswap  %eax
   4ca14:	49 89 c0             	mov    %rax,%r8
   4ca17:	89 e8                	mov    %ebp,%eax
   4ca19:	c1 c0 1a             	rol    $0x1a,%eax
   4ca1c:	0f c9                	bswap  %ecx
   4ca1e:	49 89 c9             	mov    %rcx,%r9
   4ca21:	48 89 4c 24 f0       	mov    %rcx,-0x10(%rsp)
   4ca26:	89 e9                	mov    %ebp,%ecx
   4ca28:	c1 c1 15             	rol    $0x15,%ecx
   4ca2b:	31 c1                	xor    %eax,%ecx
   4ca2d:	89 ea                	mov    %ebp,%edx
   4ca2f:	c1 c2 07             	rol    $0x7,%edx
   4ca32:	31 ca                	xor    %ecx,%edx
   4ca34:	4d 89 e2             	mov    %r12,%r10
   4ca37:	4c 89 a4 24 88 00 00 	mov    %r12,0x88(%rsp)
   4ca3e:	00 
   4ca3f:	44 89 d0             	mov    %r10d,%eax
   4ca42:	4d 89 fd             	mov    %r15,%r13
   4ca45:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
   4ca4c:	00 
   4ca4d:	44 31 e8             	xor    %r13d,%eax
   4ca50:	21 e8                	and    %ebp,%eax
   4ca52:	44 31 d0             	xor    %r10d,%eax
   4ca55:	01 f8                	add    %edi,%eax
   4ca57:	01 d0                	add    %edx,%eax
   4ca59:	89 c1                	mov    %eax,%ecx
   4ca5b:	4c 89 44 24 b8       	mov    %r8,-0x48(%rsp)
   4ca60:	44 01 c0             	add    %r8d,%eax
   4ca63:	44 89 f2             	mov    %r14d,%edx
   4ca66:	c1 c2 1e             	rol    $0x1e,%edx
   4ca69:	44 01 c1             	add    %r8d,%ecx
   4ca6c:	81 c1 98 2f 8a 42    	add    $0x428a2f98,%ecx
   4ca72:	44 89 f7             	mov    %r14d,%edi
   4ca75:	c1 c7 13             	rol    $0x13,%edi
   4ca78:	31 d7                	xor    %edx,%edi
   4ca7a:	44 89 f2             	mov    %r14d,%edx
   4ca7d:	4d 89 f4             	mov    %r14,%r12
   4ca80:	c1 c2 0a             	rol    $0xa,%edx
   4ca83:	31 fa                	xor    %edi,%edx
   4ca85:	45 89 d8             	mov    %r11d,%r8d
   4ca88:	41 31 d8             	xor    %ebx,%r8d
   4ca8b:	45 21 e0             	and    %r12d,%r8d
   4ca8e:	44 89 df             	mov    %r11d,%edi
   4ca91:	21 df                	and    %ebx,%edi
   4ca93:	44 31 c7             	xor    %r8d,%edi
   4ca96:	01 d7                	add    %edx,%edi
   4ca98:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
   4ca9d:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   4caa2:	01 d0                	add    %edx,%eax
   4caa4:	05 98 2f 8a 42       	add    $0x428a2f98,%eax
   4caa9:	89 c2                	mov    %eax,%edx
   4caab:	c1 c2 1a             	rol    $0x1a,%edx
   4caae:	01 cf                	add    %ecx,%edi
   4cab0:	89 c1                	mov    %eax,%ecx
   4cab2:	c1 c1 15             	rol    $0x15,%ecx
   4cab5:	31 d1                	xor    %edx,%ecx
   4cab7:	89 c2                	mov    %eax,%edx
   4cab9:	c1 c2 07             	rol    $0x7,%edx
   4cabc:	31 ca                	xor    %ecx,%edx
   4cabe:	44 89 e9             	mov    %r13d,%ecx
   4cac1:	31 e9                	xor    %ebp,%ecx
   4cac3:	21 c1                	and    %eax,%ecx
   4cac5:	44 31 e9             	xor    %r13d,%ecx
   4cac8:	44 01 d1             	add    %r10d,%ecx
   4cacb:	44 01 c9             	add    %r9d,%ecx
   4cace:	44 8d 14 11          	lea    (%rcx,%rdx,1),%r10d
   4cad2:	01 d1                	add    %edx,%ecx
   4cad4:	81 c1 91 44 37 71    	add    $0x71374491,%ecx
   4cada:	89 fa                	mov    %edi,%edx
   4cadc:	c1 c2 1e             	rol    $0x1e,%edx
   4cadf:	41 89 f8             	mov    %edi,%r8d
   4cae2:	41 c1 c0 13          	rol    $0x13,%r8d
   4cae6:	41 31 d0             	xor    %edx,%r8d
   4cae9:	89 fa                	mov    %edi,%edx
   4caeb:	c1 c2 0a             	rol    $0xa,%edx
   4caee:	44 31 c2             	xor    %r8d,%edx
   4caf1:	41 89 d8             	mov    %ebx,%r8d
   4caf4:	45 21 e0             	and    %r12d,%r8d
   4caf7:	41 89 d9             	mov    %ebx,%r9d
   4cafa:	45 31 e1             	xor    %r12d,%r9d
   4cafd:	41 21 f9             	and    %edi,%r9d
   4cb00:	45 31 c1             	xor    %r8d,%r9d
   4cb03:	41 01 d1             	add    %edx,%r9d
   4cb06:	41 01 c9             	add    %ecx,%r9d
   4cb09:	43 8d 0c 13          	lea    (%r11,%r10,1),%ecx
   4cb0d:	81 c1 91 44 37 71    	add    $0x71374491,%ecx
   4cb13:	89 ca                	mov    %ecx,%edx
   4cb15:	c1 c2 1a             	rol    $0x1a,%edx
   4cb18:	41 89 ca             	mov    %ecx,%r10d
   4cb1b:	41 c1 c2 15          	rol    $0x15,%r10d
   4cb1f:	41 31 d2             	xor    %edx,%r10d
   4cb22:	41 89 c8             	mov    %ecx,%r8d
   4cb25:	41 c1 c0 07          	rol    $0x7,%r8d
   4cb29:	45 31 d0             	xor    %r10d,%r8d
   4cb2c:	8b 56 08             	mov    0x8(%rsi),%edx
   4cb2f:	0f ca                	bswap  %edx
   4cb31:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   4cb36:	49 89 df             	mov    %rbx,%r15
   4cb39:	48 89 9c 24 98 00 00 	mov    %rbx,0x98(%rsp)
   4cb40:	00 
   4cb41:	89 c3                	mov    %eax,%ebx
   4cb43:	31 eb                	xor    %ebp,%ebx
   4cb45:	21 cb                	and    %ecx,%ebx
   4cb47:	31 eb                	xor    %ebp,%ebx
   4cb49:	44 01 eb             	add    %r13d,%ebx
   4cb4c:	01 d3                	add    %edx,%ebx
   4cb4e:	45 89 ca             	mov    %r9d,%r10d
   4cb51:	41 c1 c2 1e          	rol    $0x1e,%r10d
   4cb55:	46 8d 1c 03          	lea    (%rbx,%r8,1),%r11d
   4cb59:	41 8d 34 18          	lea    (%r8,%rbx,1),%esi
   4cb5d:	81 c6 cf fb c0 b5    	add    $0xb5c0fbcf,%esi
   4cb63:	45 89 c8             	mov    %r9d,%r8d
   4cb66:	41 c1 c0 13          	rol    $0x13,%r8d
   4cb6a:	45 31 d0             	xor    %r10d,%r8d
   4cb6d:	45 89 ca             	mov    %r9d,%r10d
   4cb70:	41 c1 c2 0a          	rol    $0xa,%r10d
   4cb74:	45 31 c2             	xor    %r8d,%r10d
   4cb77:	41 89 f8             	mov    %edi,%r8d
   4cb7a:	4c 89 f2             	mov    %r14,%rdx
   4cb7d:	41 31 d0             	xor    %edx,%r8d
   4cb80:	45 21 c8             	and    %r9d,%r8d
   4cb83:	41 89 fe             	mov    %edi,%r14d
   4cb86:	41 21 d6             	and    %edx,%r14d
   4cb89:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
   4cb8e:	45 31 c6             	xor    %r8d,%r14d
   4cb91:	45 01 d6             	add    %r10d,%r14d
   4cb94:	45 01 fb             	add    %r15d,%r11d
   4cb97:	41 81 c3 cf fb c0 b5 	add    $0xb5c0fbcf,%r11d
   4cb9e:	45 89 d8             	mov    %r11d,%r8d
   4cba1:	41 c1 c0 1a          	rol    $0x1a,%r8d
   4cba5:	41 01 f6             	add    %esi,%r14d
   4cba8:	44 89 de             	mov    %r11d,%esi
   4cbab:	c1 c6 15             	rol    $0x15,%esi
   4cbae:	44 31 c6             	xor    %r8d,%esi
   4cbb1:	45 89 d8             	mov    %r11d,%r8d
   4cbb4:	41 c1 c0 07          	rol    $0x7,%r8d
   4cbb8:	41 31 f0             	xor    %esi,%r8d
   4cbbb:	48 8b 74 24 d8       	mov    -0x28(%rsp),%rsi
   4cbc0:	8b 76 0c             	mov    0xc(%rsi),%esi
   4cbc3:	0f ce                	bswap  %esi
   4cbc5:	48 89 74 24 88       	mov    %rsi,-0x78(%rsp)
   4cbca:	41 89 ca             	mov    %ecx,%r10d
   4cbcd:	41 31 c2             	xor    %eax,%r10d
   4cbd0:	45 21 da             	and    %r11d,%r10d
   4cbd3:	41 31 c2             	xor    %eax,%r10d
   4cbd6:	41 01 ea             	add    %ebp,%r10d
   4cbd9:	41 01 f2             	add    %esi,%r10d
   4cbdc:	44 89 f3             	mov    %r14d,%ebx
   4cbdf:	c1 c3 1e             	rol    $0x1e,%ebx
   4cbe2:	45 89 f7             	mov    %r14d,%r15d
   4cbe5:	41 c1 c7 13          	rol    $0x13,%r15d
   4cbe9:	47 8d 24 02          	lea    (%r10,%r8,1),%r12d
   4cbed:	45 01 d0             	add    %r10d,%r8d
   4cbf0:	41 81 c0 a5 db b5 e9 	add    $0xe9b5dba5,%r8d
   4cbf7:	44 89 f5             	mov    %r14d,%ebp
   4cbfa:	c1 c5 0a             	rol    $0xa,%ebp
   4cbfd:	41 31 df             	xor    %ebx,%r15d
   4cc00:	44 31 fd             	xor    %r15d,%ebp
   4cc03:	44 89 cb             	mov    %r9d,%ebx
   4cc06:	21 fb                	and    %edi,%ebx
   4cc08:	45 89 ca             	mov    %r9d,%r10d
   4cc0b:	41 31 fa             	xor    %edi,%r10d
   4cc0e:	45 21 f2             	and    %r14d,%r10d
   4cc11:	41 31 da             	xor    %ebx,%r10d
   4cc14:	42 8d 1c 22          	lea    (%rdx,%r12,1),%ebx
   4cc18:	81 c3 a5 db b5 e9    	add    $0xe9b5dba5,%ebx
   4cc1e:	41 89 df             	mov    %ebx,%r15d
   4cc21:	41 c1 c7 1a          	rol    $0x1a,%r15d
   4cc25:	41 01 ea             	add    %ebp,%r10d
   4cc28:	89 dd                	mov    %ebx,%ebp
   4cc2a:	c1 c5 15             	rol    $0x15,%ebp
   4cc2d:	45 01 c2             	add    %r8d,%r10d
   4cc30:	41 89 d8             	mov    %ebx,%r8d
   4cc33:	41 c1 c0 07          	rol    $0x7,%r8d
   4cc37:	44 31 fd             	xor    %r15d,%ebp
   4cc3a:	41 31 e8             	xor    %ebp,%r8d
   4cc3d:	4c 8b 7c 24 d8       	mov    -0x28(%rsp),%r15
   4cc42:	41 8b 57 10          	mov    0x10(%r15),%edx
   4cc46:	0f ca                	bswap  %edx
   4cc48:	89 54 24 e0          	mov    %edx,-0x20(%rsp)
   4cc4c:	44 89 dd             	mov    %r11d,%ebp
   4cc4f:	31 cd                	xor    %ecx,%ebp
   4cc51:	21 dd                	and    %ebx,%ebp
   4cc53:	31 cd                	xor    %ecx,%ebp
   4cc55:	01 d0                	add    %edx,%eax
   4cc57:	45 89 d7             	mov    %r10d,%r15d
   4cc5a:	41 c1 c7 1e          	rol    $0x1e,%r15d
   4cc5e:	01 e8                	add    %ebp,%eax
   4cc60:	44 89 d5             	mov    %r10d,%ebp
   4cc63:	c1 c5 13             	rol    $0x13,%ebp
   4cc66:	44 01 c0             	add    %r8d,%eax
   4cc69:	05 5b c2 56 39       	add    $0x3956c25b,%eax
   4cc6e:	45 89 d4             	mov    %r10d,%r12d
   4cc71:	41 c1 c4 0a          	rol    $0xa,%r12d
   4cc75:	44 31 fd             	xor    %r15d,%ebp
   4cc78:	41 31 ec             	xor    %ebp,%r12d
   4cc7b:	44 89 f5             	mov    %r14d,%ebp
   4cc7e:	44 31 cd             	xor    %r9d,%ebp
   4cc81:	44 21 d5             	and    %r10d,%ebp
   4cc84:	45 89 f0             	mov    %r14d,%r8d
   4cc87:	45 21 c8             	and    %r9d,%r8d
   4cc8a:	41 31 e8             	xor    %ebp,%r8d
   4cc8d:	01 c7                	add    %eax,%edi
   4cc8f:	89 fd                	mov    %edi,%ebp
   4cc91:	c1 c5 1a             	rol    $0x1a,%ebp
   4cc94:	45 01 e0             	add    %r12d,%r8d
   4cc97:	41 89 ff             	mov    %edi,%r15d
   4cc9a:	41 c1 c7 15          	rol    $0x15,%r15d
   4cc9e:	41 01 c0             	add    %eax,%r8d
   4cca1:	89 f8                	mov    %edi,%eax
   4cca3:	c1 c0 07             	rol    $0x7,%eax
   4cca6:	41 31 ef             	xor    %ebp,%r15d
   4cca9:	44 31 f8             	xor    %r15d,%eax
   4ccac:	4c 8b 7c 24 d8       	mov    -0x28(%rsp),%r15
   4ccb1:	41 8b 77 14          	mov    0x14(%r15),%esi
   4ccb5:	0f ce                	bswap  %esi
   4ccb7:	48 89 34 24          	mov    %rsi,(%rsp)
   4ccbb:	01 f1                	add    %esi,%ecx
   4ccbd:	41 89 df             	mov    %ebx,%r15d
   4ccc0:	45 31 df             	xor    %r11d,%r15d
   4ccc3:	41 21 ff             	and    %edi,%r15d
   4ccc6:	45 31 df             	xor    %r11d,%r15d
   4ccc9:	44 89 c5             	mov    %r8d,%ebp
   4cccc:	c1 c5 1e             	rol    $0x1e,%ebp
   4cccf:	41 01 cf             	add    %ecx,%r15d
   4ccd2:	44 89 c1             	mov    %r8d,%ecx
   4ccd5:	c1 c1 13             	rol    $0x13,%ecx
   4ccd8:	41 01 c7             	add    %eax,%r15d
   4ccdb:	41 81 c7 f1 11 f1 59 	add    $0x59f111f1,%r15d
   4cce2:	45 89 c4             	mov    %r8d,%r12d
   4cce5:	41 c1 c4 0a          	rol    $0xa,%r12d
   4cce9:	31 e9                	xor    %ebp,%ecx
   4cceb:	41 31 cc             	xor    %ecx,%r12d
   4ccee:	44 89 d1             	mov    %r10d,%ecx
   4ccf1:	44 21 f1             	and    %r14d,%ecx
   4ccf4:	44 89 d0             	mov    %r10d,%eax
   4ccf7:	44 31 f0             	xor    %r14d,%eax
   4ccfa:	44 21 c0             	and    %r8d,%eax
   4ccfd:	31 c8                	xor    %ecx,%eax
   4ccff:	45 01 f9             	add    %r15d,%r9d
   4cd02:	44 89 c9             	mov    %r9d,%ecx
   4cd05:	c1 c1 1a             	rol    $0x1a,%ecx
   4cd08:	44 01 e0             	add    %r12d,%eax
   4cd0b:	44 89 cd             	mov    %r9d,%ebp
   4cd0e:	c1 c5 15             	rol    $0x15,%ebp
   4cd11:	44 01 f8             	add    %r15d,%eax
   4cd14:	45 89 cf             	mov    %r9d,%r15d
   4cd17:	41 c1 c7 07          	rol    $0x7,%r15d
   4cd1b:	31 cd                	xor    %ecx,%ebp
   4cd1d:	41 31 ef             	xor    %ebp,%r15d
   4cd20:	48 8b 4c 24 d8       	mov    -0x28(%rsp),%rcx
   4cd25:	8b 49 18             	mov    0x18(%rcx),%ecx
   4cd28:	0f c9                	bswap  %ecx
   4cd2a:	48 89 4c 24 f8       	mov    %rcx,-0x8(%rsp)
   4cd2f:	44 01 d9             	add    %r11d,%ecx
   4cd32:	41 89 fb             	mov    %edi,%r11d
   4cd35:	41 31 db             	xor    %ebx,%r11d
   4cd38:	45 21 cb             	and    %r9d,%r11d
   4cd3b:	41 31 db             	xor    %ebx,%r11d
   4cd3e:	89 c5                	mov    %eax,%ebp
   4cd40:	c1 c5 1e             	rol    $0x1e,%ebp
   4cd43:	41 01 cb             	add    %ecx,%r11d
   4cd46:	89 c1                	mov    %eax,%ecx
   4cd48:	c1 c1 13             	rol    $0x13,%ecx
   4cd4b:	45 01 fb             	add    %r15d,%r11d
   4cd4e:	41 81 c3 a4 82 3f 92 	add    $0x923f82a4,%r11d
   4cd55:	41 89 c7             	mov    %eax,%r15d
   4cd58:	41 c1 c7 0a          	rol    $0xa,%r15d
   4cd5c:	31 e9                	xor    %ebp,%ecx
   4cd5e:	41 31 cf             	xor    %ecx,%r15d
   4cd61:	44 89 c5             	mov    %r8d,%ebp
   4cd64:	44 31 d5             	xor    %r10d,%ebp
   4cd67:	21 c5                	and    %eax,%ebp
   4cd69:	44 89 c1             	mov    %r8d,%ecx
   4cd6c:	44 21 d1             	and    %r10d,%ecx
   4cd6f:	31 e9                	xor    %ebp,%ecx
   4cd71:	45 01 de             	add    %r11d,%r14d
   4cd74:	44 89 f5             	mov    %r14d,%ebp
   4cd77:	c1 c5 1a             	rol    $0x1a,%ebp
   4cd7a:	44 01 f9             	add    %r15d,%ecx
   4cd7d:	45 89 f7             	mov    %r14d,%r15d
   4cd80:	41 c1 c7 15          	rol    $0x15,%r15d
   4cd84:	44 01 d9             	add    %r11d,%ecx
   4cd87:	45 89 f3             	mov    %r14d,%r11d
   4cd8a:	41 c1 c3 07          	rol    $0x7,%r11d
   4cd8e:	41 31 ef             	xor    %ebp,%r15d
   4cd91:	45 31 fb             	xor    %r15d,%r11d
   4cd94:	4c 8b 7c 24 d8       	mov    -0x28(%rsp),%r15
   4cd99:	41 8b 77 1c          	mov    0x1c(%r15),%esi
   4cd9d:	0f ce                	bswap  %esi
   4cd9f:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
   4cda4:	01 f3                	add    %esi,%ebx
   4cda6:	45 89 cf             	mov    %r9d,%r15d
   4cda9:	41 31 ff             	xor    %edi,%r15d
   4cdac:	45 21 f7             	and    %r14d,%r15d
   4cdaf:	41 31 ff             	xor    %edi,%r15d
   4cdb2:	89 cd                	mov    %ecx,%ebp
   4cdb4:	c1 c5 1e             	rol    $0x1e,%ebp
   4cdb7:	41 01 df             	add    %ebx,%r15d
   4cdba:	41 89 cc             	mov    %ecx,%r12d
   4cdbd:	41 c1 c4 13          	rol    $0x13,%r12d
   4cdc1:	45 01 fb             	add    %r15d,%r11d
   4cdc4:	41 81 c3 d5 5e 1c ab 	add    $0xab1c5ed5,%r11d
   4cdcb:	89 cb                	mov    %ecx,%ebx
   4cdcd:	c1 c3 0a             	rol    $0xa,%ebx
   4cdd0:	41 31 ec             	xor    %ebp,%r12d
   4cdd3:	44 31 e3             	xor    %r12d,%ebx
   4cdd6:	89 c5                	mov    %eax,%ebp
   4cdd8:	44 21 c5             	and    %r8d,%ebp
   4cddb:	41 89 c7             	mov    %eax,%r15d
   4cdde:	45 31 c7             	xor    %r8d,%r15d
   4cde1:	41 21 cf             	and    %ecx,%r15d
   4cde4:	41 31 ef             	xor    %ebp,%r15d
   4cde7:	45 01 da             	add    %r11d,%r10d
   4cdea:	44 89 d5             	mov    %r10d,%ebp
   4cded:	c1 c5 1a             	rol    $0x1a,%ebp
   4cdf0:	41 01 df             	add    %ebx,%r15d
   4cdf3:	44 89 d3             	mov    %r10d,%ebx
   4cdf6:	c1 c3 15             	rol    $0x15,%ebx
   4cdf9:	45 01 df             	add    %r11d,%r15d
   4cdfc:	45 89 d3             	mov    %r10d,%r11d
   4cdff:	41 c1 c3 07          	rol    $0x7,%r11d
   4ce03:	31 eb                	xor    %ebp,%ebx
   4ce05:	41 31 db             	xor    %ebx,%r11d
   4ce08:	48 8b 5c 24 d8       	mov    -0x28(%rsp),%rbx
   4ce0d:	8b 73 20             	mov    0x20(%rbx),%esi
   4ce10:	0f ce                	bswap  %esi
   4ce12:	89 74 24 84          	mov    %esi,-0x7c(%rsp)
   4ce16:	01 f7                	add    %esi,%edi
   4ce18:	44 89 f3             	mov    %r14d,%ebx
   4ce1b:	44 31 cb             	xor    %r9d,%ebx
   4ce1e:	44 21 d3             	and    %r10d,%ebx
   4ce21:	44 31 cb             	xor    %r9d,%ebx
   4ce24:	44 89 fd             	mov    %r15d,%ebp
   4ce27:	c1 c5 1e             	rol    $0x1e,%ebp
   4ce2a:	01 fb                	add    %edi,%ebx
   4ce2c:	44 89 ff             	mov    %r15d,%edi
   4ce2f:	c1 c7 13             	rol    $0x13,%edi
   4ce32:	44 01 db             	add    %r11d,%ebx
   4ce35:	81 c3 98 aa 07 d8    	add    $0xd807aa98,%ebx
   4ce3b:	45 89 fc             	mov    %r15d,%r12d
   4ce3e:	41 c1 c4 0a          	rol    $0xa,%r12d
   4ce42:	31 ef                	xor    %ebp,%edi
   4ce44:	41 31 fc             	xor    %edi,%r12d
   4ce47:	89 cf                	mov    %ecx,%edi
   4ce49:	31 c7                	xor    %eax,%edi
   4ce4b:	44 21 ff             	and    %r15d,%edi
   4ce4e:	41 89 cd             	mov    %ecx,%r13d
   4ce51:	41 21 c5             	and    %eax,%r13d
   4ce54:	41 31 fd             	xor    %edi,%r13d
   4ce57:	41 01 d8             	add    %ebx,%r8d
   4ce5a:	44 89 c7             	mov    %r8d,%edi
   4ce5d:	c1 c7 1a             	rol    $0x1a,%edi
   4ce60:	45 01 e5             	add    %r12d,%r13d
   4ce63:	44 89 c5             	mov    %r8d,%ebp
   4ce66:	c1 c5 15             	rol    $0x15,%ebp
   4ce69:	41 01 dd             	add    %ebx,%r13d
   4ce6c:	44 89 c3             	mov    %r8d,%ebx
   4ce6f:	c1 c3 07             	rol    $0x7,%ebx
   4ce72:	31 fd                	xor    %edi,%ebp
   4ce74:	31 eb                	xor    %ebp,%ebx
   4ce76:	48 8b 7c 24 d8       	mov    -0x28(%rsp),%rdi
   4ce7b:	8b 77 24             	mov    0x24(%rdi),%esi
   4ce7e:	0f ce                	bswap  %esi
   4ce80:	48 89 74 24 a0       	mov    %rsi,-0x60(%rsp)
   4ce85:	42 8d 3c 0e          	lea    (%rsi,%r9,1),%edi
   4ce89:	45 89 d1             	mov    %r10d,%r9d
   4ce8c:	45 31 f1             	xor    %r14d,%r9d
   4ce8f:	45 21 c1             	and    %r8d,%r9d
   4ce92:	45 31 f1             	xor    %r14d,%r9d
   4ce95:	44 89 ed             	mov    %r13d,%ebp
   4ce98:	c1 c5 1e             	rol    $0x1e,%ebp
   4ce9b:	41 01 f9             	add    %edi,%r9d
   4ce9e:	44 89 ef             	mov    %r13d,%edi
   4cea1:	c1 c7 13             	rol    $0x13,%edi
   4cea4:	41 01 d9             	add    %ebx,%r9d
   4cea7:	41 81 c1 01 5b 83 12 	add    $0x12835b01,%r9d
   4ceae:	45 89 ec             	mov    %r13d,%r12d
   4ceb1:	41 c1 c4 0a          	rol    $0xa,%r12d
   4ceb5:	31 ef                	xor    %ebp,%edi
   4ceb7:	41 31 fc             	xor    %edi,%r12d
   4ceba:	44 89 ff             	mov    %r15d,%edi
   4cebd:	21 cf                	and    %ecx,%edi
   4cebf:	45 89 fb             	mov    %r15d,%r11d
   4cec2:	41 31 cb             	xor    %ecx,%r11d
   4cec5:	45 21 eb             	and    %r13d,%r11d
   4cec8:	41 31 fb             	xor    %edi,%r11d
   4cecb:	44 01 c8             	add    %r9d,%eax
   4cece:	89 c7                	mov    %eax,%edi
   4ced0:	c1 c7 1a             	rol    $0x1a,%edi
   4ced3:	45 01 e3             	add    %r12d,%r11d
   4ced6:	89 c5                	mov    %eax,%ebp
   4ced8:	c1 c5 15             	rol    $0x15,%ebp
   4cedb:	45 01 cb             	add    %r9d,%r11d
   4cede:	41 89 c1             	mov    %eax,%r9d
   4cee1:	41 c1 c1 07          	rol    $0x7,%r9d
   4cee5:	31 fd                	xor    %edi,%ebp
   4cee7:	41 31 e9             	xor    %ebp,%r9d
   4ceea:	48 8b 7c 24 d8       	mov    -0x28(%rsp),%rdi
   4ceef:	8b 77 28             	mov    0x28(%rdi),%esi
   4cef2:	0f ce                	bswap  %esi
   4cef4:	48 89 74 24 c8       	mov    %rsi,-0x38(%rsp)
   4cef9:	42 8d 3c 36          	lea    (%rsi,%r14,1),%edi
   4cefd:	45 89 c6             	mov    %r8d,%r14d
   4cf00:	45 31 d6             	xor    %r10d,%r14d
   4cf03:	41 21 c6             	and    %eax,%r14d
   4cf06:	45 31 d6             	xor    %r10d,%r14d
   4cf09:	44 89 dd             	mov    %r11d,%ebp
   4cf0c:	c1 c5 1e             	rol    $0x1e,%ebp
   4cf0f:	41 01 fe             	add    %edi,%r14d
   4cf12:	44 89 df             	mov    %r11d,%edi
   4cf15:	c1 c7 13             	rol    $0x13,%edi
   4cf18:	45 01 f1             	add    %r14d,%r9d
   4cf1b:	41 81 c1 be 85 31 24 	add    $0x243185be,%r9d
   4cf22:	45 89 dc             	mov    %r11d,%r12d
   4cf25:	41 c1 c4 0a          	rol    $0xa,%r12d
   4cf29:	31 ef                	xor    %ebp,%edi
   4cf2b:	41 31 fc             	xor    %edi,%r12d
   4cf2e:	44 89 ef             	mov    %r13d,%edi
   4cf31:	44 31 ff             	xor    %r15d,%edi
   4cf34:	44 21 df             	and    %r11d,%edi
   4cf37:	44 89 ea             	mov    %r13d,%edx
   4cf3a:	44 21 fa             	and    %r15d,%edx
   4cf3d:	31 fa                	xor    %edi,%edx
   4cf3f:	44 01 c9             	add    %r9d,%ecx
   4cf42:	89 cf                	mov    %ecx,%edi
   4cf44:	c1 c7 1a             	rol    $0x1a,%edi
   4cf47:	44 01 e2             	add    %r12d,%edx
   4cf4a:	89 cd                	mov    %ecx,%ebp
   4cf4c:	c1 c5 15             	rol    $0x15,%ebp
   4cf4f:	44 01 ca             	add    %r9d,%edx
   4cf52:	41 89 c9             	mov    %ecx,%r9d
   4cf55:	41 c1 c1 07          	rol    $0x7,%r9d
   4cf59:	31 fd                	xor    %edi,%ebp
   4cf5b:	41 31 e9             	xor    %ebp,%r9d
   4cf5e:	48 8b 7c 24 d8       	mov    -0x28(%rsp),%rdi
   4cf63:	8b 77 2c             	mov    0x2c(%rdi),%esi
   4cf66:	0f ce                	bswap  %esi
   4cf68:	48 89 74 24 98       	mov    %rsi,-0x68(%rsp)
   4cf6d:	42 8d 3c 16          	lea    (%rsi,%r10,1),%edi
   4cf71:	41 89 c2             	mov    %eax,%r10d
   4cf74:	45 31 c2             	xor    %r8d,%r10d
   4cf77:	41 21 ca             	and    %ecx,%r10d
   4cf7a:	45 31 c2             	xor    %r8d,%r10d
   4cf7d:	89 d5                	mov    %edx,%ebp
   4cf7f:	c1 c5 1e             	rol    $0x1e,%ebp
   4cf82:	41 01 fa             	add    %edi,%r10d
   4cf85:	41 89 d4             	mov    %edx,%r12d
   4cf88:	41 c1 c4 13          	rol    $0x13,%r12d
   4cf8c:	43 8d 3c 11          	lea    (%r9,%r10,1),%edi
   4cf90:	81 c7 c3 7d 0c 55    	add    $0x550c7dc3,%edi
   4cf96:	41 89 d1             	mov    %edx,%r9d
   4cf99:	41 c1 c1 0a          	rol    $0xa,%r9d
   4cf9d:	41 31 ec             	xor    %ebp,%r12d
   4cfa0:	45 31 e1             	xor    %r12d,%r9d
   4cfa3:	45 89 da             	mov    %r11d,%r10d
   4cfa6:	45 21 ea             	and    %r13d,%r10d
   4cfa9:	44 89 db             	mov    %r11d,%ebx
   4cfac:	44 31 eb             	xor    %r13d,%ebx
   4cfaf:	21 d3                	and    %edx,%ebx
   4cfb1:	44 31 d3             	xor    %r10d,%ebx
   4cfb4:	41 01 ff             	add    %edi,%r15d
   4cfb7:	45 89 fa             	mov    %r15d,%r10d
   4cfba:	41 c1 c2 1a          	rol    $0x1a,%r10d
   4cfbe:	44 01 cb             	add    %r9d,%ebx
   4cfc1:	45 89 f9             	mov    %r15d,%r9d
   4cfc4:	41 c1 c1 15          	rol    $0x15,%r9d
   4cfc8:	01 fb                	add    %edi,%ebx
   4cfca:	44 89 ff             	mov    %r15d,%edi
   4cfcd:	c1 c7 07             	rol    $0x7,%edi
   4cfd0:	45 31 d1             	xor    %r10d,%r9d
   4cfd3:	44 31 cf             	xor    %r9d,%edi
   4cfd6:	4c 8b 4c 24 d8       	mov    -0x28(%rsp),%r9
   4cfdb:	41 8b 71 30          	mov    0x30(%r9),%esi
   4cfdf:	0f ce                	bswap  %esi
   4cfe1:	89 74 24 90          	mov    %esi,-0x70(%rsp)
   4cfe5:	41 01 f0             	add    %esi,%r8d
   4cfe8:	41 89 c9             	mov    %ecx,%r9d
   4cfeb:	41 31 c1             	xor    %eax,%r9d
   4cfee:	45 21 f9             	and    %r15d,%r9d
   4cff1:	41 31 c1             	xor    %eax,%r9d
   4cff4:	41 89 da             	mov    %ebx,%r10d
   4cff7:	41 c1 c2 1e          	rol    $0x1e,%r10d
   4cffb:	45 01 c1             	add    %r8d,%r9d
   4cffe:	41 89 d8             	mov    %ebx,%r8d
   4d001:	41 c1 c0 13          	rol    $0x13,%r8d
   4d005:	44 01 cf             	add    %r9d,%edi
   4d008:	81 c7 74 5d be 72    	add    $0x72be5d74,%edi
   4d00e:	41 89 d9             	mov    %ebx,%r9d
   4d011:	41 c1 c1 0a          	rol    $0xa,%r9d
   4d015:	45 31 d0             	xor    %r10d,%r8d
   4d018:	45 31 c1             	xor    %r8d,%r9d
   4d01b:	41 89 d0             	mov    %edx,%r8d
   4d01e:	45 31 d8             	xor    %r11d,%r8d
   4d021:	41 21 d8             	and    %ebx,%r8d
   4d024:	41 89 d4             	mov    %edx,%r12d
   4d027:	45 21 dc             	and    %r11d,%r12d
   4d02a:	45 31 c4             	xor    %r8d,%r12d
   4d02d:	41 01 fd             	add    %edi,%r13d
   4d030:	45 89 e8             	mov    %r13d,%r8d
   4d033:	41 c1 c0 1a          	rol    $0x1a,%r8d
   4d037:	45 01 cc             	add    %r9d,%r12d
   4d03a:	45 89 e9             	mov    %r13d,%r9d
   4d03d:	41 c1 c1 15          	rol    $0x15,%r9d
   4d041:	41 01 fc             	add    %edi,%r12d
   4d044:	44 89 ef             	mov    %r13d,%edi
   4d047:	c1 c7 07             	rol    $0x7,%edi
   4d04a:	45 31 c1             	xor    %r8d,%r9d
   4d04d:	44 31 cf             	xor    %r9d,%edi
   4d050:	4c 8b 44 24 d8       	mov    -0x28(%rsp),%r8
   4d055:	45 8b 40 34          	mov    0x34(%r8),%r8d
   4d059:	41 0f c8             	bswap  %r8d
   4d05c:	4c 89 44 24 c0       	mov    %r8,-0x40(%rsp)
   4d061:	44 01 c0             	add    %r8d,%eax
   4d064:	45 89 f8             	mov    %r15d,%r8d
   4d067:	41 31 c8             	xor    %ecx,%r8d
   4d06a:	45 21 e8             	and    %r13d,%r8d
   4d06d:	41 31 c8             	xor    %ecx,%r8d
   4d070:	45 89 e1             	mov    %r12d,%r9d
   4d073:	41 c1 c1 1e          	rol    $0x1e,%r9d
   4d077:	41 01 c0             	add    %eax,%r8d
   4d07a:	44 89 e0             	mov    %r12d,%eax
   4d07d:	c1 c0 13             	rol    $0x13,%eax
   4d080:	44 01 c7             	add    %r8d,%edi
   4d083:	81 c7 fe b1 de 80    	add    $0x80deb1fe,%edi
   4d089:	45 89 e0             	mov    %r12d,%r8d
   4d08c:	41 c1 c0 0a          	rol    $0xa,%r8d
   4d090:	44 31 c8             	xor    %r9d,%eax
   4d093:	41 31 c0             	xor    %eax,%r8d
   4d096:	89 d8                	mov    %ebx,%eax
   4d098:	21 d0                	and    %edx,%eax
   4d09a:	89 dd                	mov    %ebx,%ebp
   4d09c:	31 d5                	xor    %edx,%ebp
   4d09e:	44 21 e5             	and    %r12d,%ebp
   4d0a1:	31 c5                	xor    %eax,%ebp
   4d0a3:	41 01 fb             	add    %edi,%r11d
   4d0a6:	44 89 d8             	mov    %r11d,%eax
   4d0a9:	c1 c0 1a             	rol    $0x1a,%eax
   4d0ac:	44 01 c5             	add    %r8d,%ebp
   4d0af:	45 89 d8             	mov    %r11d,%r8d
   4d0b2:	41 c1 c0 15          	rol    $0x15,%r8d
   4d0b6:	01 fd                	add    %edi,%ebp
   4d0b8:	44 89 df             	mov    %r11d,%edi
   4d0bb:	c1 c7 07             	rol    $0x7,%edi
   4d0be:	41 31 c0             	xor    %eax,%r8d
   4d0c1:	44 31 c7             	xor    %r8d,%edi
   4d0c4:	48 8b 44 24 d8       	mov    -0x28(%rsp),%rax
   4d0c9:	8b 40 38             	mov    0x38(%rax),%eax
   4d0cc:	0f c8                	bswap  %eax
   4d0ce:	48 89 44 24 e8       	mov    %rax,-0x18(%rsp)
   4d0d3:	01 c8                	add    %ecx,%eax
   4d0d5:	44 89 e9             	mov    %r13d,%ecx
   4d0d8:	44 31 f9             	xor    %r15d,%ecx
   4d0db:	44 21 d9             	and    %r11d,%ecx
   4d0de:	44 31 f9             	xor    %r15d,%ecx
   4d0e1:	41 89 e8             	mov    %ebp,%r8d
   4d0e4:	41 c1 c0 1e          	rol    $0x1e,%r8d
   4d0e8:	01 c1                	add    %eax,%ecx
   4d0ea:	89 e8                	mov    %ebp,%eax
   4d0ec:	c1 c0 13             	rol    $0x13,%eax
   4d0ef:	01 f9                	add    %edi,%ecx
   4d0f1:	81 c1 a7 06 dc 9b    	add    $0x9bdc06a7,%ecx
   4d0f7:	89 ef                	mov    %ebp,%edi
   4d0f9:	c1 c7 0a             	rol    $0xa,%edi
   4d0fc:	44 31 c0             	xor    %r8d,%eax
   4d0ff:	31 c7                	xor    %eax,%edi
   4d101:	44 89 e0             	mov    %r12d,%eax
   4d104:	31 d8                	xor    %ebx,%eax
   4d106:	21 e8                	and    %ebp,%eax
   4d108:	45 89 e6             	mov    %r12d,%r14d
   4d10b:	41 21 de             	and    %ebx,%r14d
   4d10e:	41 31 c6             	xor    %eax,%r14d
   4d111:	01 ca                	add    %ecx,%edx
   4d113:	89 d0                	mov    %edx,%eax
   4d115:	c1 c0 1a             	rol    $0x1a,%eax
   4d118:	41 01 fe             	add    %edi,%r14d
   4d11b:	89 d7                	mov    %edx,%edi
   4d11d:	c1 c7 15             	rol    $0x15,%edi
   4d120:	41 01 ce             	add    %ecx,%r14d
   4d123:	89 d1                	mov    %edx,%ecx
   4d125:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
   4d12a:	c1 c1 07             	rol    $0x7,%ecx
   4d12d:	31 c7                	xor    %eax,%edi
   4d12f:	31 f9                	xor    %edi,%ecx
   4d131:	48 8b 44 24 d8       	mov    -0x28(%rsp),%rax
   4d136:	8b 40 3c             	mov    0x3c(%rax),%eax
   4d139:	0f c8                	bswap  %eax
   4d13b:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
   4d140:	44 01 f8             	add    %r15d,%eax
   4d143:	44 89 df             	mov    %r11d,%edi
   4d146:	44 31 ef             	xor    %r13d,%edi
   4d149:	21 d7                	and    %edx,%edi
   4d14b:	44 31 ef             	xor    %r13d,%edi
   4d14e:	45 89 f0             	mov    %r14d,%r8d
   4d151:	41 c1 c0 1e          	rol    $0x1e,%r8d
   4d155:	01 c7                	add    %eax,%edi
   4d157:	44 89 f0             	mov    %r14d,%eax
   4d15a:	c1 c0 13             	rol    $0x13,%eax
   4d15d:	01 f9                	add    %edi,%ecx
   4d15f:	81 c1 74 f1 9b c1    	add    $0xc19bf174,%ecx
   4d165:	44 89 f7             	mov    %r14d,%edi
   4d168:	c1 c7 0a             	rol    $0xa,%edi
   4d16b:	44 31 c0             	xor    %r8d,%eax
   4d16e:	31 c7                	xor    %eax,%edi
   4d170:	89 e8                	mov    %ebp,%eax
   4d172:	44 21 e0             	and    %r12d,%eax
   4d175:	41 89 e8             	mov    %ebp,%r8d
   4d178:	45 31 e0             	xor    %r12d,%r8d
   4d17b:	45 21 f0             	and    %r14d,%r8d
   4d17e:	41 31 c0             	xor    %eax,%r8d
   4d181:	41 01 f8             	add    %edi,%r8d
   4d184:	8b 74 24 e0          	mov    -0x20(%rsp),%esi
   4d188:	89 f0                	mov    %esi,%eax
   4d18a:	c1 c0 19             	rol    $0x19,%eax
   4d18d:	41 01 c8             	add    %ecx,%r8d
   4d190:	4c 89 44 24 a8       	mov    %r8,-0x58(%rsp)
   4d195:	4c 8b 4c 24 88       	mov    -0x78(%rsp),%r9
   4d19a:	44 89 cf             	mov    %r9d,%edi
   4d19d:	c1 c7 19             	rol    $0x19,%edi
   4d1a0:	01 cb                	add    %ecx,%ebx
   4d1a2:	89 f1                	mov    %esi,%ecx
   4d1a4:	c1 c1 0e             	rol    $0xe,%ecx
   4d1a7:	31 c1                	xor    %eax,%ecx
   4d1a9:	44 89 c8             	mov    %r9d,%eax
   4d1ac:	c1 c0 0e             	rol    $0xe,%eax
   4d1af:	31 f8                	xor    %edi,%eax
   4d1b1:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
   4d1b6:	44 89 c7             	mov    %r8d,%edi
   4d1b9:	c1 c7 19             	rol    $0x19,%edi
   4d1bc:	45 89 c2             	mov    %r8d,%r10d
   4d1bf:	41 c1 c2 0e          	rol    $0xe,%r10d
   4d1c3:	41 31 fa             	xor    %edi,%r10d
   4d1c6:	48 8b 54 24 f0       	mov    -0x10(%rsp),%rdx
   4d1cb:	89 d7                	mov    %edx,%edi
   4d1cd:	c1 c7 19             	rol    $0x19,%edi
   4d1d0:	41 89 d7             	mov    %edx,%r15d
   4d1d3:	41 c1 c7 0e          	rol    $0xe,%r15d
   4d1d7:	41 31 ff             	xor    %edi,%r15d
   4d1da:	89 f7                	mov    %esi,%edi
   4d1dc:	c1 ef 03             	shr    $0x3,%edi
   4d1df:	31 cf                	xor    %ecx,%edi
   4d1e1:	44 89 c9             	mov    %r9d,%ecx
   4d1e4:	c1 e9 03             	shr    $0x3,%ecx
   4d1e7:	31 c1                	xor    %eax,%ecx
   4d1e9:	44 89 c0             	mov    %r8d,%eax
   4d1ec:	c1 e8 03             	shr    $0x3,%eax
   4d1ef:	44 31 d0             	xor    %r10d,%eax
   4d1f2:	41 89 d2             	mov    %edx,%r10d
   4d1f5:	41 c1 ea 03          	shr    $0x3,%r10d
   4d1f9:	45 31 fa             	xor    %r15d,%r10d
   4d1fc:	44 03 4c 24 90       	add    -0x70(%rsp),%r9d
   4d201:	41 01 f9             	add    %edi,%r9d
   4d204:	4c 89 4c 24 88       	mov    %r9,-0x78(%rsp)
   4d209:	44 03 44 24 98       	add    -0x68(%rsp),%r8d
   4d20e:	41 01 c8             	add    %ecx,%r8d
   4d211:	48 89 d1             	mov    %rdx,%rcx
   4d214:	03 4c 24 c8          	add    -0x38(%rsp),%ecx
   4d218:	01 c1                	add    %eax,%ecx
   4d21a:	49 89 cf             	mov    %rcx,%r15
   4d21d:	48 8b 74 24 e8       	mov    -0x18(%rsp),%rsi
   4d222:	89 f0                	mov    %esi,%eax
   4d224:	c1 c0 0f             	rol    $0xf,%eax
   4d227:	48 8b 54 24 b8       	mov    -0x48(%rsp),%rdx
   4d22c:	03 54 24 a0          	add    -0x60(%rsp),%edx
   4d230:	89 f1                	mov    %esi,%ecx
   4d232:	c1 c1 0d             	rol    $0xd,%ecx
   4d235:	44 01 d2             	add    %r10d,%edx
   4d238:	48 89 d7             	mov    %rdx,%rdi
   4d23b:	31 c1                	xor    %eax,%ecx
   4d23d:	89 f2                	mov    %esi,%edx
   4d23f:	c1 ea 0a             	shr    $0xa,%edx
   4d242:	31 ca                	xor    %ecx,%edx
   4d244:	48 8b 74 24 b0       	mov    -0x50(%rsp),%rsi
   4d249:	89 f0                	mov    %esi,%eax
   4d24b:	c1 c0 0f             	rol    $0xf,%eax
   4d24e:	01 fa                	add    %edi,%edx
   4d250:	89 f1                	mov    %esi,%ecx
   4d252:	c1 c1 0d             	rol    $0xd,%ecx
   4d255:	31 c1                	xor    %eax,%ecx
   4d257:	89 f7                	mov    %esi,%edi
   4d259:	c1 ef 0a             	shr    $0xa,%edi
   4d25c:	31 cf                	xor    %ecx,%edi
   4d25e:	44 01 ff             	add    %r15d,%edi
   4d261:	89 d0                	mov    %edx,%eax
   4d263:	c1 c0 0f             	rol    $0xf,%eax
   4d266:	89 d1                	mov    %edx,%ecx
   4d268:	c1 c1 0d             	rol    $0xd,%ecx
   4d26b:	31 c1                	xor    %eax,%ecx
   4d26d:	89 d0                	mov    %edx,%eax
   4d26f:	89 d6                	mov    %edx,%esi
   4d271:	89 54 24 80          	mov    %edx,-0x80(%rsp)
   4d275:	c1 e8 0a             	shr    $0xa,%eax
   4d278:	31 c8                	xor    %ecx,%eax
   4d27a:	44 01 c0             	add    %r8d,%eax
   4d27d:	49 89 c1             	mov    %rax,%r9
   4d280:	48 89 44 24 b8       	mov    %rax,-0x48(%rsp)
   4d285:	89 f8                	mov    %edi,%eax
   4d287:	c1 c0 0f             	rol    $0xf,%eax
   4d28a:	89 f9                	mov    %edi,%ecx
   4d28c:	c1 c1 0d             	rol    $0xd,%ecx
   4d28f:	31 c1                	xor    %eax,%ecx
   4d291:	89 f8                	mov    %edi,%eax
   4d293:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   4d298:	c1 e8 0a             	shr    $0xa,%eax
   4d29b:	48 89 c2             	mov    %rax,%rdx
   4d29e:	89 d8                	mov    %ebx,%eax
   4d2a0:	c1 c0 1a             	rol    $0x1a,%eax
   4d2a3:	31 ca                	xor    %ecx,%edx
   4d2a5:	89 d9                	mov    %ebx,%ecx
   4d2a7:	c1 c1 15             	rol    $0x15,%ecx
   4d2aa:	03 54 24 88          	add    -0x78(%rsp),%edx
   4d2ae:	49 89 d7             	mov    %rdx,%r15
   4d2b1:	48 89 54 24 f0       	mov    %rdx,-0x10(%rsp)
   4d2b6:	89 da                	mov    %ebx,%edx
   4d2b8:	c1 c2 07             	rol    $0x7,%edx
   4d2bb:	31 c1                	xor    %eax,%ecx
   4d2bd:	31 ca                	xor    %ecx,%edx
   4d2bf:	41 01 f5             	add    %esi,%r13d
   4d2c2:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
   4d2c7:	44 89 d0             	mov    %r10d,%eax
   4d2ca:	44 31 d8             	xor    %r11d,%eax
   4d2cd:	21 d8                	and    %ebx,%eax
   4d2cf:	44 31 d8             	xor    %r11d,%eax
   4d2d2:	44 01 e8             	add    %r13d,%eax
   4d2d5:	01 d0                	add    %edx,%eax
   4d2d7:	05 c1 69 9b e4       	add    $0xe49b69c1,%eax
   4d2dc:	4c 8b 44 24 a8       	mov    -0x58(%rsp),%r8
   4d2e1:	44 89 c1             	mov    %r8d,%ecx
   4d2e4:	c1 c1 1e             	rol    $0x1e,%ecx
   4d2e7:	44 89 c2             	mov    %r8d,%edx
   4d2ea:	c1 c2 13             	rol    $0x13,%edx
   4d2ed:	31 ca                	xor    %ecx,%edx
   4d2ef:	44 89 c1             	mov    %r8d,%ecx
   4d2f2:	c1 c1 0a             	rol    $0xa,%ecx
   4d2f5:	31 d1                	xor    %edx,%ecx
   4d2f7:	44 89 f2             	mov    %r14d,%edx
   4d2fa:	31 ea                	xor    %ebp,%edx
   4d2fc:	44 21 c2             	and    %r8d,%edx
   4d2ff:	44 89 f6             	mov    %r14d,%esi
   4d302:	21 ee                	and    %ebp,%esi
   4d304:	31 d6                	xor    %edx,%esi
   4d306:	01 ce                	add    %ecx,%esi
   4d308:	01 c6                	add    %eax,%esi
   4d30a:	41 01 c4             	add    %eax,%r12d
   4d30d:	44 89 e0             	mov    %r12d,%eax
   4d310:	c1 c0 1a             	rol    $0x1a,%eax
   4d313:	44 89 e1             	mov    %r12d,%ecx
   4d316:	c1 c1 15             	rol    $0x15,%ecx
   4d319:	31 c1                	xor    %eax,%ecx
   4d31b:	44 89 e0             	mov    %r12d,%eax
   4d31e:	c1 c0 07             	rol    $0x7,%eax
   4d321:	31 c8                	xor    %ecx,%eax
   4d323:	42 8d 0c 1f          	lea    (%rdi,%r11,1),%ecx
   4d327:	89 da                	mov    %ebx,%edx
   4d329:	44 31 d2             	xor    %r10d,%edx
   4d32c:	44 21 e2             	and    %r12d,%edx
   4d32f:	44 31 d2             	xor    %r10d,%edx
   4d332:	41 89 f5             	mov    %esi,%r13d
   4d335:	c1 c6 1e             	rol    $0x1e,%esi
   4d338:	01 ca                	add    %ecx,%edx
   4d33a:	44 89 e9             	mov    %r13d,%ecx
   4d33d:	c1 c1 13             	rol    $0x13,%ecx
   4d340:	01 d0                	add    %edx,%eax
   4d342:	05 86 47 be ef       	add    $0xefbe4786,%eax
   4d347:	44 89 ea             	mov    %r13d,%edx
   4d34a:	44 89 ef             	mov    %r13d,%edi
   4d34d:	c1 c2 0a             	rol    $0xa,%edx
   4d350:	31 f1                	xor    %esi,%ecx
   4d352:	31 ca                	xor    %ecx,%edx
   4d354:	44 89 c1             	mov    %r8d,%ecx
   4d357:	44 21 f1             	and    %r14d,%ecx
   4d35a:	45 89 c5             	mov    %r8d,%r13d
   4d35d:	45 31 f5             	xor    %r14d,%r13d
   4d360:	41 21 fd             	and    %edi,%r13d
   4d363:	41 31 cd             	xor    %ecx,%r13d
   4d366:	01 c5                	add    %eax,%ebp
   4d368:	89 e9                	mov    %ebp,%ecx
   4d36a:	c1 c1 1a             	rol    $0x1a,%ecx
   4d36d:	41 01 d5             	add    %edx,%r13d
   4d370:	89 ea                	mov    %ebp,%edx
   4d372:	c1 c2 15             	rol    $0x15,%edx
   4d375:	41 01 c5             	add    %eax,%r13d
   4d378:	89 e8                	mov    %ebp,%eax
   4d37a:	c1 c0 07             	rol    $0x7,%eax
   4d37d:	31 ca                	xor    %ecx,%edx
   4d37f:	31 d0                	xor    %edx,%eax
   4d381:	43 8d 0c 11          	lea    (%r9,%r10,1),%ecx
   4d385:	44 89 e2             	mov    %r12d,%edx
   4d388:	31 da                	xor    %ebx,%edx
   4d38a:	21 ea                	and    %ebp,%edx
   4d38c:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
   4d391:	31 da                	xor    %ebx,%edx
   4d393:	01 ca                	add    %ecx,%edx
   4d395:	01 d0                	add    %edx,%eax
   4d397:	05 c6 9d c1 0f       	add    $0xfc19dc6,%eax
   4d39c:	44 89 e9             	mov    %r13d,%ecx
   4d39f:	c1 c1 1e             	rol    $0x1e,%ecx
   4d3a2:	44 89 ea             	mov    %r13d,%edx
   4d3a5:	c1 c2 13             	rol    $0x13,%edx
   4d3a8:	31 ca                	xor    %ecx,%edx
   4d3aa:	44 89 e9             	mov    %r13d,%ecx
   4d3ad:	c1 c1 0a             	rol    $0xa,%ecx
   4d3b0:	31 d1                	xor    %edx,%ecx
   4d3b2:	89 fa                	mov    %edi,%edx
   4d3b4:	44 31 c2             	xor    %r8d,%edx
   4d3b7:	44 21 ea             	and    %r13d,%edx
   4d3ba:	89 fe                	mov    %edi,%esi
   4d3bc:	41 89 fa             	mov    %edi,%r10d
   4d3bf:	44 21 c6             	and    %r8d,%esi
   4d3c2:	31 d6                	xor    %edx,%esi
   4d3c4:	01 ce                	add    %ecx,%esi
   4d3c6:	01 c6                	add    %eax,%esi
   4d3c8:	41 01 c6             	add    %eax,%r14d
   4d3cb:	44 89 f0             	mov    %r14d,%eax
   4d3ce:	c1 c0 1a             	rol    $0x1a,%eax
   4d3d1:	44 89 f1             	mov    %r14d,%ecx
   4d3d4:	c1 c1 15             	rol    $0x15,%ecx
   4d3d7:	31 c1                	xor    %eax,%ecx
   4d3d9:	44 89 f0             	mov    %r14d,%eax
   4d3dc:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   4d3e1:	c1 c0 07             	rol    $0x7,%eax
   4d3e4:	31 c8                	xor    %ecx,%eax
   4d3e6:	41 8d 0c 1f          	lea    (%r15,%rbx,1),%ecx
   4d3ea:	44 89 64 24 20       	mov    %r12d,0x20(%rsp)
   4d3ef:	44 31 e5             	xor    %r12d,%ebp
   4d3f2:	44 21 f5             	and    %r14d,%ebp
   4d3f5:	44 31 e5             	xor    %r12d,%ebp
   4d3f8:	48 89 f7             	mov    %rsi,%rdi
   4d3fb:	c1 c6 1e             	rol    $0x1e,%esi
   4d3fe:	01 cd                	add    %ecx,%ebp
   4d400:	89 f9                	mov    %edi,%ecx
   4d402:	c1 c1 13             	rol    $0x13,%ecx
   4d405:	44 8d 04 28          	lea    (%rax,%rbp,1),%r8d
   4d409:	41 81 c0 cc a1 0c 24 	add    $0x240ca1cc,%r8d
   4d410:	41 89 fe             	mov    %edi,%r14d
   4d413:	48 89 fa             	mov    %rdi,%rdx
   4d416:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
   4d41b:	41 c1 c6 0a          	rol    $0xa,%r14d
   4d41f:	31 f1                	xor    %esi,%ecx
   4d421:	8b 7c 24 84          	mov    -0x7c(%rsp),%edi
   4d425:	89 fd                	mov    %edi,%ebp
   4d427:	c1 c5 19             	rol    $0x19,%ebp
   4d42a:	41 31 ce             	xor    %ecx,%r14d
   4d42d:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   4d432:	41 89 c3             	mov    %eax,%r11d
   4d435:	41 c1 c3 19          	rol    $0x19,%r11d
   4d439:	4c 8b 4c 24 f8       	mov    -0x8(%rsp),%r9
   4d43e:	44 89 c9             	mov    %r9d,%ecx
   4d441:	c1 c1 19             	rol    $0x19,%ecx
   4d444:	89 4c 24 d4          	mov    %ecx,-0x2c(%rsp)
   4d448:	45 89 ef             	mov    %r13d,%r15d
   4d44b:	44 89 54 24 18       	mov    %r10d,0x18(%rsp)
   4d450:	45 21 d7             	and    %r10d,%r15d
   4d453:	48 8b 34 24          	mov    (%rsp),%rsi
   4d457:	89 f1                	mov    %esi,%ecx
   4d459:	c1 c1 19             	rol    $0x19,%ecx
   4d45c:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   4d460:	89 f9                	mov    %edi,%ecx
   4d462:	c1 c1 0e             	rol    $0xe,%ecx
   4d465:	89 cf                	mov    %ecx,%edi
   4d467:	45 89 ec             	mov    %r13d,%r12d
   4d46a:	45 31 d4             	xor    %r10d,%r12d
   4d46d:	89 c1                	mov    %eax,%ecx
   4d46f:	c1 c1 0e             	rol    $0xe,%ecx
   4d472:	41 89 ca             	mov    %ecx,%r10d
   4d475:	41 21 d4             	and    %edx,%r12d
   4d478:	44 89 c8             	mov    %r9d,%eax
   4d47b:	c1 c0 0e             	rol    $0xe,%eax
   4d47e:	89 c3                	mov    %eax,%ebx
   4d480:	45 31 fc             	xor    %r15d,%r12d
   4d483:	c1 c6 0e             	rol    $0xe,%esi
   4d486:	45 01 f4             	add    %r14d,%r12d
   4d489:	8b 44 24 90          	mov    -0x70(%rsp),%eax
   4d48d:	89 c1                	mov    %eax,%ecx
   4d48f:	c1 c1 19             	rol    $0x19,%ecx
   4d492:	45 89 c6             	mov    %r8d,%r14d
   4d495:	45 01 c4             	add    %r8d,%r12d
   4d498:	4c 8b 7c 24 98       	mov    -0x68(%rsp),%r15
   4d49d:	44 89 fa             	mov    %r15d,%edx
   4d4a0:	c1 c2 19             	rol    $0x19,%edx
   4d4a3:	4c 8b 44 24 a8       	mov    -0x58(%rsp),%r8
   4d4a8:	45 01 f0             	add    %r14d,%r8d
   4d4ab:	4c 89 44 24 a8       	mov    %r8,-0x58(%rsp)
   4d4b0:	4c 8b 74 24 c8       	mov    -0x38(%rsp),%r14
   4d4b5:	45 89 f0             	mov    %r14d,%r8d
   4d4b8:	41 c1 c0 19          	rol    $0x19,%r8d
   4d4bc:	31 ef                	xor    %ebp,%edi
   4d4be:	89 7c 24 88          	mov    %edi,-0x78(%rsp)
   4d4c2:	48 8b 7c 24 a0       	mov    -0x60(%rsp),%rdi
   4d4c7:	89 fd                	mov    %edi,%ebp
   4d4c9:	c1 c5 19             	rol    $0x19,%ebp
   4d4cc:	45 31 da             	xor    %r11d,%r10d
   4d4cf:	44 89 54 24 40       	mov    %r10d,0x40(%rsp)
   4d4d4:	c1 c0 0e             	rol    $0xe,%eax
   4d4d7:	41 89 c2             	mov    %eax,%r10d
   4d4da:	33 5c 24 d4          	xor    -0x2c(%rsp),%ebx
   4d4de:	89 5c 24 d4          	mov    %ebx,-0x2c(%rsp)
   4d4e2:	44 89 f8             	mov    %r15d,%eax
   4d4e5:	c1 c0 0e             	rol    $0xe,%eax
   4d4e8:	33 74 24 10          	xor    0x10(%rsp),%esi
   4d4ec:	89 74 24 60          	mov    %esi,0x60(%rsp)
   4d4f0:	45 89 f7             	mov    %r14d,%r15d
   4d4f3:	41 c1 c7 0e          	rol    $0xe,%r15d
   4d4f7:	41 31 ca             	xor    %ecx,%r10d
   4d4fa:	44 89 54 24 5c       	mov    %r10d,0x5c(%rsp)
   4d4ff:	41 89 fe             	mov    %edi,%r14d
   4d502:	41 c1 c6 0e          	rol    $0xe,%r14d
   4d506:	31 d0                	xor    %edx,%eax
   4d508:	89 44 24 58          	mov    %eax,0x58(%rsp)
   4d50c:	8b 74 24 80          	mov    -0x80(%rsp),%esi
   4d510:	89 f0                	mov    %esi,%eax
   4d512:	c1 c0 19             	rol    $0x19,%eax
   4d515:	45 31 c7             	xor    %r8d,%r15d
   4d518:	48 8b 5c 24 b0       	mov    -0x50(%rsp),%rbx
   4d51d:	89 d9                	mov    %ebx,%ecx
   4d51f:	c1 c1 19             	rol    $0x19,%ecx
   4d522:	41 31 ee             	xor    %ebp,%r14d
   4d525:	89 f2                	mov    %esi,%edx
   4d527:	89 f5                	mov    %esi,%ebp
   4d529:	c1 c2 0e             	rol    $0xe,%edx
   4d52c:	31 c2                	xor    %eax,%edx
   4d52e:	89 d8                	mov    %ebx,%eax
   4d530:	c1 c0 0e             	rol    $0xe,%eax
   4d533:	31 c8                	xor    %ecx,%eax
   4d535:	4c 8b 5c 24 e8       	mov    -0x18(%rsp),%r11
   4d53a:	44 89 d9             	mov    %r11d,%ecx
   4d53d:	c1 c1 19             	rol    $0x19,%ecx
   4d540:	44 89 de             	mov    %r11d,%esi
   4d543:	c1 c6 0e             	rol    $0xe,%esi
   4d546:	31 ce                	xor    %ecx,%esi
   4d548:	4c 8b 54 24 c0       	mov    -0x40(%rsp),%r10
   4d54d:	44 89 d1             	mov    %r10d,%ecx
   4d550:	c1 c1 19             	rol    $0x19,%ecx
   4d553:	44 89 d7             	mov    %r10d,%edi
   4d556:	c1 c7 0e             	rol    $0xe,%edi
   4d559:	31 cf                	xor    %ecx,%edi
   4d55b:	41 89 e8             	mov    %ebp,%r8d
   4d55e:	41 c1 e8 03          	shr    $0x3,%r8d
   4d562:	41 31 d0             	xor    %edx,%r8d
   4d565:	44 89 ca             	mov    %r9d,%edx
   4d568:	41 01 d9             	add    %ebx,%r9d
   4d56b:	41 01 d8             	add    %ebx,%r8d
   4d56e:	44 89 44 24 10       	mov    %r8d,0x10(%rsp)
   4d573:	c1 eb 03             	shr    $0x3,%ebx
   4d576:	31 c3                	xor    %eax,%ebx
   4d578:	4c 8b 04 24          	mov    (%rsp),%r8
   4d57c:	44 89 c0             	mov    %r8d,%eax
   4d57f:	45 01 d8             	add    %r11d,%r8d
   4d582:	44 01 db             	add    %r11d,%ebx
   4d585:	48 89 5c 24 b0       	mov    %rbx,-0x50(%rsp)
   4d58a:	41 c1 eb 03          	shr    $0x3,%r11d
   4d58e:	41 31 f3             	xor    %esi,%r11d
   4d591:	4c 89 d1             	mov    %r10,%rcx
   4d594:	44 8b 54 24 e0       	mov    -0x20(%rsp),%r10d
   4d599:	41 01 ca             	add    %ecx,%r10d
   4d59c:	41 01 cb             	add    %ecx,%r11d
   4d59f:	4c 89 5c 24 e8       	mov    %r11,-0x18(%rsp)
   4d5a4:	c1 e9 03             	shr    $0x3,%ecx
   4d5a7:	31 f9                	xor    %edi,%ecx
   4d5a9:	8b 74 24 90          	mov    -0x70(%rsp),%esi
   4d5ad:	01 f1                	add    %esi,%ecx
   4d5af:	48 89 4c 24 c0       	mov    %rcx,-0x40(%rsp)
   4d5b4:	c1 ee 03             	shr    $0x3,%esi
   4d5b7:	33 74 24 5c          	xor    0x5c(%rsp),%esi
   4d5bb:	48 8b 7c 24 98       	mov    -0x68(%rsp),%rdi
   4d5c0:	01 fe                	add    %edi,%esi
   4d5c2:	c1 ef 03             	shr    $0x3,%edi
   4d5c5:	33 7c 24 58          	xor    0x58(%rsp),%edi
   4d5c9:	48 8b 4c 24 c8       	mov    -0x38(%rsp),%rcx
   4d5ce:	01 cf                	add    %ecx,%edi
   4d5d0:	48 89 7c 24 98       	mov    %rdi,-0x68(%rsp)
   4d5d5:	c1 e9 03             	shr    $0x3,%ecx
   4d5d8:	44 31 f9             	xor    %r15d,%ecx
   4d5db:	48 8b 7c 24 a0       	mov    -0x60(%rsp),%rdi
   4d5e0:	01 f9                	add    %edi,%ecx
   4d5e2:	48 89 4c 24 c8       	mov    %rcx,-0x38(%rsp)
   4d5e7:	c1 ef 03             	shr    $0x3,%edi
   4d5ea:	44 31 f7             	xor    %r14d,%edi
   4d5ed:	8b 4c 24 84          	mov    -0x7c(%rsp),%ecx
   4d5f1:	01 cf                	add    %ecx,%edi
   4d5f3:	48 89 7c 24 a0       	mov    %rdi,-0x60(%rsp)
   4d5f8:	c1 e9 03             	shr    $0x3,%ecx
   4d5fb:	33 4c 24 88          	xor    -0x78(%rsp),%ecx
   4d5ff:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   4d604:	01 f9                	add    %edi,%ecx
   4d606:	c1 ef 03             	shr    $0x3,%edi
   4d609:	33 7c 24 40          	xor    0x40(%rsp),%edi
   4d60d:	c1 ea 03             	shr    $0x3,%edx
   4d610:	33 54 24 d4          	xor    -0x2c(%rsp),%edx
   4d614:	c1 e8 03             	shr    $0x3,%eax
   4d617:	33 44 24 60          	xor    0x60(%rsp),%eax
   4d61b:	41 01 f9             	add    %edi,%r9d
   4d61e:	4c 8b 5c 24 b8       	mov    -0x48(%rsp),%r11
   4d623:	44 89 df             	mov    %r11d,%edi
   4d626:	c1 c7 0f             	rol    $0xf,%edi
   4d629:	41 01 d0             	add    %edx,%r8d
   4d62c:	44 89 da             	mov    %r11d,%edx
   4d62f:	c1 c2 0d             	rol    $0xd,%edx
   4d632:	41 01 c2             	add    %eax,%r10d
   4d635:	31 fa                	xor    %edi,%edx
   4d637:	45 89 de             	mov    %r11d,%r14d
   4d63a:	41 c1 ee 0a          	shr    $0xa,%r14d
   4d63e:	41 31 d6             	xor    %edx,%r14d
   4d641:	48 8b 7c 24 f0       	mov    -0x10(%rsp),%rdi
   4d646:	89 f8                	mov    %edi,%eax
   4d648:	c1 c0 0f             	rol    $0xf,%eax
   4d64b:	45 01 d6             	add    %r10d,%r14d
   4d64e:	89 fa                	mov    %edi,%edx
   4d650:	c1 c2 0d             	rol    $0xd,%edx
   4d653:	31 c2                	xor    %eax,%edx
   4d655:	41 89 fa             	mov    %edi,%r10d
   4d658:	41 c1 ea 0a          	shr    $0xa,%r10d
   4d65c:	41 31 d2             	xor    %edx,%r10d
   4d65f:	45 01 c2             	add    %r8d,%r10d
   4d662:	44 89 f0             	mov    %r14d,%eax
   4d665:	c1 c0 0f             	rol    $0xf,%eax
   4d668:	44 89 f2             	mov    %r14d,%edx
   4d66b:	c1 c2 0d             	rol    $0xd,%edx
   4d66e:	31 c2                	xor    %eax,%edx
   4d670:	44 89 f0             	mov    %r14d,%eax
   4d673:	44 89 74 24 f8       	mov    %r14d,-0x8(%rsp)
   4d678:	c1 e8 0a             	shr    $0xa,%eax
   4d67b:	31 d0                	xor    %edx,%eax
   4d67d:	44 01 c8             	add    %r9d,%eax
   4d680:	49 89 c7             	mov    %rax,%r15
   4d683:	44 89 d0             	mov    %r10d,%eax
   4d686:	c1 c0 0f             	rol    $0xf,%eax
   4d689:	44 89 d2             	mov    %r10d,%edx
   4d68c:	c1 c2 0d             	rol    $0xd,%edx
   4d68f:	31 c2                	xor    %eax,%edx
   4d691:	44 89 d0             	mov    %r10d,%eax
   4d694:	4c 89 54 24 88       	mov    %r10,-0x78(%rsp)
   4d699:	c1 e8 0a             	shr    $0xa,%eax
   4d69c:	31 d0                	xor    %edx,%eax
   4d69e:	01 e9                	add    %ebp,%ecx
   4d6a0:	01 c8                	add    %ecx,%eax
   4d6a2:	48 89 44 24 90       	mov    %rax,-0x70(%rsp)
   4d6a7:	4c 8b 44 24 a8       	mov    -0x58(%rsp),%r8
   4d6ac:	44 89 c0             	mov    %r8d,%eax
   4d6af:	c1 c0 1a             	rol    $0x1a,%eax
   4d6b2:	44 89 c1             	mov    %r8d,%ecx
   4d6b5:	c1 c1 15             	rol    $0x15,%ecx
   4d6b8:	31 c1                	xor    %eax,%ecx
   4d6ba:	44 89 c0             	mov    %r8d,%eax
   4d6bd:	c1 c0 07             	rol    $0x7,%eax
   4d6c0:	31 c8                	xor    %ecx,%eax
   4d6c2:	8b 7c 24 20          	mov    0x20(%rsp),%edi
   4d6c6:	44 01 f7             	add    %r14d,%edi
   4d6c9:	4c 8b 5c 24 28       	mov    0x28(%rsp),%r11
   4d6ce:	44 89 d9             	mov    %r11d,%ecx
   4d6d1:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   4d6d6:	31 d1                	xor    %edx,%ecx
   4d6d8:	44 21 c1             	and    %r8d,%ecx
   4d6db:	31 d1                	xor    %edx,%ecx
   4d6dd:	48 89 d5             	mov    %rdx,%rbp
   4d6e0:	01 f9                	add    %edi,%ecx
   4d6e2:	44 89 e2             	mov    %r12d,%edx
   4d6e5:	c1 c2 1e             	rol    $0x1e,%edx
   4d6e8:	01 c1                	add    %eax,%ecx
   4d6ea:	81 c1 6f 2c e9 2d    	add    $0x2de92c6f,%ecx
   4d6f0:	44 89 e0             	mov    %r12d,%eax
   4d6f3:	c1 c0 13             	rol    $0x13,%eax
   4d6f6:	31 d0                	xor    %edx,%eax
   4d6f8:	44 89 e2             	mov    %r12d,%edx
   4d6fb:	c1 c2 0a             	rol    $0xa,%edx
   4d6fe:	31 c2                	xor    %eax,%edx
   4d700:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
   4d705:	44 89 f7             	mov    %r14d,%edi
   4d708:	44 31 ef             	xor    %r13d,%edi
   4d70b:	44 21 e7             	and    %r12d,%edi
   4d70e:	4c 89 e3             	mov    %r12,%rbx
   4d711:	44 89 f0             	mov    %r14d,%eax
   4d714:	44 21 e8             	and    %r13d,%eax
   4d717:	31 f8                	xor    %edi,%eax
   4d719:	01 d0                	add    %edx,%eax
   4d71b:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
   4d720:	41 01 c9             	add    %ecx,%r9d
   4d723:	44 89 ca             	mov    %r9d,%edx
   4d726:	c1 c2 1a             	rol    $0x1a,%edx
   4d729:	01 c8                	add    %ecx,%eax
   4d72b:	44 89 c9             	mov    %r9d,%ecx
   4d72e:	c1 c1 15             	rol    $0x15,%ecx
   4d731:	31 d1                	xor    %edx,%ecx
   4d733:	44 89 ca             	mov    %r9d,%edx
   4d736:	c1 c2 07             	rol    $0x7,%edx
   4d739:	31 ca                	xor    %ecx,%edx
   4d73b:	41 8d 0c 2a          	lea    (%r10,%rbp,1),%ecx
   4d73f:	44 89 c7             	mov    %r8d,%edi
   4d742:	4d 89 dc             	mov    %r11,%r12
   4d745:	44 31 e7             	xor    %r12d,%edi
   4d748:	44 21 cf             	and    %r9d,%edi
   4d74b:	45 89 ca             	mov    %r9d,%r10d
   4d74e:	44 31 e7             	xor    %r12d,%edi
   4d751:	4c 89 dd             	mov    %r11,%rbp
   4d754:	01 cf                	add    %ecx,%edi
   4d756:	01 fa                	add    %edi,%edx
   4d758:	81 c2 aa 84 74 4a    	add    $0x4a7484aa,%edx
   4d75e:	89 c1                	mov    %eax,%ecx
   4d760:	c1 c1 1e             	rol    $0x1e,%ecx
   4d763:	89 c7                	mov    %eax,%edi
   4d765:	c1 c7 13             	rol    $0x13,%edi
   4d768:	31 cf                	xor    %ecx,%edi
   4d76a:	41 89 c1             	mov    %eax,%r9d
   4d76d:	41 c1 c1 0a          	rol    $0xa,%r9d
   4d771:	41 31 f9             	xor    %edi,%r9d
   4d774:	89 df                	mov    %ebx,%edi
   4d776:	44 21 f7             	and    %r14d,%edi
   4d779:	89 d9                	mov    %ebx,%ecx
   4d77b:	44 31 f1             	xor    %r14d,%ecx
   4d77e:	4d 89 f3             	mov    %r14,%r11
   4d781:	21 c1                	and    %eax,%ecx
   4d783:	31 f9                	xor    %edi,%ecx
   4d785:	44 01 c9             	add    %r9d,%ecx
   4d788:	01 d1                	add    %edx,%ecx
   4d78a:	41 01 d5             	add    %edx,%r13d
   4d78d:	44 89 ea             	mov    %r13d,%edx
   4d790:	c1 c2 1a             	rol    $0x1a,%edx
   4d793:	44 89 ef             	mov    %r13d,%edi
   4d796:	c1 c7 15             	rol    $0x15,%edi
   4d799:	31 d7                	xor    %edx,%edi
   4d79b:	44 89 ea             	mov    %r13d,%edx
   4d79e:	4d 89 ec             	mov    %r13,%r12
   4d7a1:	c1 c2 07             	rol    $0x7,%edx
   4d7a4:	31 fa                	xor    %edi,%edx
   4d7a6:	4d 89 fe             	mov    %r15,%r14
   4d7a9:	45 89 d1             	mov    %r10d,%r9d
   4d7ac:	45 31 c1             	xor    %r8d,%r9d
   4d7af:	45 21 e1             	and    %r12d,%r9d
   4d7b2:	45 31 c1             	xor    %r8d,%r9d
   4d7b5:	45 01 f9             	add    %r15d,%r9d
   4d7b8:	41 01 e9             	add    %ebp,%r9d
   4d7bb:	89 cf                	mov    %ecx,%edi
   4d7bd:	c1 c7 1e             	rol    $0x1e,%edi
   4d7c0:	44 01 ca             	add    %r9d,%edx
   4d7c3:	81 c2 dc a9 b0 5c    	add    $0x5cb0a9dc,%edx
   4d7c9:	41 89 c9             	mov    %ecx,%r9d
   4d7cc:	41 c1 c1 13          	rol    $0x13,%r9d
   4d7d0:	41 31 f9             	xor    %edi,%r9d
   4d7d3:	89 cf                	mov    %ecx,%edi
   4d7d5:	c1 c7 0a             	rol    $0xa,%edi
   4d7d8:	44 31 cf             	xor    %r9d,%edi
   4d7db:	41 89 c5             	mov    %eax,%r13d
   4d7de:	41 31 dd             	xor    %ebx,%r13d
   4d7e1:	41 21 cd             	and    %ecx,%r13d
   4d7e4:	41 89 c1             	mov    %eax,%r9d
   4d7e7:	41 21 d9             	and    %ebx,%r9d
   4d7ea:	45 31 e9             	xor    %r13d,%r9d
   4d7ed:	41 01 f9             	add    %edi,%r9d
   4d7f0:	41 01 d3             	add    %edx,%r11d
   4d7f3:	44 89 df             	mov    %r11d,%edi
   4d7f6:	c1 c7 1a             	rol    $0x1a,%edi
   4d7f9:	41 01 d1             	add    %edx,%r9d
   4d7fc:	44 89 da             	mov    %r11d,%edx
   4d7ff:	c1 c2 15             	rol    $0x15,%edx
   4d802:	31 fa                	xor    %edi,%edx
   4d804:	44 89 df             	mov    %r11d,%edi
   4d807:	c1 c7 07             	rol    $0x7,%edi
   4d80a:	31 d7                	xor    %edx,%edi
   4d80c:	4c 8b 7c 24 90       	mov    -0x70(%rsp),%r15
   4d811:	43 8d 14 07          	lea    (%r15,%r8,1),%edx
   4d815:	45 89 e0             	mov    %r12d,%r8d
   4d818:	45 31 d0             	xor    %r10d,%r8d
   4d81b:	45 21 d8             	and    %r11d,%r8d
   4d81e:	4c 89 dd             	mov    %r11,%rbp
   4d821:	45 31 d0             	xor    %r10d,%r8d
   4d824:	41 01 d0             	add    %edx,%r8d
   4d827:	42 8d 14 07          	lea    (%rdi,%r8,1),%edx
   4d82b:	81 c2 da 88 f9 76    	add    $0x76f988da,%edx
   4d831:	44 89 cf             	mov    %r9d,%edi
   4d834:	c1 c7 1e             	rol    $0x1e,%edi
   4d837:	45 89 c8             	mov    %r9d,%r8d
   4d83a:	41 c1 c0 13          	rol    $0x13,%r8d
   4d83e:	41 31 f8             	xor    %edi,%r8d
   4d841:	44 89 cf             	mov    %r9d,%edi
   4d844:	c1 c7 0a             	rol    $0xa,%edi
   4d847:	44 31 c7             	xor    %r8d,%edi
   4d84a:	41 89 cd             	mov    %ecx,%r13d
   4d84d:	41 21 c5             	and    %eax,%r13d
   4d850:	41 89 c8             	mov    %ecx,%r8d
   4d853:	41 31 c0             	xor    %eax,%r8d
   4d856:	45 21 c8             	and    %r9d,%r8d
   4d859:	45 31 e8             	xor    %r13d,%r8d
   4d85c:	41 01 f8             	add    %edi,%r8d
   4d85f:	41 01 d0             	add    %edx,%r8d
   4d862:	01 d3                	add    %edx,%ebx
   4d864:	4d 89 f3             	mov    %r14,%r11
   4d867:	4c 89 74 24 e0       	mov    %r14,-0x20(%rsp)
   4d86c:	44 89 da             	mov    %r11d,%edx
   4d86f:	c1 c2 0f             	rol    $0xf,%edx
   4d872:	44 89 df             	mov    %r11d,%edi
   4d875:	c1 c7 0d             	rol    $0xd,%edi
   4d878:	31 d7                	xor    %edx,%edi
   4d87a:	41 c1 ee 0a          	shr    $0xa,%r14d
   4d87e:	41 31 fe             	xor    %edi,%r14d
   4d881:	48 8b 54 24 a0       	mov    -0x60(%rsp),%rdx
   4d886:	03 54 24 08          	add    0x8(%rsp),%edx
   4d88a:	41 01 d6             	add    %edx,%r14d
   4d88d:	44 89 fa             	mov    %r15d,%edx
   4d890:	c1 c2 0f             	rol    $0xf,%edx
   4d893:	44 89 ff             	mov    %r15d,%edi
   4d896:	c1 c7 0d             	rol    $0xd,%edi
   4d899:	31 d7                	xor    %edx,%edi
   4d89b:	41 c1 ef 0a          	shr    $0xa,%r15d
   4d89f:	41 31 ff             	xor    %edi,%r15d
   4d8a2:	48 8b 54 24 c8       	mov    -0x38(%rsp),%rdx
   4d8a7:	03 54 24 b8          	add    -0x48(%rsp),%edx
   4d8ab:	41 01 d7             	add    %edx,%r15d
   4d8ae:	44 89 f2             	mov    %r14d,%edx
   4d8b1:	c1 c2 0f             	rol    $0xf,%edx
   4d8b4:	44 89 f7             	mov    %r14d,%edi
   4d8b7:	c1 c7 0d             	rol    $0xd,%edi
   4d8ba:	31 d7                	xor    %edx,%edi
   4d8bc:	44 89 f2             	mov    %r14d,%edx
   4d8bf:	45 89 f3             	mov    %r14d,%r11d
   4d8c2:	44 89 74 24 38       	mov    %r14d,0x38(%rsp)
   4d8c7:	c1 ea 0a             	shr    $0xa,%edx
   4d8ca:	31 fa                	xor    %edi,%edx
   4d8cc:	48 8b 7c 24 98       	mov    -0x68(%rsp),%rdi
   4d8d1:	03 7c 24 f0          	add    -0x10(%rsp),%edi
   4d8d5:	01 fa                	add    %edi,%edx
   4d8d7:	49 89 d6             	mov    %rdx,%r14
   4d8da:	44 89 fa             	mov    %r15d,%edx
   4d8dd:	c1 c2 0f             	rol    $0xf,%edx
   4d8e0:	44 89 ff             	mov    %r15d,%edi
   4d8e3:	c1 c7 0d             	rol    $0xd,%edi
   4d8e6:	31 d7                	xor    %edx,%edi
   4d8e8:	44 89 fa             	mov    %r15d,%edx
   4d8eb:	4c 89 3c 24          	mov    %r15,(%rsp)
   4d8ef:	c1 ea 0a             	shr    $0xa,%edx
   4d8f2:	31 fa                	xor    %edi,%edx
   4d8f4:	03 74 24 f8          	add    -0x8(%rsp),%esi
   4d8f8:	01 f2                	add    %esi,%edx
   4d8fa:	49 89 d5             	mov    %rdx,%r13
   4d8fd:	89 da                	mov    %ebx,%edx
   4d8ff:	c1 c2 1a             	rol    $0x1a,%edx
   4d902:	89 de                	mov    %ebx,%esi
   4d904:	c1 c6 15             	rol    $0x15,%esi
   4d907:	31 d6                	xor    %edx,%esi
   4d909:	89 da                	mov    %ebx,%edx
   4d90b:	c1 c2 07             	rol    $0x7,%edx
   4d90e:	31 f2                	xor    %esi,%edx
   4d910:	45 01 da             	add    %r11d,%r10d
   4d913:	89 ee                	mov    %ebp,%esi
   4d915:	44 31 e6             	xor    %r12d,%esi
   4d918:	21 de                	and    %ebx,%esi
   4d91a:	44 31 e6             	xor    %r12d,%esi
   4d91d:	44 01 d6             	add    %r10d,%esi
   4d920:	44 89 c7             	mov    %r8d,%edi
   4d923:	c1 c7 1e             	rol    $0x1e,%edi
   4d926:	01 f2                	add    %esi,%edx
   4d928:	81 c2 52 51 3e 98    	add    $0x983e5152,%edx
   4d92e:	44 89 c6             	mov    %r8d,%esi
   4d931:	c1 c6 13             	rol    $0x13,%esi
   4d934:	31 fe                	xor    %edi,%esi
   4d936:	44 89 c7             	mov    %r8d,%edi
   4d939:	c1 c7 0a             	rol    $0xa,%edi
   4d93c:	31 f7                	xor    %esi,%edi
   4d93e:	44 89 ce             	mov    %r9d,%esi
   4d941:	31 ce                	xor    %ecx,%esi
   4d943:	44 21 c6             	and    %r8d,%esi
   4d946:	45 89 ca             	mov    %r9d,%r10d
   4d949:	41 21 ca             	and    %ecx,%r10d
   4d94c:	41 31 f2             	xor    %esi,%r10d
   4d94f:	41 01 fa             	add    %edi,%r10d
   4d952:	01 d0                	add    %edx,%eax
   4d954:	89 c6                	mov    %eax,%esi
   4d956:	c1 c6 1a             	rol    $0x1a,%esi
   4d959:	41 01 d2             	add    %edx,%r10d
   4d95c:	89 c2                	mov    %eax,%edx
   4d95e:	c1 c2 15             	rol    $0x15,%edx
   4d961:	31 f2                	xor    %esi,%edx
   4d963:	89 c6                	mov    %eax,%esi
   4d965:	c1 c6 07             	rol    $0x7,%esi
   4d968:	31 d6                	xor    %edx,%esi
   4d96a:	89 df                	mov    %ebx,%edi
   4d96c:	31 ef                	xor    %ebp,%edi
   4d96e:	21 c7                	and    %eax,%edi
   4d970:	31 ef                	xor    %ebp,%edi
   4d972:	44 01 ff             	add    %r15d,%edi
   4d975:	44 01 e7             	add    %r12d,%edi
   4d978:	8d 14 3e             	lea    (%rsi,%rdi,1),%edx
   4d97b:	81 c2 6d c6 31 a8    	add    $0xa831c66d,%edx
   4d981:	44 89 d6             	mov    %r10d,%esi
   4d984:	c1 c6 1e             	rol    $0x1e,%esi
   4d987:	44 89 d7             	mov    %r10d,%edi
   4d98a:	c1 c7 13             	rol    $0x13,%edi
   4d98d:	31 f7                	xor    %esi,%edi
   4d98f:	45 89 d3             	mov    %r10d,%r11d
   4d992:	41 c1 c3 0a          	rol    $0xa,%r11d
   4d996:	41 31 fb             	xor    %edi,%r11d
   4d999:	44 89 c7             	mov    %r8d,%edi
   4d99c:	44 21 cf             	and    %r9d,%edi
   4d99f:	45 89 c7             	mov    %r8d,%r15d
   4d9a2:	45 31 cf             	xor    %r9d,%r15d
   4d9a5:	45 21 d7             	and    %r10d,%r15d
   4d9a8:	41 31 ff             	xor    %edi,%r15d
   4d9ab:	45 01 df             	add    %r11d,%r15d
   4d9ae:	41 01 d7             	add    %edx,%r15d
   4d9b1:	01 d1                	add    %edx,%ecx
   4d9b3:	89 ca                	mov    %ecx,%edx
   4d9b5:	c1 c2 1a             	rol    $0x1a,%edx
   4d9b8:	89 cf                	mov    %ecx,%edi
   4d9ba:	c1 c7 15             	rol    $0x15,%edi
   4d9bd:	31 d7                	xor    %edx,%edi
   4d9bf:	89 ca                	mov    %ecx,%edx
   4d9c1:	c1 c2 07             	rol    $0x7,%edx
   4d9c4:	31 fa                	xor    %edi,%edx
   4d9c6:	41 89 c3             	mov    %eax,%r11d
   4d9c9:	41 31 db             	xor    %ebx,%r11d
   4d9cc:	41 21 cb             	and    %ecx,%r11d
   4d9cf:	41 31 db             	xor    %ebx,%r11d
   4d9d2:	45 01 f3             	add    %r14d,%r11d
   4d9d5:	41 01 eb             	add    %ebp,%r11d
   4d9d8:	44 89 ff             	mov    %r15d,%edi
   4d9db:	c1 c7 1e             	rol    $0x1e,%edi
   4d9de:	44 01 da             	add    %r11d,%edx
   4d9e1:	81 c2 c8 27 03 b0    	add    $0xb00327c8,%edx
   4d9e7:	45 89 fb             	mov    %r15d,%r11d
   4d9ea:	41 c1 c3 13          	rol    $0x13,%r11d
   4d9ee:	41 31 fb             	xor    %edi,%r11d
   4d9f1:	44 89 ff             	mov    %r15d,%edi
   4d9f4:	c1 c7 0a             	rol    $0xa,%edi
   4d9f7:	44 31 df             	xor    %r11d,%edi
   4d9fa:	45 89 d4             	mov    %r10d,%r12d
   4d9fd:	45 31 c4             	xor    %r8d,%r12d
   4da00:	45 21 fc             	and    %r15d,%r12d
   4da03:	44 89 d6             	mov    %r10d,%esi
   4da06:	44 21 c6             	and    %r8d,%esi
   4da09:	44 31 e6             	xor    %r12d,%esi
   4da0c:	01 fe                	add    %edi,%esi
   4da0e:	41 01 d1             	add    %edx,%r9d
   4da11:	44 89 cf             	mov    %r9d,%edi
   4da14:	c1 c7 1a             	rol    $0x1a,%edi
   4da17:	01 d6                	add    %edx,%esi
   4da19:	44 89 ca             	mov    %r9d,%edx
   4da1c:	c1 c2 15             	rol    $0x15,%edx
   4da1f:	31 fa                	xor    %edi,%edx
   4da21:	44 89 cf             	mov    %r9d,%edi
   4da24:	c1 c7 07             	rol    $0x7,%edi
   4da27:	31 d7                	xor    %edx,%edi
   4da29:	42 8d 14 2b          	lea    (%rbx,%r13,1),%edx
   4da2d:	89 cb                	mov    %ecx,%ebx
   4da2f:	31 c3                	xor    %eax,%ebx
   4da31:	44 21 cb             	and    %r9d,%ebx
   4da34:	31 c3                	xor    %eax,%ebx
   4da36:	01 d3                	add    %edx,%ebx
   4da38:	8d 14 1f             	lea    (%rdi,%rbx,1),%edx
   4da3b:	81 c2 c7 7f 59 bf    	add    $0xbf597fc7,%edx
   4da41:	89 f7                	mov    %esi,%edi
   4da43:	c1 c7 1e             	rol    $0x1e,%edi
   4da46:	89 f3                	mov    %esi,%ebx
   4da48:	c1 c3 13             	rol    $0x13,%ebx
   4da4b:	31 fb                	xor    %edi,%ebx
   4da4d:	41 89 f4             	mov    %esi,%r12d
   4da50:	41 c1 c4 0a          	rol    $0xa,%r12d
   4da54:	41 31 dc             	xor    %ebx,%r12d
   4da57:	44 89 fb             	mov    %r15d,%ebx
   4da5a:	44 89 54 24 a0       	mov    %r10d,-0x60(%rsp)
   4da5f:	44 21 d3             	and    %r10d,%ebx
   4da62:	45 89 fb             	mov    %r15d,%r11d
   4da65:	45 31 d3             	xor    %r10d,%r11d
   4da68:	41 21 f3             	and    %esi,%r11d
   4da6b:	41 31 db             	xor    %ebx,%r11d
   4da6e:	45 01 e3             	add    %r12d,%r11d
   4da71:	41 01 d3             	add    %edx,%r11d
   4da74:	41 01 d0             	add    %edx,%r8d
   4da77:	4c 89 74 24 98       	mov    %r14,-0x68(%rsp)
   4da7c:	44 89 f2             	mov    %r14d,%edx
   4da7f:	c1 c2 0f             	rol    $0xf,%edx
   4da82:	44 89 f3             	mov    %r14d,%ebx
   4da85:	c1 c3 0d             	rol    $0xd,%ebx
   4da88:	31 d3                	xor    %edx,%ebx
   4da8a:	44 89 f7             	mov    %r14d,%edi
   4da8d:	c1 ef 0a             	shr    $0xa,%edi
   4da90:	31 df                	xor    %ebx,%edi
   4da92:	48 8b 54 24 c0       	mov    -0x40(%rsp),%rdx
   4da97:	03 54 24 88          	add    -0x78(%rsp),%edx
   4da9b:	01 d7                	add    %edx,%edi
   4da9d:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
   4daa2:	44 89 ea             	mov    %r13d,%edx
   4daa5:	c1 c2 0f             	rol    $0xf,%edx
   4daa8:	44 89 eb             	mov    %r13d,%ebx
   4daab:	c1 c3 0d             	rol    $0xd,%ebx
   4daae:	31 d3                	xor    %edx,%ebx
   4dab0:	44 89 ea             	mov    %r13d,%edx
   4dab3:	49 89 d2             	mov    %rdx,%r10
   4dab6:	41 c1 ea 0a          	shr    $0xa,%r10d
   4daba:	41 31 da             	xor    %ebx,%r10d
   4dabd:	48 8b 54 24 e8       	mov    -0x18(%rsp),%rdx
   4dac2:	03 54 24 e0          	add    -0x20(%rsp),%edx
   4dac6:	41 01 d2             	add    %edx,%r10d
   4dac9:	89 fa                	mov    %edi,%edx
   4dacb:	c1 c2 0f             	rol    $0xf,%edx
   4dace:	89 fb                	mov    %edi,%ebx
   4dad0:	c1 c3 0d             	rol    $0xd,%ebx
   4dad3:	31 d3                	xor    %edx,%ebx
   4dad5:	89 fa                	mov    %edi,%edx
   4dad7:	89 7c 24 84          	mov    %edi,-0x7c(%rsp)
   4dadb:	c1 ea 0a             	shr    $0xa,%edx
   4dade:	31 da                	xor    %ebx,%edx
   4dae0:	48 8b 5c 24 b0       	mov    -0x50(%rsp),%rbx
   4dae5:	03 5c 24 90          	add    -0x70(%rsp),%ebx
   4dae9:	01 da                	add    %ebx,%edx
   4daeb:	49 89 d5             	mov    %rdx,%r13
   4daee:	48 89 54 24 b0       	mov    %rdx,-0x50(%rsp)
   4daf3:	44 89 d2             	mov    %r10d,%edx
   4daf6:	c1 c2 0f             	rol    $0xf,%edx
   4daf9:	44 89 d3             	mov    %r10d,%ebx
   4dafc:	c1 c3 0d             	rol    $0xd,%ebx
   4daff:	31 d3                	xor    %edx,%ebx
   4db01:	45 89 d4             	mov    %r10d,%r12d
   4db04:	4d 89 d6             	mov    %r10,%r14
   4db07:	4c 89 54 24 c0       	mov    %r10,-0x40(%rsp)
   4db0c:	41 c1 ec 0a          	shr    $0xa,%r12d
   4db10:	41 31 dc             	xor    %ebx,%r12d
   4db13:	44 8b 54 24 10       	mov    0x10(%rsp),%r10d
   4db18:	44 03 54 24 38       	add    0x38(%rsp),%r10d
   4db1d:	45 01 d4             	add    %r10d,%r12d
   4db20:	4c 89 64 24 a8       	mov    %r12,-0x58(%rsp)
   4db25:	44 89 c2             	mov    %r8d,%edx
   4db28:	c1 c2 1a             	rol    $0x1a,%edx
   4db2b:	44 89 c3             	mov    %r8d,%ebx
   4db2e:	c1 c3 15             	rol    $0x15,%ebx
   4db31:	31 d3                	xor    %edx,%ebx
   4db33:	44 89 c2             	mov    %r8d,%edx
   4db36:	c1 c2 07             	rol    $0x7,%edx
   4db39:	31 da                	xor    %ebx,%edx
   4db3b:	01 f8                	add    %edi,%eax
   4db3d:	44 89 cb             	mov    %r9d,%ebx
   4db40:	31 cb                	xor    %ecx,%ebx
   4db42:	44 21 c3             	and    %r8d,%ebx
   4db45:	31 cb                	xor    %ecx,%ebx
   4db47:	01 c3                	add    %eax,%ebx
   4db49:	44 89 d8             	mov    %r11d,%eax
   4db4c:	c1 c0 1e             	rol    $0x1e,%eax
   4db4f:	01 da                	add    %ebx,%edx
   4db51:	81 c2 f3 0b e0 c6    	add    $0xc6e00bf3,%edx
   4db57:	44 89 db             	mov    %r11d,%ebx
   4db5a:	c1 c3 13             	rol    $0x13,%ebx
   4db5d:	31 c3                	xor    %eax,%ebx
   4db5f:	44 89 dd             	mov    %r11d,%ebp
   4db62:	c1 c5 0a             	rol    $0xa,%ebp
   4db65:	31 dd                	xor    %ebx,%ebp
   4db67:	89 f3                	mov    %esi,%ebx
   4db69:	44 31 fb             	xor    %r15d,%ebx
   4db6c:	44 21 db             	and    %r11d,%ebx
   4db6f:	41 89 f2             	mov    %esi,%r10d
   4db72:	45 21 fa             	and    %r15d,%r10d
   4db75:	41 31 da             	xor    %ebx,%r10d
   4db78:	41 01 ea             	add    %ebp,%r10d
   4db7b:	8b 44 24 a0          	mov    -0x60(%rsp),%eax
   4db7f:	01 d0                	add    %edx,%eax
   4db81:	89 c3                	mov    %eax,%ebx
   4db83:	c1 c3 1a             	rol    $0x1a,%ebx
   4db86:	41 01 d2             	add    %edx,%r10d
   4db89:	89 c2                	mov    %eax,%edx
   4db8b:	c1 c2 15             	rol    $0x15,%edx
   4db8e:	31 da                	xor    %ebx,%edx
   4db90:	89 c3                	mov    %eax,%ebx
   4db92:	c1 c3 07             	rol    $0x7,%ebx
   4db95:	31 d3                	xor    %edx,%ebx
   4db97:	44 01 f1             	add    %r14d,%ecx
   4db9a:	44 89 c2             	mov    %r8d,%edx
   4db9d:	44 31 ca             	xor    %r9d,%edx
   4dba0:	21 c2                	and    %eax,%edx
   4dba2:	44 31 ca             	xor    %r9d,%edx
   4dba5:	01 ca                	add    %ecx,%edx
   4dba7:	8d 0c 13             	lea    (%rbx,%rdx,1),%ecx
   4dbaa:	81 c1 47 91 a7 d5    	add    $0xd5a79147,%ecx
   4dbb0:	44 89 d2             	mov    %r10d,%edx
   4dbb3:	c1 c2 1e             	rol    $0x1e,%edx
   4dbb6:	44 89 d3             	mov    %r10d,%ebx
   4dbb9:	c1 c3 13             	rol    $0x13,%ebx
   4dbbc:	31 d3                	xor    %edx,%ebx
   4dbbe:	44 89 d5             	mov    %r10d,%ebp
   4dbc1:	c1 c5 0a             	rol    $0xa,%ebp
   4dbc4:	31 dd                	xor    %ebx,%ebp
   4dbc6:	44 89 db             	mov    %r11d,%ebx
   4dbc9:	21 f3                	and    %esi,%ebx
   4dbcb:	45 89 de             	mov    %r11d,%r14d
   4dbce:	41 31 f6             	xor    %esi,%r14d
   4dbd1:	45 21 d6             	and    %r10d,%r14d
   4dbd4:	41 31 de             	xor    %ebx,%r14d
   4dbd7:	41 01 ee             	add    %ebp,%r14d
   4dbda:	41 01 ce             	add    %ecx,%r14d
   4dbdd:	41 01 cf             	add    %ecx,%r15d
   4dbe0:	44 89 f9             	mov    %r15d,%ecx
   4dbe3:	c1 c1 1a             	rol    $0x1a,%ecx
   4dbe6:	44 89 fb             	mov    %r15d,%ebx
   4dbe9:	c1 c3 15             	rol    $0x15,%ebx
   4dbec:	31 cb                	xor    %ecx,%ebx
   4dbee:	44 89 f9             	mov    %r15d,%ecx
   4dbf1:	c1 c1 07             	rol    $0x7,%ecx
   4dbf4:	31 d9                	xor    %ebx,%ecx
   4dbf6:	45 01 e9             	add    %r13d,%r9d
   4dbf9:	89 c3                	mov    %eax,%ebx
   4dbfb:	44 31 c3             	xor    %r8d,%ebx
   4dbfe:	44 21 fb             	and    %r15d,%ebx
   4dc01:	44 31 c3             	xor    %r8d,%ebx
   4dc04:	44 01 cb             	add    %r9d,%ebx
   4dc07:	45 89 f1             	mov    %r14d,%r9d
   4dc0a:	41 c1 c1 1e          	rol    $0x1e,%r9d
   4dc0e:	01 d9                	add    %ebx,%ecx
   4dc10:	81 c1 51 63 ca 06    	add    $0x6ca6351,%ecx
   4dc16:	44 89 f3             	mov    %r14d,%ebx
   4dc19:	c1 c3 13             	rol    $0x13,%ebx
   4dc1c:	44 31 cb             	xor    %r9d,%ebx
   4dc1f:	44 89 f5             	mov    %r14d,%ebp
   4dc22:	c1 c5 0a             	rol    $0xa,%ebp
   4dc25:	31 dd                	xor    %ebx,%ebp
   4dc27:	44 89 d3             	mov    %r10d,%ebx
   4dc2a:	44 31 db             	xor    %r11d,%ebx
   4dc2d:	44 21 f3             	and    %r14d,%ebx
   4dc30:	45 89 d1             	mov    %r10d,%r9d
   4dc33:	45 21 d9             	and    %r11d,%r9d
   4dc36:	41 31 d9             	xor    %ebx,%r9d
   4dc39:	41 01 e9             	add    %ebp,%r9d
   4dc3c:	01 ce                	add    %ecx,%esi
   4dc3e:	89 f3                	mov    %esi,%ebx
   4dc40:	c1 c3 1a             	rol    $0x1a,%ebx
   4dc43:	41 01 c9             	add    %ecx,%r9d
   4dc46:	89 f1                	mov    %esi,%ecx
   4dc48:	c1 c1 15             	rol    $0x15,%ecx
   4dc4b:	31 d9                	xor    %ebx,%ecx
   4dc4d:	89 f3                	mov    %esi,%ebx
   4dc4f:	48 89 74 24 c8       	mov    %rsi,-0x38(%rsp)
   4dc54:	c1 c3 07             	rol    $0x7,%ebx
   4dc57:	31 cb                	xor    %ecx,%ebx
   4dc59:	43 8d 0c 04          	lea    (%r12,%r8,1),%ecx
   4dc5d:	45 89 f8             	mov    %r15d,%r8d
   4dc60:	89 44 24 a0          	mov    %eax,-0x60(%rsp)
   4dc64:	41 31 c0             	xor    %eax,%r8d
   4dc67:	41 21 f0             	and    %esi,%r8d
   4dc6a:	41 31 c0             	xor    %eax,%r8d
   4dc6d:	41 01 c8             	add    %ecx,%r8d
   4dc70:	41 01 d8             	add    %ebx,%r8d
   4dc73:	41 81 c0 67 29 29 14 	add    $0x14292967,%r8d
   4dc7a:	44 89 c9             	mov    %r9d,%ecx
   4dc7d:	c1 c1 1e             	rol    $0x1e,%ecx
   4dc80:	44 89 cd             	mov    %r9d,%ebp
   4dc83:	c1 c5 13             	rol    $0x13,%ebp
   4dc86:	31 cd                	xor    %ecx,%ebp
   4dc88:	44 89 cb             	mov    %r9d,%ebx
   4dc8b:	c1 c3 0a             	rol    $0xa,%ebx
   4dc8e:	31 eb                	xor    %ebp,%ebx
   4dc90:	4c 89 74 24 e8       	mov    %r14,-0x18(%rsp)
   4dc95:	44 89 f5             	mov    %r14d,%ebp
   4dc98:	44 21 d5             	and    %r10d,%ebp
   4dc9b:	8b 4c 24 f8          	mov    -0x8(%rsp),%ecx
   4dc9f:	41 89 cd             	mov    %ecx,%r13d
   4dca2:	41 c1 c5 19          	rol    $0x19,%r13d
   4dca6:	48 8b 74 24 f0       	mov    -0x10(%rsp),%rsi
   4dcab:	41 89 f4             	mov    %esi,%r12d
   4dcae:	41 c1 c4 19          	rol    $0x19,%r12d
   4dcb2:	45 31 d6             	xor    %r10d,%r14d
   4dcb5:	48 8b 54 24 b8       	mov    -0x48(%rsp),%rdx
   4dcba:	89 d0                	mov    %edx,%eax
   4dcbc:	c1 c0 19             	rol    $0x19,%eax
   4dcbf:	89 44 24 20          	mov    %eax,0x20(%rsp)
   4dcc3:	45 21 ce             	and    %r9d,%r14d
   4dcc6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   4dccb:	89 c7                	mov    %eax,%edi
   4dccd:	c1 c7 19             	rol    $0x19,%edi
   4dcd0:	89 7c 24 18          	mov    %edi,0x18(%rsp)
   4dcd4:	41 31 ee             	xor    %ebp,%r14d
   4dcd7:	89 cf                	mov    %ecx,%edi
   4dcd9:	c1 c7 0e             	rol    $0xe,%edi
   4dcdc:	41 01 de             	add    %ebx,%r14d
   4dcdf:	89 f1                	mov    %esi,%ecx
   4dce1:	c1 c1 0e             	rol    $0xe,%ecx
   4dce4:	89 ce                	mov    %ecx,%esi
   4dce6:	45 01 c6             	add    %r8d,%r14d
   4dce9:	89 d1                	mov    %edx,%ecx
   4dceb:	c1 c1 0e             	rol    $0xe,%ecx
   4dcee:	89 ca                	mov    %ecx,%edx
   4dcf0:	45 01 c3             	add    %r8d,%r11d
   4dcf3:	89 c1                	mov    %eax,%ecx
   4dcf5:	c1 c1 0e             	rol    $0xe,%ecx
   4dcf8:	89 c8                	mov    %ecx,%eax
   4dcfa:	44 31 ef             	xor    %r13d,%edi
   4dcfd:	89 7c 24 28          	mov    %edi,0x28(%rsp)
   4dd01:	8b 4c 24 38          	mov    0x38(%rsp),%ecx
   4dd05:	89 cb                	mov    %ecx,%ebx
   4dd07:	c1 c3 19             	rol    $0x19,%ebx
   4dd0a:	41 89 f0             	mov    %esi,%r8d
   4dd0d:	45 31 e0             	xor    %r12d,%r8d
   4dd10:	48 8b 7c 24 90       	mov    -0x70(%rsp),%rdi
   4dd15:	89 fd                	mov    %edi,%ebp
   4dd17:	c1 c5 19             	rol    $0x19,%ebp
   4dd1a:	33 54 24 20          	xor    0x20(%rsp),%edx
   4dd1e:	89 54 24 48          	mov    %edx,0x48(%rsp)
   4dd22:	48 8b 74 24 e0       	mov    -0x20(%rsp),%rsi
   4dd27:	41 89 f5             	mov    %esi,%r13d
   4dd2a:	41 c1 c5 19          	rol    $0x19,%r13d
   4dd2e:	33 44 24 18          	xor    0x18(%rsp),%eax
   4dd32:	89 44 24 18          	mov    %eax,0x18(%rsp)
   4dd36:	89 c8                	mov    %ecx,%eax
   4dd38:	41 89 cc             	mov    %ecx,%r12d
   4dd3b:	c1 c0 0e             	rol    $0xe,%eax
   4dd3e:	31 d8                	xor    %ebx,%eax
   4dd40:	89 f9                	mov    %edi,%ecx
   4dd42:	c1 c1 0e             	rol    $0xe,%ecx
   4dd45:	31 e9                	xor    %ebp,%ecx
   4dd47:	89 f5                	mov    %esi,%ebp
   4dd49:	c1 c5 0e             	rol    $0xe,%ebp
   4dd4c:	44 31 ed             	xor    %r13d,%ebp
   4dd4f:	48 8b 54 24 88       	mov    -0x78(%rsp),%rdx
   4dd54:	89 d3                	mov    %edx,%ebx
   4dd56:	c1 c3 19             	rol    $0x19,%ebx
   4dd59:	41 89 d5             	mov    %edx,%r13d
   4dd5c:	41 c1 c5 0e          	rol    $0xe,%r13d
   4dd60:	41 31 dd             	xor    %ebx,%r13d
   4dd63:	41 c1 ec 03          	shr    $0x3,%r12d
   4dd67:	41 31 c4             	xor    %eax,%r12d
   4dd6a:	41 01 fc             	add    %edi,%r12d
   4dd6d:	44 89 64 24 20       	mov    %r12d,0x20(%rsp)
   4dd72:	c1 ef 03             	shr    $0x3,%edi
   4dd75:	31 cf                	xor    %ecx,%edi
   4dd77:	01 f7                	add    %esi,%edi
   4dd79:	48 89 7c 24 90       	mov    %rdi,-0x70(%rsp)
   4dd7e:	c1 ee 03             	shr    $0x3,%esi
   4dd81:	31 ee                	xor    %ebp,%esi
   4dd83:	01 d6                	add    %edx,%esi
   4dd85:	48 89 74 24 e0       	mov    %rsi,-0x20(%rsp)
   4dd8a:	c1 ea 03             	shr    $0x3,%edx
   4dd8d:	44 31 ea             	xor    %r13d,%edx
   4dd90:	8b 6c 24 f8          	mov    -0x8(%rsp),%ebp
   4dd94:	01 ea                	add    %ebp,%edx
   4dd96:	48 89 54 24 88       	mov    %rdx,-0x78(%rsp)
   4dd9b:	c1 ed 03             	shr    $0x3,%ebp
   4dd9e:	33 6c 24 28          	xor    0x28(%rsp),%ebp
   4dda2:	4c 8b 6c 24 f0       	mov    -0x10(%rsp),%r13
   4dda7:	44 01 ed             	add    %r13d,%ebp
   4ddaa:	41 c1 ed 03          	shr    $0x3,%r13d
   4ddae:	45 31 c5             	xor    %r8d,%r13d
   4ddb1:	48 8b 44 24 b8       	mov    -0x48(%rsp),%rax
   4ddb6:	41 01 c5             	add    %eax,%r13d
   4ddb9:	c1 e8 03             	shr    $0x3,%eax
   4ddbc:	33 44 24 48          	xor    0x48(%rsp),%eax
   4ddc0:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   4ddc5:	01 c8                	add    %ecx,%eax
   4ddc7:	48 89 c3             	mov    %rax,%rbx
   4ddca:	c1 e9 03             	shr    $0x3,%ecx
   4ddcd:	33 4c 24 18          	xor    0x18(%rsp),%ecx
   4ddd1:	48 8b 54 24 b0       	mov    -0x50(%rsp),%rdx
   4ddd6:	89 d0                	mov    %edx,%eax
   4ddd8:	c1 c0 0f             	rol    $0xf,%eax
   4dddb:	03 4c 24 80          	add    -0x80(%rsp),%ecx
   4dddf:	49 89 c8             	mov    %rcx,%r8
   4dde2:	89 d1                	mov    %edx,%ecx
   4dde4:	c1 c1 0d             	rol    $0xd,%ecx
   4dde7:	31 c1                	xor    %eax,%ecx
   4dde9:	89 d0                	mov    %edx,%eax
   4ddeb:	c1 e8 0a             	shr    $0xa,%eax
   4ddee:	31 c8                	xor    %ecx,%eax
   4ddf0:	44 03 04 24          	add    (%rsp),%r8d
   4ddf4:	48 8b 54 24 a8       	mov    -0x58(%rsp),%rdx
   4ddf9:	89 d6                	mov    %edx,%esi
   4ddfb:	c1 c6 0f             	rol    $0xf,%esi
   4ddfe:	44 01 c0             	add    %r8d,%eax
   4de01:	89 d1                	mov    %edx,%ecx
   4de03:	c1 c1 0d             	rol    $0xd,%ecx
   4de06:	31 f1                	xor    %esi,%ecx
   4de08:	41 89 d0             	mov    %edx,%r8d
   4de0b:	41 c1 e8 0a          	shr    $0xa,%r8d
   4de0f:	41 31 c8             	xor    %ecx,%r8d
   4de12:	03 5c 24 98          	add    -0x68(%rsp),%ebx
   4de16:	89 c2                	mov    %eax,%edx
   4de18:	c1 c2 0f             	rol    $0xf,%edx
   4de1b:	41 01 d8             	add    %ebx,%r8d
   4de1e:	89 c1                	mov    %eax,%ecx
   4de20:	c1 c1 0d             	rol    $0xd,%ecx
   4de23:	31 d1                	xor    %edx,%ecx
   4de25:	89 c2                	mov    %eax,%edx
   4de27:	89 c7                	mov    %eax,%edi
   4de29:	89 44 24 80          	mov    %eax,-0x80(%rsp)
   4de2d:	c1 ea 0a             	shr    $0xa,%edx
   4de30:	31 ca                	xor    %ecx,%edx
   4de32:	44 03 6c 24 30       	add    0x30(%rsp),%r13d
   4de37:	44 89 c0             	mov    %r8d,%eax
   4de3a:	c1 c0 0f             	rol    $0xf,%eax
   4de3d:	44 01 ea             	add    %r13d,%edx
   4de40:	44 89 c1             	mov    %r8d,%ecx
   4de43:	c1 c1 0d             	rol    $0xd,%ecx
   4de46:	31 c1                	xor    %eax,%ecx
   4de48:	45 89 c5             	mov    %r8d,%r13d
   4de4b:	4c 89 c6             	mov    %r8,%rsi
   4de4e:	4c 89 44 24 b8       	mov    %r8,-0x48(%rsp)
   4de53:	41 c1 ed 0a          	shr    $0xa,%r13d
   4de57:	41 31 cd             	xor    %ecx,%r13d
   4de5a:	03 6c 24 84          	add    -0x7c(%rsp),%ebp
   4de5e:	44 89 d8             	mov    %r11d,%eax
   4de61:	c1 c0 1a             	rol    $0x1a,%eax
   4de64:	41 01 ed             	add    %ebp,%r13d
   4de67:	44 89 d9             	mov    %r11d,%ecx
   4de6a:	c1 c1 15             	rol    $0x15,%ecx
   4de6d:	31 c1                	xor    %eax,%ecx
   4de6f:	44 89 d8             	mov    %r11d,%eax
   4de72:	c1 c0 07             	rol    $0x7,%eax
   4de75:	31 c8                	xor    %ecx,%eax
   4de77:	44 8b 44 24 a0       	mov    -0x60(%rsp),%r8d
   4de7c:	41 01 f8             	add    %edi,%r8d
   4de7f:	48 8b 5c 24 c8       	mov    -0x38(%rsp),%rbx
   4de84:	89 d9                	mov    %ebx,%ecx
   4de86:	44 31 f9             	xor    %r15d,%ecx
   4de89:	44 21 d9             	and    %r11d,%ecx
   4de8c:	44 31 f9             	xor    %r15d,%ecx
   4de8f:	44 01 c1             	add    %r8d,%ecx
   4de92:	01 c8                	add    %ecx,%eax
   4de94:	05 85 0a b7 27       	add    $0x27b70a85,%eax
   4de99:	44 89 f1             	mov    %r14d,%ecx
   4de9c:	c1 c1 1e             	rol    $0x1e,%ecx
   4de9f:	45 89 f0             	mov    %r14d,%r8d
   4dea2:	41 c1 c0 13          	rol    $0x13,%r8d
   4dea6:	41 31 c8             	xor    %ecx,%r8d
   4dea9:	44 89 f1             	mov    %r14d,%ecx
   4deac:	c1 c1 0a             	rol    $0xa,%ecx
   4deaf:	44 31 c1             	xor    %r8d,%ecx
   4deb2:	44 89 cd             	mov    %r9d,%ebp
   4deb5:	48 8b 7c 24 e8       	mov    -0x18(%rsp),%rdi
   4deba:	31 fd                	xor    %edi,%ebp
   4debc:	44 21 f5             	and    %r14d,%ebp
   4debf:	45 89 c8             	mov    %r9d,%r8d
   4dec2:	41 21 f8             	and    %edi,%r8d
   4dec5:	41 31 e8             	xor    %ebp,%r8d
   4dec8:	41 01 c8             	add    %ecx,%r8d
   4decb:	41 01 c0             	add    %eax,%r8d
   4dece:	45 89 c4             	mov    %r8d,%r12d
   4ded1:	41 01 c2             	add    %eax,%r10d
   4ded4:	44 89 d0             	mov    %r10d,%eax
   4ded7:	c1 c0 1a             	rol    $0x1a,%eax
   4deda:	44 89 d1             	mov    %r10d,%ecx
   4dedd:	c1 c1 15             	rol    $0x15,%ecx
   4dee0:	31 c1                	xor    %eax,%ecx
   4dee2:	44 89 d0             	mov    %r10d,%eax
   4dee5:	c1 c0 07             	rol    $0x7,%eax
   4dee8:	31 c8                	xor    %ecx,%eax
   4deea:	42 8d 0c 3e          	lea    (%rsi,%r15,1),%ecx
   4deee:	44 89 de             	mov    %r11d,%esi
   4def1:	49 89 d8             	mov    %rbx,%r8
   4def4:	44 31 c6             	xor    %r8d,%esi
   4def7:	44 21 d6             	and    %r10d,%esi
   4defa:	44 31 c6             	xor    %r8d,%esi
   4defd:	49 89 df             	mov    %rbx,%r15
   4df00:	01 ce                	add    %ecx,%esi
   4df02:	44 89 e1             	mov    %r12d,%ecx
   4df05:	c1 c1 1e             	rol    $0x1e,%ecx
   4df08:	01 f0                	add    %esi,%eax
   4df0a:	05 38 21 1b 2e       	add    $0x2e1b2138,%eax
   4df0f:	44 89 e6             	mov    %r12d,%esi
   4df12:	c1 c6 13             	rol    $0x13,%esi
   4df15:	31 ce                	xor    %ecx,%esi
   4df17:	44 89 e1             	mov    %r12d,%ecx
   4df1a:	c1 c1 0a             	rol    $0xa,%ecx
   4df1d:	31 f1                	xor    %esi,%ecx
   4df1f:	44 89 f6             	mov    %r14d,%esi
   4df22:	44 21 ce             	and    %r9d,%esi
   4df25:	44 89 f3             	mov    %r14d,%ebx
   4df28:	44 31 cb             	xor    %r9d,%ebx
   4df2b:	44 21 e3             	and    %r12d,%ebx
   4df2e:	31 f3                	xor    %esi,%ebx
   4df30:	01 cb                	add    %ecx,%ebx
   4df32:	01 c7                	add    %eax,%edi
   4df34:	89 f9                	mov    %edi,%ecx
   4df36:	c1 c1 1a             	rol    $0x1a,%ecx
   4df39:	01 c3                	add    %eax,%ebx
   4df3b:	89 f8                	mov    %edi,%eax
   4df3d:	c1 c0 15             	rol    $0x15,%eax
   4df40:	31 c8                	xor    %ecx,%eax
   4df42:	89 f9                	mov    %edi,%ecx
   4df44:	c1 c1 07             	rol    $0x7,%ecx
   4df47:	31 c1                	xor    %eax,%ecx
   4df49:	44 89 d6             	mov    %r10d,%esi
   4df4c:	44 31 de             	xor    %r11d,%esi
   4df4f:	21 fe                	and    %edi,%esi
   4df51:	44 31 de             	xor    %r11d,%esi
   4df54:	01 d6                	add    %edx,%esi
   4df56:	44 01 fe             	add    %r15d,%esi
   4df59:	8d 04 31             	lea    (%rcx,%rsi,1),%eax
   4df5c:	05 fc 6d 2c 4d       	add    $0x4d2c6dfc,%eax
   4df61:	89 d9                	mov    %ebx,%ecx
   4df63:	c1 c1 1e             	rol    $0x1e,%ecx
   4df66:	89 de                	mov    %ebx,%esi
   4df68:	c1 c6 13             	rol    $0x13,%esi
   4df6b:	31 ce                	xor    %ecx,%esi
   4df6d:	89 d9                	mov    %ebx,%ecx
   4df6f:	c1 c1 0a             	rol    $0xa,%ecx
   4df72:	31 f1                	xor    %esi,%ecx
   4df74:	44 89 e5             	mov    %r12d,%ebp
   4df77:	44 31 f5             	xor    %r14d,%ebp
   4df7a:	21 dd                	and    %ebx,%ebp
   4df7c:	44 89 e6             	mov    %r12d,%esi
   4df7f:	44 21 f6             	and    %r14d,%esi
   4df82:	31 ee                	xor    %ebp,%esi
   4df84:	01 ce                	add    %ecx,%esi
   4df86:	01 c6                	add    %eax,%esi
   4df88:	49 89 f7             	mov    %rsi,%r15
   4df8b:	41 01 c1             	add    %eax,%r9d
   4df8e:	44 89 c8             	mov    %r9d,%eax
   4df91:	c1 c0 1a             	rol    $0x1a,%eax
   4df94:	44 89 c9             	mov    %r9d,%ecx
   4df97:	c1 c1 15             	rol    $0x15,%ecx
   4df9a:	31 c1                	xor    %eax,%ecx
   4df9c:	44 89 c8             	mov    %r9d,%eax
   4df9f:	c1 c0 07             	rol    $0x7,%eax
   4dfa2:	31 c8                	xor    %ecx,%eax
   4dfa4:	43 8d 0c 2b          	lea    (%r11,%r13,1),%ecx
   4dfa8:	41 89 fb             	mov    %edi,%r11d
   4dfab:	45 31 d3             	xor    %r10d,%r11d
   4dfae:	45 21 cb             	and    %r9d,%r11d
   4dfb1:	45 31 d3             	xor    %r10d,%r11d
   4dfb4:	41 01 cb             	add    %ecx,%r11d
   4dfb7:	44 89 f9             	mov    %r15d,%ecx
   4dfba:	c1 c1 1e             	rol    $0x1e,%ecx
   4dfbd:	44 01 d8             	add    %r11d,%eax
   4dfc0:	05 13 0d 38 53       	add    $0x53380d13,%eax
   4dfc5:	45 89 fb             	mov    %r15d,%r11d
   4dfc8:	41 c1 c3 13          	rol    $0x13,%r11d
   4dfcc:	41 31 cb             	xor    %ecx,%r11d
   4dfcf:	44 89 f9             	mov    %r15d,%ecx
   4dfd2:	c1 c1 0a             	rol    $0xa,%ecx
   4dfd5:	44 31 d9             	xor    %r11d,%ecx
   4dfd8:	41 89 db             	mov    %ebx,%r11d
   4dfdb:	45 21 e3             	and    %r12d,%r11d
   4dfde:	89 de                	mov    %ebx,%esi
   4dfe0:	44 31 e6             	xor    %r12d,%esi
   4dfe3:	44 21 fe             	and    %r15d,%esi
   4dfe6:	44 31 de             	xor    %r11d,%esi
   4dfe9:	01 ce                	add    %ecx,%esi
   4dfeb:	01 c6                	add    %eax,%esi
   4dfed:	49 89 f3             	mov    %rsi,%r11
   4dff0:	48 89 54 24 f0       	mov    %rdx,-0x10(%rsp)
   4dff5:	89 d1                	mov    %edx,%ecx
   4dff7:	c1 c1 0f             	rol    $0xf,%ecx
   4dffa:	41 01 c6             	add    %eax,%r14d
   4dffd:	89 d0                	mov    %edx,%eax
   4dfff:	c1 c0 0d             	rol    $0xd,%eax
   4e002:	31 c8                	xor    %ecx,%eax
   4e004:	89 d6                	mov    %edx,%esi
   4e006:	c1 ee 0a             	shr    $0xa,%esi
   4e009:	31 c6                	xor    %eax,%esi
   4e00b:	48 8b 4c 24 88       	mov    -0x78(%rsp),%rcx
   4e010:	03 4c 24 c0          	add    -0x40(%rsp),%ecx
   4e014:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
   4e019:	44 89 e8             	mov    %r13d,%eax
   4e01c:	c1 c0 0f             	rol    $0xf,%eax
   4e01f:	01 ce                	add    %ecx,%esi
   4e021:	44 89 e9             	mov    %r13d,%ecx
   4e024:	c1 c1 0d             	rol    $0xd,%ecx
   4e027:	31 c1                	xor    %eax,%ecx
   4e029:	41 c1 ed 0a          	shr    $0xa,%r13d
   4e02d:	41 31 cd             	xor    %ecx,%r13d
   4e030:	48 8b 4c 24 e0       	mov    -0x20(%rsp),%rcx
   4e035:	03 4c 24 b0          	add    -0x50(%rsp),%ecx
   4e039:	89 f0                	mov    %esi,%eax
   4e03b:	c1 c0 0f             	rol    $0xf,%eax
   4e03e:	41 01 cd             	add    %ecx,%r13d
   4e041:	89 f1                	mov    %esi,%ecx
   4e043:	c1 c1 0d             	rol    $0xd,%ecx
   4e046:	31 c1                	xor    %eax,%ecx
   4e048:	89 f2                	mov    %esi,%edx
   4e04a:	89 74 24 f8          	mov    %esi,-0x8(%rsp)
   4e04e:	c1 ea 0a             	shr    $0xa,%edx
   4e051:	31 ca                	xor    %ecx,%edx
   4e053:	48 8b 4c 24 90       	mov    -0x70(%rsp),%rcx
   4e058:	03 4c 24 a8          	add    -0x58(%rsp),%ecx
   4e05c:	44 89 e8             	mov    %r13d,%eax
   4e05f:	c1 c0 0f             	rol    $0xf,%eax
   4e062:	01 ca                	add    %ecx,%edx
   4e064:	48 89 54 24 c8       	mov    %rdx,-0x38(%rsp)
   4e069:	44 89 e9             	mov    %r13d,%ecx
   4e06c:	c1 c1 0d             	rol    $0xd,%ecx
   4e06f:	31 c1                	xor    %eax,%ecx
   4e071:	44 89 e8             	mov    %r13d,%eax
   4e074:	4c 89 6c 24 e8       	mov    %r13,-0x18(%rsp)
   4e079:	c1 e8 0a             	shr    $0xa,%eax
   4e07c:	31 c8                	xor    %ecx,%eax
   4e07e:	48 89 c1             	mov    %rax,%rcx
   4e081:	44 8b 44 24 20       	mov    0x20(%rsp),%r8d
   4e086:	44 03 44 24 80       	add    -0x80(%rsp),%r8d
   4e08b:	44 89 f0             	mov    %r14d,%eax
   4e08e:	c1 c0 1a             	rol    $0x1a,%eax
   4e091:	44 01 c1             	add    %r8d,%ecx
   4e094:	49 89 c8             	mov    %rcx,%r8
   4e097:	48 89 4c 24 a0       	mov    %rcx,-0x60(%rsp)
   4e09c:	44 89 f1             	mov    %r14d,%ecx
   4e09f:	c1 c1 15             	rol    $0x15,%ecx
   4e0a2:	31 c1                	xor    %eax,%ecx
   4e0a4:	44 89 f0             	mov    %r14d,%eax
   4e0a7:	c1 c0 07             	rol    $0x7,%eax
   4e0aa:	31 c8                	xor    %ecx,%eax
   4e0ac:	41 01 f2             	add    %esi,%r10d
   4e0af:	44 89 c9             	mov    %r9d,%ecx
   4e0b2:	31 f9                	xor    %edi,%ecx
   4e0b4:	44 21 f1             	and    %r14d,%ecx
   4e0b7:	31 f9                	xor    %edi,%ecx
   4e0b9:	44 01 d1             	add    %r10d,%ecx
   4e0bc:	01 c1                	add    %eax,%ecx
   4e0be:	81 c1 54 73 0a 65    	add    $0x650a7354,%ecx
   4e0c4:	4c 89 de             	mov    %r11,%rsi
   4e0c7:	89 f0                	mov    %esi,%eax
   4e0c9:	c1 c0 1e             	rol    $0x1e,%eax
   4e0cc:	41 89 f2             	mov    %esi,%r10d
   4e0cf:	41 c1 c2 13          	rol    $0x13,%r10d
   4e0d3:	41 31 c2             	xor    %eax,%r10d
   4e0d6:	41 c1 c3 0a          	rol    $0xa,%r11d
   4e0da:	45 31 d3             	xor    %r10d,%r11d
   4e0dd:	45 89 fa             	mov    %r15d,%r10d
   4e0e0:	41 31 da             	xor    %ebx,%r10d
   4e0e3:	41 21 f2             	and    %esi,%r10d
   4e0e6:	44 89 f8             	mov    %r15d,%eax
   4e0e9:	21 d8                	and    %ebx,%eax
   4e0eb:	44 31 d0             	xor    %r10d,%eax
   4e0ee:	44 01 d8             	add    %r11d,%eax
   4e0f1:	01 c8                	add    %ecx,%eax
   4e0f3:	41 01 cc             	add    %ecx,%r12d
   4e0f6:	44 89 e1             	mov    %r12d,%ecx
   4e0f9:	c1 c1 1a             	rol    $0x1a,%ecx
   4e0fc:	45 89 e2             	mov    %r12d,%r10d
   4e0ff:	41 c1 c2 15          	rol    $0x15,%r10d
   4e103:	41 31 ca             	xor    %ecx,%r10d
   4e106:	44 89 e1             	mov    %r12d,%ecx
   4e109:	c1 c1 07             	rol    $0x7,%ecx
   4e10c:	44 31 d1             	xor    %r10d,%ecx
   4e10f:	44 01 ef             	add    %r13d,%edi
   4e112:	45 89 f2             	mov    %r14d,%r10d
   4e115:	45 31 ca             	xor    %r9d,%r10d
   4e118:	45 21 e2             	and    %r12d,%r10d
   4e11b:	45 31 ca             	xor    %r9d,%r10d
   4e11e:	41 01 fa             	add    %edi,%r10d
   4e121:	89 c7                	mov    %eax,%edi
   4e123:	c1 c7 1e             	rol    $0x1e,%edi
   4e126:	44 01 d1             	add    %r10d,%ecx
   4e129:	81 c1 bb 0a 6a 76    	add    $0x766a0abb,%ecx
   4e12f:	41 89 c2             	mov    %eax,%r10d
   4e132:	41 c1 c2 13          	rol    $0x13,%r10d
   4e136:	41 31 fa             	xor    %edi,%r10d
   4e139:	41 89 c3             	mov    %eax,%r11d
   4e13c:	41 c1 c3 0a          	rol    $0xa,%r11d
   4e140:	45 31 d3             	xor    %r10d,%r11d
   4e143:	41 89 f2             	mov    %esi,%r10d
   4e146:	45 21 fa             	and    %r15d,%r10d
   4e149:	41 89 f5             	mov    %esi,%r13d
   4e14c:	45 31 fd             	xor    %r15d,%r13d
   4e14f:	41 21 c5             	and    %eax,%r13d
   4e152:	45 31 d5             	xor    %r10d,%r13d
   4e155:	45 01 dd             	add    %r11d,%r13d
   4e158:	01 cb                	add    %ecx,%ebx
   4e15a:	41 89 da             	mov    %ebx,%r10d
   4e15d:	41 c1 c2 1a          	rol    $0x1a,%r10d
   4e161:	41 01 cd             	add    %ecx,%r13d
   4e164:	89 d9                	mov    %ebx,%ecx
   4e166:	c1 c1 15             	rol    $0x15,%ecx
   4e169:	44 31 d1             	xor    %r10d,%ecx
   4e16c:	41 89 da             	mov    %ebx,%r10d
   4e16f:	41 c1 c2 07          	rol    $0x7,%r10d
   4e173:	41 31 ca             	xor    %ecx,%r10d
   4e176:	42 8d 0c 0a          	lea    (%rdx,%r9,1),%ecx
   4e17a:	45 89 e1             	mov    %r12d,%r9d
   4e17d:	45 31 f1             	xor    %r14d,%r9d
   4e180:	41 21 d9             	and    %ebx,%r9d
   4e183:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   4e188:	45 31 f1             	xor    %r14d,%r9d
   4e18b:	41 01 c9             	add    %ecx,%r9d
   4e18e:	43 8d 0c 0a          	lea    (%r10,%r9,1),%ecx
   4e192:	81 c1 2e c9 c2 81    	add    $0x81c2c92e,%ecx
   4e198:	45 89 e9             	mov    %r13d,%r9d
   4e19b:	41 c1 c1 1e          	rol    $0x1e,%r9d
   4e19f:	45 89 ea             	mov    %r13d,%r10d
   4e1a2:	41 c1 c2 13          	rol    $0x13,%r10d
   4e1a6:	45 31 ca             	xor    %r9d,%r10d
   4e1a9:	45 89 e9             	mov    %r13d,%r9d
   4e1ac:	41 c1 c1 0a          	rol    $0xa,%r9d
   4e1b0:	45 31 d1             	xor    %r10d,%r9d
   4e1b3:	41 89 c2             	mov    %eax,%r10d
   4e1b6:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
   4e1bb:	41 31 f2             	xor    %esi,%r10d
   4e1be:	45 21 ea             	and    %r13d,%r10d
   4e1c1:	89 c2                	mov    %eax,%edx
   4e1c3:	21 f2                	and    %esi,%edx
   4e1c5:	44 31 d2             	xor    %r10d,%edx
   4e1c8:	44 01 ca             	add    %r9d,%edx
   4e1cb:	01 ca                	add    %ecx,%edx
   4e1cd:	48 89 d6             	mov    %rdx,%rsi
   4e1d0:	41 01 cf             	add    %ecx,%r15d
   4e1d3:	44 89 f9             	mov    %r15d,%ecx
   4e1d6:	c1 c1 1a             	rol    $0x1a,%ecx
   4e1d9:	45 89 f9             	mov    %r15d,%r9d
   4e1dc:	41 c1 c1 15          	rol    $0x15,%r9d
   4e1e0:	41 31 c9             	xor    %ecx,%r9d
   4e1e3:	44 89 f9             	mov    %r15d,%ecx
   4e1e6:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   4e1eb:	c1 c1 07             	rol    $0x7,%ecx
   4e1ee:	44 31 c9             	xor    %r9d,%ecx
   4e1f1:	43 8d 14 30          	lea    (%r8,%r14,1),%edx
   4e1f5:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   4e1fa:	44 31 e3             	xor    %r12d,%ebx
   4e1fd:	44 21 fb             	and    %r15d,%ebx
   4e200:	44 31 e3             	xor    %r12d,%ebx
   4e203:	01 d3                	add    %edx,%ebx
   4e205:	89 f2                	mov    %esi,%edx
   4e207:	c1 c2 1e             	rol    $0x1e,%edx
   4e20a:	44 8d 0c 19          	lea    (%rcx,%rbx,1),%r9d
   4e20e:	41 81 c1 85 2c 72 92 	add    $0x92722c85,%r9d
   4e215:	89 f1                	mov    %esi,%ecx
   4e217:	c1 c1 13             	rol    $0x13,%ecx
   4e21a:	31 d1                	xor    %edx,%ecx
   4e21c:	41 89 f6             	mov    %esi,%r14d
   4e21f:	49 89 f0             	mov    %rsi,%r8
   4e222:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
   4e227:	41 c1 c6 0a          	rol    $0xa,%r14d
   4e22b:	41 31 ce             	xor    %ecx,%r14d
   4e22e:	44 8b 54 24 84       	mov    -0x7c(%rsp),%r10d
   4e233:	45 89 d7             	mov    %r10d,%r15d
   4e236:	41 c1 c7 19          	rol    $0x19,%r15d
   4e23a:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   4e23f:	41 89 f3             	mov    %esi,%r11d
   4e242:	41 c1 c3 19          	rol    $0x19,%r11d
   4e246:	44 89 ea             	mov    %r13d,%edx
   4e249:	89 c7                	mov    %eax,%edi
   4e24b:	89 44 24 48          	mov    %eax,0x48(%rsp)
   4e24f:	21 c2                	and    %eax,%edx
   4e251:	48 8b 4c 24 98       	mov    -0x68(%rsp),%rcx
   4e256:	41 89 cc             	mov    %ecx,%r12d
   4e259:	41 c1 c4 19          	rol    $0x19,%r12d
   4e25d:	48 8b 04 24          	mov    (%rsp),%rax
   4e261:	89 c3                	mov    %eax,%ebx
   4e263:	c1 c3 19             	rol    $0x19,%ebx
   4e266:	89 5c 24 90          	mov    %ebx,-0x70(%rsp)
   4e26a:	44 89 ed             	mov    %r13d,%ebp
   4e26d:	31 fd                	xor    %edi,%ebp
   4e26f:	41 c1 c2 0e          	rol    $0xe,%r10d
   4e273:	44 21 c5             	and    %r8d,%ebp
   4e276:	89 f7                	mov    %esi,%edi
   4e278:	c1 c7 0e             	rol    $0xe,%edi
   4e27b:	31 d5                	xor    %edx,%ebp
   4e27d:	89 ca                	mov    %ecx,%edx
   4e27f:	c1 c2 0e             	rol    $0xe,%edx
   4e282:	41 89 d0             	mov    %edx,%r8d
   4e285:	44 01 f5             	add    %r14d,%ebp
   4e288:	c1 c0 0e             	rol    $0xe,%eax
   4e28b:	89 44 24 88          	mov    %eax,-0x78(%rsp)
   4e28f:	44 01 cd             	add    %r9d,%ebp
   4e292:	8b 44 24 80          	mov    -0x80(%rsp),%eax
   4e296:	89 c1                	mov    %eax,%ecx
   4e298:	c1 c1 19             	rol    $0x19,%ecx
   4e29b:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   4e2a0:	45 01 ce             	add    %r9d,%r14d
   4e2a3:	4c 8b 4c 24 a8       	mov    -0x58(%rsp),%r9
   4e2a8:	44 89 ca             	mov    %r9d,%edx
   4e2ab:	c1 c2 19             	rol    $0x19,%edx
   4e2ae:	45 31 fa             	xor    %r15d,%r10d
   4e2b1:	48 8b 5c 24 b0       	mov    -0x50(%rsp),%rbx
   4e2b6:	41 89 df             	mov    %ebx,%r15d
   4e2b9:	41 c1 c7 19          	rol    $0x19,%r15d
   4e2bd:	44 31 df             	xor    %r11d,%edi
   4e2c0:	89 7c 24 e0          	mov    %edi,-0x20(%rsp)
   4e2c4:	48 8b 7c 24 c0       	mov    -0x40(%rsp),%rdi
   4e2c9:	89 fe                	mov    %edi,%esi
   4e2cb:	c1 c6 19             	rol    $0x19,%esi
   4e2ce:	45 31 e0             	xor    %r12d,%r8d
   4e2d1:	44 89 44 24 10       	mov    %r8d,0x10(%rsp)
   4e2d6:	41 89 c4             	mov    %eax,%r12d
   4e2d9:	41 89 c0             	mov    %eax,%r8d
   4e2dc:	41 c1 c4 0e          	rol    $0xe,%r12d
   4e2e0:	44 8b 5c 24 88       	mov    -0x78(%rsp),%r11d
   4e2e5:	44 33 5c 24 90       	xor    -0x70(%rsp),%r11d
   4e2ea:	44 89 c8             	mov    %r9d,%eax
   4e2ed:	c1 c0 0e             	rol    $0xe,%eax
   4e2f0:	41 31 cc             	xor    %ecx,%r12d
   4e2f3:	89 d9                	mov    %ebx,%ecx
   4e2f5:	c1 c1 0e             	rol    $0xe,%ecx
   4e2f8:	31 d0                	xor    %edx,%eax
   4e2fa:	89 fa                	mov    %edi,%edx
   4e2fc:	c1 c2 0e             	rol    $0xe,%edx
   4e2ff:	44 31 f9             	xor    %r15d,%ecx
   4e302:	31 f2                	xor    %esi,%edx
   4e304:	45 89 c7             	mov    %r8d,%r15d
   4e307:	41 c1 ef 03          	shr    $0x3,%r15d
   4e30b:	45 31 e7             	xor    %r12d,%r15d
   4e30e:	45 01 cf             	add    %r9d,%r15d
   4e311:	41 c1 e9 03          	shr    $0x3,%r9d
   4e315:	41 31 c1             	xor    %eax,%r9d
   4e318:	48 89 d8             	mov    %rbx,%rax
   4e31b:	41 01 c1             	add    %eax,%r9d
   4e31e:	4c 89 4c 24 a8       	mov    %r9,-0x58(%rsp)
   4e323:	c1 e8 03             	shr    $0x3,%eax
   4e326:	31 c8                	xor    %ecx,%eax
   4e328:	01 f8                	add    %edi,%eax
   4e32a:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
   4e32f:	c1 ef 03             	shr    $0x3,%edi
   4e332:	31 d7                	xor    %edx,%edi
   4e334:	44 8b 64 24 84       	mov    -0x7c(%rsp),%r12d
   4e339:	44 01 e7             	add    %r12d,%edi
   4e33c:	48 89 7c 24 c0       	mov    %rdi,-0x40(%rsp)
   4e341:	41 c1 ec 03          	shr    $0x3,%r12d
   4e345:	45 31 d4             	xor    %r10d,%r12d
   4e348:	4c 8b 54 24 30       	mov    0x30(%rsp),%r10
   4e34d:	45 01 d4             	add    %r10d,%r12d
   4e350:	41 c1 ea 03          	shr    $0x3,%r10d
   4e354:	44 33 54 24 e0       	xor    -0x20(%rsp),%r10d
   4e359:	48 8b 44 24 98       	mov    -0x68(%rsp),%rax
   4e35e:	41 01 c2             	add    %eax,%r10d
   4e361:	c1 e8 03             	shr    $0x3,%eax
   4e364:	33 44 24 10          	xor    0x10(%rsp),%eax
   4e368:	48 8b 0c 24          	mov    (%rsp),%rcx
   4e36c:	01 c8                	add    %ecx,%eax
   4e36e:	49 89 c1             	mov    %rax,%r9
   4e371:	c1 e9 03             	shr    $0x3,%ecx
   4e374:	44 31 d9             	xor    %r11d,%ecx
   4e377:	03 4c 24 38          	add    0x38(%rsp),%ecx
   4e37b:	48 89 ce             	mov    %rcx,%rsi
   4e37e:	48 8b 54 24 c8       	mov    -0x38(%rsp),%rdx
   4e383:	89 d0                	mov    %edx,%eax
   4e385:	c1 c0 0f             	rol    $0xf,%eax
   4e388:	89 d1                	mov    %edx,%ecx
   4e38a:	c1 c1 0d             	rol    $0xd,%ecx
   4e38d:	31 c1                	xor    %eax,%ecx
   4e38f:	c1 ea 0a             	shr    $0xa,%edx
   4e392:	31 ca                	xor    %ecx,%edx
   4e394:	03 74 24 b8          	add    -0x48(%rsp),%esi
   4e398:	01 f2                	add    %esi,%edx
   4e39a:	48 8b 74 24 a0       	mov    -0x60(%rsp),%rsi
   4e39f:	89 f0                	mov    %esi,%eax
   4e3a1:	c1 c0 0f             	rol    $0xf,%eax
   4e3a4:	89 f1                	mov    %esi,%ecx
   4e3a6:	c1 c1 0d             	rol    $0xd,%ecx
   4e3a9:	31 c1                	xor    %eax,%ecx
   4e3ab:	c1 ee 0a             	shr    $0xa,%esi
   4e3ae:	31 ce                	xor    %ecx,%esi
   4e3b0:	44 03 4c 24 f0       	add    -0x10(%rsp),%r9d
   4e3b5:	44 01 ce             	add    %r9d,%esi
   4e3b8:	89 d0                	mov    %edx,%eax
   4e3ba:	c1 c0 0f             	rol    $0xf,%eax
   4e3bd:	89 d1                	mov    %edx,%ecx
   4e3bf:	c1 c1 0d             	rol    $0xd,%ecx
   4e3c2:	31 c1                	xor    %eax,%ecx
   4e3c4:	89 d0                	mov    %edx,%eax
   4e3c6:	89 54 24 e0          	mov    %edx,-0x20(%rsp)
   4e3ca:	c1 e8 0a             	shr    $0xa,%eax
   4e3cd:	31 c8                	xor    %ecx,%eax
   4e3cf:	44 03 54 24 08       	add    0x8(%rsp),%r10d
   4e3d4:	44 01 d0             	add    %r10d,%eax
   4e3d7:	48 89 44 24 98       	mov    %rax,-0x68(%rsp)
   4e3dc:	89 f0                	mov    %esi,%eax
   4e3de:	c1 c0 0f             	rol    $0xf,%eax
   4e3e1:	89 f1                	mov    %esi,%ecx
   4e3e3:	c1 c1 0d             	rol    $0xd,%ecx
   4e3e6:	31 c1                	xor    %eax,%ecx
   4e3e8:	89 f0                	mov    %esi,%eax
   4e3ea:	48 89 f7             	mov    %rsi,%rdi
   4e3ed:	48 89 74 24 88       	mov    %rsi,-0x78(%rsp)
   4e3f2:	c1 e8 0a             	shr    $0xa,%eax
   4e3f5:	31 c8                	xor    %ecx,%eax
   4e3f7:	44 03 64 24 f8       	add    -0x8(%rsp),%r12d
   4e3fc:	44 01 e0             	add    %r12d,%eax
   4e3ff:	48 89 44 24 90       	mov    %rax,-0x70(%rsp)
   4e404:	44 89 f0             	mov    %r14d,%eax
   4e407:	c1 c0 1a             	rol    $0x1a,%eax
   4e40a:	44 89 f1             	mov    %r14d,%ecx
   4e40d:	c1 c1 15             	rol    $0x15,%ecx
   4e410:	31 c1                	xor    %eax,%ecx
   4e412:	44 89 f0             	mov    %r14d,%eax
   4e415:	c1 c0 07             	rol    $0x7,%eax
   4e418:	31 c8                	xor    %ecx,%eax
   4e41a:	44 8b 44 24 18       	mov    0x18(%rsp),%r8d
   4e41f:	41 01 d0             	add    %edx,%r8d
   4e422:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
   4e427:	89 f1                	mov    %esi,%ecx
   4e429:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
   4e42e:	31 d1                	xor    %edx,%ecx
   4e430:	44 21 f1             	and    %r14d,%ecx
   4e433:	4c 89 f3             	mov    %r14,%rbx
   4e436:	31 d1                	xor    %edx,%ecx
   4e438:	49 89 d4             	mov    %rdx,%r12
   4e43b:	44 01 c1             	add    %r8d,%ecx
   4e43e:	89 ea                	mov    %ebp,%edx
   4e440:	c1 c2 1e             	rol    $0x1e,%edx
   4e443:	01 c8                	add    %ecx,%eax
   4e445:	05 a1 e8 bf a2       	add    $0xa2bfe8a1,%eax
   4e44a:	89 e9                	mov    %ebp,%ecx
   4e44c:	c1 c1 13             	rol    $0x13,%ecx
   4e44f:	31 d1                	xor    %edx,%ecx
   4e451:	89 ea                	mov    %ebp,%edx
   4e453:	c1 c2 0a             	rol    $0xa,%edx
   4e456:	31 ca                	xor    %ecx,%edx
   4e458:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
   4e45d:	44 89 d9             	mov    %r11d,%ecx
   4e460:	44 31 e9             	xor    %r13d,%ecx
   4e463:	21 e9                	and    %ebp,%ecx
   4e465:	45 89 d8             	mov    %r11d,%r8d
   4e468:	45 21 e8             	and    %r13d,%r8d
   4e46b:	41 31 c8             	xor    %ecx,%r8d
   4e46e:	41 01 d0             	add    %edx,%r8d
   4e471:	44 8b 54 24 48       	mov    0x48(%rsp),%r10d
   4e476:	41 01 c2             	add    %eax,%r10d
   4e479:	44 89 d1             	mov    %r10d,%ecx
   4e47c:	c1 c1 1a             	rol    $0x1a,%ecx
   4e47f:	41 01 c0             	add    %eax,%r8d
   4e482:	45 89 c1             	mov    %r8d,%r9d
   4e485:	44 89 d0             	mov    %r10d,%eax
   4e488:	c1 c0 15             	rol    $0x15,%eax
   4e48b:	31 c8                	xor    %ecx,%eax
   4e48d:	44 89 d1             	mov    %r10d,%ecx
   4e490:	c1 c1 07             	rol    $0x7,%ecx
   4e493:	31 c1                	xor    %eax,%ecx
   4e495:	42 8d 04 27          	lea    (%rdi,%r12,1),%eax
   4e499:	89 da                	mov    %ebx,%edx
   4e49b:	31 f2                	xor    %esi,%edx
   4e49d:	44 21 d2             	and    %r10d,%edx
   4e4a0:	44 89 d7             	mov    %r10d,%edi
   4e4a3:	31 f2                	xor    %esi,%edx
   4e4a5:	01 c2                	add    %eax,%edx
   4e4a7:	8d 04 11             	lea    (%rcx,%rdx,1),%eax
   4e4aa:	05 4b 66 1a a8       	add    $0xa81a664b,%eax
   4e4af:	44 89 c1             	mov    %r8d,%ecx
   4e4b2:	c1 c1 1e             	rol    $0x1e,%ecx
   4e4b5:	44 89 c2             	mov    %r8d,%edx
   4e4b8:	c1 c2 13             	rol    $0x13,%edx
   4e4bb:	31 ca                	xor    %ecx,%edx
   4e4bd:	44 89 c1             	mov    %r8d,%ecx
   4e4c0:	c1 c1 0a             	rol    $0xa,%ecx
   4e4c3:	31 d1                	xor    %edx,%ecx
   4e4c5:	89 ea                	mov    %ebp,%edx
   4e4c7:	44 21 da             	and    %r11d,%edx
   4e4ca:	41 89 ea             	mov    %ebp,%r10d
   4e4cd:	45 31 da             	xor    %r11d,%r10d
   4e4d0:	45 21 c2             	and    %r8d,%r10d
   4e4d3:	41 31 d2             	xor    %edx,%r10d
   4e4d6:	41 01 ca             	add    %ecx,%r10d
   4e4d9:	41 01 c2             	add    %eax,%r10d
   4e4dc:	41 01 c5             	add    %eax,%r13d
   4e4df:	44 89 e8             	mov    %r13d,%eax
   4e4e2:	c1 c0 1a             	rol    $0x1a,%eax
   4e4e5:	44 89 e9             	mov    %r13d,%ecx
   4e4e8:	c1 c1 15             	rol    $0x15,%ecx
   4e4eb:	31 c1                	xor    %eax,%ecx
   4e4ed:	44 89 e8             	mov    %r13d,%eax
   4e4f0:	c1 c0 07             	rol    $0x7,%eax
   4e4f3:	31 c8                	xor    %ecx,%eax
   4e4f5:	4c 8b 74 24 98       	mov    -0x68(%rsp),%r14
   4e4fa:	89 fa                	mov    %edi,%edx
   4e4fc:	31 da                	xor    %ebx,%edx
   4e4fe:	44 21 ea             	and    %r13d,%edx
   4e501:	31 da                	xor    %ebx,%edx
   4e503:	44 01 f2             	add    %r14d,%edx
   4e506:	01 f2                	add    %esi,%edx
   4e508:	44 89 d1             	mov    %r10d,%ecx
   4e50b:	c1 c1 1e             	rol    $0x1e,%ecx
   4e50e:	01 d0                	add    %edx,%eax
   4e510:	05 70 8b 4b c2       	add    $0xc24b8b70,%eax
   4e515:	44 89 d2             	mov    %r10d,%edx
   4e518:	c1 c2 13             	rol    $0x13,%edx
   4e51b:	31 ca                	xor    %ecx,%edx
   4e51d:	44 89 d1             	mov    %r10d,%ecx
   4e520:	c1 c1 0a             	rol    $0xa,%ecx
   4e523:	31 d1                	xor    %edx,%ecx
   4e525:	44 89 c2             	mov    %r8d,%edx
   4e528:	31 ea                	xor    %ebp,%edx
   4e52a:	44 21 d2             	and    %r10d,%edx
   4e52d:	45 89 c4             	mov    %r8d,%r12d
   4e530:	41 21 ec             	and    %ebp,%r12d
   4e533:	41 31 d4             	xor    %edx,%r12d
   4e536:	41 01 cc             	add    %ecx,%r12d
   4e539:	41 01 c3             	add    %eax,%r11d
   4e53c:	44 89 d9             	mov    %r11d,%ecx
   4e53f:	c1 c1 1a             	rol    $0x1a,%ecx
   4e542:	41 01 c4             	add    %eax,%r12d
   4e545:	44 89 d8             	mov    %r11d,%eax
   4e548:	c1 c0 15             	rol    $0x15,%eax
   4e54b:	31 c8                	xor    %ecx,%eax
   4e54d:	44 89 d9             	mov    %r11d,%ecx
   4e550:	c1 c1 07             	rol    $0x7,%ecx
   4e553:	31 c1                	xor    %eax,%ecx
   4e555:	48 8b 74 24 90       	mov    -0x70(%rsp),%rsi
   4e55a:	44 89 ea             	mov    %r13d,%edx
   4e55d:	31 fa                	xor    %edi,%edx
   4e55f:	44 21 da             	and    %r11d,%edx
   4e562:	31 fa                	xor    %edi,%edx
   4e564:	01 f2                	add    %esi,%edx
   4e566:	01 da                	add    %ebx,%edx
   4e568:	8d 04 11             	lea    (%rcx,%rdx,1),%eax
   4e56b:	05 a3 51 6c c7       	add    $0xc76c51a3,%eax
   4e570:	44 89 e1             	mov    %r12d,%ecx
   4e573:	c1 c1 1e             	rol    $0x1e,%ecx
   4e576:	44 89 e2             	mov    %r12d,%edx
   4e579:	c1 c2 13             	rol    $0x13,%edx
   4e57c:	31 ca                	xor    %ecx,%edx
   4e57e:	44 89 e1             	mov    %r12d,%ecx
   4e581:	c1 c1 0a             	rol    $0xa,%ecx
   4e584:	31 d1                	xor    %edx,%ecx
   4e586:	44 89 d2             	mov    %r10d,%edx
   4e589:	44 21 c2             	and    %r8d,%edx
   4e58c:	44 89 d3             	mov    %r10d,%ebx
   4e58f:	44 31 c3             	xor    %r8d,%ebx
   4e592:	44 21 e3             	and    %r12d,%ebx
   4e595:	31 d3                	xor    %edx,%ebx
   4e597:	01 cb                	add    %ecx,%ebx
   4e599:	01 c3                	add    %eax,%ebx
   4e59b:	49 89 d8             	mov    %rbx,%r8
   4e59e:	01 c5                	add    %eax,%ebp
   4e5a0:	44 89 f0             	mov    %r14d,%eax
   4e5a3:	c1 c0 0f             	rol    $0xf,%eax
   4e5a6:	44 89 f1             	mov    %r14d,%ecx
   4e5a9:	c1 c1 0d             	rol    $0xd,%ecx
   4e5ac:	31 c1                	xor    %eax,%ecx
   4e5ae:	44 89 f2             	mov    %r14d,%edx
   4e5b1:	c1 ea 0a             	shr    $0xa,%edx
   4e5b4:	31 ca                	xor    %ecx,%edx
   4e5b6:	48 8b 44 24 c0       	mov    -0x40(%rsp),%rax
   4e5bb:	03 44 24 e8          	add    -0x18(%rsp),%eax
   4e5bf:	01 c2                	add    %eax,%edx
   4e5c1:	89 f0                	mov    %esi,%eax
   4e5c3:	c1 c0 0f             	rol    $0xf,%eax
   4e5c6:	89 f1                	mov    %esi,%ecx
   4e5c8:	c1 c1 0d             	rol    $0xd,%ecx
   4e5cb:	31 c1                	xor    %eax,%ecx
   4e5cd:	89 f3                	mov    %esi,%ebx
   4e5cf:	c1 eb 0a             	shr    $0xa,%ebx
   4e5d2:	31 cb                	xor    %ecx,%ebx
   4e5d4:	48 8b 44 24 b0       	mov    -0x50(%rsp),%rax
   4e5d9:	03 44 24 c8          	add    -0x38(%rsp),%eax
   4e5dd:	01 c3                	add    %eax,%ebx
   4e5df:	89 d0                	mov    %edx,%eax
   4e5e1:	c1 c0 0f             	rol    $0xf,%eax
   4e5e4:	89 d1                	mov    %edx,%ecx
   4e5e6:	c1 c1 0d             	rol    $0xd,%ecx
   4e5e9:	31 c1                	xor    %eax,%ecx
   4e5eb:	89 d0                	mov    %edx,%eax
   4e5ed:	89 54 24 84          	mov    %edx,-0x7c(%rsp)
   4e5f1:	c1 e8 0a             	shr    $0xa,%eax
   4e5f4:	31 c8                	xor    %ecx,%eax
   4e5f6:	48 8b 4c 24 a8       	mov    -0x58(%rsp),%rcx
   4e5fb:	03 4c 24 a0          	add    -0x60(%rsp),%ecx
   4e5ff:	01 c8                	add    %ecx,%eax
   4e601:	49 89 c6             	mov    %rax,%r14
   4e604:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   4e609:	89 d8                	mov    %ebx,%eax
   4e60b:	c1 c0 0f             	rol    $0xf,%eax
   4e60e:	89 d9                	mov    %ebx,%ecx
   4e610:	c1 c1 0d             	rol    $0xd,%ecx
   4e613:	31 c1                	xor    %eax,%ecx
   4e615:	89 d8                	mov    %ebx,%eax
   4e617:	48 89 5c 24 b0       	mov    %rbx,-0x50(%rsp)
   4e61c:	c1 e8 0a             	shr    $0xa,%eax
   4e61f:	31 c8                	xor    %ecx,%eax
   4e621:	44 03 7c 24 e0       	add    -0x20(%rsp),%r15d
   4e626:	44 01 f8             	add    %r15d,%eax
   4e629:	49 89 c7             	mov    %rax,%r15
   4e62c:	48 89 44 24 c0       	mov    %rax,-0x40(%rsp)
   4e631:	89 e8                	mov    %ebp,%eax
   4e633:	c1 c0 1a             	rol    $0x1a,%eax
   4e636:	89 e9                	mov    %ebp,%ecx
   4e638:	c1 c1 15             	rol    $0x15,%ecx
   4e63b:	31 c1                	xor    %eax,%ecx
   4e63d:	89 e8                	mov    %ebp,%eax
   4e63f:	c1 c0 07             	rol    $0x7,%eax
   4e642:	31 c8                	xor    %ecx,%eax
   4e644:	01 d7                	add    %edx,%edi
   4e646:	44 89 d9             	mov    %r11d,%ecx
   4e649:	44 31 e9             	xor    %r13d,%ecx
   4e64c:	21 e9                	and    %ebp,%ecx
   4e64e:	44 31 e9             	xor    %r13d,%ecx
   4e651:	01 f9                	add    %edi,%ecx
   4e653:	44 89 c2             	mov    %r8d,%edx
   4e656:	c1 c2 1e             	rol    $0x1e,%edx
   4e659:	01 c8                	add    %ecx,%eax
   4e65b:	05 19 e8 92 d1       	add    $0xd192e819,%eax
   4e660:	44 89 c1             	mov    %r8d,%ecx
   4e663:	c1 c1 13             	rol    $0x13,%ecx
   4e666:	31 d1                	xor    %edx,%ecx
   4e668:	44 89 c2             	mov    %r8d,%edx
   4e66b:	4c 89 c6             	mov    %r8,%rsi
   4e66e:	c1 c2 0a             	rol    $0xa,%edx
   4e671:	31 ca                	xor    %ecx,%edx
   4e673:	44 89 e1             	mov    %r12d,%ecx
   4e676:	44 31 d1             	xor    %r10d,%ecx
   4e679:	21 f1                	and    %esi,%ecx
   4e67b:	45 89 e0             	mov    %r12d,%r8d
   4e67e:	45 21 d0             	and    %r10d,%r8d
   4e681:	41 31 c8             	xor    %ecx,%r8d
   4e684:	41 01 d0             	add    %edx,%r8d
   4e687:	41 01 c1             	add    %eax,%r9d
   4e68a:	44 89 c9             	mov    %r9d,%ecx
   4e68d:	c1 c1 1a             	rol    $0x1a,%ecx
   4e690:	41 01 c0             	add    %eax,%r8d
   4e693:	44 89 c8             	mov    %r9d,%eax
   4e696:	c1 c0 15             	rol    $0x15,%eax
   4e699:	31 c8                	xor    %ecx,%eax
   4e69b:	44 89 c9             	mov    %r9d,%ecx
   4e69e:	c1 c1 07             	rol    $0x7,%ecx
   4e6a1:	31 c1                	xor    %eax,%ecx
   4e6a3:	89 ea                	mov    %ebp,%edx
   4e6a5:	44 31 da             	xor    %r11d,%edx
   4e6a8:	44 21 ca             	and    %r9d,%edx
   4e6ab:	44 31 da             	xor    %r11d,%edx
   4e6ae:	01 da                	add    %ebx,%edx
   4e6b0:	44 01 ea             	add    %r13d,%edx
   4e6b3:	8d 04 11             	lea    (%rcx,%rdx,1),%eax
   4e6b6:	05 24 06 99 d6       	add    $0xd6990624,%eax
   4e6bb:	44 89 c1             	mov    %r8d,%ecx
   4e6be:	c1 c1 1e             	rol    $0x1e,%ecx
   4e6c1:	44 89 c2             	mov    %r8d,%edx
   4e6c4:	c1 c2 13             	rol    $0x13,%edx
   4e6c7:	31 ca                	xor    %ecx,%edx
   4e6c9:	44 89 c1             	mov    %r8d,%ecx
   4e6cc:	c1 c1 0a             	rol    $0xa,%ecx
   4e6cf:	31 d1                	xor    %edx,%ecx
   4e6d1:	48 89 f7             	mov    %rsi,%rdi
   4e6d4:	89 fa                	mov    %edi,%edx
   4e6d6:	44 21 e2             	and    %r12d,%edx
   4e6d9:	44 31 e6             	xor    %r12d,%esi
   4e6dc:	44 21 c6             	and    %r8d,%esi
   4e6df:	31 d6                	xor    %edx,%esi
   4e6e1:	01 ce                	add    %ecx,%esi
   4e6e3:	01 c6                	add    %eax,%esi
   4e6e5:	41 01 c2             	add    %eax,%r10d
   4e6e8:	44 89 d0             	mov    %r10d,%eax
   4e6eb:	c1 c0 1a             	rol    $0x1a,%eax
   4e6ee:	44 89 d1             	mov    %r10d,%ecx
   4e6f1:	c1 c1 15             	rol    $0x15,%ecx
   4e6f4:	31 c1                	xor    %eax,%ecx
   4e6f6:	44 89 d0             	mov    %r10d,%eax
   4e6f9:	c1 c0 07             	rol    $0x7,%eax
   4e6fc:	31 c8                	xor    %ecx,%eax
   4e6fe:	44 89 ca             	mov    %r9d,%edx
   4e701:	31 ea                	xor    %ebp,%edx
   4e703:	44 21 d2             	and    %r10d,%edx
   4e706:	31 ea                	xor    %ebp,%edx
   4e708:	44 01 f2             	add    %r14d,%edx
   4e70b:	44 01 da             	add    %r11d,%edx
   4e70e:	89 f1                	mov    %esi,%ecx
   4e710:	c1 c1 1e             	rol    $0x1e,%ecx
   4e713:	01 d0                	add    %edx,%eax
   4e715:	05 85 35 0e f4       	add    $0xf40e3585,%eax
   4e71a:	89 f2                	mov    %esi,%edx
   4e71c:	c1 c2 13             	rol    $0x13,%edx
   4e71f:	31 ca                	xor    %ecx,%edx
   4e721:	89 f1                	mov    %esi,%ecx
   4e723:	c1 c1 0a             	rol    $0xa,%ecx
   4e726:	31 d1                	xor    %edx,%ecx
   4e728:	44 89 c2             	mov    %r8d,%edx
   4e72b:	49 89 fb             	mov    %rdi,%r11
   4e72e:	44 31 da             	xor    %r11d,%edx
   4e731:	21 f2                	and    %esi,%edx
   4e733:	48 89 f7             	mov    %rsi,%rdi
   4e736:	44 89 c6             	mov    %r8d,%esi
   4e739:	44 21 de             	and    %r11d,%esi
   4e73c:	4c 89 db             	mov    %r11,%rbx
   4e73f:	31 d6                	xor    %edx,%esi
   4e741:	01 ce                	add    %ecx,%esi
   4e743:	41 01 c4             	add    %eax,%r12d
   4e746:	44 89 e1             	mov    %r12d,%ecx
   4e749:	c1 c1 1a             	rol    $0x1a,%ecx
   4e74c:	01 c6                	add    %eax,%esi
   4e74e:	44 89 e0             	mov    %r12d,%eax
   4e751:	c1 c0 15             	rol    $0x15,%eax
   4e754:	31 c8                	xor    %ecx,%eax
   4e756:	44 89 e1             	mov    %r12d,%ecx
   4e759:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
   4e75e:	c1 c1 07             	rol    $0x7,%ecx
   4e761:	31 c1                	xor    %eax,%ecx
   4e763:	41 8d 04 2f          	lea    (%r15,%rbp,1),%eax
   4e767:	44 89 d2             	mov    %r10d,%edx
   4e76a:	44 89 4c 24 a8       	mov    %r9d,-0x58(%rsp)
   4e76f:	44 31 ca             	xor    %r9d,%edx
   4e772:	44 21 e2             	and    %r12d,%edx
   4e775:	44 31 ca             	xor    %r9d,%edx
   4e778:	01 c2                	add    %eax,%edx
   4e77a:	44 8d 34 11          	lea    (%rcx,%rdx,1),%r14d
   4e77e:	41 81 c6 70 a0 6a 10 	add    $0x106aa070,%r14d
   4e785:	89 f0                	mov    %esi,%eax
   4e787:	c1 c0 1e             	rol    $0x1e,%eax
   4e78a:	89 f2                	mov    %esi,%edx
   4e78c:	c1 c2 13             	rol    $0x13,%edx
   4e78f:	31 c2                	xor    %eax,%edx
   4e791:	89 f1                	mov    %esi,%ecx
   4e793:	49 89 f7             	mov    %rsi,%r15
   4e796:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
   4e79b:	c1 c1 0a             	rol    $0xa,%ecx
   4e79e:	31 d1                	xor    %edx,%ecx
   4e7a0:	48 89 fa             	mov    %rdi,%rdx
   4e7a3:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   4e7a8:	89 d0                	mov    %edx,%eax
   4e7aa:	44 89 44 24 20       	mov    %r8d,0x20(%rsp)
   4e7af:	44 21 c0             	and    %r8d,%eax
   4e7b2:	8b 6c 24 f8          	mov    -0x8(%rsp),%ebp
   4e7b6:	89 ef                	mov    %ebp,%edi
   4e7b8:	c1 c7 19             	rol    $0x19,%edi
   4e7bb:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   4e7c0:	41 89 f1             	mov    %esi,%r9d
   4e7c3:	41 c1 c1 19          	rol    $0x19,%r9d
   4e7c7:	44 89 0c 24          	mov    %r9d,(%rsp)
   4e7cb:	44 31 c2             	xor    %r8d,%edx
   4e7ce:	4c 8b 4c 24 f0       	mov    -0x10(%rsp),%r9
   4e7d3:	45 89 cc             	mov    %r9d,%r12d
   4e7d6:	41 c1 c4 19          	rol    $0x19,%r12d
   4e7da:	44 21 fa             	and    %r15d,%edx
   4e7dd:	4c 8b 44 24 b8       	mov    -0x48(%rsp),%r8
   4e7e2:	45 89 c7             	mov    %r8d,%r15d
   4e7e5:	41 c1 c7 19          	rol    $0x19,%r15d
   4e7e9:	31 c2                	xor    %eax,%edx
   4e7eb:	c1 c5 0e             	rol    $0xe,%ebp
   4e7ee:	01 ca                	add    %ecx,%edx
   4e7f0:	c1 c6 0e             	rol    $0xe,%esi
   4e7f3:	44 01 f2             	add    %r14d,%edx
   4e7f6:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   4e7fb:	45 89 cb             	mov    %r9d,%r11d
   4e7fe:	41 c1 c3 0e          	rol    $0xe,%r11d
   4e802:	44 01 f3             	add    %r14d,%ebx
   4e805:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   4e80a:	45 89 c6             	mov    %r8d,%r14d
   4e80d:	41 c1 c6 0e          	rol    $0xe,%r14d
   4e811:	31 fd                	xor    %edi,%ebp
   4e813:	8b 44 24 e0          	mov    -0x20(%rsp),%eax
   4e817:	89 c7                	mov    %eax,%edi
   4e819:	c1 c7 19             	rol    $0x19,%edi
   4e81c:	33 34 24             	xor    (%rsp),%esi
   4e81f:	48 8b 4c 24 a0       	mov    -0x60(%rsp),%rcx
   4e824:	41 89 c8             	mov    %ecx,%r8d
   4e827:	41 c1 c0 19          	rol    $0x19,%r8d
   4e82b:	45 31 e3             	xor    %r12d,%r11d
   4e82e:	4c 8b 4c 24 c8       	mov    -0x38(%rsp),%r9
   4e833:	45 89 cc             	mov    %r9d,%r12d
   4e836:	41 c1 c4 19          	rol    $0x19,%r12d
   4e83a:	45 31 fe             	xor    %r15d,%r14d
   4e83d:	41 89 c7             	mov    %eax,%r15d
   4e840:	41 c1 c7 0e          	rol    $0xe,%r15d
   4e844:	41 31 ff             	xor    %edi,%r15d
   4e847:	89 cf                	mov    %ecx,%edi
   4e849:	c1 c7 0e             	rol    $0xe,%edi
   4e84c:	44 31 c7             	xor    %r8d,%edi
   4e84f:	45 89 c8             	mov    %r9d,%r8d
   4e852:	41 c1 c0 0e          	rol    $0xe,%r8d
   4e856:	45 31 e0             	xor    %r12d,%r8d
   4e859:	48 8b 54 24 e8       	mov    -0x18(%rsp),%rdx
   4e85e:	41 89 d4             	mov    %edx,%r12d
   4e861:	41 c1 c4 19          	rol    $0x19,%r12d
   4e865:	41 89 d5             	mov    %edx,%r13d
   4e868:	41 c1 c5 0e          	rol    $0xe,%r13d
   4e86c:	45 31 e5             	xor    %r12d,%r13d
   4e86f:	c1 e8 03             	shr    $0x3,%eax
   4e872:	44 31 f8             	xor    %r15d,%eax
   4e875:	01 c8                	add    %ecx,%eax
   4e877:	89 04 24             	mov    %eax,(%rsp)
   4e87a:	c1 e9 03             	shr    $0x3,%ecx
   4e87d:	31 f9                	xor    %edi,%ecx
   4e87f:	4c 89 c8             	mov    %r9,%rax
   4e882:	01 c1                	add    %eax,%ecx
   4e884:	48 89 4c 24 a0       	mov    %rcx,-0x60(%rsp)
   4e889:	c1 e8 03             	shr    $0x3,%eax
   4e88c:	44 31 c0             	xor    %r8d,%eax
   4e88f:	01 d0                	add    %edx,%eax
   4e891:	48 89 44 24 c8       	mov    %rax,-0x38(%rsp)
   4e896:	c1 ea 03             	shr    $0x3,%edx
   4e899:	44 31 ea             	xor    %r13d,%edx
   4e89c:	44 8b 64 24 f8       	mov    -0x8(%rsp),%r12d
   4e8a1:	44 01 e2             	add    %r12d,%edx
   4e8a4:	48 89 54 24 e8       	mov    %rdx,-0x18(%rsp)
   4e8a9:	41 c1 ec 03          	shr    $0x3,%r12d
   4e8ad:	41 31 ec             	xor    %ebp,%r12d
   4e8b0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
   4e8b5:	45 01 c4             	add    %r8d,%r12d
   4e8b8:	41 c1 e8 03          	shr    $0x3,%r8d
   4e8bc:	41 31 f0             	xor    %esi,%r8d
   4e8bf:	48 8b 44 24 f0       	mov    -0x10(%rsp),%rax
   4e8c4:	41 01 c0             	add    %eax,%r8d
   4e8c7:	c1 e8 03             	shr    $0x3,%eax
   4e8ca:	44 31 d8             	xor    %r11d,%eax
   4e8cd:	48 8b 4c 24 b8       	mov    -0x48(%rsp),%rcx
   4e8d2:	01 c8                	add    %ecx,%eax
   4e8d4:	48 89 c7             	mov    %rax,%rdi
   4e8d7:	c1 e9 03             	shr    $0x3,%ecx
   4e8da:	44 31 f1             	xor    %r14d,%ecx
   4e8dd:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   4e8e2:	89 d0                	mov    %edx,%eax
   4e8e4:	c1 c0 0f             	rol    $0xf,%eax
   4e8e7:	03 4c 24 80          	add    -0x80(%rsp),%ecx
   4e8eb:	49 89 cb             	mov    %rcx,%r11
   4e8ee:	89 d1                	mov    %edx,%ecx
   4e8f0:	c1 c1 0d             	rol    $0xd,%ecx
   4e8f3:	31 c1                	xor    %eax,%ecx
   4e8f5:	c1 ea 0a             	shr    $0xa,%edx
   4e8f8:	31 ca                	xor    %ecx,%edx
   4e8fa:	48 8b 5c 24 88       	mov    -0x78(%rsp),%rbx
   4e8ff:	41 01 db             	add    %ebx,%r11d
   4e902:	4c 8b 74 24 c0       	mov    -0x40(%rsp),%r14
   4e907:	44 89 f0             	mov    %r14d,%eax
   4e90a:	c1 c0 0f             	rol    $0xf,%eax
   4e90d:	44 01 da             	add    %r11d,%edx
   4e910:	44 89 f1             	mov    %r14d,%ecx
   4e913:	c1 c1 0d             	rol    $0xd,%ecx
   4e916:	31 c1                	xor    %eax,%ecx
   4e918:	41 c1 ee 0a          	shr    $0xa,%r14d
   4e91c:	41 31 ce             	xor    %ecx,%r14d
   4e91f:	48 8b 6c 24 98       	mov    -0x68(%rsp),%rbp
   4e924:	01 ef                	add    %ebp,%edi
   4e926:	89 d0                	mov    %edx,%eax
   4e928:	c1 c0 0f             	rol    $0xf,%eax
   4e92b:	41 01 fe             	add    %edi,%r14d
   4e92e:	89 d1                	mov    %edx,%ecx
   4e930:	c1 c1 0d             	rol    $0xd,%ecx
   4e933:	31 c1                	xor    %eax,%ecx
   4e935:	45 89 f7             	mov    %r14d,%r15d
   4e938:	41 c1 c7 0f          	rol    $0xf,%r15d
   4e93c:	44 89 f6             	mov    %r14d,%esi
   4e93f:	c1 c6 0d             	rol    $0xd,%esi
   4e942:	89 d0                	mov    %edx,%eax
   4e944:	c1 e8 0a             	shr    $0xa,%eax
   4e947:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   4e94c:	41 89 fd             	mov    %edi,%r13d
   4e94f:	41 c1 c5 1a          	rol    $0x1a,%r13d
   4e953:	31 c8                	xor    %ecx,%eax
   4e955:	41 89 f9             	mov    %edi,%r9d
   4e958:	41 c1 c1 15          	rol    $0x15,%r9d
   4e95c:	4c 8b 5c 24 90       	mov    -0x70(%rsp),%r11
   4e961:	45 01 d8             	add    %r11d,%r8d
   4e964:	89 f9                	mov    %edi,%ecx
   4e966:	c1 c1 07             	rol    $0x7,%ecx
   4e969:	44 01 c0             	add    %r8d,%eax
   4e96c:	48 89 44 24 f0       	mov    %rax,-0x10(%rsp)
   4e971:	8b 44 24 84          	mov    -0x7c(%rsp),%eax
   4e975:	89 c7                	mov    %eax,%edi
   4e977:	c1 c7 19             	rol    $0x19,%edi
   4e97a:	89 7c 24 40          	mov    %edi,0x40(%rsp)
   4e97e:	44 31 fe             	xor    %r15d,%esi
   4e981:	44 89 df             	mov    %r11d,%edi
   4e984:	c1 c7 19             	rol    $0x19,%edi
   4e987:	89 7c 24 80          	mov    %edi,-0x80(%rsp)
   4e98b:	49 89 e8             	mov    %rbp,%r8
   4e98e:	89 ef                	mov    %ebp,%edi
   4e990:	c1 c7 19             	rol    $0x19,%edi
   4e993:	89 7c 24 b8          	mov    %edi,-0x48(%rsp)
   4e997:	45 89 f7             	mov    %r14d,%r15d
   4e99a:	41 c1 ef 0a          	shr    $0xa,%r15d
   4e99e:	48 89 df             	mov    %rbx,%rdi
   4e9a1:	c1 c3 19             	rol    $0x19,%ebx
   4e9a4:	89 5c 24 d4          	mov    %ebx,-0x2c(%rsp)
   4e9a8:	41 31 f7             	xor    %esi,%r15d
   4e9ab:	89 c6                	mov    %eax,%esi
   4e9ad:	c1 c6 0e             	rol    $0xe,%esi
   4e9b0:	41 01 c4             	add    %eax,%r12d
   4e9b3:	44 89 d8             	mov    %r11d,%eax
   4e9b6:	c1 c0 0e             	rol    $0xe,%eax
   4e9b9:	41 89 c3             	mov    %eax,%r11d
   4e9bc:	45 01 e7             	add    %r12d,%r15d
   4e9bf:	4c 89 7c 24 f8       	mov    %r15,-0x8(%rsp)
   4e9c4:	44 89 c0             	mov    %r8d,%eax
   4e9c7:	c1 c0 0e             	rol    $0xe,%eax
   4e9ca:	41 89 c4             	mov    %eax,%r12d
   4e9cd:	45 31 e9             	xor    %r13d,%r9d
   4e9d0:	89 f8                	mov    %edi,%eax
   4e9d2:	c1 c0 0e             	rol    $0xe,%eax
   4e9d5:	41 89 c5             	mov    %eax,%r13d
   4e9d8:	44 31 c9             	xor    %r9d,%ecx
   4e9db:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
   4e9e0:	89 d0                	mov    %edx,%eax
   4e9e2:	c1 c0 19             	rol    $0x19,%eax
   4e9e5:	33 74 24 40          	xor    0x40(%rsp),%esi
   4e9e9:	41 89 f7             	mov    %esi,%r15d
   4e9ec:	48 8b 6c 24 c0       	mov    -0x40(%rsp),%rbp
   4e9f1:	89 ef                	mov    %ebp,%edi
   4e9f3:	c1 c7 19             	rol    $0x19,%edi
   4e9f6:	44 33 5c 24 80       	xor    -0x80(%rsp),%r11d
   4e9fb:	44 89 5c 24 80       	mov    %r11d,-0x80(%rsp)
   4ea00:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   4ea05:	41 89 d8             	mov    %ebx,%r8d
   4ea08:	41 c1 c0 19          	rol    $0x19,%r8d
   4ea0c:	44 33 64 24 b8       	xor    -0x48(%rsp),%r12d
   4ea11:	44 89 64 24 40       	mov    %r12d,0x40(%rsp)
   4ea16:	48 8b 74 24 b0       	mov    -0x50(%rsp),%rsi
   4ea1b:	41 89 f3             	mov    %esi,%r11d
   4ea1e:	41 c1 c3 19          	rol    $0x19,%r11d
   4ea22:	44 33 6c 24 d4       	xor    -0x2c(%rsp),%r13d
   4ea27:	44 89 6c 24 d4       	mov    %r13d,-0x2c(%rsp)
   4ea2c:	41 89 d4             	mov    %edx,%r12d
   4ea2f:	41 c1 c4 0e          	rol    $0xe,%r12d
   4ea33:	41 31 c4             	xor    %eax,%r12d
   4ea36:	89 e9                	mov    %ebp,%ecx
   4ea38:	c1 c1 0e             	rol    $0xe,%ecx
   4ea3b:	31 f9                	xor    %edi,%ecx
   4ea3d:	89 d8                	mov    %ebx,%eax
   4ea3f:	c1 c0 0e             	rol    $0xe,%eax
   4ea42:	44 31 c0             	xor    %r8d,%eax
   4ea45:	41 89 f5             	mov    %esi,%r13d
   4ea48:	41 c1 c5 0e          	rol    $0xe,%r13d
   4ea4c:	45 31 dd             	xor    %r11d,%r13d
   4ea4f:	44 8b 4c 24 a8       	mov    -0x58(%rsp),%r9d
   4ea54:	41 01 d1             	add    %edx,%r9d
   4ea57:	01 14 24             	add    %edx,(%rsp)
   4ea5a:	c1 ea 03             	shr    $0x3,%edx
   4ea5d:	44 31 e2             	xor    %r12d,%edx
   4ea60:	49 89 d0             	mov    %rdx,%r8
   4ea63:	48 8b 54 24 a0       	mov    -0x60(%rsp),%rdx
   4ea68:	01 ea                	add    %ebp,%edx
   4ea6a:	48 89 54 24 a0       	mov    %rdx,-0x60(%rsp)
   4ea6f:	41 01 e8             	add    %ebp,%r8d
   4ea72:	4c 89 44 24 a8       	mov    %r8,-0x58(%rsp)
   4ea77:	c1 ed 03             	shr    $0x3,%ebp
   4ea7a:	31 cd                	xor    %ecx,%ebp
   4ea7c:	48 8b 4c 24 c8       	mov    -0x38(%rsp),%rcx
   4ea81:	48 89 da             	mov    %rbx,%rdx
   4ea84:	01 d1                	add    %edx,%ecx
   4ea86:	48 89 4c 24 c8       	mov    %rcx,-0x38(%rsp)
   4ea8b:	01 d5                	add    %edx,%ebp
   4ea8d:	48 89 6c 24 c0       	mov    %rbp,-0x40(%rsp)
   4ea92:	89 d1                	mov    %edx,%ecx
   4ea94:	c1 e9 03             	shr    $0x3,%ecx
   4ea97:	31 c1                	xor    %eax,%ecx
   4ea99:	48 89 f0             	mov    %rsi,%rax
   4ea9c:	48 8b 54 24 e8       	mov    -0x18(%rsp),%rdx
   4eaa1:	01 c2                	add    %eax,%edx
   4eaa3:	48 89 54 24 e8       	mov    %rdx,-0x18(%rsp)
   4eaa8:	01 c1                	add    %eax,%ecx
   4eaaa:	89 4c 24 b8          	mov    %ecx,-0x48(%rsp)
   4eaae:	c1 e8 03             	shr    $0x3,%eax
   4eab1:	44 31 e8             	xor    %r13d,%eax
   4eab4:	44 8b 64 24 84       	mov    -0x7c(%rsp),%r12d
   4eab9:	44 01 e0             	add    %r12d,%eax
   4eabc:	48 89 44 24 b0       	mov    %rax,-0x50(%rsp)
   4eac1:	41 c1 ec 03          	shr    $0x3,%r12d
   4eac5:	45 31 fc             	xor    %r15d,%r12d
   4eac8:	4c 8b 7c 24 90       	mov    -0x70(%rsp),%r15
   4eacd:	45 01 fc             	add    %r15d,%r12d
   4ead0:	41 c1 ef 03          	shr    $0x3,%r15d
   4ead4:	44 33 7c 24 80       	xor    -0x80(%rsp),%r15d
   4ead9:	48 8b 4c 24 98       	mov    -0x68(%rsp),%rcx
   4eade:	41 01 cf             	add    %ecx,%r15d
   4eae1:	c1 e9 03             	shr    $0x3,%ecx
   4eae4:	33 4c 24 40          	xor    0x40(%rsp),%ecx
   4eae8:	48 8b 44 24 88       	mov    -0x78(%rsp),%rax
   4eaed:	01 c1                	add    %eax,%ecx
   4eaef:	48 89 4c 24 98       	mov    %rcx,-0x68(%rsp)
   4eaf4:	c1 e8 03             	shr    $0x3,%eax
   4eaf7:	33 44 24 d4          	xor    -0x2c(%rsp),%eax
   4eafb:	03 44 24 e0          	add    -0x20(%rsp),%eax
   4eaff:	44 01 f0             	add    %r14d,%eax
   4eb02:	48 89 44 24 88       	mov    %rax,-0x78(%rsp)
   4eb07:	43 8d 04 16          	lea    (%r14,%r10,1),%eax
   4eb0b:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   4eb10:	89 f7                	mov    %esi,%edi
   4eb12:	44 31 d7             	xor    %r10d,%edi
   4eb15:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
   4eb1a:	44 21 ef             	and    %r13d,%edi
   4eb1d:	44 31 d7             	xor    %r10d,%edi
   4eb20:	44 01 cf             	add    %r9d,%edi
   4eb23:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   4eb28:	01 cf                	add    %ecx,%edi
   4eb2a:	81 c7 16 c1 a4 19    	add    $0x19a4c116,%edi
   4eb30:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   4eb35:	41 89 d0             	mov    %edx,%r8d
   4eb38:	41 c1 c0 1e          	rol    $0x1e,%r8d
   4eb3c:	41 89 d1             	mov    %edx,%r9d
   4eb3f:	41 c1 c1 13          	rol    $0x13,%r9d
   4eb43:	45 31 c1             	xor    %r8d,%r9d
   4eb46:	41 89 d0             	mov    %edx,%r8d
   4eb49:	41 c1 c0 0a          	rol    $0xa,%r8d
   4eb4d:	45 31 c8             	xor    %r9d,%r8d
   4eb50:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   4eb55:	41 89 ea             	mov    %ebp,%r10d
   4eb58:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
   4eb5d:	45 31 da             	xor    %r11d,%r10d
   4eb60:	41 21 d2             	and    %edx,%r10d
   4eb63:	41 89 e9             	mov    %ebp,%r9d
   4eb66:	45 21 d9             	and    %r11d,%r9d
   4eb69:	45 31 d1             	xor    %r10d,%r9d
   4eb6c:	45 01 c1             	add    %r8d,%r9d
   4eb6f:	41 01 f9             	add    %edi,%r9d
   4eb72:	8b 5c 24 20          	mov    0x20(%rsp),%ebx
   4eb76:	01 fb                	add    %edi,%ebx
   4eb78:	89 df                	mov    %ebx,%edi
   4eb7a:	c1 c7 1a             	rol    $0x1a,%edi
   4eb7d:	41 89 d8             	mov    %ebx,%r8d
   4eb80:	41 c1 c0 15          	rol    $0x15,%r8d
   4eb84:	41 31 f8             	xor    %edi,%r8d
   4eb87:	89 df                	mov    %ebx,%edi
   4eb89:	c1 c7 07             	rol    $0x7,%edi
   4eb8c:	44 31 c7             	xor    %r8d,%edi
   4eb8f:	45 89 e8             	mov    %r13d,%r8d
   4eb92:	49 89 f2             	mov    %rsi,%r10
   4eb95:	45 31 d0             	xor    %r10d,%r8d
   4eb98:	41 21 d8             	and    %ebx,%r8d
   4eb9b:	45 31 d0             	xor    %r10d,%r8d
   4eb9e:	41 01 c0             	add    %eax,%r8d
   4eba1:	44 89 c8             	mov    %r9d,%eax
   4eba4:	c1 c0 1e             	rol    $0x1e,%eax
   4eba7:	44 01 c7             	add    %r8d,%edi
   4ebaa:	81 c7 08 6c 37 1e    	add    $0x1e376c08,%edi
   4ebb0:	45 89 c8             	mov    %r9d,%r8d
   4ebb3:	41 c1 c0 13          	rol    $0x13,%r8d
   4ebb7:	41 31 c0             	xor    %eax,%r8d
   4ebba:	44 89 c8             	mov    %r9d,%eax
   4ebbd:	c1 c0 0a             	rol    $0xa,%eax
   4ebc0:	44 31 c0             	xor    %r8d,%eax
   4ebc3:	41 89 d0             	mov    %edx,%r8d
   4ebc6:	41 21 e8             	and    %ebp,%r8d
   4ebc9:	41 89 d6             	mov    %edx,%r14d
   4ebcc:	41 31 ee             	xor    %ebp,%r14d
   4ebcf:	45 21 ce             	and    %r9d,%r14d
   4ebd2:	45 31 c6             	xor    %r8d,%r14d
   4ebd5:	41 01 c6             	add    %eax,%r14d
   4ebd8:	41 01 fb             	add    %edi,%r11d
   4ebdb:	44 89 d8             	mov    %r11d,%eax
   4ebde:	c1 c0 1a             	rol    $0x1a,%eax
   4ebe1:	41 01 fe             	add    %edi,%r14d
   4ebe4:	44 89 df             	mov    %r11d,%edi
   4ebe7:	c1 c7 15             	rol    $0x15,%edi
   4ebea:	31 c7                	xor    %eax,%edi
   4ebec:	44 89 d8             	mov    %r11d,%eax
   4ebef:	c1 c0 07             	rol    $0x7,%eax
   4ebf2:	31 f8                	xor    %edi,%eax
   4ebf4:	48 8b 4c 24 f0       	mov    -0x10(%rsp),%rcx
   4ebf9:	8d 3c 31             	lea    (%rcx,%rsi,1),%edi
   4ebfc:	41 89 d8             	mov    %ebx,%r8d
   4ebff:	4d 89 ea             	mov    %r13,%r10
   4ec02:	45 31 d0             	xor    %r10d,%r8d
   4ec05:	45 21 d8             	and    %r11d,%r8d
   4ec08:	45 31 d0             	xor    %r10d,%r8d
   4ec0b:	41 01 f8             	add    %edi,%r8d
   4ec0e:	44 01 c0             	add    %r8d,%eax
   4ec11:	05 4c 77 48 27       	add    $0x2748774c,%eax
   4ec16:	44 89 f7             	mov    %r14d,%edi
   4ec19:	c1 c7 1e             	rol    $0x1e,%edi
   4ec1c:	45 89 f0             	mov    %r14d,%r8d
   4ec1f:	41 c1 c0 13          	rol    $0x13,%r8d
   4ec23:	41 31 f8             	xor    %edi,%r8d
   4ec26:	44 89 f7             	mov    %r14d,%edi
   4ec29:	c1 c7 0a             	rol    $0xa,%edi
   4ec2c:	44 31 c7             	xor    %r8d,%edi
   4ec2f:	45 89 c8             	mov    %r9d,%r8d
   4ec32:	41 31 d0             	xor    %edx,%r8d
   4ec35:	45 21 f0             	and    %r14d,%r8d
   4ec38:	45 89 ca             	mov    %r9d,%r10d
   4ec3b:	41 21 d2             	and    %edx,%r10d
   4ec3e:	45 31 c2             	xor    %r8d,%r10d
   4ec41:	41 01 fa             	add    %edi,%r10d
   4ec44:	41 01 c2             	add    %eax,%r10d
   4ec47:	01 c5                	add    %eax,%ebp
   4ec49:	89 e8                	mov    %ebp,%eax
   4ec4b:	c1 c0 1a             	rol    $0x1a,%eax
   4ec4e:	89 ef                	mov    %ebp,%edi
   4ec50:	c1 c7 15             	rol    $0x15,%edi
   4ec53:	31 c7                	xor    %eax,%edi
   4ec55:	89 e8                	mov    %ebp,%eax
   4ec57:	c1 c0 07             	rol    $0x7,%eax
   4ec5a:	31 f8                	xor    %edi,%eax
   4ec5c:	48 8b 74 24 f8       	mov    -0x8(%rsp),%rsi
   4ec61:	45 89 d8             	mov    %r11d,%r8d
   4ec64:	41 31 d8             	xor    %ebx,%r8d
   4ec67:	41 21 e8             	and    %ebp,%r8d
   4ec6a:	41 31 d8             	xor    %ebx,%r8d
   4ec6d:	41 01 f0             	add    %esi,%r8d
   4ec70:	45 01 e8             	add    %r13d,%r8d
   4ec73:	44 89 d7             	mov    %r10d,%edi
   4ec76:	c1 c7 1e             	rol    $0x1e,%edi
   4ec79:	44 01 c0             	add    %r8d,%eax
   4ec7c:	05 b5 bc b0 34       	add    $0x34b0bcb5,%eax
   4ec81:	45 89 d0             	mov    %r10d,%r8d
   4ec84:	41 c1 c0 13          	rol    $0x13,%r8d
   4ec88:	41 31 f8             	xor    %edi,%r8d
   4ec8b:	44 89 d7             	mov    %r10d,%edi
   4ec8e:	c1 c7 0a             	rol    $0xa,%edi
   4ec91:	44 31 c7             	xor    %r8d,%edi
   4ec94:	45 89 f5             	mov    %r14d,%r13d
   4ec97:	45 21 cd             	and    %r9d,%r13d
   4ec9a:	45 89 f0             	mov    %r14d,%r8d
   4ec9d:	45 31 c8             	xor    %r9d,%r8d
   4eca0:	45 21 d0             	and    %r10d,%r8d
   4eca3:	45 31 e8             	xor    %r13d,%r8d
   4eca6:	41 01 f8             	add    %edi,%r8d
   4eca9:	41 01 c0             	add    %eax,%r8d
   4ecac:	89 cf                	mov    %ecx,%edi
   4ecae:	c1 c7 0f             	rol    $0xf,%edi
   4ecb1:	01 c2                	add    %eax,%edx
   4ecb3:	89 c8                	mov    %ecx,%eax
   4ecb5:	c1 c0 0d             	rol    $0xd,%eax
   4ecb8:	31 f8                	xor    %edi,%eax
   4ecba:	48 8b 7c 24 98       	mov    -0x68(%rsp),%rdi
   4ecbf:	01 cf                	add    %ecx,%edi
   4ecc1:	48 89 7c 24 98       	mov    %rdi,-0x68(%rsp)
   4ecc6:	89 cf                	mov    %ecx,%edi
   4ecc8:	c1 ef 0a             	shr    $0xa,%edi
   4eccb:	31 c7                	xor    %eax,%edi
   4eccd:	89 f0                	mov    %esi,%eax
   4eccf:	c1 c0 0f             	rol    $0xf,%eax
   4ecd2:	03 7c 24 e8          	add    -0x18(%rsp),%edi
   4ecd6:	41 89 f5             	mov    %esi,%r13d
   4ecd9:	41 c1 c5 0d          	rol    $0xd,%r13d
   4ecdd:	41 31 c5             	xor    %eax,%r13d
   4ece0:	41 01 f7             	add    %esi,%r15d
   4ece3:	4c 89 7c 24 90       	mov    %r15,-0x70(%rsp)
   4ece8:	c1 ee 0a             	shr    $0xa,%esi
   4eceb:	44 31 ee             	xor    %r13d,%esi
   4ecee:	89 f8                	mov    %edi,%eax
   4ecf0:	c1 c0 0f             	rol    $0xf,%eax
   4ecf3:	03 74 24 c8          	add    -0x38(%rsp),%esi
   4ecf7:	41 89 fd             	mov    %edi,%r13d
   4ecfa:	41 c1 c5 0d          	rol    $0xd,%r13d
   4ecfe:	41 31 c5             	xor    %eax,%r13d
   4ed01:	01 fb                	add    %edi,%ebx
   4ed03:	41 01 fc             	add    %edi,%r12d
   4ed06:	89 f9                	mov    %edi,%ecx
   4ed08:	c1 e9 0a             	shr    $0xa,%ecx
   4ed0b:	89 f7                	mov    %esi,%edi
   4ed0d:	c1 c7 0f             	rol    $0xf,%edi
   4ed10:	44 31 e9             	xor    %r13d,%ecx
   4ed13:	89 f0                	mov    %esi,%eax
   4ed15:	c1 c0 0d             	rol    $0xd,%eax
   4ed18:	03 4c 24 a0          	add    -0x60(%rsp),%ecx
   4ed1c:	31 f8                	xor    %edi,%eax
   4ed1e:	41 89 f5             	mov    %esi,%r13d
   4ed21:	41 c1 ed 0a          	shr    $0xa,%r13d
   4ed25:	41 31 c5             	xor    %eax,%r13d
   4ed28:	89 d0                	mov    %edx,%eax
   4ed2a:	c1 c0 1a             	rol    $0x1a,%eax
   4ed2d:	44 03 2c 24          	add    (%rsp),%r13d
   4ed31:	89 d7                	mov    %edx,%edi
   4ed33:	c1 c7 15             	rol    $0x15,%edi
   4ed36:	31 c7                	xor    %eax,%edi
   4ed38:	89 d0                	mov    %edx,%eax
   4ed3a:	c1 c0 07             	rol    $0x7,%eax
   4ed3d:	31 f8                	xor    %edi,%eax
   4ed3f:	48 8b 7c 24 b0       	mov    -0x50(%rsp),%rdi
   4ed44:	01 f7                	add    %esi,%edi
   4ed46:	48 89 7c 24 b0       	mov    %rdi,-0x50(%rsp)
   4ed4b:	46 8d 3c 1e          	lea    (%rsi,%r11,1),%r15d
   4ed4f:	89 ef                	mov    %ebp,%edi
   4ed51:	44 31 df             	xor    %r11d,%edi
   4ed54:	21 d7                	and    %edx,%edi
   4ed56:	44 31 df             	xor    %r11d,%edi
   4ed59:	01 df                	add    %ebx,%edi
   4ed5b:	01 f8                	add    %edi,%eax
   4ed5d:	05 b3 0c 1c 39       	add    $0x391c0cb3,%eax
   4ed62:	44 89 c6             	mov    %r8d,%esi
   4ed65:	c1 c6 1e             	rol    $0x1e,%esi
   4ed68:	44 89 c7             	mov    %r8d,%edi
   4ed6b:	c1 c7 13             	rol    $0x13,%edi
   4ed6e:	31 f7                	xor    %esi,%edi
   4ed70:	44 89 c6             	mov    %r8d,%esi
   4ed73:	c1 c6 0a             	rol    $0xa,%esi
   4ed76:	31 fe                	xor    %edi,%esi
   4ed78:	44 89 d7             	mov    %r10d,%edi
   4ed7b:	44 31 f7             	xor    %r14d,%edi
   4ed7e:	44 21 c7             	and    %r8d,%edi
   4ed81:	44 89 d3             	mov    %r10d,%ebx
   4ed84:	44 21 f3             	and    %r14d,%ebx
   4ed87:	31 fb                	xor    %edi,%ebx
   4ed89:	01 f3                	add    %esi,%ebx
   4ed8b:	01 c3                	add    %eax,%ebx
   4ed8d:	41 01 c1             	add    %eax,%r9d
   4ed90:	44 89 c8             	mov    %r9d,%eax
   4ed93:	c1 c0 1a             	rol    $0x1a,%eax
   4ed96:	44 89 ce             	mov    %r9d,%esi
   4ed99:	c1 c6 15             	rol    $0x15,%esi
   4ed9c:	31 c6                	xor    %eax,%esi
   4ed9e:	44 89 c8             	mov    %r9d,%eax
   4eda1:	c1 c0 07             	rol    $0x7,%eax
   4eda4:	31 f0                	xor    %esi,%eax
   4eda6:	89 d6                	mov    %edx,%esi
   4eda8:	31 ee                	xor    %ebp,%esi
   4edaa:	44 21 ce             	and    %r9d,%esi
   4edad:	31 ee                	xor    %ebp,%esi
   4edaf:	44 01 fe             	add    %r15d,%esi
   4edb2:	89 df                	mov    %ebx,%edi
   4edb4:	c1 c7 1e             	rol    $0x1e,%edi
   4edb7:	01 f0                	add    %esi,%eax
   4edb9:	05 4a aa d8 4e       	add    $0x4ed8aa4a,%eax
   4edbe:	89 de                	mov    %ebx,%esi
   4edc0:	c1 c6 13             	rol    $0x13,%esi
   4edc3:	31 fe                	xor    %edi,%esi
   4edc5:	89 df                	mov    %ebx,%edi
   4edc7:	c1 c7 0a             	rol    $0xa,%edi
   4edca:	31 f7                	xor    %esi,%edi
   4edcc:	44 89 c6             	mov    %r8d,%esi
   4edcf:	44 21 d6             	and    %r10d,%esi
   4edd2:	45 89 c7             	mov    %r8d,%r15d
   4edd5:	45 31 d7             	xor    %r10d,%r15d
   4edd8:	41 21 df             	and    %ebx,%r15d
   4eddb:	41 31 f7             	xor    %esi,%r15d
   4edde:	41 01 ff             	add    %edi,%r15d
   4ede1:	41 01 c6             	add    %eax,%r14d
   4ede4:	44 89 f6             	mov    %r14d,%esi
   4ede7:	c1 c6 1a             	rol    $0x1a,%esi
   4edea:	41 01 c7             	add    %eax,%r15d
   4eded:	44 89 f0             	mov    %r14d,%eax
   4edf0:	c1 c0 15             	rol    $0x15,%eax
   4edf3:	31 f0                	xor    %esi,%eax
   4edf5:	44 89 f6             	mov    %r14d,%esi
   4edf8:	c1 c6 07             	rol    $0x7,%esi
   4edfb:	31 c6                	xor    %eax,%esi
   4edfd:	44 89 cf             	mov    %r9d,%edi
   4ee00:	31 d7                	xor    %edx,%edi
   4ee02:	44 21 f7             	and    %r14d,%edi
   4ee05:	31 d7                	xor    %edx,%edi
   4ee07:	01 cf                	add    %ecx,%edi
   4ee09:	01 ef                	add    %ebp,%edi
   4ee0b:	8d 04 3e             	lea    (%rsi,%rdi,1),%eax
   4ee0e:	05 4f ca 9c 5b       	add    $0x5b9cca4f,%eax
   4ee13:	44 89 fe             	mov    %r15d,%esi
   4ee16:	c1 c6 1e             	rol    $0x1e,%esi
   4ee19:	44 89 ff             	mov    %r15d,%edi
   4ee1c:	c1 c7 13             	rol    $0x13,%edi
   4ee1f:	31 f7                	xor    %esi,%edi
   4ee21:	44 89 fe             	mov    %r15d,%esi
   4ee24:	c1 c6 0a             	rol    $0xa,%esi
   4ee27:	31 fe                	xor    %edi,%esi
   4ee29:	89 dd                	mov    %ebx,%ebp
   4ee2b:	44 31 c5             	xor    %r8d,%ebp
   4ee2e:	44 21 fd             	and    %r15d,%ebp
   4ee31:	89 df                	mov    %ebx,%edi
   4ee33:	44 21 c7             	and    %r8d,%edi
   4ee36:	31 ef                	xor    %ebp,%edi
   4ee38:	01 f7                	add    %esi,%edi
   4ee3a:	01 c7                	add    %eax,%edi
   4ee3c:	41 01 c2             	add    %eax,%r10d
   4ee3f:	44 89 d0             	mov    %r10d,%eax
   4ee42:	c1 c0 1a             	rol    $0x1a,%eax
   4ee45:	44 89 d6             	mov    %r10d,%esi
   4ee48:	c1 c6 15             	rol    $0x15,%esi
   4ee4b:	31 c6                	xor    %eax,%esi
   4ee4d:	44 89 d0             	mov    %r10d,%eax
   4ee50:	c1 c0 07             	rol    $0x7,%eax
   4ee53:	31 f0                	xor    %esi,%eax
   4ee55:	44 01 ea             	add    %r13d,%edx
   4ee58:	44 89 f6             	mov    %r14d,%esi
   4ee5b:	44 31 ce             	xor    %r9d,%esi
   4ee5e:	44 21 d6             	and    %r10d,%esi
   4ee61:	44 31 ce             	xor    %r9d,%esi
   4ee64:	01 d6                	add    %edx,%esi
   4ee66:	89 fa                	mov    %edi,%edx
   4ee68:	c1 c2 1e             	rol    $0x1e,%edx
   4ee6b:	01 f0                	add    %esi,%eax
   4ee6d:	05 f3 6f 2e 68       	add    $0x682e6ff3,%eax
   4ee72:	89 fe                	mov    %edi,%esi
   4ee74:	c1 c6 13             	rol    $0x13,%esi
   4ee77:	31 d6                	xor    %edx,%esi
   4ee79:	89 fa                	mov    %edi,%edx
   4ee7b:	c1 c2 0a             	rol    $0xa,%edx
   4ee7e:	31 f2                	xor    %esi,%edx
   4ee80:	44 89 fd             	mov    %r15d,%ebp
   4ee83:	21 dd                	and    %ebx,%ebp
   4ee85:	45 89 fb             	mov    %r15d,%r11d
   4ee88:	41 31 db             	xor    %ebx,%r11d
   4ee8b:	41 21 fb             	and    %edi,%r11d
   4ee8e:	41 31 eb             	xor    %ebp,%r11d
   4ee91:	41 01 d3             	add    %edx,%r11d
   4ee94:	41 01 c3             	add    %eax,%r11d
   4ee97:	89 ca                	mov    %ecx,%edx
   4ee99:	c1 c2 0f             	rol    $0xf,%edx
   4ee9c:	41 01 c0             	add    %eax,%r8d
   4ee9f:	89 c8                	mov    %ecx,%eax
   4eea1:	c1 c0 0d             	rol    $0xd,%eax
   4eea4:	31 d0                	xor    %edx,%eax
   4eea6:	01 4c 24 b8          	add    %ecx,-0x48(%rsp)
   4eeaa:	c1 e9 0a             	shr    $0xa,%ecx
   4eead:	31 c1                	xor    %eax,%ecx
   4eeaf:	44 89 e8             	mov    %r13d,%eax
   4eeb2:	c1 c0 0f             	rol    $0xf,%eax
   4eeb5:	03 4c 24 88          	add    -0x78(%rsp),%ecx
   4eeb9:	44 89 ea             	mov    %r13d,%edx
   4eebc:	c1 c2 0d             	rol    $0xd,%edx
   4eebf:	31 c2                	xor    %eax,%edx
   4eec1:	48 8b 44 24 c0       	mov    -0x40(%rsp),%rax
   4eec6:	44 01 e8             	add    %r13d,%eax
   4eec9:	48 89 44 24 c0       	mov    %rax,-0x40(%rsp)
   4eece:	44 89 e8             	mov    %r13d,%eax
   4eed1:	c1 e8 0a             	shr    $0xa,%eax
   4eed4:	31 d0                	xor    %edx,%eax
   4eed6:	89 ca                	mov    %ecx,%edx
   4eed8:	c1 c2 0f             	rol    $0xf,%edx
   4eedb:	03 44 24 98          	add    -0x68(%rsp),%eax
   4eedf:	41 89 cd             	mov    %ecx,%r13d
   4eee2:	41 c1 c5 0d          	rol    $0xd,%r13d
   4eee6:	41 31 d5             	xor    %edx,%r13d
   4eee9:	41 01 c9             	add    %ecx,%r9d
   4eeec:	48 8b 54 24 a8       	mov    -0x58(%rsp),%rdx
   4eef1:	01 ca                	add    %ecx,%edx
   4eef3:	48 89 54 24 a8       	mov    %rdx,-0x58(%rsp)
   4eef8:	89 cd                	mov    %ecx,%ebp
   4eefa:	c1 ed 0a             	shr    $0xa,%ebp
   4eefd:	89 c1                	mov    %eax,%ecx
   4eeff:	c1 c1 0f             	rol    $0xf,%ecx
   4ef02:	44 31 ed             	xor    %r13d,%ebp
   4ef05:	89 c2                	mov    %eax,%edx
   4ef07:	c1 c2 0d             	rol    $0xd,%edx
   4ef0a:	03 6c 24 90          	add    -0x70(%rsp),%ebp
   4ef0e:	31 ca                	xor    %ecx,%edx
   4ef10:	89 c6                	mov    %eax,%esi
   4ef12:	c1 ee 0a             	shr    $0xa,%esi
   4ef15:	31 d6                	xor    %edx,%esi
   4ef17:	44 89 c1             	mov    %r8d,%ecx
   4ef1a:	c1 c1 1a             	rol    $0x1a,%ecx
   4ef1d:	44 01 e6             	add    %r12d,%esi
   4ef20:	44 89 c2             	mov    %r8d,%edx
   4ef23:	c1 c2 15             	rol    $0x15,%edx
   4ef26:	31 ca                	xor    %ecx,%edx
   4ef28:	44 89 c1             	mov    %r8d,%ecx
   4ef2b:	c1 c1 07             	rol    $0x7,%ecx
   4ef2e:	31 d1                	xor    %edx,%ecx
   4ef30:	44 01 f0             	add    %r14d,%eax
   4ef33:	44 89 d2             	mov    %r10d,%edx
   4ef36:	44 31 f2             	xor    %r14d,%edx
   4ef39:	44 21 c2             	and    %r8d,%edx
   4ef3c:	44 31 f2             	xor    %r14d,%edx
   4ef3f:	44 01 ca             	add    %r9d,%edx
   4ef42:	01 d1                	add    %edx,%ecx
   4ef44:	81 c1 ee 82 8f 74    	add    $0x748f82ee,%ecx
   4ef4a:	44 89 da             	mov    %r11d,%edx
   4ef4d:	c1 c2 1e             	rol    $0x1e,%edx
   4ef50:	45 89 d9             	mov    %r11d,%r9d
   4ef53:	41 c1 c1 13          	rol    $0x13,%r9d
   4ef57:	41 31 d1             	xor    %edx,%r9d
   4ef5a:	45 89 de             	mov    %r11d,%r14d
   4ef5d:	41 c1 c6 0a          	rol    $0xa,%r14d
   4ef61:	45 31 ce             	xor    %r9d,%r14d
   4ef64:	41 89 f9             	mov    %edi,%r9d
   4ef67:	45 31 f9             	xor    %r15d,%r9d
   4ef6a:	45 21 d9             	and    %r11d,%r9d
   4ef6d:	41 89 fd             	mov    %edi,%r13d
   4ef70:	45 21 fd             	and    %r15d,%r13d
   4ef73:	45 31 cd             	xor    %r9d,%r13d
   4ef76:	45 01 f5             	add    %r14d,%r13d
   4ef79:	41 01 cd             	add    %ecx,%r13d
   4ef7c:	01 cb                	add    %ecx,%ebx
   4ef7e:	89 d9                	mov    %ebx,%ecx
   4ef80:	c1 c1 1a             	rol    $0x1a,%ecx
   4ef83:	41 89 d9             	mov    %ebx,%r9d
   4ef86:	41 c1 c1 15          	rol    $0x15,%r9d
   4ef8a:	41 31 c9             	xor    %ecx,%r9d
   4ef8d:	89 d9                	mov    %ebx,%ecx
   4ef8f:	c1 c1 07             	rol    $0x7,%ecx
   4ef92:	44 31 c9             	xor    %r9d,%ecx
   4ef95:	45 89 c1             	mov    %r8d,%r9d
   4ef98:	45 31 d1             	xor    %r10d,%r9d
   4ef9b:	41 21 d9             	and    %ebx,%r9d
   4ef9e:	45 31 d1             	xor    %r10d,%r9d
   4efa1:	41 01 c1             	add    %eax,%r9d
   4efa4:	42 8d 04 09          	lea    (%rcx,%r9,1),%eax
   4efa8:	05 6f 63 a5 78       	add    $0x78a5636f,%eax
   4efad:	44 89 e9             	mov    %r13d,%ecx
   4efb0:	c1 c1 1e             	rol    $0x1e,%ecx
   4efb3:	45 89 e9             	mov    %r13d,%r9d
   4efb6:	41 c1 c1 13          	rol    $0x13,%r9d
   4efba:	41 31 c9             	xor    %ecx,%r9d
   4efbd:	44 89 e9             	mov    %r13d,%ecx
   4efc0:	c1 c1 0a             	rol    $0xa,%ecx
   4efc3:	44 31 c9             	xor    %r9d,%ecx
   4efc6:	45 89 de             	mov    %r11d,%r14d
   4efc9:	41 21 fe             	and    %edi,%r14d
   4efcc:	45 89 d9             	mov    %r11d,%r9d
   4efcf:	41 31 f9             	xor    %edi,%r9d
   4efd2:	45 21 e9             	and    %r13d,%r9d
   4efd5:	45 31 f1             	xor    %r14d,%r9d
   4efd8:	41 01 c9             	add    %ecx,%r9d
   4efdb:	41 01 c1             	add    %eax,%r9d
   4efde:	41 01 c7             	add    %eax,%r15d
   4efe1:	44 89 f8             	mov    %r15d,%eax
   4efe4:	c1 c0 1a             	rol    $0x1a,%eax
   4efe7:	44 89 f9             	mov    %r15d,%ecx
   4efea:	c1 c1 15             	rol    $0x15,%ecx
   4efed:	31 c1                	xor    %eax,%ecx
   4efef:	44 89 f8             	mov    %r15d,%eax
   4eff2:	c1 c0 07             	rol    $0x7,%eax
   4eff5:	31 c8                	xor    %ecx,%eax
   4eff7:	41 8d 0c 2a          	lea    (%r10,%rbp,1),%ecx
   4effb:	41 89 da             	mov    %ebx,%r10d
   4effe:	45 31 c2             	xor    %r8d,%r10d
   4f001:	45 21 fa             	and    %r15d,%r10d
   4f004:	45 31 c2             	xor    %r8d,%r10d
   4f007:	45 89 ce             	mov    %r9d,%r14d
   4f00a:	41 c1 c6 1e          	rol    $0x1e,%r14d
   4f00e:	41 01 ca             	add    %ecx,%r10d
   4f011:	44 89 c9             	mov    %r9d,%ecx
   4f014:	c1 c1 13             	rol    $0x13,%ecx
   4f017:	44 01 d0             	add    %r10d,%eax
   4f01a:	05 14 78 c8 84       	add    $0x84c87814,%eax
   4f01f:	45 89 cc             	mov    %r9d,%r12d
   4f022:	41 c1 c4 0a          	rol    $0xa,%r12d
   4f026:	44 31 f1             	xor    %r14d,%ecx
   4f029:	41 31 cc             	xor    %ecx,%r12d
   4f02c:	44 89 e9             	mov    %r13d,%ecx
   4f02f:	44 31 d9             	xor    %r11d,%ecx
   4f032:	44 21 c9             	and    %r9d,%ecx
   4f035:	45 89 ea             	mov    %r13d,%r10d
   4f038:	45 21 da             	and    %r11d,%r10d
   4f03b:	41 31 ca             	xor    %ecx,%r10d
   4f03e:	01 c7                	add    %eax,%edi
   4f040:	89 f9                	mov    %edi,%ecx
   4f042:	c1 c1 1a             	rol    $0x1a,%ecx
   4f045:	45 01 e2             	add    %r12d,%r10d
   4f048:	41 89 fe             	mov    %edi,%r14d
   4f04b:	41 c1 c6 15          	rol    $0x15,%r14d
   4f04f:	41 01 c2             	add    %eax,%r10d
   4f052:	89 f8                	mov    %edi,%eax
   4f054:	c1 c0 07             	rol    $0x7,%eax
   4f057:	41 31 ce             	xor    %ecx,%r14d
   4f05a:	44 31 f0             	xor    %r14d,%eax
   4f05d:	42 8d 0c 06          	lea    (%rsi,%r8,1),%ecx
   4f061:	45 89 f8             	mov    %r15d,%r8d
   4f064:	41 31 d8             	xor    %ebx,%r8d
   4f067:	41 21 f8             	and    %edi,%r8d
   4f06a:	41 31 d8             	xor    %ebx,%r8d
   4f06d:	41 01 c8             	add    %ecx,%r8d
   4f070:	44 01 c0             	add    %r8d,%eax
   4f073:	05 08 02 c7 8c       	add    $0x8cc70208,%eax
   4f078:	44 89 d1             	mov    %r10d,%ecx
   4f07b:	c1 c1 1e             	rol    $0x1e,%ecx
   4f07e:	45 89 d0             	mov    %r10d,%r8d
   4f081:	41 c1 c0 13          	rol    $0x13,%r8d
   4f085:	41 31 c8             	xor    %ecx,%r8d
   4f088:	44 89 d1             	mov    %r10d,%ecx
   4f08b:	c1 c1 0a             	rol    $0xa,%ecx
   4f08e:	44 31 c1             	xor    %r8d,%ecx
   4f091:	45 89 ce             	mov    %r9d,%r14d
   4f094:	45 21 ee             	and    %r13d,%r14d
   4f097:	45 89 c8             	mov    %r9d,%r8d
   4f09a:	45 31 e8             	xor    %r13d,%r8d
   4f09d:	45 21 d0             	and    %r10d,%r8d
   4f0a0:	45 31 f0             	xor    %r14d,%r8d
   4f0a3:	41 01 c8             	add    %ecx,%r8d
   4f0a6:	41 01 c0             	add    %eax,%r8d
   4f0a9:	41 01 c3             	add    %eax,%r11d
   4f0ac:	89 e8                	mov    %ebp,%eax
   4f0ae:	c1 c0 0f             	rol    $0xf,%eax
   4f0b1:	89 e9                	mov    %ebp,%ecx
   4f0b3:	c1 c1 0d             	rol    $0xd,%ecx
   4f0b6:	31 c1                	xor    %eax,%ecx
   4f0b8:	c1 ed 0a             	shr    $0xa,%ebp
   4f0bb:	89 f0                	mov    %esi,%eax
   4f0bd:	c1 c0 0f             	rol    $0xf,%eax
   4f0c0:	31 cd                	xor    %ecx,%ebp
   4f0c2:	89 f1                	mov    %esi,%ecx
   4f0c4:	c1 c1 0d             	rol    $0xd,%ecx
   4f0c7:	03 6c 24 b0          	add    -0x50(%rsp),%ebp
   4f0cb:	31 c1                	xor    %eax,%ecx
   4f0cd:	c1 ee 0a             	shr    $0xa,%esi
   4f0d0:	31 ce                	xor    %ecx,%esi
   4f0d2:	03 74 24 b8          	add    -0x48(%rsp),%esi
   4f0d6:	89 e8                	mov    %ebp,%eax
   4f0d8:	c1 c0 0f             	rol    $0xf,%eax
   4f0db:	89 e9                	mov    %ebp,%ecx
   4f0dd:	c1 c1 0d             	rol    $0xd,%ecx
   4f0e0:	31 c1                	xor    %eax,%ecx
   4f0e2:	41 89 f6             	mov    %esi,%r14d
   4f0e5:	41 c1 c6 0f          	rol    $0xf,%r14d
   4f0e9:	41 89 ec             	mov    %ebp,%r12d
   4f0ec:	41 c1 ec 0a          	shr    $0xa,%r12d
   4f0f0:	89 f0                	mov    %esi,%eax
   4f0f2:	c1 c0 0d             	rol    $0xd,%eax
   4f0f5:	41 31 cc             	xor    %ecx,%r12d
   4f0f8:	44 31 f0             	xor    %r14d,%eax
   4f0fb:	41 89 f6             	mov    %esi,%r14d
   4f0fe:	41 c1 ee 0a          	shr    $0xa,%r14d
   4f102:	41 31 c6             	xor    %eax,%r14d
   4f105:	44 89 d8             	mov    %r11d,%eax
   4f108:	c1 c0 1a             	rol    $0x1a,%eax
   4f10b:	01 dd                	add    %ebx,%ebp
   4f10d:	44 89 d9             	mov    %r11d,%ecx
   4f110:	c1 c1 15             	rol    $0x15,%ecx
   4f113:	31 c1                	xor    %eax,%ecx
   4f115:	44 89 d8             	mov    %r11d,%eax
   4f118:	c1 c0 07             	rol    $0x7,%eax
   4f11b:	31 c8                	xor    %ecx,%eax
   4f11d:	44 01 fe             	add    %r15d,%esi
   4f120:	89 f9                	mov    %edi,%ecx
   4f122:	44 31 f9             	xor    %r15d,%ecx
   4f125:	44 21 d9             	and    %r11d,%ecx
   4f128:	44 31 f9             	xor    %r15d,%ecx
   4f12b:	01 e9                	add    %ebp,%ecx
   4f12d:	01 c8                	add    %ecx,%eax
   4f12f:	05 fa ff be 90       	add    $0x90befffa,%eax
   4f134:	44 89 c1             	mov    %r8d,%ecx
   4f137:	c1 c1 1e             	rol    $0x1e,%ecx
   4f13a:	44 89 c3             	mov    %r8d,%ebx
   4f13d:	c1 c3 13             	rol    $0x13,%ebx
   4f140:	31 cb                	xor    %ecx,%ebx
   4f142:	44 89 c5             	mov    %r8d,%ebp
   4f145:	c1 c5 0a             	rol    $0xa,%ebp
   4f148:	31 dd                	xor    %ebx,%ebp
   4f14a:	44 89 d3             	mov    %r10d,%ebx
   4f14d:	44 31 cb             	xor    %r9d,%ebx
   4f150:	44 21 c3             	and    %r8d,%ebx
   4f153:	44 89 d1             	mov    %r10d,%ecx
   4f156:	44 21 c9             	and    %r9d,%ecx
   4f159:	31 d9                	xor    %ebx,%ecx
   4f15b:	01 e9                	add    %ebp,%ecx
   4f15d:	01 c1                	add    %eax,%ecx
   4f15f:	41 01 c5             	add    %eax,%r13d
   4f162:	44 89 e8             	mov    %r13d,%eax
   4f165:	c1 c0 1a             	rol    $0x1a,%eax
   4f168:	44 89 eb             	mov    %r13d,%ebx
   4f16b:	c1 c3 15             	rol    $0x15,%ebx
   4f16e:	31 c3                	xor    %eax,%ebx
   4f170:	44 89 e8             	mov    %r13d,%eax
   4f173:	c1 c0 07             	rol    $0x7,%eax
   4f176:	31 d8                	xor    %ebx,%eax
   4f178:	44 89 db             	mov    %r11d,%ebx
   4f17b:	31 fb                	xor    %edi,%ebx
   4f17d:	44 21 eb             	and    %r13d,%ebx
   4f180:	31 fb                	xor    %edi,%ebx
   4f182:	01 f3                	add    %esi,%ebx
   4f184:	01 c3                	add    %eax,%ebx
   4f186:	81 c3 eb 6c 50 a4    	add    $0xa4506ceb,%ebx
   4f18c:	89 c8                	mov    %ecx,%eax
   4f18e:	c1 c0 1e             	rol    $0x1e,%eax
   4f191:	89 cd                	mov    %ecx,%ebp
   4f193:	c1 c5 13             	rol    $0x13,%ebp
   4f196:	31 c5                	xor    %eax,%ebp
   4f198:	41 89 cf             	mov    %ecx,%r15d
   4f19b:	41 c1 c7 0a          	rol    $0xa,%r15d
   4f19f:	41 31 ef             	xor    %ebp,%r15d
   4f1a2:	44 89 c5             	mov    %r8d,%ebp
   4f1a5:	44 21 d5             	and    %r10d,%ebp
   4f1a8:	44 89 c0             	mov    %r8d,%eax
   4f1ab:	44 31 d0             	xor    %r10d,%eax
   4f1ae:	21 c8                	and    %ecx,%eax
   4f1b0:	31 e8                	xor    %ebp,%eax
   4f1b2:	44 01 f8             	add    %r15d,%eax
   4f1b5:	01 d8                	add    %ebx,%eax
   4f1b7:	41 01 d9             	add    %ebx,%r9d
   4f1ba:	44 89 cb             	mov    %r9d,%ebx
   4f1bd:	c1 c3 1a             	rol    $0x1a,%ebx
   4f1c0:	44 89 cd             	mov    %r9d,%ebp
   4f1c3:	c1 c5 15             	rol    $0x15,%ebp
   4f1c6:	31 dd                	xor    %ebx,%ebp
   4f1c8:	44 89 cb             	mov    %r9d,%ebx
   4f1cb:	c1 c3 07             	rol    $0x7,%ebx
   4f1ce:	31 eb                	xor    %ebp,%ebx
   4f1d0:	48 8b 54 24 c0       	mov    -0x40(%rsp),%rdx
   4f1d5:	44 01 e2             	add    %r12d,%edx
   4f1d8:	01 fa                	add    %edi,%edx
   4f1da:	44 89 ef             	mov    %r13d,%edi
   4f1dd:	44 31 df             	xor    %r11d,%edi
   4f1e0:	44 21 cf             	and    %r9d,%edi
   4f1e3:	44 31 df             	xor    %r11d,%edi
   4f1e6:	44 89 de             	mov    %r11d,%esi
   4f1e9:	01 fa                	add    %edi,%edx
   4f1eb:	44 8d 1c 13          	lea    (%rbx,%rdx,1),%r11d
   4f1ef:	41 81 c3 f7 a3 f9 be 	add    $0xbef9a3f7,%r11d
   4f1f6:	89 c7                	mov    %eax,%edi
   4f1f8:	c1 c7 1e             	rol    $0x1e,%edi
   4f1fb:	89 c3                	mov    %eax,%ebx
   4f1fd:	c1 c3 13             	rol    $0x13,%ebx
   4f200:	31 fb                	xor    %edi,%ebx
   4f202:	89 c5                	mov    %eax,%ebp
   4f204:	c1 c5 0a             	rol    $0xa,%ebp
   4f207:	31 dd                	xor    %ebx,%ebp
   4f209:	89 cb                	mov    %ecx,%ebx
   4f20b:	44 31 c3             	xor    %r8d,%ebx
   4f20e:	21 c3                	and    %eax,%ebx
   4f210:	89 cf                	mov    %ecx,%edi
   4f212:	44 21 c7             	and    %r8d,%edi
   4f215:	31 df                	xor    %ebx,%edi
   4f217:	01 ef                	add    %ebp,%edi
   4f219:	44 01 df             	add    %r11d,%edi
   4f21c:	45 01 da             	add    %r11d,%r10d
   4f21f:	45 89 d3             	mov    %r10d,%r11d
   4f222:	41 c1 c3 1a          	rol    $0x1a,%r11d
   4f226:	44 89 d3             	mov    %r10d,%ebx
   4f229:	c1 c3 15             	rol    $0x15,%ebx
   4f22c:	44 31 db             	xor    %r11d,%ebx
   4f22f:	45 89 d3             	mov    %r10d,%r11d
   4f232:	41 c1 c3 07          	rol    $0x7,%r11d
   4f236:	41 31 db             	xor    %ebx,%r11d
   4f239:	48 8b 54 24 a8       	mov    -0x58(%rsp),%rdx
   4f23e:	44 01 f2             	add    %r14d,%edx
   4f241:	01 f2                	add    %esi,%edx
   4f243:	44 89 ce             	mov    %r9d,%esi
   4f246:	44 31 ee             	xor    %r13d,%esi
   4f249:	44 21 d6             	and    %r10d,%esi
   4f24c:	44 31 ee             	xor    %r13d,%esi
   4f24f:	89 fb                	mov    %edi,%ebx
   4f251:	c1 c3 1e             	rol    $0x1e,%ebx
   4f254:	01 f2                	add    %esi,%edx
   4f256:	89 fe                	mov    %edi,%esi
   4f258:	c1 c6 13             	rol    $0x13,%esi
   4f25b:	41 01 d3             	add    %edx,%r11d
   4f25e:	41 81 c3 f2 78 71 c6 	add    $0xc67178f2,%r11d
   4f265:	89 fd                	mov    %edi,%ebp
   4f267:	c1 c5 0a             	rol    $0xa,%ebp
   4f26a:	31 de                	xor    %ebx,%esi
   4f26c:	31 f5                	xor    %esi,%ebp
   4f26e:	89 c3                	mov    %eax,%ebx
   4f270:	21 cb                	and    %ecx,%ebx
   4f272:	89 c2                	mov    %eax,%edx
   4f274:	31 ca                	xor    %ecx,%edx
   4f276:	21 fa                	and    %edi,%edx
   4f278:	31 da                	xor    %ebx,%edx
   4f27a:	03 54 24 78          	add    0x78(%rsp),%edx
   4f27e:	01 ea                	add    %ebp,%edx
   4f280:	03 bc 24 98 00 00 00 	add    0x98(%rsp),%edi
   4f287:	44 01 da             	add    %r11d,%edx
   4f28a:	03 84 24 a0 00 00 00 	add    0xa0(%rsp),%eax
   4f291:	03 4c 24 50          	add    0x50(%rsp),%ecx
   4f295:	44 03 84 24 80 00 00 	add    0x80(%rsp),%r8d
   4f29c:	00 
   4f29d:	45 01 d8             	add    %r11d,%r8d
   4f2a0:	48 8b 74 24 d8       	mov    -0x28(%rsp),%rsi
   4f2a5:	44 03 94 24 90 00 00 	add    0x90(%rsp),%r10d
   4f2ac:	00 
   4f2ad:	44 03 8c 24 88 00 00 	add    0x88(%rsp),%r9d
   4f2b4:	00 
   4f2b5:	44 03 6c 24 64       	add    0x64(%rsp),%r13d
   4f2ba:	48 83 c6 40          	add    $0x40,%rsi
   4f2be:	41 89 d6             	mov    %edx,%r14d
   4f2c1:	89 fb                	mov    %edi,%ebx
   4f2c3:	41 89 c3             	mov    %eax,%r11d
   4f2c6:	41 89 cf             	mov    %ecx,%r15d
   4f2c9:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
   4f2ce:	44 89 c5             	mov    %r8d,%ebp
   4f2d1:	45 89 d7             	mov    %r10d,%r15d
   4f2d4:	45 89 cc             	mov    %r9d,%r12d
   4f2d7:	48 3b 74 24 70       	cmp    0x70(%rsp),%rsi
   4f2dc:	0f 85 0e d7 ff ff    	jne    4c9f0 <sha2::sha256::compress256+0x50>
   4f2e2:	eb 18                	jmp    4f2fc <sha2::sha256::compress256+0x295c>
   4f2e4:	45 89 e1             	mov    %r12d,%r9d
   4f2e7:	45 89 fa             	mov    %r15d,%r10d
   4f2ea:	41 89 e8             	mov    %ebp,%r8d
   4f2ed:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   4f2f2:	89 c1                	mov    %eax,%ecx
   4f2f4:	44 89 d8             	mov    %r11d,%eax
   4f2f7:	89 df                	mov    %ebx,%edi
   4f2f9:	44 89 f2             	mov    %r14d,%edx
   4f2fc:	4c 8b 5c 24 68       	mov    0x68(%rsp),%r11
   4f301:	41 89 13             	mov    %edx,(%r11)
   4f304:	41 89 7b 04          	mov    %edi,0x4(%r11)
   4f308:	41 89 43 08          	mov    %eax,0x8(%r11)
   4f30c:	41 89 4b 0c          	mov    %ecx,0xc(%r11)
   4f310:	45 89 43 10          	mov    %r8d,0x10(%r11)
   4f314:	45 89 53 14          	mov    %r10d,0x14(%r11)
   4f318:	45 89 4b 18          	mov    %r9d,0x18(%r11)
   4f31c:	45 89 6b 1c          	mov    %r13d,0x1c(%r11)
   4f320:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   4f327:	5b                   	pop    %rbx
   4f328:	41 5c                	pop    %r12
   4f32a:	41 5d                	pop    %r13
   4f32c:	41 5e                	pop    %r14
   4f32e:	41 5f                	pop    %r15
   4f330:	5d                   	pop    %rbp
   4f331:	c3                   	ret
   4f332:	cc                   	int3
   4f333:	cc                   	int3
   4f334:	cc                   	int3
   4f335:	cc                   	int3
   4f336:	cc                   	int3
   4f337:	cc                   	int3
   4f338:	cc                   	int3
   4f339:	cc                   	int3
   4f33a:	cc                   	int3
   4f33b:	cc                   	int3
   4f33c:	cc                   	int3
   4f33d:	cc                   	int3
   4f33e:	cc                   	int3
   4f33f:	cc                   	int3

