0000000000062a50 <c2_sha256_boundary>:
   62a50:	48 83 ec 38          	sub    $0x38,%rsp
   62a54:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   62a59:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   62a5e:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   62a63:	e8 f8 4a ff ff       	call   57560 <<digest::core_api::wrapper::CoreWrapper<digest::core_api::ct_variable::CtVariableCoreWrapper<sha2::core_api::Sha256VarCore, typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UTerm, typenum::bit::B1>, typenum::bit::B0>, typenum::bit::B0>, typenum::bit::B0>, typenum::bit::B0>, typenum::bit::B0>, sha2::OidSha256>> as digest::digest::Digest>::digest::<&[u8]>>
   62a68:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   62a6d:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
   62a72:	48 8d 15 ef c6 0a 00 	lea    0xac6ef(%rip),%rdx        # 10f168 <__frame_dummy_init_array_entry+0x1208>
   62a79:	e8 e2 83 00 00       	call   6ae60 <<generic_array::GenericArray<u8, typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UTerm, typenum::bit::B1>, typenum::bit::B0>, typenum::bit::B0>, typenum::bit::B0>, typenum::bit::B0>, typenum::bit::B0>> as core::convert::Into<[u8; 32]>>::into>
   62a7e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   62a83:	48 83 c4 38          	add    $0x38,%rsp
   62a87:	c3                   	ret
   62a88:	cc                   	int3
   62a89:	cc                   	int3
   62a8a:	cc                   	int3
   62a8b:	cc                   	int3
   62a8c:	cc                   	int3
   62a8d:	cc                   	int3
   62a8e:	cc                   	int3
   62a8f:	cc                   	int3

0000000000092060 <sha2::sha256::compress256>:
   92060:	48 83 ec 18          	sub    $0x18,%rsp
   92064:	48 89 14 24          	mov    %rdx,(%rsp)
   92068:	48 89 f0             	mov    %rsi,%rax
   9206b:	48 8b 34 24          	mov    (%rsp),%rsi
   9206f:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   92074:	48 89 f8             	mov    %rdi,%rax
   92077:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   9207c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   92081:	48 8d 15 d0 f3 07 00 	lea    0x7f3d0(%rip),%rdx        # 111458 <__frame_dummy_init_array_entry+0x34f8>
   92088:	ff 15 2a 56 08 00    	call   *0x8562a(%rip)        # 1176b8 <_DYNAMIC+0xb18>
   9208e:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   92093:	48 89 c6             	mov    %rax,%rsi
   92096:	e8 05 2f 00 00       	call   94fa0 <sha2::sha256::soft::compress>
   9209b:	48 83 c4 18          	add    $0x18,%rsp
   9209f:	c3                   	ret

00000000000920a0 <sha2::sha256::soft::sha256load>:
   920a0:	48 89 f1             	mov    %rsi,%rcx
   920a3:	48 89 f8             	mov    %rdi,%rax
   920a6:	44 8b 42 0c          	mov    0xc(%rdx),%r8d
   920aa:	8b 31                	mov    (%rcx),%esi
   920ac:	8b 51 04             	mov    0x4(%rcx),%edx
   920af:	8b 49 08             	mov    0x8(%rcx),%ecx
   920b2:	44 89 07             	mov    %r8d,(%rdi)
   920b5:	89 77 04             	mov    %esi,0x4(%rdi)
   920b8:	89 57 08             	mov    %edx,0x8(%rdi)
   920bb:	89 4f 0c             	mov    %ecx,0xc(%rdi)
   920be:	c3                   	ret
   920bf:	cc                   	int3

00000000000920c0 <sha2::sha256::soft::sha256msg1>:
   920c0:	48 83 ec 68          	sub    $0x68,%rsp
   920c4:	48 89 34 24          	mov    %rsi,(%rsp)
   920c8:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
   920cd:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
   920d2:	48 8b 06             	mov    (%rsi),%rax
   920d5:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   920da:	48 8b 46 08          	mov    0x8(%rsi),%rax
   920de:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   920e3:	48 8b 02             	mov    (%rdx),%rax
   920e6:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   920eb:	48 8b 42 08          	mov    0x8(%rdx),%rax
   920ef:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   920f4:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   920f9:	48 8d 74 24 38       	lea    0x38(%rsp),%rsi
   920fe:	48 8d 54 24 48       	lea    0x48(%rsp),%rdx
   92103:	e8 98 ff ff ff       	call   920a0 <sha2::sha256::soft::sha256load>
   92108:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   9210d:	48 8d 74 24 28       	lea    0x28(%rsp),%rsi
   92112:	e8 49 34 00 00       	call   95560 <sha2::sha256::soft::sha256msg1::sigma0x4>
   92117:	48 8b 34 24          	mov    (%rsp),%rsi
   9211b:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   92120:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   92125:	48 8b 0e             	mov    (%rsi),%rcx
   92128:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   9212d:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   92131:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   92136:	44 8b 44 24 58       	mov    0x58(%rsp),%r8d
   9213b:	44 03 44 24 18       	add    0x18(%rsp),%r8d
   92140:	8b 74 24 5c          	mov    0x5c(%rsp),%esi
   92144:	03 74 24 1c          	add    0x1c(%rsp),%esi
   92148:	8b 54 24 60          	mov    0x60(%rsp),%edx
   9214c:	03 54 24 20          	add    0x20(%rsp),%edx
   92150:	8b 4c 24 64          	mov    0x64(%rsp),%ecx
   92154:	03 4c 24 24          	add    0x24(%rsp),%ecx
   92158:	44 89 07             	mov    %r8d,(%rdi)
   9215b:	89 77 04             	mov    %esi,0x4(%rdi)
   9215e:	89 57 08             	mov    %edx,0x8(%rdi)
   92161:	89 4f 0c             	mov    %ecx,0xc(%rdi)
   92164:	48 83 c4 68          	add    $0x68,%rsp
   92168:	c3                   	ret
   92169:	cc                   	int3
   9216a:	cc                   	int3
   9216b:	cc                   	int3
   9216c:	cc                   	int3
   9216d:	cc                   	int3
   9216e:	cc                   	int3
   9216f:	cc                   	int3

0000000000092170 <sha2::sha256::soft::sha256msg2>:
   92170:	48 83 ec 48          	sub    $0x48,%rsp
   92174:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
   92179:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
   9217e:	8b 06                	mov    (%rsi),%eax
   92180:	89 44 24 28          	mov    %eax,0x28(%rsp)
   92184:	8b 46 04             	mov    0x4(%rsi),%eax
   92187:	89 44 24 20          	mov    %eax,0x20(%rsp)
   9218b:	8b 46 08             	mov    0x8(%rsi),%eax
   9218e:	89 44 24 18          	mov    %eax,0x18(%rsp)
   92192:	8b 46 0c             	mov    0xc(%rsi),%eax
   92195:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   92199:	8b 02                	mov    (%rdx),%eax
   9219b:	89 44 24 14          	mov    %eax,0x14(%rsp)
   9219f:	8b 7a 04             	mov    0x4(%rdx),%edi
   921a2:	89 7c 24 08          	mov    %edi,0x8(%rsp)
   921a6:	be 11 00 00 00       	mov    $0x11,%esi
   921ab:	ff 15 ff 54 08 00    	call   *0x854ff(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   921b1:	8b 7c 24 08          	mov    0x8(%rsp),%edi
   921b5:	89 44 24 04          	mov    %eax,0x4(%rsp)
   921b9:	be 13 00 00 00       	mov    $0x13,%esi
   921be:	ff 15 ec 54 08 00    	call   *0x854ec(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   921c4:	8b 4c 24 04          	mov    0x4(%rsp),%ecx
   921c8:	8b 54 24 08          	mov    0x8(%rsp),%edx
   921cc:	8b 7c 24 14          	mov    0x14(%rsp),%edi
   921d0:	89 c6                	mov    %eax,%esi
   921d2:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   921d6:	31 f1                	xor    %esi,%ecx
   921d8:	c1 ea 0a             	shr    $0xa,%edx
   921db:	31 d1                	xor    %edx,%ecx
   921dd:	01 c8                	add    %ecx,%eax
   921df:	89 44 24 34          	mov    %eax,0x34(%rsp)
   921e3:	be 11 00 00 00       	mov    $0x11,%esi
   921e8:	ff 15 c2 54 08 00    	call   *0x854c2(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   921ee:	8b 7c 24 14          	mov    0x14(%rsp),%edi
   921f2:	89 44 24 10          	mov    %eax,0x10(%rsp)
   921f6:	be 13 00 00 00       	mov    $0x13,%esi
   921fb:	ff 15 af 54 08 00    	call   *0x854af(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   92201:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
   92205:	8b 54 24 14          	mov    0x14(%rsp),%edx
   92209:	8b 7c 24 34          	mov    0x34(%rsp),%edi
   9220d:	89 c6                	mov    %eax,%esi
   9220f:	8b 44 24 18          	mov    0x18(%rsp),%eax
   92213:	31 f1                	xor    %esi,%ecx
   92215:	c1 ea 0a             	shr    $0xa,%edx
   92218:	31 d1                	xor    %edx,%ecx
   9221a:	01 c8                	add    %ecx,%eax
   9221c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   92220:	be 11 00 00 00       	mov    $0x11,%esi
   92225:	ff 15 85 54 08 00    	call   *0x85485(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   9222b:	8b 7c 24 34          	mov    0x34(%rsp),%edi
   9222f:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   92233:	be 13 00 00 00       	mov    $0x13,%esi
   92238:	ff 15 72 54 08 00    	call   *0x85472(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   9223e:	8b 4c 24 1c          	mov    0x1c(%rsp),%ecx
   92242:	8b 7c 24 30          	mov    0x30(%rsp),%edi
   92246:	8b 54 24 34          	mov    0x34(%rsp),%edx
   9224a:	89 c6                	mov    %eax,%esi
   9224c:	8b 44 24 20          	mov    0x20(%rsp),%eax
   92250:	31 f1                	xor    %esi,%ecx
   92252:	c1 ea 0a             	shr    $0xa,%edx
   92255:	31 d1                	xor    %edx,%ecx
   92257:	01 c8                	add    %ecx,%eax
   92259:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   9225d:	be 11 00 00 00       	mov    $0x11,%esi
   92262:	ff 15 48 54 08 00    	call   *0x85448(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   92268:	8b 7c 24 30          	mov    0x30(%rsp),%edi
   9226c:	89 44 24 24          	mov    %eax,0x24(%rsp)
   92270:	be 13 00 00 00       	mov    $0x13,%esi
   92275:	ff 15 35 54 08 00    	call   *0x85435(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   9227b:	44 8b 4c 24 24       	mov    0x24(%rsp),%r9d
   92280:	44 8b 44 24 28       	mov    0x28(%rsp),%r8d
   92285:	8b 74 24 2c          	mov    0x2c(%rsp),%esi
   92289:	8b 54 24 30          	mov    0x30(%rsp),%edx
   9228d:	8b 4c 24 34          	mov    0x34(%rsp),%ecx
   92291:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   92296:	41 89 c2             	mov    %eax,%r10d
   92299:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   9229e:	45 31 d1             	xor    %r10d,%r9d
   922a1:	41 89 d2             	mov    %edx,%r10d
   922a4:	41 c1 ea 0a          	shr    $0xa,%r10d
   922a8:	45 31 d1             	xor    %r10d,%r9d
   922ab:	45 01 c8             	add    %r9d,%r8d
   922ae:	44 89 07             	mov    %r8d,(%rdi)
   922b1:	89 77 04             	mov    %esi,0x4(%rdi)
   922b4:	89 57 08             	mov    %edx,0x8(%rdi)
   922b7:	89 4f 0c             	mov    %ecx,0xc(%rdi)
   922ba:	48 83 c4 48          	add    $0x48,%rsp
   922be:	c3                   	ret
   922bf:	cc                   	int3

00000000000922c0 <sha2::sha256::soft::sha256swap>:
   922c0:	48 89 f1             	mov    %rsi,%rcx
   922c3:	48 89 f8             	mov    %rdi,%rax
   922c6:	44 8b 41 08          	mov    0x8(%rcx),%r8d
   922ca:	8b 71 0c             	mov    0xc(%rcx),%esi
   922cd:	8b 11                	mov    (%rcx),%edx
   922cf:	8b 49 04             	mov    0x4(%rcx),%ecx
   922d2:	44 89 07             	mov    %r8d,(%rdi)
   922d5:	89 77 04             	mov    %esi,0x4(%rdi)
   922d8:	89 57 08             	mov    %edx,0x8(%rdi)
   922db:	89 4f 0c             	mov    %ecx,0xc(%rdi)
   922de:	c3                   	ret
   922df:	cc                   	int3

00000000000922e0 <sha2::sha256::soft::sha256_digest_round_x2>:
   922e0:	55                   	push   %rbp
   922e1:	41 57                	push   %r15
   922e3:	41 56                	push   %r14
   922e5:	53                   	push   %rbx
   922e6:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
   922ed:	48 89 7c 24 68       	mov    %rdi,0x68(%rsp)
   922f2:	48 89 7c 24 70       	mov    %rdi,0x70(%rsp)
   922f7:	8b 41 08             	mov    0x8(%rcx),%eax
   922fa:	89 44 24 40          	mov    %eax,0x40(%rsp)
   922fe:	8b 41 0c             	mov    0xc(%rcx),%eax
   92301:	89 44 24 10          	mov    %eax,0x10(%rsp)
   92305:	8b 02                	mov    (%rdx),%eax
   92307:	89 44 24 24          	mov    %eax,0x24(%rsp)
   9230b:	8b 42 04             	mov    0x4(%rdx),%eax
   9230e:	89 44 24 28          	mov    %eax,0x28(%rsp)
   92312:	8b 7a 08             	mov    0x8(%rdx),%edi
   92315:	89 7c 24 30          	mov    %edi,0x30(%rsp)
   92319:	8b 42 0c             	mov    0xc(%rdx),%eax
   9231c:	89 44 24 34          	mov    %eax,0x34(%rsp)
   92320:	8b 06                	mov    (%rsi),%eax
   92322:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   92326:	8b 46 04             	mov    0x4(%rsi),%eax
   92329:	89 44 24 20          	mov    %eax,0x20(%rsp)
   9232d:	8b 46 08             	mov    0x8(%rsi),%eax
   92330:	89 44 24 38          	mov    %eax,0x38(%rsp)
   92334:	8b 46 0c             	mov    0xc(%rsi),%eax
   92337:	89 44 24 14          	mov    %eax,0x14(%rsp)
   9233b:	be 06 00 00 00       	mov    $0x6,%esi
   92340:	ff 15 6a 53 08 00    	call   *0x8536a(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   92346:	8b 7c 24 30          	mov    0x30(%rsp),%edi
   9234a:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   9234e:	be 0b 00 00 00       	mov    $0xb,%esi
   92353:	ff 15 57 53 08 00    	call   *0x85357(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   92359:	8b 7c 24 30          	mov    0x30(%rsp),%edi
   9235d:	89 c1                	mov    %eax,%ecx
   9235f:	8b 44 24 0c          	mov    0xc(%rsp),%eax
   92363:	31 c8                	xor    %ecx,%eax
   92365:	89 44 24 18          	mov    %eax,0x18(%rsp)
   92369:	be 19 00 00 00       	mov    $0x19,%esi
   9236e:	ff 15 3c 53 08 00    	call   *0x8533c(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   92374:	8b 54 24 10          	mov    0x10(%rsp),%edx
   92378:	8b 4c 24 14          	mov    0x14(%rsp),%ecx
   9237c:	8b 7c 24 24          	mov    0x24(%rsp),%edi
   92380:	44 8b 44 24 30       	mov    0x30(%rsp),%r8d
   92385:	44 8b 4c 24 34       	mov    0x34(%rsp),%r9d
   9238a:	8b 74 24 38          	mov    0x38(%rsp),%esi
   9238e:	41 89 c2             	mov    %eax,%r10d
   92391:	8b 44 24 18          	mov    0x18(%rsp),%eax
   92395:	44 31 d0             	xor    %r10d,%eax
   92398:	41 31 f1             	xor    %esi,%r9d
   9239b:	45 21 c8             	and    %r9d,%r8d
   9239e:	44 31 c6             	xor    %r8d,%esi
   923a1:	01 f0                	add    %esi,%eax
   923a3:	01 d0                	add    %edx,%eax
   923a5:	01 c8                	add    %ecx,%eax
   923a7:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   923ab:	be 02 00 00 00       	mov    $0x2,%esi
   923b0:	ff 15 fa 52 08 00    	call   *0x852fa(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   923b6:	8b 7c 24 24          	mov    0x24(%rsp),%edi
   923ba:	89 c3                	mov    %eax,%ebx
   923bc:	be 0d 00 00 00       	mov    $0xd,%esi
   923c1:	ff 15 e9 52 08 00    	call   *0x852e9(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   923c7:	8b 7c 24 24          	mov    0x24(%rsp),%edi
   923cb:	31 c3                	xor    %eax,%ebx
   923cd:	be 16 00 00 00       	mov    $0x16,%esi
   923d2:	ff 15 d8 52 08 00    	call   *0x852d8(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   923d8:	8b 74 24 1c          	mov    0x1c(%rsp),%esi
   923dc:	44 8b 5c 24 20       	mov    0x20(%rsp),%r11d
   923e1:	44 8b 4c 24 24       	mov    0x24(%rsp),%r9d
   923e6:	44 8b 44 24 28       	mov    0x28(%rsp),%r8d
   923eb:	8b 7c 24 2c          	mov    0x2c(%rsp),%edi
   923ef:	8b 54 24 30          	mov    0x30(%rsp),%edx
   923f3:	8b 4c 24 34          	mov    0x34(%rsp),%ecx
   923f7:	41 89 c2             	mov    %eax,%r10d
   923fa:	8b 44 24 38          	mov    0x38(%rsp),%eax
   923fe:	44 31 d3             	xor    %r10d,%ebx
   92401:	45 89 ca             	mov    %r9d,%r10d
   92404:	45 21 c2             	and    %r8d,%r10d
   92407:	44 89 cd             	mov    %r9d,%ebp
   9240a:	21 fd                	and    %edi,%ebp
   9240c:	41 31 ea             	xor    %ebp,%r10d
   9240f:	44 89 c5             	mov    %r8d,%ebp
   92412:	21 fd                	and    %edi,%ebp
   92414:	41 31 ea             	xor    %ebp,%r10d
   92417:	44 01 d3             	add    %r10d,%ebx
   9241a:	41 89 f2             	mov    %esi,%r10d
   9241d:	41 01 da             	add    %ebx,%r10d
   92420:	44 01 de             	add    %r11d,%esi
   92423:	44 89 54 24 78       	mov    %r10d,0x78(%rsp)
   92428:	44 89 4c 24 7c       	mov    %r9d,0x7c(%rsp)
   9242d:	44 89 84 24 80 00 00 	mov    %r8d,0x80(%rsp)
   92434:	00 
   92435:	89 bc 24 84 00 00 00 	mov    %edi,0x84(%rsp)
   9243c:	89 b4 24 88 00 00 00 	mov    %esi,0x88(%rsp)
   92443:	89 94 24 8c 00 00 00 	mov    %edx,0x8c(%rsp)
   9244a:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
   92451:	89 84 24 94 00 00 00 	mov    %eax,0x94(%rsp)
   92458:	8b 44 24 78          	mov    0x78(%rsp),%eax
   9245c:	89 44 24 50          	mov    %eax,0x50(%rsp)
   92460:	8b 44 24 7c          	mov    0x7c(%rsp),%eax
   92464:	89 44 24 54          	mov    %eax,0x54(%rsp)
   92468:	8b 84 24 80 00 00 00 	mov    0x80(%rsp),%eax
   9246f:	89 44 24 58          	mov    %eax,0x58(%rsp)
   92473:	8b ac 24 84 00 00 00 	mov    0x84(%rsp),%ebp
   9247a:	8b bc 24 88 00 00 00 	mov    0x88(%rsp),%edi
   92481:	89 7c 24 5c          	mov    %edi,0x5c(%rsp)
   92485:	8b 84 24 8c 00 00 00 	mov    0x8c(%rsp),%eax
   9248c:	89 44 24 60          	mov    %eax,0x60(%rsp)
   92490:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   92497:	89 44 24 64          	mov    %eax,0x64(%rsp)
   9249b:	8b 84 24 94 00 00 00 	mov    0x94(%rsp),%eax
   924a2:	89 44 24 44          	mov    %eax,0x44(%rsp)
   924a6:	be 06 00 00 00       	mov    $0x6,%esi
   924ab:	ff 15 ff 51 08 00    	call   *0x851ff(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   924b1:	8b 7c 24 5c          	mov    0x5c(%rsp),%edi
   924b5:	89 44 24 3c          	mov    %eax,0x3c(%rsp)
   924b9:	be 0b 00 00 00       	mov    $0xb,%esi
   924be:	ff 15 ec 51 08 00    	call   *0x851ec(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   924c4:	8b 7c 24 5c          	mov    0x5c(%rsp),%edi
   924c8:	89 c1                	mov    %eax,%ecx
   924ca:	8b 44 24 3c          	mov    0x3c(%rsp),%eax
   924ce:	31 c8                	xor    %ecx,%eax
   924d0:	89 44 24 48          	mov    %eax,0x48(%rsp)
   924d4:	be 19 00 00 00       	mov    $0x19,%esi
   924d9:	ff 15 d1 51 08 00    	call   *0x851d1(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   924df:	8b 54 24 40          	mov    0x40(%rsp),%edx
   924e3:	8b 4c 24 44          	mov    0x44(%rsp),%ecx
   924e7:	8b 7c 24 50          	mov    0x50(%rsp),%edi
   924eb:	44 8b 44 24 5c       	mov    0x5c(%rsp),%r8d
   924f0:	44 8b 4c 24 60       	mov    0x60(%rsp),%r9d
   924f5:	8b 74 24 64          	mov    0x64(%rsp),%esi
   924f9:	41 89 c2             	mov    %eax,%r10d
   924fc:	8b 44 24 48          	mov    0x48(%rsp),%eax
   92500:	44 31 d0             	xor    %r10d,%eax
   92503:	41 31 f1             	xor    %esi,%r9d
   92506:	45 21 c8             	and    %r9d,%r8d
   92509:	44 31 c6             	xor    %r8d,%esi
   9250c:	01 f0                	add    %esi,%eax
   9250e:	01 d0                	add    %edx,%eax
   92510:	01 c8                	add    %ecx,%eax
   92512:	89 44 24 4c          	mov    %eax,0x4c(%rsp)
   92516:	be 02 00 00 00       	mov    $0x2,%esi
   9251b:	ff 15 8f 51 08 00    	call   *0x8518f(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   92521:	8b 7c 24 50          	mov    0x50(%rsp),%edi
   92525:	41 89 c6             	mov    %eax,%r14d
   92528:	be 0d 00 00 00       	mov    $0xd,%esi
   9252d:	ff 15 7d 51 08 00    	call   *0x8517d(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   92533:	8b 7c 24 50          	mov    0x50(%rsp),%edi
   92537:	41 31 c6             	xor    %eax,%r14d
   9253a:	be 16 00 00 00       	mov    $0x16,%esi
   9253f:	ff 15 6b 51 08 00    	call   *0x8516b(%rip)        # 1176b0 <_DYNAMIC+0xb10>
   92545:	44 8b 44 24 4c       	mov    0x4c(%rsp),%r8d
   9254a:	44 8b 5c 24 50       	mov    0x50(%rsp),%r11d
   9254f:	44 8b 54 24 54       	mov    0x54(%rsp),%r10d
   92554:	44 8b 4c 24 58       	mov    0x58(%rsp),%r9d
   92559:	8b 74 24 5c          	mov    0x5c(%rsp),%esi
   9255d:	8b 54 24 60          	mov    0x60(%rsp),%edx
   92561:	8b 4c 24 64          	mov    0x64(%rsp),%ecx
   92565:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   9256a:	89 c3                	mov    %eax,%ebx
   9256c:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   92571:	41 31 de             	xor    %ebx,%r14d
   92574:	44 89 db             	mov    %r11d,%ebx
   92577:	44 21 d3             	and    %r10d,%ebx
   9257a:	45 89 df             	mov    %r11d,%r15d
   9257d:	45 21 cf             	and    %r9d,%r15d
   92580:	44 31 fb             	xor    %r15d,%ebx
   92583:	45 89 d7             	mov    %r10d,%r15d
   92586:	45 21 cf             	and    %r9d,%r15d
   92589:	44 31 fb             	xor    %r15d,%ebx
   9258c:	41 01 de             	add    %ebx,%r14d
   9258f:	44 89 c3             	mov    %r8d,%ebx
   92592:	44 01 f3             	add    %r14d,%ebx
   92595:	41 01 e8             	add    %ebp,%r8d
   92598:	89 9c 24 98 00 00 00 	mov    %ebx,0x98(%rsp)
   9259f:	44 89 9c 24 9c 00 00 	mov    %r11d,0x9c(%rsp)
   925a6:	00 
   925a7:	44 89 94 24 a0 00 00 	mov    %r10d,0xa0(%rsp)
   925ae:	00 
   925af:	44 89 8c 24 a4 00 00 	mov    %r9d,0xa4(%rsp)
   925b6:	00 
   925b7:	44 89 84 24 a8 00 00 	mov    %r8d,0xa8(%rsp)
   925be:	00 
   925bf:	89 b4 24 ac 00 00 00 	mov    %esi,0xac(%rsp)
   925c6:	89 94 24 b0 00 00 00 	mov    %edx,0xb0(%rsp)
   925cd:	89 8c 24 b4 00 00 00 	mov    %ecx,0xb4(%rsp)
   925d4:	44 8b 84 24 98 00 00 	mov    0x98(%rsp),%r8d
   925db:	00 
   925dc:	8b b4 24 9c 00 00 00 	mov    0x9c(%rsp),%esi
   925e3:	8b 94 24 a8 00 00 00 	mov    0xa8(%rsp),%edx
   925ea:	8b 8c 24 ac 00 00 00 	mov    0xac(%rsp),%ecx
   925f1:	44 89 07             	mov    %r8d,(%rdi)
   925f4:	89 77 04             	mov    %esi,0x4(%rdi)
   925f7:	89 57 08             	mov    %edx,0x8(%rdi)
   925fa:	89 4f 0c             	mov    %ecx,0xc(%rdi)
   925fd:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
   92604:	5b                   	pop    %rbx
   92605:	41 5e                	pop    %r14
   92607:	41 5f                	pop    %r15
   92609:	5d                   	pop    %rbp
   9260a:	c3                   	ret
   9260b:	cc                   	int3
   9260c:	cc                   	int3
   9260d:	cc                   	int3
   9260e:	cc                   	int3
   9260f:	cc                   	int3

0000000000092610 <sha2::sha256::soft::sha256_digest_block_u32>:
   92610:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
   92617:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   9261e:	00 
   9261f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
   92626:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   9262d:	00 
   9262e:	48 81 ec 38 01 00 00 	sub    $0x138,%rsp
   92635:	48 89 f0             	mov    %rsi,%rax
   92638:	48 89 f9             	mov    %rdi,%rcx
   9263b:	48 89 0c 24          	mov    %rcx,(%rsp)
   9263f:	44 8b 01             	mov    (%rcx),%r8d
   92642:	8b 79 04             	mov    0x4(%rcx),%edi
   92645:	8b 71 10             	mov    0x10(%rcx),%esi
   92648:	8b 51 14             	mov    0x14(%rcx),%edx
   9264b:	44 89 44 24 08       	mov    %r8d,0x8(%rsp)
   92650:	89 7c 24 0c          	mov    %edi,0xc(%rsp)
   92654:	89 74 24 10          	mov    %esi,0x10(%rsp)
   92658:	89 54 24 14          	mov    %edx,0x14(%rsp)
   9265c:	8b 79 08             	mov    0x8(%rcx),%edi
   9265f:	8b 71 0c             	mov    0xc(%rcx),%esi
   92662:	8b 51 18             	mov    0x18(%rcx),%edx
   92665:	8b 49 1c             	mov    0x1c(%rcx),%ecx
   92668:	89 7c 24 18          	mov    %edi,0x18(%rsp)
   9266c:	89 74 24 1c          	mov    %esi,0x1c(%rsp)
   92670:	89 54 24 20          	mov    %edx,0x20(%rsp)
   92674:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   92678:	8b 78 0c             	mov    0xc(%rax),%edi
   9267b:	8b 70 08             	mov    0x8(%rax),%esi
   9267e:	8b 50 04             	mov    0x4(%rax),%edx
   92681:	8b 08                	mov    (%rax),%ecx
   92683:	89 7c 24 28          	mov    %edi,0x28(%rsp)
   92687:	89 74 24 2c          	mov    %esi,0x2c(%rsp)
   9268b:	89 54 24 30          	mov    %edx,0x30(%rsp)
   9268f:	89 4c 24 34          	mov    %ecx,0x34(%rsp)
   92693:	8b 78 1c             	mov    0x1c(%rax),%edi
   92696:	8b 70 18             	mov    0x18(%rax),%esi
   92699:	8b 50 14             	mov    0x14(%rax),%edx
   9269c:	8b 48 10             	mov    0x10(%rax),%ecx
   9269f:	89 7c 24 38          	mov    %edi,0x38(%rsp)
   926a3:	89 74 24 3c          	mov    %esi,0x3c(%rsp)
   926a7:	89 54 24 40          	mov    %edx,0x40(%rsp)
   926ab:	89 4c 24 44          	mov    %ecx,0x44(%rsp)
   926af:	8b 78 2c             	mov    0x2c(%rax),%edi
   926b2:	8b 70 28             	mov    0x28(%rax),%esi
   926b5:	8b 50 24             	mov    0x24(%rax),%edx
   926b8:	8b 48 20             	mov    0x20(%rax),%ecx
   926bb:	89 7c 24 48          	mov    %edi,0x48(%rsp)
   926bf:	89 74 24 4c          	mov    %esi,0x4c(%rsp)
   926c3:	89 54 24 50          	mov    %edx,0x50(%rsp)
   926c7:	89 4c 24 54          	mov    %ecx,0x54(%rsp)
   926cb:	8b 70 3c             	mov    0x3c(%rax),%esi
   926ce:	8b 50 38             	mov    0x38(%rax),%edx
   926d1:	8b 48 34             	mov    0x34(%rax),%ecx
   926d4:	8b 40 30             	mov    0x30(%rax),%eax
   926d7:	89 74 24 58          	mov    %esi,0x58(%rsp)
   926db:	89 54 24 5c          	mov    %edx,0x5c(%rsp)
   926df:	89 4c 24 60          	mov    %ecx,0x60(%rsp)
   926e3:	89 44 24 64          	mov    %eax,0x64(%rsp)
   926e7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   926ec:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   926f3:	00 
   926f4:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   926f9:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   92700:	00 
   92701:	48 8d bc 24 a8 00 00 	lea    0xa8(%rsp),%rdi
   92708:	00 
   92709:	48 8d 35 f4 46 f8 ff 	lea    -0x7b90c(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   92710:	ba 00 01 00 00       	mov    $0x100,%edx
   92715:	e8 d6 a7 07 00       	call   10cef0 <memcpy@plt>
   9271a:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   92721:	00 
   92722:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
   92729:	00 
   9272a:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   92731:	00 
   92732:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   92739:	00 
   9273a:	8b b4 24 88 00 00 00 	mov    0x88(%rsp),%esi
   92741:	03 b4 24 98 00 00 00 	add    0x98(%rsp),%esi
   92748:	8b 94 24 8c 00 00 00 	mov    0x8c(%rsp),%edx
   9274f:	03 94 24 9c 00 00 00 	add    0x9c(%rsp),%edx
   92756:	8b 8c 24 90 00 00 00 	mov    0x90(%rsp),%ecx
   9275d:	03 8c 24 a0 00 00 00 	add    0xa0(%rsp),%ecx
   92764:	8b 84 24 94 00 00 00 	mov    0x94(%rsp),%eax
   9276b:	03 84 24 a4 00 00 00 	add    0xa4(%rsp),%eax
   92772:	89 74 24 78          	mov    %esi,0x78(%rsp)
   92776:	89 54 24 7c          	mov    %edx,0x7c(%rsp)
   9277a:	89 8c 24 80 00 00 00 	mov    %ecx,0x80(%rsp)
   92781:	89 84 24 84 00 00 00 	mov    %eax,0x84(%rsp)
   92788:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   9278d:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
   92794:	00 
   92795:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   9279a:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
   927a1:	00 
   927a2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   927a7:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
   927ae:	00 
   927af:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   927b4:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   927bb:	00 
   927bc:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
   927c1:	48 89 84 24 38 1e 00 	mov    %rax,0x1e38(%rsp)
   927c8:	00 
   927c9:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   927d0:	00 
   927d1:	48 89 84 24 40 1e 00 	mov    %rax,0x1e40(%rsp)
   927d8:	00 
   927d9:	48 8d bc 24 a8 01 00 	lea    0x1a8(%rsp),%rdi
   927e0:	00 
   927e1:	48 8d b4 24 b8 01 00 	lea    0x1b8(%rsp),%rsi
   927e8:	00 
   927e9:	48 8d 94 24 c8 01 00 	lea    0x1c8(%rsp),%rdx
   927f0:	00 
   927f1:	48 8d 8c 24 38 1e 00 	lea    0x1e38(%rsp),%rcx
   927f8:	00 
   927f9:	e8 e2 fa ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   927fe:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
   92805:	00 
   92806:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   9280b:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
   92812:	00 
   92813:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   92818:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
   9281d:	48 89 84 24 48 1e 00 	mov    %rax,0x1e48(%rsp)
   92824:	00 
   92825:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   9282c:	00 
   9282d:	48 89 84 24 50 1e 00 	mov    %rax,0x1e50(%rsp)
   92834:	00 
   92835:	48 8d bc 24 d8 01 00 	lea    0x1d8(%rsp),%rdi
   9283c:	00 
   9283d:	48 8d b4 24 48 1e 00 	lea    0x1e48(%rsp),%rsi
   92844:	00 
   92845:	e8 76 fa ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   9284a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   9284f:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
   92856:	00 
   92857:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   9285c:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
   92863:	00 
   92864:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   92869:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
   92870:	00 
   92871:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   92876:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   9287d:	00 
   9287e:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
   92885:	00 
   92886:	48 89 84 24 58 1e 00 	mov    %rax,0x1e58(%rsp)
   9288d:	00 
   9288e:	48 8b 84 24 e0 01 00 	mov    0x1e0(%rsp),%rax
   92895:	00 
   92896:	48 89 84 24 60 1e 00 	mov    %rax,0x1e60(%rsp)
   9289d:	00 
   9289e:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
   928a5:	00 
   928a6:	48 8d b4 24 f8 01 00 	lea    0x1f8(%rsp),%rsi
   928ad:	00 
   928ae:	48 8d 94 24 08 02 00 	lea    0x208(%rsp),%rdx
   928b5:	00 
   928b6:	48 8d 8c 24 58 1e 00 	lea    0x1e58(%rsp),%rcx
   928bd:	00 
   928be:	e8 1d fa ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   928c3:	48 8b 84 24 e8 01 00 	mov    0x1e8(%rsp),%rax
   928ca:	00 
   928cb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   928d0:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
   928d7:	00 
   928d8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   928dd:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   928e2:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
   928e9:	00 
   928ea:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   928ef:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
   928f6:	00 
   928f7:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
   928fe:	00 
   928ff:	48 8d 35 fe 44 f8 ff 	lea    -0x7bb02(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   92906:	ba 00 01 00 00       	mov    $0x100,%edx
   9290b:	e8 e0 a5 07 00       	call   10cef0 <memcpy@plt>
   92910:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
   92917:	00 
   92918:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
   9291f:	00 
   92920:	48 8b 84 24 60 02 00 	mov    0x260(%rsp),%rax
   92927:	00 
   92928:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
   9292f:	00 
   92930:	8b b4 24 28 02 00 00 	mov    0x228(%rsp),%esi
   92937:	03 b4 24 38 02 00 00 	add    0x238(%rsp),%esi
   9293e:	8b 94 24 2c 02 00 00 	mov    0x22c(%rsp),%edx
   92945:	03 94 24 3c 02 00 00 	add    0x23c(%rsp),%edx
   9294c:	8b 8c 24 30 02 00 00 	mov    0x230(%rsp),%ecx
   92953:	03 8c 24 40 02 00 00 	add    0x240(%rsp),%ecx
   9295a:	8b 84 24 34 02 00 00 	mov    0x234(%rsp),%eax
   92961:	03 84 24 44 02 00 00 	add    0x244(%rsp),%eax
   92968:	89 b4 24 18 02 00 00 	mov    %esi,0x218(%rsp)
   9296f:	89 94 24 1c 02 00 00 	mov    %edx,0x21c(%rsp)
   92976:	89 8c 24 20 02 00 00 	mov    %ecx,0x220(%rsp)
   9297d:	89 84 24 24 02 00 00 	mov    %eax,0x224(%rsp)
   92984:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   92989:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
   92990:	00 
   92991:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   92996:	48 89 84 24 60 03 00 	mov    %rax,0x360(%rsp)
   9299d:	00 
   9299e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   929a3:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
   929aa:	00 
   929ab:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   929b0:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   929b7:	00 
   929b8:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
   929bf:	00 
   929c0:	48 89 84 24 68 1e 00 	mov    %rax,0x1e68(%rsp)
   929c7:	00 
   929c8:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   929cf:	00 
   929d0:	48 89 84 24 70 1e 00 	mov    %rax,0x1e70(%rsp)
   929d7:	00 
   929d8:	48 8d bc 24 48 03 00 	lea    0x348(%rsp),%rdi
   929df:	00 
   929e0:	48 8d b4 24 58 03 00 	lea    0x358(%rsp),%rsi
   929e7:	00 
   929e8:	48 8d 94 24 68 03 00 	lea    0x368(%rsp),%rdx
   929ef:	00 
   929f0:	48 8d 8c 24 68 1e 00 	lea    0x1e68(%rsp),%rcx
   929f7:	00 
   929f8:	e8 e3 f8 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   929fd:	48 8b 84 24 48 03 00 	mov    0x348(%rsp),%rax
   92a04:	00 
   92a05:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   92a0a:	48 8b 84 24 50 03 00 	mov    0x350(%rsp),%rax
   92a11:	00 
   92a12:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   92a17:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
   92a1e:	00 
   92a1f:	48 89 84 24 78 1e 00 	mov    %rax,0x1e78(%rsp)
   92a26:	00 
   92a27:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   92a2e:	00 
   92a2f:	48 89 84 24 80 1e 00 	mov    %rax,0x1e80(%rsp)
   92a36:	00 
   92a37:	48 8d bc 24 78 03 00 	lea    0x378(%rsp),%rdi
   92a3e:	00 
   92a3f:	48 8d b4 24 78 1e 00 	lea    0x1e78(%rsp),%rsi
   92a46:	00 
   92a47:	e8 74 f8 ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   92a4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   92a51:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
   92a58:	00 
   92a59:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   92a5e:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
   92a65:	00 
   92a66:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   92a6b:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
   92a72:	00 
   92a73:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   92a78:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
   92a7f:	00 
   92a80:	48 8b 84 24 78 03 00 	mov    0x378(%rsp),%rax
   92a87:	00 
   92a88:	48 89 84 24 88 1e 00 	mov    %rax,0x1e88(%rsp)
   92a8f:	00 
   92a90:	48 8b 84 24 80 03 00 	mov    0x380(%rsp),%rax
   92a97:	00 
   92a98:	48 89 84 24 90 1e 00 	mov    %rax,0x1e90(%rsp)
   92a9f:	00 
   92aa0:	48 8d bc 24 88 03 00 	lea    0x388(%rsp),%rdi
   92aa7:	00 
   92aa8:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
   92aaf:	00 
   92ab0:	48 8d 94 24 a8 03 00 	lea    0x3a8(%rsp),%rdx
   92ab7:	00 
   92ab8:	48 8d 8c 24 88 1e 00 	lea    0x1e88(%rsp),%rcx
   92abf:	00 
   92ac0:	e8 1b f8 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   92ac5:	48 8b 84 24 88 03 00 	mov    0x388(%rsp),%rax
   92acc:	00 
   92acd:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   92ad2:	48 8b 84 24 90 03 00 	mov    0x390(%rsp),%rax
   92ad9:	00 
   92ada:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   92adf:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   92ae4:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
   92aeb:	00 
   92aec:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   92af1:	48 89 84 24 d0 03 00 	mov    %rax,0x3d0(%rsp)
   92af8:	00 
   92af9:	48 8d bc 24 e8 03 00 	lea    0x3e8(%rsp),%rdi
   92b00:	00 
   92b01:	48 8d 35 fc 42 f8 ff 	lea    -0x7bd04(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   92b08:	ba 00 01 00 00       	mov    $0x100,%edx
   92b0d:	e8 de a3 07 00       	call   10cef0 <memcpy@plt>
   92b12:	48 8b 84 24 08 04 00 	mov    0x408(%rsp),%rax
   92b19:	00 
   92b1a:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
   92b21:	00 
   92b22:	48 8b 84 24 10 04 00 	mov    0x410(%rsp),%rax
   92b29:	00 
   92b2a:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
   92b31:	00 
   92b32:	8b b4 24 c8 03 00 00 	mov    0x3c8(%rsp),%esi
   92b39:	03 b4 24 d8 03 00 00 	add    0x3d8(%rsp),%esi
   92b40:	8b 94 24 cc 03 00 00 	mov    0x3cc(%rsp),%edx
   92b47:	03 94 24 dc 03 00 00 	add    0x3dc(%rsp),%edx
   92b4e:	8b 8c 24 d0 03 00 00 	mov    0x3d0(%rsp),%ecx
   92b55:	03 8c 24 e0 03 00 00 	add    0x3e0(%rsp),%ecx
   92b5c:	8b 84 24 d4 03 00 00 	mov    0x3d4(%rsp),%eax
   92b63:	03 84 24 e4 03 00 00 	add    0x3e4(%rsp),%eax
   92b6a:	89 b4 24 b8 03 00 00 	mov    %esi,0x3b8(%rsp)
   92b71:	89 94 24 bc 03 00 00 	mov    %edx,0x3bc(%rsp)
   92b78:	89 8c 24 c0 03 00 00 	mov    %ecx,0x3c0(%rsp)
   92b7f:	89 84 24 c4 03 00 00 	mov    %eax,0x3c4(%rsp)
   92b86:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   92b8b:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
   92b92:	00 
   92b93:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   92b98:	48 89 84 24 00 05 00 	mov    %rax,0x500(%rsp)
   92b9f:	00 
   92ba0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   92ba5:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
   92bac:	00 
   92bad:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   92bb2:	48 89 84 24 10 05 00 	mov    %rax,0x510(%rsp)
   92bb9:	00 
   92bba:	48 8b 84 24 b8 03 00 	mov    0x3b8(%rsp),%rax
   92bc1:	00 
   92bc2:	48 89 84 24 98 1e 00 	mov    %rax,0x1e98(%rsp)
   92bc9:	00 
   92bca:	48 8b 84 24 c0 03 00 	mov    0x3c0(%rsp),%rax
   92bd1:	00 
   92bd2:	48 89 84 24 a0 1e 00 	mov    %rax,0x1ea0(%rsp)
   92bd9:	00 
   92bda:	48 8d bc 24 e8 04 00 	lea    0x4e8(%rsp),%rdi
   92be1:	00 
   92be2:	48 8d b4 24 f8 04 00 	lea    0x4f8(%rsp),%rsi
   92be9:	00 
   92bea:	48 8d 94 24 08 05 00 	lea    0x508(%rsp),%rdx
   92bf1:	00 
   92bf2:	48 8d 8c 24 98 1e 00 	lea    0x1e98(%rsp),%rcx
   92bf9:	00 
   92bfa:	e8 e1 f6 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   92bff:	48 8b 84 24 e8 04 00 	mov    0x4e8(%rsp),%rax
   92c06:	00 
   92c07:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   92c0c:	48 8b 84 24 f0 04 00 	mov    0x4f0(%rsp),%rax
   92c13:	00 
   92c14:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   92c19:	48 8b 84 24 b8 03 00 	mov    0x3b8(%rsp),%rax
   92c20:	00 
   92c21:	48 89 84 24 a8 1e 00 	mov    %rax,0x1ea8(%rsp)
   92c28:	00 
   92c29:	48 8b 84 24 c0 03 00 	mov    0x3c0(%rsp),%rax
   92c30:	00 
   92c31:	48 89 84 24 b0 1e 00 	mov    %rax,0x1eb0(%rsp)
   92c38:	00 
   92c39:	48 8d bc 24 18 05 00 	lea    0x518(%rsp),%rdi
   92c40:	00 
   92c41:	48 8d b4 24 a8 1e 00 	lea    0x1ea8(%rsp),%rsi
   92c48:	00 
   92c49:	e8 72 f6 ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   92c4e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   92c53:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
   92c5a:	00 
   92c5b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   92c60:	48 89 84 24 40 05 00 	mov    %rax,0x540(%rsp)
   92c67:	00 
   92c68:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   92c6d:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
   92c74:	00 
   92c75:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   92c7a:	48 89 84 24 50 05 00 	mov    %rax,0x550(%rsp)
   92c81:	00 
   92c82:	48 8b 84 24 18 05 00 	mov    0x518(%rsp),%rax
   92c89:	00 
   92c8a:	48 89 84 24 b8 1e 00 	mov    %rax,0x1eb8(%rsp)
   92c91:	00 
   92c92:	48 8b 84 24 20 05 00 	mov    0x520(%rsp),%rax
   92c99:	00 
   92c9a:	48 89 84 24 c0 1e 00 	mov    %rax,0x1ec0(%rsp)
   92ca1:	00 
   92ca2:	48 8d bc 24 28 05 00 	lea    0x528(%rsp),%rdi
   92ca9:	00 
   92caa:	48 8d b4 24 38 05 00 	lea    0x538(%rsp),%rsi
   92cb1:	00 
   92cb2:	48 8d 94 24 48 05 00 	lea    0x548(%rsp),%rdx
   92cb9:	00 
   92cba:	48 8d 8c 24 b8 1e 00 	lea    0x1eb8(%rsp),%rcx
   92cc1:	00 
   92cc2:	e8 19 f6 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   92cc7:	48 8b 84 24 28 05 00 	mov    0x528(%rsp),%rax
   92cce:	00 
   92ccf:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   92cd4:	48 8b 84 24 30 05 00 	mov    0x530(%rsp),%rax
   92cdb:	00 
   92cdc:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   92ce1:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   92ce6:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
   92ced:	00 
   92cee:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   92cf3:	48 89 84 24 70 05 00 	mov    %rax,0x570(%rsp)
   92cfa:	00 
   92cfb:	48 8d bc 24 88 05 00 	lea    0x588(%rsp),%rdi
   92d02:	00 
   92d03:	48 8d 35 fa 40 f8 ff 	lea    -0x7bf06(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   92d0a:	ba 00 01 00 00       	mov    $0x100,%edx
   92d0f:	e8 dc a1 07 00       	call   10cef0 <memcpy@plt>
   92d14:	48 8b 84 24 b8 05 00 	mov    0x5b8(%rsp),%rax
   92d1b:	00 
   92d1c:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
   92d23:	00 
   92d24:	48 8b 84 24 c0 05 00 	mov    0x5c0(%rsp),%rax
   92d2b:	00 
   92d2c:	48 89 84 24 80 05 00 	mov    %rax,0x580(%rsp)
   92d33:	00 
   92d34:	8b b4 24 68 05 00 00 	mov    0x568(%rsp),%esi
   92d3b:	03 b4 24 78 05 00 00 	add    0x578(%rsp),%esi
   92d42:	8b 94 24 6c 05 00 00 	mov    0x56c(%rsp),%edx
   92d49:	03 94 24 7c 05 00 00 	add    0x57c(%rsp),%edx
   92d50:	8b 8c 24 70 05 00 00 	mov    0x570(%rsp),%ecx
   92d57:	03 8c 24 80 05 00 00 	add    0x580(%rsp),%ecx
   92d5e:	8b 84 24 74 05 00 00 	mov    0x574(%rsp),%eax
   92d65:	03 84 24 84 05 00 00 	add    0x584(%rsp),%eax
   92d6c:	89 b4 24 58 05 00 00 	mov    %esi,0x558(%rsp)
   92d73:	89 94 24 5c 05 00 00 	mov    %edx,0x55c(%rsp)
   92d7a:	89 8c 24 60 05 00 00 	mov    %ecx,0x560(%rsp)
   92d81:	89 84 24 64 05 00 00 	mov    %eax,0x564(%rsp)
   92d88:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   92d8d:	48 89 84 24 98 06 00 	mov    %rax,0x698(%rsp)
   92d94:	00 
   92d95:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   92d9a:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
   92da1:	00 
   92da2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   92da7:	48 89 84 24 a8 06 00 	mov    %rax,0x6a8(%rsp)
   92dae:	00 
   92daf:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   92db4:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
   92dbb:	00 
   92dbc:	48 8b 84 24 58 05 00 	mov    0x558(%rsp),%rax
   92dc3:	00 
   92dc4:	48 89 84 24 c8 1e 00 	mov    %rax,0x1ec8(%rsp)
   92dcb:	00 
   92dcc:	48 8b 84 24 60 05 00 	mov    0x560(%rsp),%rax
   92dd3:	00 
   92dd4:	48 89 84 24 d0 1e 00 	mov    %rax,0x1ed0(%rsp)
   92ddb:	00 
   92ddc:	48 8d bc 24 88 06 00 	lea    0x688(%rsp),%rdi
   92de3:	00 
   92de4:	48 8d b4 24 98 06 00 	lea    0x698(%rsp),%rsi
   92deb:	00 
   92dec:	48 8d 94 24 a8 06 00 	lea    0x6a8(%rsp),%rdx
   92df3:	00 
   92df4:	48 8d 8c 24 c8 1e 00 	lea    0x1ec8(%rsp),%rcx
   92dfb:	00 
   92dfc:	e8 df f4 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   92e01:	48 8b 84 24 88 06 00 	mov    0x688(%rsp),%rax
   92e08:	00 
   92e09:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   92e0e:	48 8b 84 24 90 06 00 	mov    0x690(%rsp),%rax
   92e15:	00 
   92e16:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   92e1b:	48 8b 84 24 58 05 00 	mov    0x558(%rsp),%rax
   92e22:	00 
   92e23:	48 89 84 24 d8 1e 00 	mov    %rax,0x1ed8(%rsp)
   92e2a:	00 
   92e2b:	48 8b 84 24 60 05 00 	mov    0x560(%rsp),%rax
   92e32:	00 
   92e33:	48 89 84 24 e0 1e 00 	mov    %rax,0x1ee0(%rsp)
   92e3a:	00 
   92e3b:	48 8d bc 24 b8 06 00 	lea    0x6b8(%rsp),%rdi
   92e42:	00 
   92e43:	48 8d b4 24 d8 1e 00 	lea    0x1ed8(%rsp),%rsi
   92e4a:	00 
   92e4b:	e8 70 f4 ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   92e50:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   92e55:	48 89 84 24 d8 06 00 	mov    %rax,0x6d8(%rsp)
   92e5c:	00 
   92e5d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   92e62:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
   92e69:	00 
   92e6a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   92e6f:	48 89 84 24 e8 06 00 	mov    %rax,0x6e8(%rsp)
   92e76:	00 
   92e77:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   92e7c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
   92e83:	00 
   92e84:	48 8b 84 24 b8 06 00 	mov    0x6b8(%rsp),%rax
   92e8b:	00 
   92e8c:	48 89 84 24 e8 1e 00 	mov    %rax,0x1ee8(%rsp)
   92e93:	00 
   92e94:	48 8b 84 24 c0 06 00 	mov    0x6c0(%rsp),%rax
   92e9b:	00 
   92e9c:	48 89 84 24 f0 1e 00 	mov    %rax,0x1ef0(%rsp)
   92ea3:	00 
   92ea4:	48 8d bc 24 c8 06 00 	lea    0x6c8(%rsp),%rdi
   92eab:	00 
   92eac:	48 8d b4 24 d8 06 00 	lea    0x6d8(%rsp),%rsi
   92eb3:	00 
   92eb4:	48 8d 94 24 e8 06 00 	lea    0x6e8(%rsp),%rdx
   92ebb:	00 
   92ebc:	48 8d 8c 24 e8 1e 00 	lea    0x1ee8(%rsp),%rcx
   92ec3:	00 
   92ec4:	e8 17 f4 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   92ec9:	48 8b 84 24 c8 06 00 	mov    0x6c8(%rsp),%rax
   92ed0:	00 
   92ed1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   92ed6:	48 8b 84 24 d0 06 00 	mov    0x6d0(%rsp),%rax
   92edd:	00 
   92ede:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   92ee3:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   92ee8:	48 89 84 24 08 07 00 	mov    %rax,0x708(%rsp)
   92eef:	00 
   92ef0:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   92ef5:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
   92efc:	00 
   92efd:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   92f02:	48 89 84 24 18 07 00 	mov    %rax,0x718(%rsp)
   92f09:	00 
   92f0a:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   92f0f:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
   92f16:	00 
   92f17:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   92f1c:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
   92f23:	00 
   92f24:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   92f29:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
   92f30:	00 
   92f31:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   92f36:	48 89 84 24 38 07 00 	mov    %rax,0x738(%rsp)
   92f3d:	00 
   92f3e:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   92f43:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
   92f4a:	00 
   92f4b:	48 8d bc 24 f8 06 00 	lea    0x6f8(%rsp),%rdi
   92f52:	00 
   92f53:	48 8d b4 24 08 07 00 	lea    0x708(%rsp),%rsi
   92f5a:	00 
   92f5b:	48 8d 94 24 18 07 00 	lea    0x718(%rsp),%rdx
   92f62:	00 
   92f63:	48 8d 8c 24 28 07 00 	lea    0x728(%rsp),%rcx
   92f6a:	00 
   92f6b:	4c 8d 84 24 38 07 00 	lea    0x738(%rsp),%r8
   92f72:	00 
   92f73:	e8 78 23 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   92f78:	48 8b 84 24 f8 06 00 	mov    0x6f8(%rsp),%rax
   92f7f:	00 
   92f80:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   92f85:	48 8b 84 24 00 07 00 	mov    0x700(%rsp),%rax
   92f8c:	00 
   92f8d:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   92f92:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   92f97:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
   92f9e:	00 
   92f9f:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   92fa4:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
   92fab:	00 
   92fac:	48 8d bc 24 78 07 00 	lea    0x778(%rsp),%rdi
   92fb3:	00 
   92fb4:	48 8d 35 49 3e f8 ff 	lea    -0x7c1b7(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   92fbb:	ba 00 01 00 00       	mov    $0x100,%edx
   92fc0:	e8 2b 9f 07 00       	call   10cef0 <memcpy@plt>
   92fc5:	48 8b 84 24 b8 07 00 	mov    0x7b8(%rsp),%rax
   92fcc:	00 
   92fcd:	48 89 84 24 68 07 00 	mov    %rax,0x768(%rsp)
   92fd4:	00 
   92fd5:	48 8b 84 24 c0 07 00 	mov    0x7c0(%rsp),%rax
   92fdc:	00 
   92fdd:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
   92fe4:	00 
   92fe5:	8b b4 24 58 07 00 00 	mov    0x758(%rsp),%esi
   92fec:	03 b4 24 68 07 00 00 	add    0x768(%rsp),%esi
   92ff3:	8b 94 24 5c 07 00 00 	mov    0x75c(%rsp),%edx
   92ffa:	03 94 24 6c 07 00 00 	add    0x76c(%rsp),%edx
   93001:	8b 8c 24 60 07 00 00 	mov    0x760(%rsp),%ecx
   93008:	03 8c 24 70 07 00 00 	add    0x770(%rsp),%ecx
   9300f:	8b 84 24 64 07 00 00 	mov    0x764(%rsp),%eax
   93016:	03 84 24 74 07 00 00 	add    0x774(%rsp),%eax
   9301d:	89 b4 24 48 07 00 00 	mov    %esi,0x748(%rsp)
   93024:	89 94 24 4c 07 00 00 	mov    %edx,0x74c(%rsp)
   9302b:	89 8c 24 50 07 00 00 	mov    %ecx,0x750(%rsp)
   93032:	89 84 24 54 07 00 00 	mov    %eax,0x754(%rsp)
   93039:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   9303e:	48 89 84 24 88 08 00 	mov    %rax,0x888(%rsp)
   93045:	00 
   93046:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   9304b:	48 89 84 24 90 08 00 	mov    %rax,0x890(%rsp)
   93052:	00 
   93053:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   93058:	48 89 84 24 98 08 00 	mov    %rax,0x898(%rsp)
   9305f:	00 
   93060:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   93065:	48 89 84 24 a0 08 00 	mov    %rax,0x8a0(%rsp)
   9306c:	00 
   9306d:	48 8b 84 24 48 07 00 	mov    0x748(%rsp),%rax
   93074:	00 
   93075:	48 89 84 24 f8 1e 00 	mov    %rax,0x1ef8(%rsp)
   9307c:	00 
   9307d:	48 8b 84 24 50 07 00 	mov    0x750(%rsp),%rax
   93084:	00 
   93085:	48 89 84 24 00 1f 00 	mov    %rax,0x1f00(%rsp)
   9308c:	00 
   9308d:	48 8d bc 24 78 08 00 	lea    0x878(%rsp),%rdi
   93094:	00 
   93095:	48 8d b4 24 88 08 00 	lea    0x888(%rsp),%rsi
   9309c:	00 
   9309d:	48 8d 94 24 98 08 00 	lea    0x898(%rsp),%rdx
   930a4:	00 
   930a5:	48 8d 8c 24 f8 1e 00 	lea    0x1ef8(%rsp),%rcx
   930ac:	00 
   930ad:	e8 2e f2 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   930b2:	48 8b 84 24 78 08 00 	mov    0x878(%rsp),%rax
   930b9:	00 
   930ba:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   930bf:	48 8b 84 24 80 08 00 	mov    0x880(%rsp),%rax
   930c6:	00 
   930c7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   930cc:	48 8b 84 24 48 07 00 	mov    0x748(%rsp),%rax
   930d3:	00 
   930d4:	48 89 84 24 08 1f 00 	mov    %rax,0x1f08(%rsp)
   930db:	00 
   930dc:	48 8b 84 24 50 07 00 	mov    0x750(%rsp),%rax
   930e3:	00 
   930e4:	48 89 84 24 10 1f 00 	mov    %rax,0x1f10(%rsp)
   930eb:	00 
   930ec:	48 8d bc 24 a8 08 00 	lea    0x8a8(%rsp),%rdi
   930f3:	00 
   930f4:	48 8d b4 24 08 1f 00 	lea    0x1f08(%rsp),%rsi
   930fb:	00 
   930fc:	e8 bf f1 ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   93101:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   93106:	48 89 84 24 c8 08 00 	mov    %rax,0x8c8(%rsp)
   9310d:	00 
   9310e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   93113:	48 89 84 24 d0 08 00 	mov    %rax,0x8d0(%rsp)
   9311a:	00 
   9311b:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   93120:	48 89 84 24 d8 08 00 	mov    %rax,0x8d8(%rsp)
   93127:	00 
   93128:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   9312d:	48 89 84 24 e0 08 00 	mov    %rax,0x8e0(%rsp)
   93134:	00 
   93135:	48 8b 84 24 a8 08 00 	mov    0x8a8(%rsp),%rax
   9313c:	00 
   9313d:	48 89 84 24 18 1f 00 	mov    %rax,0x1f18(%rsp)
   93144:	00 
   93145:	48 8b 84 24 b0 08 00 	mov    0x8b0(%rsp),%rax
   9314c:	00 
   9314d:	48 89 84 24 20 1f 00 	mov    %rax,0x1f20(%rsp)
   93154:	00 
   93155:	48 8d bc 24 b8 08 00 	lea    0x8b8(%rsp),%rdi
   9315c:	00 
   9315d:	48 8d b4 24 c8 08 00 	lea    0x8c8(%rsp),%rsi
   93164:	00 
   93165:	48 8d 94 24 d8 08 00 	lea    0x8d8(%rsp),%rdx
   9316c:	00 
   9316d:	48 8d 8c 24 18 1f 00 	lea    0x1f18(%rsp),%rcx
   93174:	00 
   93175:	e8 66 f1 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   9317a:	48 8b 84 24 b8 08 00 	mov    0x8b8(%rsp),%rax
   93181:	00 
   93182:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   93187:	48 8b 84 24 c0 08 00 	mov    0x8c0(%rsp),%rax
   9318e:	00 
   9318f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   93194:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   93199:	48 89 84 24 f8 08 00 	mov    %rax,0x8f8(%rsp)
   931a0:	00 
   931a1:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   931a6:	48 89 84 24 00 09 00 	mov    %rax,0x900(%rsp)
   931ad:	00 
   931ae:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   931b3:	48 89 84 24 08 09 00 	mov    %rax,0x908(%rsp)
   931ba:	00 
   931bb:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   931c0:	48 89 84 24 10 09 00 	mov    %rax,0x910(%rsp)
   931c7:	00 
   931c8:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   931cd:	48 89 84 24 18 09 00 	mov    %rax,0x918(%rsp)
   931d4:	00 
   931d5:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   931da:	48 89 84 24 20 09 00 	mov    %rax,0x920(%rsp)
   931e1:	00 
   931e2:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   931e7:	48 89 84 24 28 09 00 	mov    %rax,0x928(%rsp)
   931ee:	00 
   931ef:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   931f4:	48 89 84 24 30 09 00 	mov    %rax,0x930(%rsp)
   931fb:	00 
   931fc:	48 8d bc 24 e8 08 00 	lea    0x8e8(%rsp),%rdi
   93203:	00 
   93204:	48 8d b4 24 f8 08 00 	lea    0x8f8(%rsp),%rsi
   9320b:	00 
   9320c:	48 8d 94 24 08 09 00 	lea    0x908(%rsp),%rdx
   93213:	00 
   93214:	48 8d 8c 24 18 09 00 	lea    0x918(%rsp),%rcx
   9321b:	00 
   9321c:	4c 8d 84 24 28 09 00 	lea    0x928(%rsp),%r8
   93223:	00 
   93224:	e8 c7 20 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   93229:	48 8b 84 24 e8 08 00 	mov    0x8e8(%rsp),%rax
   93230:	00 
   93231:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   93236:	48 8b 84 24 f0 08 00 	mov    0x8f0(%rsp),%rax
   9323d:	00 
   9323e:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   93243:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   93248:	48 89 84 24 48 09 00 	mov    %rax,0x948(%rsp)
   9324f:	00 
   93250:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   93255:	48 89 84 24 50 09 00 	mov    %rax,0x950(%rsp)
   9325c:	00 
   9325d:	48 8d bc 24 68 09 00 	lea    0x968(%rsp),%rdi
   93264:	00 
   93265:	48 8d 35 98 3b f8 ff 	lea    -0x7c468(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   9326c:	ba 00 01 00 00       	mov    $0x100,%edx
   93271:	e8 7a 9c 07 00       	call   10cef0 <memcpy@plt>
   93276:	48 8b 84 24 b8 09 00 	mov    0x9b8(%rsp),%rax
   9327d:	00 
   9327e:	48 89 84 24 58 09 00 	mov    %rax,0x958(%rsp)
   93285:	00 
   93286:	48 8b 84 24 c0 09 00 	mov    0x9c0(%rsp),%rax
   9328d:	00 
   9328e:	48 89 84 24 60 09 00 	mov    %rax,0x960(%rsp)
   93295:	00 
   93296:	8b b4 24 48 09 00 00 	mov    0x948(%rsp),%esi
   9329d:	03 b4 24 58 09 00 00 	add    0x958(%rsp),%esi
   932a4:	8b 94 24 4c 09 00 00 	mov    0x94c(%rsp),%edx
   932ab:	03 94 24 5c 09 00 00 	add    0x95c(%rsp),%edx
   932b2:	8b 8c 24 50 09 00 00 	mov    0x950(%rsp),%ecx
   932b9:	03 8c 24 60 09 00 00 	add    0x960(%rsp),%ecx
   932c0:	8b 84 24 54 09 00 00 	mov    0x954(%rsp),%eax
   932c7:	03 84 24 64 09 00 00 	add    0x964(%rsp),%eax
   932ce:	89 b4 24 38 09 00 00 	mov    %esi,0x938(%rsp)
   932d5:	89 94 24 3c 09 00 00 	mov    %edx,0x93c(%rsp)
   932dc:	89 8c 24 40 09 00 00 	mov    %ecx,0x940(%rsp)
   932e3:	89 84 24 44 09 00 00 	mov    %eax,0x944(%rsp)
   932ea:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   932ef:	48 89 84 24 78 0a 00 	mov    %rax,0xa78(%rsp)
   932f6:	00 
   932f7:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   932fc:	48 89 84 24 80 0a 00 	mov    %rax,0xa80(%rsp)
   93303:	00 
   93304:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   93309:	48 89 84 24 88 0a 00 	mov    %rax,0xa88(%rsp)
   93310:	00 
   93311:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   93316:	48 89 84 24 90 0a 00 	mov    %rax,0xa90(%rsp)
   9331d:	00 
   9331e:	48 8b 84 24 38 09 00 	mov    0x938(%rsp),%rax
   93325:	00 
   93326:	48 89 84 24 28 1f 00 	mov    %rax,0x1f28(%rsp)
   9332d:	00 
   9332e:	48 8b 84 24 40 09 00 	mov    0x940(%rsp),%rax
   93335:	00 
   93336:	48 89 84 24 30 1f 00 	mov    %rax,0x1f30(%rsp)
   9333d:	00 
   9333e:	48 8d bc 24 68 0a 00 	lea    0xa68(%rsp),%rdi
   93345:	00 
   93346:	48 8d b4 24 78 0a 00 	lea    0xa78(%rsp),%rsi
   9334d:	00 
   9334e:	48 8d 94 24 88 0a 00 	lea    0xa88(%rsp),%rdx
   93355:	00 
   93356:	48 8d 8c 24 28 1f 00 	lea    0x1f28(%rsp),%rcx
   9335d:	00 
   9335e:	e8 7d ef ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   93363:	48 8b 84 24 68 0a 00 	mov    0xa68(%rsp),%rax
   9336a:	00 
   9336b:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   93370:	48 8b 84 24 70 0a 00 	mov    0xa70(%rsp),%rax
   93377:	00 
   93378:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   9337d:	48 8b 84 24 38 09 00 	mov    0x938(%rsp),%rax
   93384:	00 
   93385:	48 89 84 24 38 1f 00 	mov    %rax,0x1f38(%rsp)
   9338c:	00 
   9338d:	48 8b 84 24 40 09 00 	mov    0x940(%rsp),%rax
   93394:	00 
   93395:	48 89 84 24 40 1f 00 	mov    %rax,0x1f40(%rsp)
   9339c:	00 
   9339d:	48 8d bc 24 98 0a 00 	lea    0xa98(%rsp),%rdi
   933a4:	00 
   933a5:	48 8d b4 24 38 1f 00 	lea    0x1f38(%rsp),%rsi
   933ac:	00 
   933ad:	e8 0e ef ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   933b2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   933b7:	48 89 84 24 b8 0a 00 	mov    %rax,0xab8(%rsp)
   933be:	00 
   933bf:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   933c4:	48 89 84 24 c0 0a 00 	mov    %rax,0xac0(%rsp)
   933cb:	00 
   933cc:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   933d1:	48 89 84 24 c8 0a 00 	mov    %rax,0xac8(%rsp)
   933d8:	00 
   933d9:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   933de:	48 89 84 24 d0 0a 00 	mov    %rax,0xad0(%rsp)
   933e5:	00 
   933e6:	48 8b 84 24 98 0a 00 	mov    0xa98(%rsp),%rax
   933ed:	00 
   933ee:	48 89 84 24 48 1f 00 	mov    %rax,0x1f48(%rsp)
   933f5:	00 
   933f6:	48 8b 84 24 a0 0a 00 	mov    0xaa0(%rsp),%rax
   933fd:	00 
   933fe:	48 89 84 24 50 1f 00 	mov    %rax,0x1f50(%rsp)
   93405:	00 
   93406:	48 8d bc 24 a8 0a 00 	lea    0xaa8(%rsp),%rdi
   9340d:	00 
   9340e:	48 8d b4 24 b8 0a 00 	lea    0xab8(%rsp),%rsi
   93415:	00 
   93416:	48 8d 94 24 c8 0a 00 	lea    0xac8(%rsp),%rdx
   9341d:	00 
   9341e:	48 8d 8c 24 48 1f 00 	lea    0x1f48(%rsp),%rcx
   93425:	00 
   93426:	e8 b5 ee ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   9342b:	48 8b 84 24 a8 0a 00 	mov    0xaa8(%rsp),%rax
   93432:	00 
   93433:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   93438:	48 8b 84 24 b0 0a 00 	mov    0xab0(%rsp),%rax
   9343f:	00 
   93440:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   93445:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   9344a:	48 89 84 24 e8 0a 00 	mov    %rax,0xae8(%rsp)
   93451:	00 
   93452:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   93457:	48 89 84 24 f0 0a 00 	mov    %rax,0xaf0(%rsp)
   9345e:	00 
   9345f:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   93464:	48 89 84 24 f8 0a 00 	mov    %rax,0xaf8(%rsp)
   9346b:	00 
   9346c:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   93471:	48 89 84 24 00 0b 00 	mov    %rax,0xb00(%rsp)
   93478:	00 
   93479:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   9347e:	48 89 84 24 08 0b 00 	mov    %rax,0xb08(%rsp)
   93485:	00 
   93486:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   9348b:	48 89 84 24 10 0b 00 	mov    %rax,0xb10(%rsp)
   93492:	00 
   93493:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   93498:	48 89 84 24 18 0b 00 	mov    %rax,0xb18(%rsp)
   9349f:	00 
   934a0:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   934a5:	48 89 84 24 20 0b 00 	mov    %rax,0xb20(%rsp)
   934ac:	00 
   934ad:	48 8d bc 24 d8 0a 00 	lea    0xad8(%rsp),%rdi
   934b4:	00 
   934b5:	48 8d b4 24 e8 0a 00 	lea    0xae8(%rsp),%rsi
   934bc:	00 
   934bd:	48 8d 94 24 f8 0a 00 	lea    0xaf8(%rsp),%rdx
   934c4:	00 
   934c5:	48 8d 8c 24 08 0b 00 	lea    0xb08(%rsp),%rcx
   934cc:	00 
   934cd:	4c 8d 84 24 18 0b 00 	lea    0xb18(%rsp),%r8
   934d4:	00 
   934d5:	e8 16 1e 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   934da:	48 8b 84 24 d8 0a 00 	mov    0xad8(%rsp),%rax
   934e1:	00 
   934e2:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   934e7:	48 8b 84 24 e0 0a 00 	mov    0xae0(%rsp),%rax
   934ee:	00 
   934ef:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   934f4:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   934f9:	48 89 84 24 38 0b 00 	mov    %rax,0xb38(%rsp)
   93500:	00 
   93501:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   93506:	48 89 84 24 40 0b 00 	mov    %rax,0xb40(%rsp)
   9350d:	00 
   9350e:	48 8d bc 24 58 0b 00 	lea    0xb58(%rsp),%rdi
   93515:	00 
   93516:	48 8d 35 e7 38 f8 ff 	lea    -0x7c719(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   9351d:	ba 00 01 00 00       	mov    $0x100,%edx
   93522:	e8 c9 99 07 00       	call   10cef0 <memcpy@plt>
   93527:	48 8b 84 24 b8 0b 00 	mov    0xbb8(%rsp),%rax
   9352e:	00 
   9352f:	48 89 84 24 48 0b 00 	mov    %rax,0xb48(%rsp)
   93536:	00 
   93537:	48 8b 84 24 c0 0b 00 	mov    0xbc0(%rsp),%rax
   9353e:	00 
   9353f:	48 89 84 24 50 0b 00 	mov    %rax,0xb50(%rsp)
   93546:	00 
   93547:	8b b4 24 38 0b 00 00 	mov    0xb38(%rsp),%esi
   9354e:	03 b4 24 48 0b 00 00 	add    0xb48(%rsp),%esi
   93555:	8b 94 24 3c 0b 00 00 	mov    0xb3c(%rsp),%edx
   9355c:	03 94 24 4c 0b 00 00 	add    0xb4c(%rsp),%edx
   93563:	8b 8c 24 40 0b 00 00 	mov    0xb40(%rsp),%ecx
   9356a:	03 8c 24 50 0b 00 00 	add    0xb50(%rsp),%ecx
   93571:	8b 84 24 44 0b 00 00 	mov    0xb44(%rsp),%eax
   93578:	03 84 24 54 0b 00 00 	add    0xb54(%rsp),%eax
   9357f:	89 b4 24 28 0b 00 00 	mov    %esi,0xb28(%rsp)
   93586:	89 94 24 2c 0b 00 00 	mov    %edx,0xb2c(%rsp)
   9358d:	89 8c 24 30 0b 00 00 	mov    %ecx,0xb30(%rsp)
   93594:	89 84 24 34 0b 00 00 	mov    %eax,0xb34(%rsp)
   9359b:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   935a0:	48 89 84 24 68 0c 00 	mov    %rax,0xc68(%rsp)
   935a7:	00 
   935a8:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   935ad:	48 89 84 24 70 0c 00 	mov    %rax,0xc70(%rsp)
   935b4:	00 
   935b5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   935ba:	48 89 84 24 78 0c 00 	mov    %rax,0xc78(%rsp)
   935c1:	00 
   935c2:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   935c7:	48 89 84 24 80 0c 00 	mov    %rax,0xc80(%rsp)
   935ce:	00 
   935cf:	48 8b 84 24 28 0b 00 	mov    0xb28(%rsp),%rax
   935d6:	00 
   935d7:	48 89 84 24 58 1f 00 	mov    %rax,0x1f58(%rsp)
   935de:	00 
   935df:	48 8b 84 24 30 0b 00 	mov    0xb30(%rsp),%rax
   935e6:	00 
   935e7:	48 89 84 24 60 1f 00 	mov    %rax,0x1f60(%rsp)
   935ee:	00 
   935ef:	48 8d bc 24 58 0c 00 	lea    0xc58(%rsp),%rdi
   935f6:	00 
   935f7:	48 8d b4 24 68 0c 00 	lea    0xc68(%rsp),%rsi
   935fe:	00 
   935ff:	48 8d 94 24 78 0c 00 	lea    0xc78(%rsp),%rdx
   93606:	00 
   93607:	48 8d 8c 24 58 1f 00 	lea    0x1f58(%rsp),%rcx
   9360e:	00 
   9360f:	e8 cc ec ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   93614:	48 8b 84 24 58 0c 00 	mov    0xc58(%rsp),%rax
   9361b:	00 
   9361c:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   93621:	48 8b 84 24 60 0c 00 	mov    0xc60(%rsp),%rax
   93628:	00 
   93629:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   9362e:	48 8b 84 24 28 0b 00 	mov    0xb28(%rsp),%rax
   93635:	00 
   93636:	48 89 84 24 68 1f 00 	mov    %rax,0x1f68(%rsp)
   9363d:	00 
   9363e:	48 8b 84 24 30 0b 00 	mov    0xb30(%rsp),%rax
   93645:	00 
   93646:	48 89 84 24 70 1f 00 	mov    %rax,0x1f70(%rsp)
   9364d:	00 
   9364e:	48 8d bc 24 88 0c 00 	lea    0xc88(%rsp),%rdi
   93655:	00 
   93656:	48 8d b4 24 68 1f 00 	lea    0x1f68(%rsp),%rsi
   9365d:	00 
   9365e:	e8 5d ec ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   93663:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   93668:	48 89 84 24 a8 0c 00 	mov    %rax,0xca8(%rsp)
   9366f:	00 
   93670:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   93675:	48 89 84 24 b0 0c 00 	mov    %rax,0xcb0(%rsp)
   9367c:	00 
   9367d:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   93682:	48 89 84 24 b8 0c 00 	mov    %rax,0xcb8(%rsp)
   93689:	00 
   9368a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   9368f:	48 89 84 24 c0 0c 00 	mov    %rax,0xcc0(%rsp)
   93696:	00 
   93697:	48 8b 84 24 88 0c 00 	mov    0xc88(%rsp),%rax
   9369e:	00 
   9369f:	48 89 84 24 78 1f 00 	mov    %rax,0x1f78(%rsp)
   936a6:	00 
   936a7:	48 8b 84 24 90 0c 00 	mov    0xc90(%rsp),%rax
   936ae:	00 
   936af:	48 89 84 24 80 1f 00 	mov    %rax,0x1f80(%rsp)
   936b6:	00 
   936b7:	48 8d bc 24 98 0c 00 	lea    0xc98(%rsp),%rdi
   936be:	00 
   936bf:	48 8d b4 24 a8 0c 00 	lea    0xca8(%rsp),%rsi
   936c6:	00 
   936c7:	48 8d 94 24 b8 0c 00 	lea    0xcb8(%rsp),%rdx
   936ce:	00 
   936cf:	48 8d 8c 24 78 1f 00 	lea    0x1f78(%rsp),%rcx
   936d6:	00 
   936d7:	e8 04 ec ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   936dc:	48 8b 84 24 98 0c 00 	mov    0xc98(%rsp),%rax
   936e3:	00 
   936e4:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   936e9:	48 8b 84 24 a0 0c 00 	mov    0xca0(%rsp),%rax
   936f0:	00 
   936f1:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   936f6:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   936fb:	48 89 84 24 d8 0c 00 	mov    %rax,0xcd8(%rsp)
   93702:	00 
   93703:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   93708:	48 89 84 24 e0 0c 00 	mov    %rax,0xce0(%rsp)
   9370f:	00 
   93710:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   93715:	48 89 84 24 e8 0c 00 	mov    %rax,0xce8(%rsp)
   9371c:	00 
   9371d:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   93722:	48 89 84 24 f0 0c 00 	mov    %rax,0xcf0(%rsp)
   93729:	00 
   9372a:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   9372f:	48 89 84 24 f8 0c 00 	mov    %rax,0xcf8(%rsp)
   93736:	00 
   93737:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   9373c:	48 89 84 24 00 0d 00 	mov    %rax,0xd00(%rsp)
   93743:	00 
   93744:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   93749:	48 89 84 24 08 0d 00 	mov    %rax,0xd08(%rsp)
   93750:	00 
   93751:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   93756:	48 89 84 24 10 0d 00 	mov    %rax,0xd10(%rsp)
   9375d:	00 
   9375e:	48 8d bc 24 c8 0c 00 	lea    0xcc8(%rsp),%rdi
   93765:	00 
   93766:	48 8d b4 24 d8 0c 00 	lea    0xcd8(%rsp),%rsi
   9376d:	00 
   9376e:	48 8d 94 24 e8 0c 00 	lea    0xce8(%rsp),%rdx
   93775:	00 
   93776:	48 8d 8c 24 f8 0c 00 	lea    0xcf8(%rsp),%rcx
   9377d:	00 
   9377e:	4c 8d 84 24 08 0d 00 	lea    0xd08(%rsp),%r8
   93785:	00 
   93786:	e8 65 1b 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   9378b:	48 8b 84 24 c8 0c 00 	mov    0xcc8(%rsp),%rax
   93792:	00 
   93793:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   93798:	48 8b 84 24 d0 0c 00 	mov    0xcd0(%rsp),%rax
   9379f:	00 
   937a0:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   937a5:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   937aa:	48 89 84 24 28 0d 00 	mov    %rax,0xd28(%rsp)
   937b1:	00 
   937b2:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   937b7:	48 89 84 24 30 0d 00 	mov    %rax,0xd30(%rsp)
   937be:	00 
   937bf:	48 8d bc 24 48 0d 00 	lea    0xd48(%rsp),%rdi
   937c6:	00 
   937c7:	48 8d 35 36 36 f8 ff 	lea    -0x7c9ca(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   937ce:	ba 00 01 00 00       	mov    $0x100,%edx
   937d3:	e8 18 97 07 00       	call   10cef0 <memcpy@plt>
   937d8:	48 8b 84 24 b8 0d 00 	mov    0xdb8(%rsp),%rax
   937df:	00 
   937e0:	48 89 84 24 38 0d 00 	mov    %rax,0xd38(%rsp)
   937e7:	00 
   937e8:	48 8b 84 24 c0 0d 00 	mov    0xdc0(%rsp),%rax
   937ef:	00 
   937f0:	48 89 84 24 40 0d 00 	mov    %rax,0xd40(%rsp)
   937f7:	00 
   937f8:	8b b4 24 28 0d 00 00 	mov    0xd28(%rsp),%esi
   937ff:	03 b4 24 38 0d 00 00 	add    0xd38(%rsp),%esi
   93806:	8b 94 24 2c 0d 00 00 	mov    0xd2c(%rsp),%edx
   9380d:	03 94 24 3c 0d 00 00 	add    0xd3c(%rsp),%edx
   93814:	8b 8c 24 30 0d 00 00 	mov    0xd30(%rsp),%ecx
   9381b:	03 8c 24 40 0d 00 00 	add    0xd40(%rsp),%ecx
   93822:	8b 84 24 34 0d 00 00 	mov    0xd34(%rsp),%eax
   93829:	03 84 24 44 0d 00 00 	add    0xd44(%rsp),%eax
   93830:	89 b4 24 18 0d 00 00 	mov    %esi,0xd18(%rsp)
   93837:	89 94 24 1c 0d 00 00 	mov    %edx,0xd1c(%rsp)
   9383e:	89 8c 24 20 0d 00 00 	mov    %ecx,0xd20(%rsp)
   93845:	89 84 24 24 0d 00 00 	mov    %eax,0xd24(%rsp)
   9384c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   93851:	48 89 84 24 58 0e 00 	mov    %rax,0xe58(%rsp)
   93858:	00 
   93859:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   9385e:	48 89 84 24 60 0e 00 	mov    %rax,0xe60(%rsp)
   93865:	00 
   93866:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   9386b:	48 89 84 24 68 0e 00 	mov    %rax,0xe68(%rsp)
   93872:	00 
   93873:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   93878:	48 89 84 24 70 0e 00 	mov    %rax,0xe70(%rsp)
   9387f:	00 
   93880:	48 8b 84 24 18 0d 00 	mov    0xd18(%rsp),%rax
   93887:	00 
   93888:	48 89 84 24 88 1f 00 	mov    %rax,0x1f88(%rsp)
   9388f:	00 
   93890:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   93897:	00 
   93898:	48 89 84 24 90 1f 00 	mov    %rax,0x1f90(%rsp)
   9389f:	00 
   938a0:	48 8d bc 24 48 0e 00 	lea    0xe48(%rsp),%rdi
   938a7:	00 
   938a8:	48 8d b4 24 58 0e 00 	lea    0xe58(%rsp),%rsi
   938af:	00 
   938b0:	48 8d 94 24 68 0e 00 	lea    0xe68(%rsp),%rdx
   938b7:	00 
   938b8:	48 8d 8c 24 88 1f 00 	lea    0x1f88(%rsp),%rcx
   938bf:	00 
   938c0:	e8 1b ea ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   938c5:	48 8b 84 24 48 0e 00 	mov    0xe48(%rsp),%rax
   938cc:	00 
   938cd:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   938d2:	48 8b 84 24 50 0e 00 	mov    0xe50(%rsp),%rax
   938d9:	00 
   938da:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   938df:	48 8b 84 24 18 0d 00 	mov    0xd18(%rsp),%rax
   938e6:	00 
   938e7:	48 89 84 24 98 1f 00 	mov    %rax,0x1f98(%rsp)
   938ee:	00 
   938ef:	48 8b 84 24 20 0d 00 	mov    0xd20(%rsp),%rax
   938f6:	00 
   938f7:	48 89 84 24 a0 1f 00 	mov    %rax,0x1fa0(%rsp)
   938fe:	00 
   938ff:	48 8d bc 24 78 0e 00 	lea    0xe78(%rsp),%rdi
   93906:	00 
   93907:	48 8d b4 24 98 1f 00 	lea    0x1f98(%rsp),%rsi
   9390e:	00 
   9390f:	e8 ac e9 ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   93914:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   93919:	48 89 84 24 98 0e 00 	mov    %rax,0xe98(%rsp)
   93920:	00 
   93921:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   93926:	48 89 84 24 a0 0e 00 	mov    %rax,0xea0(%rsp)
   9392d:	00 
   9392e:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   93933:	48 89 84 24 a8 0e 00 	mov    %rax,0xea8(%rsp)
   9393a:	00 
   9393b:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   93940:	48 89 84 24 b0 0e 00 	mov    %rax,0xeb0(%rsp)
   93947:	00 
   93948:	48 8b 84 24 78 0e 00 	mov    0xe78(%rsp),%rax
   9394f:	00 
   93950:	48 89 84 24 a8 1f 00 	mov    %rax,0x1fa8(%rsp)
   93957:	00 
   93958:	48 8b 84 24 80 0e 00 	mov    0xe80(%rsp),%rax
   9395f:	00 
   93960:	48 89 84 24 b0 1f 00 	mov    %rax,0x1fb0(%rsp)
   93967:	00 
   93968:	48 8d bc 24 88 0e 00 	lea    0xe88(%rsp),%rdi
   9396f:	00 
   93970:	48 8d b4 24 98 0e 00 	lea    0xe98(%rsp),%rsi
   93977:	00 
   93978:	48 8d 94 24 a8 0e 00 	lea    0xea8(%rsp),%rdx
   9397f:	00 
   93980:	48 8d 8c 24 a8 1f 00 	lea    0x1fa8(%rsp),%rcx
   93987:	00 
   93988:	e8 53 e9 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   9398d:	48 8b 84 24 88 0e 00 	mov    0xe88(%rsp),%rax
   93994:	00 
   93995:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   9399a:	48 8b 84 24 90 0e 00 	mov    0xe90(%rsp),%rax
   939a1:	00 
   939a2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   939a7:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   939ac:	48 89 84 24 c8 0e 00 	mov    %rax,0xec8(%rsp)
   939b3:	00 
   939b4:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   939b9:	48 89 84 24 d0 0e 00 	mov    %rax,0xed0(%rsp)
   939c0:	00 
   939c1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   939c6:	48 89 84 24 d8 0e 00 	mov    %rax,0xed8(%rsp)
   939cd:	00 
   939ce:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   939d3:	48 89 84 24 e0 0e 00 	mov    %rax,0xee0(%rsp)
   939da:	00 
   939db:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   939e0:	48 89 84 24 e8 0e 00 	mov    %rax,0xee8(%rsp)
   939e7:	00 
   939e8:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   939ed:	48 89 84 24 f0 0e 00 	mov    %rax,0xef0(%rsp)
   939f4:	00 
   939f5:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   939fa:	48 89 84 24 f8 0e 00 	mov    %rax,0xef8(%rsp)
   93a01:	00 
   93a02:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   93a07:	48 89 84 24 00 0f 00 	mov    %rax,0xf00(%rsp)
   93a0e:	00 
   93a0f:	48 8d bc 24 b8 0e 00 	lea    0xeb8(%rsp),%rdi
   93a16:	00 
   93a17:	48 8d b4 24 c8 0e 00 	lea    0xec8(%rsp),%rsi
   93a1e:	00 
   93a1f:	48 8d 94 24 d8 0e 00 	lea    0xed8(%rsp),%rdx
   93a26:	00 
   93a27:	48 8d 8c 24 e8 0e 00 	lea    0xee8(%rsp),%rcx
   93a2e:	00 
   93a2f:	4c 8d 84 24 f8 0e 00 	lea    0xef8(%rsp),%r8
   93a36:	00 
   93a37:	e8 b4 18 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   93a3c:	48 8b 84 24 b8 0e 00 	mov    0xeb8(%rsp),%rax
   93a43:	00 
   93a44:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   93a49:	48 8b 84 24 c0 0e 00 	mov    0xec0(%rsp),%rax
   93a50:	00 
   93a51:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   93a56:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   93a5b:	48 89 84 24 18 0f 00 	mov    %rax,0xf18(%rsp)
   93a62:	00 
   93a63:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   93a68:	48 89 84 24 20 0f 00 	mov    %rax,0xf20(%rsp)
   93a6f:	00 
   93a70:	48 8d bc 24 38 0f 00 	lea    0xf38(%rsp),%rdi
   93a77:	00 
   93a78:	48 8d 35 85 33 f8 ff 	lea    -0x7cc7b(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   93a7f:	ba 00 01 00 00       	mov    $0x100,%edx
   93a84:	e8 67 94 07 00       	call   10cef0 <memcpy@plt>
   93a89:	48 8b 84 24 b8 0f 00 	mov    0xfb8(%rsp),%rax
   93a90:	00 
   93a91:	48 89 84 24 28 0f 00 	mov    %rax,0xf28(%rsp)
   93a98:	00 
   93a99:	48 8b 84 24 c0 0f 00 	mov    0xfc0(%rsp),%rax
   93aa0:	00 
   93aa1:	48 89 84 24 30 0f 00 	mov    %rax,0xf30(%rsp)
   93aa8:	00 
   93aa9:	8b b4 24 18 0f 00 00 	mov    0xf18(%rsp),%esi
   93ab0:	03 b4 24 28 0f 00 00 	add    0xf28(%rsp),%esi
   93ab7:	8b 94 24 1c 0f 00 00 	mov    0xf1c(%rsp),%edx
   93abe:	03 94 24 2c 0f 00 00 	add    0xf2c(%rsp),%edx
   93ac5:	8b 8c 24 20 0f 00 00 	mov    0xf20(%rsp),%ecx
   93acc:	03 8c 24 30 0f 00 00 	add    0xf30(%rsp),%ecx
   93ad3:	8b 84 24 24 0f 00 00 	mov    0xf24(%rsp),%eax
   93ada:	03 84 24 34 0f 00 00 	add    0xf34(%rsp),%eax
   93ae1:	89 b4 24 08 0f 00 00 	mov    %esi,0xf08(%rsp)
   93ae8:	89 94 24 0c 0f 00 00 	mov    %edx,0xf0c(%rsp)
   93aef:	89 8c 24 10 0f 00 00 	mov    %ecx,0xf10(%rsp)
   93af6:	89 84 24 14 0f 00 00 	mov    %eax,0xf14(%rsp)
   93afd:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   93b02:	48 89 84 24 48 10 00 	mov    %rax,0x1048(%rsp)
   93b09:	00 
   93b0a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   93b0f:	48 89 84 24 50 10 00 	mov    %rax,0x1050(%rsp)
   93b16:	00 
   93b17:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   93b1c:	48 89 84 24 58 10 00 	mov    %rax,0x1058(%rsp)
   93b23:	00 
   93b24:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   93b29:	48 89 84 24 60 10 00 	mov    %rax,0x1060(%rsp)
   93b30:	00 
   93b31:	48 8b 84 24 08 0f 00 	mov    0xf08(%rsp),%rax
   93b38:	00 
   93b39:	48 89 84 24 b8 1f 00 	mov    %rax,0x1fb8(%rsp)
   93b40:	00 
   93b41:	48 8b 84 24 10 0f 00 	mov    0xf10(%rsp),%rax
   93b48:	00 
   93b49:	48 89 84 24 c0 1f 00 	mov    %rax,0x1fc0(%rsp)
   93b50:	00 
   93b51:	48 8d bc 24 38 10 00 	lea    0x1038(%rsp),%rdi
   93b58:	00 
   93b59:	48 8d b4 24 48 10 00 	lea    0x1048(%rsp),%rsi
   93b60:	00 
   93b61:	48 8d 94 24 58 10 00 	lea    0x1058(%rsp),%rdx
   93b68:	00 
   93b69:	48 8d 8c 24 b8 1f 00 	lea    0x1fb8(%rsp),%rcx
   93b70:	00 
   93b71:	e8 6a e7 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   93b76:	48 8b 84 24 38 10 00 	mov    0x1038(%rsp),%rax
   93b7d:	00 
   93b7e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   93b83:	48 8b 84 24 40 10 00 	mov    0x1040(%rsp),%rax
   93b8a:	00 
   93b8b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   93b90:	48 8b 84 24 08 0f 00 	mov    0xf08(%rsp),%rax
   93b97:	00 
   93b98:	48 89 84 24 c8 1f 00 	mov    %rax,0x1fc8(%rsp)
   93b9f:	00 
   93ba0:	48 8b 84 24 10 0f 00 	mov    0xf10(%rsp),%rax
   93ba7:	00 
   93ba8:	48 89 84 24 d0 1f 00 	mov    %rax,0x1fd0(%rsp)
   93baf:	00 
   93bb0:	48 8d bc 24 68 10 00 	lea    0x1068(%rsp),%rdi
   93bb7:	00 
   93bb8:	48 8d b4 24 c8 1f 00 	lea    0x1fc8(%rsp),%rsi
   93bbf:	00 
   93bc0:	e8 fb e6 ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   93bc5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   93bca:	48 89 84 24 88 10 00 	mov    %rax,0x1088(%rsp)
   93bd1:	00 
   93bd2:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   93bd7:	48 89 84 24 90 10 00 	mov    %rax,0x1090(%rsp)
   93bde:	00 
   93bdf:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   93be4:	48 89 84 24 98 10 00 	mov    %rax,0x1098(%rsp)
   93beb:	00 
   93bec:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   93bf1:	48 89 84 24 a0 10 00 	mov    %rax,0x10a0(%rsp)
   93bf8:	00 
   93bf9:	48 8b 84 24 68 10 00 	mov    0x1068(%rsp),%rax
   93c00:	00 
   93c01:	48 89 84 24 d8 1f 00 	mov    %rax,0x1fd8(%rsp)
   93c08:	00 
   93c09:	48 8b 84 24 70 10 00 	mov    0x1070(%rsp),%rax
   93c10:	00 
   93c11:	48 89 84 24 e0 1f 00 	mov    %rax,0x1fe0(%rsp)
   93c18:	00 
   93c19:	48 8d bc 24 78 10 00 	lea    0x1078(%rsp),%rdi
   93c20:	00 
   93c21:	48 8d b4 24 88 10 00 	lea    0x1088(%rsp),%rsi
   93c28:	00 
   93c29:	48 8d 94 24 98 10 00 	lea    0x1098(%rsp),%rdx
   93c30:	00 
   93c31:	48 8d 8c 24 d8 1f 00 	lea    0x1fd8(%rsp),%rcx
   93c38:	00 
   93c39:	e8 a2 e6 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   93c3e:	48 8b 84 24 78 10 00 	mov    0x1078(%rsp),%rax
   93c45:	00 
   93c46:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   93c4b:	48 8b 84 24 80 10 00 	mov    0x1080(%rsp),%rax
   93c52:	00 
   93c53:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   93c58:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   93c5d:	48 89 84 24 b8 10 00 	mov    %rax,0x10b8(%rsp)
   93c64:	00 
   93c65:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   93c6a:	48 89 84 24 c0 10 00 	mov    %rax,0x10c0(%rsp)
   93c71:	00 
   93c72:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   93c77:	48 89 84 24 c8 10 00 	mov    %rax,0x10c8(%rsp)
   93c7e:	00 
   93c7f:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   93c84:	48 89 84 24 d0 10 00 	mov    %rax,0x10d0(%rsp)
   93c8b:	00 
   93c8c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   93c91:	48 89 84 24 d8 10 00 	mov    %rax,0x10d8(%rsp)
   93c98:	00 
   93c99:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   93c9e:	48 89 84 24 e0 10 00 	mov    %rax,0x10e0(%rsp)
   93ca5:	00 
   93ca6:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   93cab:	48 89 84 24 e8 10 00 	mov    %rax,0x10e8(%rsp)
   93cb2:	00 
   93cb3:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   93cb8:	48 89 84 24 f0 10 00 	mov    %rax,0x10f0(%rsp)
   93cbf:	00 
   93cc0:	48 8d bc 24 a8 10 00 	lea    0x10a8(%rsp),%rdi
   93cc7:	00 
   93cc8:	48 8d b4 24 b8 10 00 	lea    0x10b8(%rsp),%rsi
   93ccf:	00 
   93cd0:	48 8d 94 24 c8 10 00 	lea    0x10c8(%rsp),%rdx
   93cd7:	00 
   93cd8:	48 8d 8c 24 d8 10 00 	lea    0x10d8(%rsp),%rcx
   93cdf:	00 
   93ce0:	4c 8d 84 24 e8 10 00 	lea    0x10e8(%rsp),%r8
   93ce7:	00 
   93ce8:	e8 03 16 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   93ced:	48 8b 84 24 a8 10 00 	mov    0x10a8(%rsp),%rax
   93cf4:	00 
   93cf5:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   93cfa:	48 8b 84 24 b0 10 00 	mov    0x10b0(%rsp),%rax
   93d01:	00 
   93d02:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   93d07:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   93d0c:	48 89 84 24 08 11 00 	mov    %rax,0x1108(%rsp)
   93d13:	00 
   93d14:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   93d19:	48 89 84 24 10 11 00 	mov    %rax,0x1110(%rsp)
   93d20:	00 
   93d21:	48 8d bc 24 28 11 00 	lea    0x1128(%rsp),%rdi
   93d28:	00 
   93d29:	48 8d 35 d4 30 f8 ff 	lea    -0x7cf2c(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   93d30:	ba 00 01 00 00       	mov    $0x100,%edx
   93d35:	e8 b6 91 07 00       	call   10cef0 <memcpy@plt>
   93d3a:	48 8b 84 24 b8 11 00 	mov    0x11b8(%rsp),%rax
   93d41:	00 
   93d42:	48 89 84 24 18 11 00 	mov    %rax,0x1118(%rsp)
   93d49:	00 
   93d4a:	48 8b 84 24 c0 11 00 	mov    0x11c0(%rsp),%rax
   93d51:	00 
   93d52:	48 89 84 24 20 11 00 	mov    %rax,0x1120(%rsp)
   93d59:	00 
   93d5a:	8b b4 24 08 11 00 00 	mov    0x1108(%rsp),%esi
   93d61:	03 b4 24 18 11 00 00 	add    0x1118(%rsp),%esi
   93d68:	8b 94 24 0c 11 00 00 	mov    0x110c(%rsp),%edx
   93d6f:	03 94 24 1c 11 00 00 	add    0x111c(%rsp),%edx
   93d76:	8b 8c 24 10 11 00 00 	mov    0x1110(%rsp),%ecx
   93d7d:	03 8c 24 20 11 00 00 	add    0x1120(%rsp),%ecx
   93d84:	8b 84 24 14 11 00 00 	mov    0x1114(%rsp),%eax
   93d8b:	03 84 24 24 11 00 00 	add    0x1124(%rsp),%eax
   93d92:	89 b4 24 f8 10 00 00 	mov    %esi,0x10f8(%rsp)
   93d99:	89 94 24 fc 10 00 00 	mov    %edx,0x10fc(%rsp)
   93da0:	89 8c 24 00 11 00 00 	mov    %ecx,0x1100(%rsp)
   93da7:	89 84 24 04 11 00 00 	mov    %eax,0x1104(%rsp)
   93dae:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   93db3:	48 89 84 24 38 12 00 	mov    %rax,0x1238(%rsp)
   93dba:	00 
   93dbb:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   93dc0:	48 89 84 24 40 12 00 	mov    %rax,0x1240(%rsp)
   93dc7:	00 
   93dc8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   93dcd:	48 89 84 24 48 12 00 	mov    %rax,0x1248(%rsp)
   93dd4:	00 
   93dd5:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   93dda:	48 89 84 24 50 12 00 	mov    %rax,0x1250(%rsp)
   93de1:	00 
   93de2:	48 8b 84 24 f8 10 00 	mov    0x10f8(%rsp),%rax
   93de9:	00 
   93dea:	48 89 84 24 e8 1f 00 	mov    %rax,0x1fe8(%rsp)
   93df1:	00 
   93df2:	48 8b 84 24 00 11 00 	mov    0x1100(%rsp),%rax
   93df9:	00 
   93dfa:	48 89 84 24 f0 1f 00 	mov    %rax,0x1ff0(%rsp)
   93e01:	00 
   93e02:	48 8d bc 24 28 12 00 	lea    0x1228(%rsp),%rdi
   93e09:	00 
   93e0a:	48 8d b4 24 38 12 00 	lea    0x1238(%rsp),%rsi
   93e11:	00 
   93e12:	48 8d 94 24 48 12 00 	lea    0x1248(%rsp),%rdx
   93e19:	00 
   93e1a:	48 8d 8c 24 e8 1f 00 	lea    0x1fe8(%rsp),%rcx
   93e21:	00 
   93e22:	e8 b9 e4 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   93e27:	48 8b 84 24 28 12 00 	mov    0x1228(%rsp),%rax
   93e2e:	00 
   93e2f:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   93e34:	48 8b 84 24 30 12 00 	mov    0x1230(%rsp),%rax
   93e3b:	00 
   93e3c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   93e41:	48 8b 84 24 f8 10 00 	mov    0x10f8(%rsp),%rax
   93e48:	00 
   93e49:	48 89 84 24 f8 1f 00 	mov    %rax,0x1ff8(%rsp)
   93e50:	00 
   93e51:	48 8b 84 24 00 11 00 	mov    0x1100(%rsp),%rax
   93e58:	00 
   93e59:	48 89 84 24 00 20 00 	mov    %rax,0x2000(%rsp)
   93e60:	00 
   93e61:	48 8d bc 24 58 12 00 	lea    0x1258(%rsp),%rdi
   93e68:	00 
   93e69:	48 8d b4 24 f8 1f 00 	lea    0x1ff8(%rsp),%rsi
   93e70:	00 
   93e71:	e8 4a e4 ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   93e76:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   93e7b:	48 89 84 24 78 12 00 	mov    %rax,0x1278(%rsp)
   93e82:	00 
   93e83:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   93e88:	48 89 84 24 80 12 00 	mov    %rax,0x1280(%rsp)
   93e8f:	00 
   93e90:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   93e95:	48 89 84 24 88 12 00 	mov    %rax,0x1288(%rsp)
   93e9c:	00 
   93e9d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   93ea2:	48 89 84 24 90 12 00 	mov    %rax,0x1290(%rsp)
   93ea9:	00 
   93eaa:	48 8b 84 24 58 12 00 	mov    0x1258(%rsp),%rax
   93eb1:	00 
   93eb2:	48 89 84 24 08 20 00 	mov    %rax,0x2008(%rsp)
   93eb9:	00 
   93eba:	48 8b 84 24 60 12 00 	mov    0x1260(%rsp),%rax
   93ec1:	00 
   93ec2:	48 89 84 24 10 20 00 	mov    %rax,0x2010(%rsp)
   93ec9:	00 
   93eca:	48 8d bc 24 68 12 00 	lea    0x1268(%rsp),%rdi
   93ed1:	00 
   93ed2:	48 8d b4 24 78 12 00 	lea    0x1278(%rsp),%rsi
   93ed9:	00 
   93eda:	48 8d 94 24 88 12 00 	lea    0x1288(%rsp),%rdx
   93ee1:	00 
   93ee2:	48 8d 8c 24 08 20 00 	lea    0x2008(%rsp),%rcx
   93ee9:	00 
   93eea:	e8 f1 e3 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   93eef:	48 8b 84 24 68 12 00 	mov    0x1268(%rsp),%rax
   93ef6:	00 
   93ef7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   93efc:	48 8b 84 24 70 12 00 	mov    0x1270(%rsp),%rax
   93f03:	00 
   93f04:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   93f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   93f0e:	48 89 84 24 a8 12 00 	mov    %rax,0x12a8(%rsp)
   93f15:	00 
   93f16:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   93f1b:	48 89 84 24 b0 12 00 	mov    %rax,0x12b0(%rsp)
   93f22:	00 
   93f23:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   93f28:	48 89 84 24 b8 12 00 	mov    %rax,0x12b8(%rsp)
   93f2f:	00 
   93f30:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   93f35:	48 89 84 24 c0 12 00 	mov    %rax,0x12c0(%rsp)
   93f3c:	00 
   93f3d:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   93f42:	48 89 84 24 c8 12 00 	mov    %rax,0x12c8(%rsp)
   93f49:	00 
   93f4a:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   93f4f:	48 89 84 24 d0 12 00 	mov    %rax,0x12d0(%rsp)
   93f56:	00 
   93f57:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   93f5c:	48 89 84 24 d8 12 00 	mov    %rax,0x12d8(%rsp)
   93f63:	00 
   93f64:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   93f69:	48 89 84 24 e0 12 00 	mov    %rax,0x12e0(%rsp)
   93f70:	00 
   93f71:	48 8d bc 24 98 12 00 	lea    0x1298(%rsp),%rdi
   93f78:	00 
   93f79:	48 8d b4 24 a8 12 00 	lea    0x12a8(%rsp),%rsi
   93f80:	00 
   93f81:	48 8d 94 24 b8 12 00 	lea    0x12b8(%rsp),%rdx
   93f88:	00 
   93f89:	48 8d 8c 24 c8 12 00 	lea    0x12c8(%rsp),%rcx
   93f90:	00 
   93f91:	4c 8d 84 24 d8 12 00 	lea    0x12d8(%rsp),%r8
   93f98:	00 
   93f99:	e8 52 13 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   93f9e:	48 8b 84 24 98 12 00 	mov    0x1298(%rsp),%rax
   93fa5:	00 
   93fa6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   93fab:	48 8b 84 24 a0 12 00 	mov    0x12a0(%rsp),%rax
   93fb2:	00 
   93fb3:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   93fb8:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   93fbd:	48 89 84 24 f8 12 00 	mov    %rax,0x12f8(%rsp)
   93fc4:	00 
   93fc5:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   93fca:	48 89 84 24 00 13 00 	mov    %rax,0x1300(%rsp)
   93fd1:	00 
   93fd2:	48 8d bc 24 18 13 00 	lea    0x1318(%rsp),%rdi
   93fd9:	00 
   93fda:	48 8d 35 23 2e f8 ff 	lea    -0x7d1dd(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   93fe1:	ba 00 01 00 00       	mov    $0x100,%edx
   93fe6:	e8 05 8f 07 00       	call   10cef0 <memcpy@plt>
   93feb:	48 8b 84 24 b8 13 00 	mov    0x13b8(%rsp),%rax
   93ff2:	00 
   93ff3:	48 89 84 24 08 13 00 	mov    %rax,0x1308(%rsp)
   93ffa:	00 
   93ffb:	48 8b 84 24 c0 13 00 	mov    0x13c0(%rsp),%rax
   94002:	00 
   94003:	48 89 84 24 10 13 00 	mov    %rax,0x1310(%rsp)
   9400a:	00 
   9400b:	8b b4 24 f8 12 00 00 	mov    0x12f8(%rsp),%esi
   94012:	03 b4 24 08 13 00 00 	add    0x1308(%rsp),%esi
   94019:	8b 94 24 fc 12 00 00 	mov    0x12fc(%rsp),%edx
   94020:	03 94 24 0c 13 00 00 	add    0x130c(%rsp),%edx
   94027:	8b 8c 24 00 13 00 00 	mov    0x1300(%rsp),%ecx
   9402e:	03 8c 24 10 13 00 00 	add    0x1310(%rsp),%ecx
   94035:	8b 84 24 04 13 00 00 	mov    0x1304(%rsp),%eax
   9403c:	03 84 24 14 13 00 00 	add    0x1314(%rsp),%eax
   94043:	89 b4 24 e8 12 00 00 	mov    %esi,0x12e8(%rsp)
   9404a:	89 94 24 ec 12 00 00 	mov    %edx,0x12ec(%rsp)
   94051:	89 8c 24 f0 12 00 00 	mov    %ecx,0x12f0(%rsp)
   94058:	89 84 24 f4 12 00 00 	mov    %eax,0x12f4(%rsp)
   9405f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   94064:	48 89 84 24 28 14 00 	mov    %rax,0x1428(%rsp)
   9406b:	00 
   9406c:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   94071:	48 89 84 24 30 14 00 	mov    %rax,0x1430(%rsp)
   94078:	00 
   94079:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   9407e:	48 89 84 24 38 14 00 	mov    %rax,0x1438(%rsp)
   94085:	00 
   94086:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   9408b:	48 89 84 24 40 14 00 	mov    %rax,0x1440(%rsp)
   94092:	00 
   94093:	48 8b 84 24 e8 12 00 	mov    0x12e8(%rsp),%rax
   9409a:	00 
   9409b:	48 89 84 24 18 20 00 	mov    %rax,0x2018(%rsp)
   940a2:	00 
   940a3:	48 8b 84 24 f0 12 00 	mov    0x12f0(%rsp),%rax
   940aa:	00 
   940ab:	48 89 84 24 20 20 00 	mov    %rax,0x2020(%rsp)
   940b2:	00 
   940b3:	48 8d bc 24 18 14 00 	lea    0x1418(%rsp),%rdi
   940ba:	00 
   940bb:	48 8d b4 24 28 14 00 	lea    0x1428(%rsp),%rsi
   940c2:	00 
   940c3:	48 8d 94 24 38 14 00 	lea    0x1438(%rsp),%rdx
   940ca:	00 
   940cb:	48 8d 8c 24 18 20 00 	lea    0x2018(%rsp),%rcx
   940d2:	00 
   940d3:	e8 08 e2 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   940d8:	48 8b 84 24 18 14 00 	mov    0x1418(%rsp),%rax
   940df:	00 
   940e0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   940e5:	48 8b 84 24 20 14 00 	mov    0x1420(%rsp),%rax
   940ec:	00 
   940ed:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   940f2:	48 8b 84 24 e8 12 00 	mov    0x12e8(%rsp),%rax
   940f9:	00 
   940fa:	48 89 84 24 28 20 00 	mov    %rax,0x2028(%rsp)
   94101:	00 
   94102:	48 8b 84 24 f0 12 00 	mov    0x12f0(%rsp),%rax
   94109:	00 
   9410a:	48 89 84 24 30 20 00 	mov    %rax,0x2030(%rsp)
   94111:	00 
   94112:	48 8d bc 24 48 14 00 	lea    0x1448(%rsp),%rdi
   94119:	00 
   9411a:	48 8d b4 24 28 20 00 	lea    0x2028(%rsp),%rsi
   94121:	00 
   94122:	e8 99 e1 ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   94127:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   9412c:	48 89 84 24 68 14 00 	mov    %rax,0x1468(%rsp)
   94133:	00 
   94134:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   94139:	48 89 84 24 70 14 00 	mov    %rax,0x1470(%rsp)
   94140:	00 
   94141:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   94146:	48 89 84 24 78 14 00 	mov    %rax,0x1478(%rsp)
   9414d:	00 
   9414e:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   94153:	48 89 84 24 80 14 00 	mov    %rax,0x1480(%rsp)
   9415a:	00 
   9415b:	48 8b 84 24 48 14 00 	mov    0x1448(%rsp),%rax
   94162:	00 
   94163:	48 89 84 24 38 20 00 	mov    %rax,0x2038(%rsp)
   9416a:	00 
   9416b:	48 8b 84 24 50 14 00 	mov    0x1450(%rsp),%rax
   94172:	00 
   94173:	48 89 84 24 40 20 00 	mov    %rax,0x2040(%rsp)
   9417a:	00 
   9417b:	48 8d bc 24 58 14 00 	lea    0x1458(%rsp),%rdi
   94182:	00 
   94183:	48 8d b4 24 68 14 00 	lea    0x1468(%rsp),%rsi
   9418a:	00 
   9418b:	48 8d 94 24 78 14 00 	lea    0x1478(%rsp),%rdx
   94192:	00 
   94193:	48 8d 8c 24 38 20 00 	lea    0x2038(%rsp),%rcx
   9419a:	00 
   9419b:	e8 40 e1 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   941a0:	48 8b 84 24 58 14 00 	mov    0x1458(%rsp),%rax
   941a7:	00 
   941a8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   941ad:	48 8b 84 24 60 14 00 	mov    0x1460(%rsp),%rax
   941b4:	00 
   941b5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   941ba:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   941bf:	48 89 84 24 98 14 00 	mov    %rax,0x1498(%rsp)
   941c6:	00 
   941c7:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   941cc:	48 89 84 24 a0 14 00 	mov    %rax,0x14a0(%rsp)
   941d3:	00 
   941d4:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   941d9:	48 89 84 24 a8 14 00 	mov    %rax,0x14a8(%rsp)
   941e0:	00 
   941e1:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   941e6:	48 89 84 24 b0 14 00 	mov    %rax,0x14b0(%rsp)
   941ed:	00 
   941ee:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   941f3:	48 89 84 24 b8 14 00 	mov    %rax,0x14b8(%rsp)
   941fa:	00 
   941fb:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   94200:	48 89 84 24 c0 14 00 	mov    %rax,0x14c0(%rsp)
   94207:	00 
   94208:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   9420d:	48 89 84 24 c8 14 00 	mov    %rax,0x14c8(%rsp)
   94214:	00 
   94215:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   9421a:	48 89 84 24 d0 14 00 	mov    %rax,0x14d0(%rsp)
   94221:	00 
   94222:	48 8d bc 24 88 14 00 	lea    0x1488(%rsp),%rdi
   94229:	00 
   9422a:	48 8d b4 24 98 14 00 	lea    0x1498(%rsp),%rsi
   94231:	00 
   94232:	48 8d 94 24 a8 14 00 	lea    0x14a8(%rsp),%rdx
   94239:	00 
   9423a:	48 8d 8c 24 b8 14 00 	lea    0x14b8(%rsp),%rcx
   94241:	00 
   94242:	4c 8d 84 24 c8 14 00 	lea    0x14c8(%rsp),%r8
   94249:	00 
   9424a:	e8 a1 10 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   9424f:	48 8b 84 24 88 14 00 	mov    0x1488(%rsp),%rax
   94256:	00 
   94257:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   9425c:	48 8b 84 24 90 14 00 	mov    0x1490(%rsp),%rax
   94263:	00 
   94264:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   94269:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   9426e:	48 89 84 24 e8 14 00 	mov    %rax,0x14e8(%rsp)
   94275:	00 
   94276:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   9427b:	48 89 84 24 f0 14 00 	mov    %rax,0x14f0(%rsp)
   94282:	00 
   94283:	48 8d bc 24 08 15 00 	lea    0x1508(%rsp),%rdi
   9428a:	00 
   9428b:	48 8d 35 72 2b f8 ff 	lea    -0x7d48e(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   94292:	ba 00 01 00 00       	mov    $0x100,%edx
   94297:	e8 54 8c 07 00       	call   10cef0 <memcpy@plt>
   9429c:	48 8b 84 24 b8 15 00 	mov    0x15b8(%rsp),%rax
   942a3:	00 
   942a4:	48 89 84 24 f8 14 00 	mov    %rax,0x14f8(%rsp)
   942ab:	00 
   942ac:	48 8b 84 24 c0 15 00 	mov    0x15c0(%rsp),%rax
   942b3:	00 
   942b4:	48 89 84 24 00 15 00 	mov    %rax,0x1500(%rsp)
   942bb:	00 
   942bc:	8b b4 24 e8 14 00 00 	mov    0x14e8(%rsp),%esi
   942c3:	03 b4 24 f8 14 00 00 	add    0x14f8(%rsp),%esi
   942ca:	8b 94 24 ec 14 00 00 	mov    0x14ec(%rsp),%edx
   942d1:	03 94 24 fc 14 00 00 	add    0x14fc(%rsp),%edx
   942d8:	8b 8c 24 f0 14 00 00 	mov    0x14f0(%rsp),%ecx
   942df:	03 8c 24 00 15 00 00 	add    0x1500(%rsp),%ecx
   942e6:	8b 84 24 f4 14 00 00 	mov    0x14f4(%rsp),%eax
   942ed:	03 84 24 04 15 00 00 	add    0x1504(%rsp),%eax
   942f4:	89 b4 24 d8 14 00 00 	mov    %esi,0x14d8(%rsp)
   942fb:	89 94 24 dc 14 00 00 	mov    %edx,0x14dc(%rsp)
   94302:	89 8c 24 e0 14 00 00 	mov    %ecx,0x14e0(%rsp)
   94309:	89 84 24 e4 14 00 00 	mov    %eax,0x14e4(%rsp)
   94310:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   94315:	48 89 84 24 18 16 00 	mov    %rax,0x1618(%rsp)
   9431c:	00 
   9431d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   94322:	48 89 84 24 20 16 00 	mov    %rax,0x1620(%rsp)
   94329:	00 
   9432a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   9432f:	48 89 84 24 28 16 00 	mov    %rax,0x1628(%rsp)
   94336:	00 
   94337:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   9433c:	48 89 84 24 30 16 00 	mov    %rax,0x1630(%rsp)
   94343:	00 
   94344:	48 8b 84 24 d8 14 00 	mov    0x14d8(%rsp),%rax
   9434b:	00 
   9434c:	48 89 84 24 48 20 00 	mov    %rax,0x2048(%rsp)
   94353:	00 
   94354:	48 8b 84 24 e0 14 00 	mov    0x14e0(%rsp),%rax
   9435b:	00 
   9435c:	48 89 84 24 50 20 00 	mov    %rax,0x2050(%rsp)
   94363:	00 
   94364:	48 8d bc 24 08 16 00 	lea    0x1608(%rsp),%rdi
   9436b:	00 
   9436c:	48 8d b4 24 18 16 00 	lea    0x1618(%rsp),%rsi
   94373:	00 
   94374:	48 8d 94 24 28 16 00 	lea    0x1628(%rsp),%rdx
   9437b:	00 
   9437c:	48 8d 8c 24 48 20 00 	lea    0x2048(%rsp),%rcx
   94383:	00 
   94384:	e8 57 df ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   94389:	48 8b 84 24 08 16 00 	mov    0x1608(%rsp),%rax
   94390:	00 
   94391:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   94396:	48 8b 84 24 10 16 00 	mov    0x1610(%rsp),%rax
   9439d:	00 
   9439e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   943a3:	48 8b 84 24 d8 14 00 	mov    0x14d8(%rsp),%rax
   943aa:	00 
   943ab:	48 89 84 24 58 20 00 	mov    %rax,0x2058(%rsp)
   943b2:	00 
   943b3:	48 8b 84 24 e0 14 00 	mov    0x14e0(%rsp),%rax
   943ba:	00 
   943bb:	48 89 84 24 60 20 00 	mov    %rax,0x2060(%rsp)
   943c2:	00 
   943c3:	48 8d bc 24 38 16 00 	lea    0x1638(%rsp),%rdi
   943ca:	00 
   943cb:	48 8d b4 24 58 20 00 	lea    0x2058(%rsp),%rsi
   943d2:	00 
   943d3:	e8 e8 de ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   943d8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   943dd:	48 89 84 24 58 16 00 	mov    %rax,0x1658(%rsp)
   943e4:	00 
   943e5:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   943ea:	48 89 84 24 60 16 00 	mov    %rax,0x1660(%rsp)
   943f1:	00 
   943f2:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   943f7:	48 89 84 24 68 16 00 	mov    %rax,0x1668(%rsp)
   943fe:	00 
   943ff:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   94404:	48 89 84 24 70 16 00 	mov    %rax,0x1670(%rsp)
   9440b:	00 
   9440c:	48 8b 84 24 38 16 00 	mov    0x1638(%rsp),%rax
   94413:	00 
   94414:	48 89 84 24 68 20 00 	mov    %rax,0x2068(%rsp)
   9441b:	00 
   9441c:	48 8b 84 24 40 16 00 	mov    0x1640(%rsp),%rax
   94423:	00 
   94424:	48 89 84 24 70 20 00 	mov    %rax,0x2070(%rsp)
   9442b:	00 
   9442c:	48 8d bc 24 48 16 00 	lea    0x1648(%rsp),%rdi
   94433:	00 
   94434:	48 8d b4 24 58 16 00 	lea    0x1658(%rsp),%rsi
   9443b:	00 
   9443c:	48 8d 94 24 68 16 00 	lea    0x1668(%rsp),%rdx
   94443:	00 
   94444:	48 8d 8c 24 68 20 00 	lea    0x2068(%rsp),%rcx
   9444b:	00 
   9444c:	e8 8f de ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   94451:	48 8b 84 24 48 16 00 	mov    0x1648(%rsp),%rax
   94458:	00 
   94459:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   9445e:	48 8b 84 24 50 16 00 	mov    0x1650(%rsp),%rax
   94465:	00 
   94466:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   9446b:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   94470:	48 89 84 24 88 16 00 	mov    %rax,0x1688(%rsp)
   94477:	00 
   94478:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   9447d:	48 89 84 24 90 16 00 	mov    %rax,0x1690(%rsp)
   94484:	00 
   94485:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   9448a:	48 89 84 24 98 16 00 	mov    %rax,0x1698(%rsp)
   94491:	00 
   94492:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   94497:	48 89 84 24 a0 16 00 	mov    %rax,0x16a0(%rsp)
   9449e:	00 
   9449f:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   944a4:	48 89 84 24 a8 16 00 	mov    %rax,0x16a8(%rsp)
   944ab:	00 
   944ac:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   944b1:	48 89 84 24 b0 16 00 	mov    %rax,0x16b0(%rsp)
   944b8:	00 
   944b9:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   944be:	48 89 84 24 b8 16 00 	mov    %rax,0x16b8(%rsp)
   944c5:	00 
   944c6:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   944cb:	48 89 84 24 c0 16 00 	mov    %rax,0x16c0(%rsp)
   944d2:	00 
   944d3:	48 8d bc 24 78 16 00 	lea    0x1678(%rsp),%rdi
   944da:	00 
   944db:	48 8d b4 24 88 16 00 	lea    0x1688(%rsp),%rsi
   944e2:	00 
   944e3:	48 8d 94 24 98 16 00 	lea    0x1698(%rsp),%rdx
   944ea:	00 
   944eb:	48 8d 8c 24 a8 16 00 	lea    0x16a8(%rsp),%rcx
   944f2:	00 
   944f3:	4c 8d 84 24 b8 16 00 	lea    0x16b8(%rsp),%r8
   944fa:	00 
   944fb:	e8 f0 0d 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   94500:	48 8b 84 24 78 16 00 	mov    0x1678(%rsp),%rax
   94507:	00 
   94508:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   9450d:	48 8b 84 24 80 16 00 	mov    0x1680(%rsp),%rax
   94514:	00 
   94515:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   9451a:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   9451f:	48 89 84 24 d8 16 00 	mov    %rax,0x16d8(%rsp)
   94526:	00 
   94527:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   9452c:	48 89 84 24 e0 16 00 	mov    %rax,0x16e0(%rsp)
   94533:	00 
   94534:	48 8d bc 24 f8 16 00 	lea    0x16f8(%rsp),%rdi
   9453b:	00 
   9453c:	48 8d 35 c1 28 f8 ff 	lea    -0x7d73f(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   94543:	ba 00 01 00 00       	mov    $0x100,%edx
   94548:	e8 a3 89 07 00       	call   10cef0 <memcpy@plt>
   9454d:	48 8b 84 24 b8 17 00 	mov    0x17b8(%rsp),%rax
   94554:	00 
   94555:	48 89 84 24 e8 16 00 	mov    %rax,0x16e8(%rsp)
   9455c:	00 
   9455d:	48 8b 84 24 c0 17 00 	mov    0x17c0(%rsp),%rax
   94564:	00 
   94565:	48 89 84 24 f0 16 00 	mov    %rax,0x16f0(%rsp)
   9456c:	00 
   9456d:	8b b4 24 d8 16 00 00 	mov    0x16d8(%rsp),%esi
   94574:	03 b4 24 e8 16 00 00 	add    0x16e8(%rsp),%esi
   9457b:	8b 94 24 dc 16 00 00 	mov    0x16dc(%rsp),%edx
   94582:	03 94 24 ec 16 00 00 	add    0x16ec(%rsp),%edx
   94589:	8b 8c 24 e0 16 00 00 	mov    0x16e0(%rsp),%ecx
   94590:	03 8c 24 f0 16 00 00 	add    0x16f0(%rsp),%ecx
   94597:	8b 84 24 e4 16 00 00 	mov    0x16e4(%rsp),%eax
   9459e:	03 84 24 f4 16 00 00 	add    0x16f4(%rsp),%eax
   945a5:	89 b4 24 c8 16 00 00 	mov    %esi,0x16c8(%rsp)
   945ac:	89 94 24 cc 16 00 00 	mov    %edx,0x16cc(%rsp)
   945b3:	89 8c 24 d0 16 00 00 	mov    %ecx,0x16d0(%rsp)
   945ba:	89 84 24 d4 16 00 00 	mov    %eax,0x16d4(%rsp)
   945c1:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   945c6:	48 89 84 24 08 18 00 	mov    %rax,0x1808(%rsp)
   945cd:	00 
   945ce:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   945d3:	48 89 84 24 10 18 00 	mov    %rax,0x1810(%rsp)
   945da:	00 
   945db:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   945e0:	48 89 84 24 18 18 00 	mov    %rax,0x1818(%rsp)
   945e7:	00 
   945e8:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   945ed:	48 89 84 24 20 18 00 	mov    %rax,0x1820(%rsp)
   945f4:	00 
   945f5:	48 8b 84 24 c8 16 00 	mov    0x16c8(%rsp),%rax
   945fc:	00 
   945fd:	48 89 84 24 78 20 00 	mov    %rax,0x2078(%rsp)
   94604:	00 
   94605:	48 8b 84 24 d0 16 00 	mov    0x16d0(%rsp),%rax
   9460c:	00 
   9460d:	48 89 84 24 80 20 00 	mov    %rax,0x2080(%rsp)
   94614:	00 
   94615:	48 8d bc 24 f8 17 00 	lea    0x17f8(%rsp),%rdi
   9461c:	00 
   9461d:	48 8d b4 24 08 18 00 	lea    0x1808(%rsp),%rsi
   94624:	00 
   94625:	48 8d 94 24 18 18 00 	lea    0x1818(%rsp),%rdx
   9462c:	00 
   9462d:	48 8d 8c 24 78 20 00 	lea    0x2078(%rsp),%rcx
   94634:	00 
   94635:	e8 a6 dc ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   9463a:	48 8b 84 24 f8 17 00 	mov    0x17f8(%rsp),%rax
   94641:	00 
   94642:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   94647:	48 8b 84 24 00 18 00 	mov    0x1800(%rsp),%rax
   9464e:	00 
   9464f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   94654:	48 8b 84 24 c8 16 00 	mov    0x16c8(%rsp),%rax
   9465b:	00 
   9465c:	48 89 84 24 88 20 00 	mov    %rax,0x2088(%rsp)
   94663:	00 
   94664:	48 8b 84 24 d0 16 00 	mov    0x16d0(%rsp),%rax
   9466b:	00 
   9466c:	48 89 84 24 90 20 00 	mov    %rax,0x2090(%rsp)
   94673:	00 
   94674:	48 8d bc 24 28 18 00 	lea    0x1828(%rsp),%rdi
   9467b:	00 
   9467c:	48 8d b4 24 88 20 00 	lea    0x2088(%rsp),%rsi
   94683:	00 
   94684:	e8 37 dc ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   94689:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   9468e:	48 89 84 24 48 18 00 	mov    %rax,0x1848(%rsp)
   94695:	00 
   94696:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   9469b:	48 89 84 24 50 18 00 	mov    %rax,0x1850(%rsp)
   946a2:	00 
   946a3:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   946a8:	48 89 84 24 58 18 00 	mov    %rax,0x1858(%rsp)
   946af:	00 
   946b0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   946b5:	48 89 84 24 60 18 00 	mov    %rax,0x1860(%rsp)
   946bc:	00 
   946bd:	48 8b 84 24 28 18 00 	mov    0x1828(%rsp),%rax
   946c4:	00 
   946c5:	48 89 84 24 98 20 00 	mov    %rax,0x2098(%rsp)
   946cc:	00 
   946cd:	48 8b 84 24 30 18 00 	mov    0x1830(%rsp),%rax
   946d4:	00 
   946d5:	48 89 84 24 a0 20 00 	mov    %rax,0x20a0(%rsp)
   946dc:	00 
   946dd:	48 8d bc 24 38 18 00 	lea    0x1838(%rsp),%rdi
   946e4:	00 
   946e5:	48 8d b4 24 48 18 00 	lea    0x1848(%rsp),%rsi
   946ec:	00 
   946ed:	48 8d 94 24 58 18 00 	lea    0x1858(%rsp),%rdx
   946f4:	00 
   946f5:	48 8d 8c 24 98 20 00 	lea    0x2098(%rsp),%rcx
   946fc:	00 
   946fd:	e8 de db ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   94702:	48 8b 84 24 38 18 00 	mov    0x1838(%rsp),%rax
   94709:	00 
   9470a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   9470f:	48 8b 84 24 40 18 00 	mov    0x1840(%rsp),%rax
   94716:	00 
   94717:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   9471c:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   94721:	48 89 84 24 78 18 00 	mov    %rax,0x1878(%rsp)
   94728:	00 
   94729:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   9472e:	48 89 84 24 80 18 00 	mov    %rax,0x1880(%rsp)
   94735:	00 
   94736:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   9473b:	48 89 84 24 88 18 00 	mov    %rax,0x1888(%rsp)
   94742:	00 
   94743:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   94748:	48 89 84 24 90 18 00 	mov    %rax,0x1890(%rsp)
   9474f:	00 
   94750:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   94755:	48 89 84 24 98 18 00 	mov    %rax,0x1898(%rsp)
   9475c:	00 
   9475d:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   94762:	48 89 84 24 a0 18 00 	mov    %rax,0x18a0(%rsp)
   94769:	00 
   9476a:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   9476f:	48 89 84 24 a8 18 00 	mov    %rax,0x18a8(%rsp)
   94776:	00 
   94777:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   9477c:	48 89 84 24 b0 18 00 	mov    %rax,0x18b0(%rsp)
   94783:	00 
   94784:	48 8d bc 24 68 18 00 	lea    0x1868(%rsp),%rdi
   9478b:	00 
   9478c:	48 8d b4 24 78 18 00 	lea    0x1878(%rsp),%rsi
   94793:	00 
   94794:	48 8d 94 24 88 18 00 	lea    0x1888(%rsp),%rdx
   9479b:	00 
   9479c:	48 8d 8c 24 98 18 00 	lea    0x1898(%rsp),%rcx
   947a3:	00 
   947a4:	4c 8d 84 24 a8 18 00 	lea    0x18a8(%rsp),%r8
   947ab:	00 
   947ac:	e8 3f 0b 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   947b1:	48 8b 84 24 68 18 00 	mov    0x1868(%rsp),%rax
   947b8:	00 
   947b9:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   947be:	48 8b 84 24 70 18 00 	mov    0x1870(%rsp),%rax
   947c5:	00 
   947c6:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   947cb:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   947d0:	48 89 84 24 c8 18 00 	mov    %rax,0x18c8(%rsp)
   947d7:	00 
   947d8:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   947dd:	48 89 84 24 d0 18 00 	mov    %rax,0x18d0(%rsp)
   947e4:	00 
   947e5:	48 8d bc 24 e8 18 00 	lea    0x18e8(%rsp),%rdi
   947ec:	00 
   947ed:	48 8d 35 10 26 f8 ff 	lea    -0x7d9f0(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   947f4:	ba 00 01 00 00       	mov    $0x100,%edx
   947f9:	e8 f2 86 07 00       	call   10cef0 <memcpy@plt>
   947fe:	48 8b 84 24 b8 19 00 	mov    0x19b8(%rsp),%rax
   94805:	00 
   94806:	48 89 84 24 d8 18 00 	mov    %rax,0x18d8(%rsp)
   9480d:	00 
   9480e:	48 8b 84 24 c0 19 00 	mov    0x19c0(%rsp),%rax
   94815:	00 
   94816:	48 89 84 24 e0 18 00 	mov    %rax,0x18e0(%rsp)
   9481d:	00 
   9481e:	8b b4 24 c8 18 00 00 	mov    0x18c8(%rsp),%esi
   94825:	03 b4 24 d8 18 00 00 	add    0x18d8(%rsp),%esi
   9482c:	8b 94 24 cc 18 00 00 	mov    0x18cc(%rsp),%edx
   94833:	03 94 24 dc 18 00 00 	add    0x18dc(%rsp),%edx
   9483a:	8b 8c 24 d0 18 00 00 	mov    0x18d0(%rsp),%ecx
   94841:	03 8c 24 e0 18 00 00 	add    0x18e0(%rsp),%ecx
   94848:	8b 84 24 d4 18 00 00 	mov    0x18d4(%rsp),%eax
   9484f:	03 84 24 e4 18 00 00 	add    0x18e4(%rsp),%eax
   94856:	89 b4 24 b8 18 00 00 	mov    %esi,0x18b8(%rsp)
   9485d:	89 94 24 bc 18 00 00 	mov    %edx,0x18bc(%rsp)
   94864:	89 8c 24 c0 18 00 00 	mov    %ecx,0x18c0(%rsp)
   9486b:	89 84 24 c4 18 00 00 	mov    %eax,0x18c4(%rsp)
   94872:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   94877:	48 89 84 24 f8 19 00 	mov    %rax,0x19f8(%rsp)
   9487e:	00 
   9487f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   94884:	48 89 84 24 00 1a 00 	mov    %rax,0x1a00(%rsp)
   9488b:	00 
   9488c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   94891:	48 89 84 24 08 1a 00 	mov    %rax,0x1a08(%rsp)
   94898:	00 
   94899:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   9489e:	48 89 84 24 10 1a 00 	mov    %rax,0x1a10(%rsp)
   948a5:	00 
   948a6:	48 8b 84 24 b8 18 00 	mov    0x18b8(%rsp),%rax
   948ad:	00 
   948ae:	48 89 84 24 a8 20 00 	mov    %rax,0x20a8(%rsp)
   948b5:	00 
   948b6:	48 8b 84 24 c0 18 00 	mov    0x18c0(%rsp),%rax
   948bd:	00 
   948be:	48 89 84 24 b0 20 00 	mov    %rax,0x20b0(%rsp)
   948c5:	00 
   948c6:	48 8d bc 24 e8 19 00 	lea    0x19e8(%rsp),%rdi
   948cd:	00 
   948ce:	48 8d b4 24 f8 19 00 	lea    0x19f8(%rsp),%rsi
   948d5:	00 
   948d6:	48 8d 94 24 08 1a 00 	lea    0x1a08(%rsp),%rdx
   948dd:	00 
   948de:	48 8d 8c 24 a8 20 00 	lea    0x20a8(%rsp),%rcx
   948e5:	00 
   948e6:	e8 f5 d9 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   948eb:	48 8b 84 24 e8 19 00 	mov    0x19e8(%rsp),%rax
   948f2:	00 
   948f3:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   948f8:	48 8b 84 24 f0 19 00 	mov    0x19f0(%rsp),%rax
   948ff:	00 
   94900:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   94905:	48 8b 84 24 b8 18 00 	mov    0x18b8(%rsp),%rax
   9490c:	00 
   9490d:	48 89 84 24 b8 20 00 	mov    %rax,0x20b8(%rsp)
   94914:	00 
   94915:	48 8b 84 24 c0 18 00 	mov    0x18c0(%rsp),%rax
   9491c:	00 
   9491d:	48 89 84 24 c0 20 00 	mov    %rax,0x20c0(%rsp)
   94924:	00 
   94925:	48 8d bc 24 18 1a 00 	lea    0x1a18(%rsp),%rdi
   9492c:	00 
   9492d:	48 8d b4 24 b8 20 00 	lea    0x20b8(%rsp),%rsi
   94934:	00 
   94935:	e8 86 d9 ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   9493a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   9493f:	48 89 84 24 38 1a 00 	mov    %rax,0x1a38(%rsp)
   94946:	00 
   94947:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   9494c:	48 89 84 24 40 1a 00 	mov    %rax,0x1a40(%rsp)
   94953:	00 
   94954:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   94959:	48 89 84 24 48 1a 00 	mov    %rax,0x1a48(%rsp)
   94960:	00 
   94961:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   94966:	48 89 84 24 50 1a 00 	mov    %rax,0x1a50(%rsp)
   9496d:	00 
   9496e:	48 8b 84 24 18 1a 00 	mov    0x1a18(%rsp),%rax
   94975:	00 
   94976:	48 89 84 24 c8 20 00 	mov    %rax,0x20c8(%rsp)
   9497d:	00 
   9497e:	48 8b 84 24 20 1a 00 	mov    0x1a20(%rsp),%rax
   94985:	00 
   94986:	48 89 84 24 d0 20 00 	mov    %rax,0x20d0(%rsp)
   9498d:	00 
   9498e:	48 8d bc 24 28 1a 00 	lea    0x1a28(%rsp),%rdi
   94995:	00 
   94996:	48 8d b4 24 38 1a 00 	lea    0x1a38(%rsp),%rsi
   9499d:	00 
   9499e:	48 8d 94 24 48 1a 00 	lea    0x1a48(%rsp),%rdx
   949a5:	00 
   949a6:	48 8d 8c 24 c8 20 00 	lea    0x20c8(%rsp),%rcx
   949ad:	00 
   949ae:	e8 2d d9 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   949b3:	48 8b 84 24 28 1a 00 	mov    0x1a28(%rsp),%rax
   949ba:	00 
   949bb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   949c0:	48 8b 84 24 30 1a 00 	mov    0x1a30(%rsp),%rax
   949c7:	00 
   949c8:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   949cd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   949d2:	48 89 84 24 68 1a 00 	mov    %rax,0x1a68(%rsp)
   949d9:	00 
   949da:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   949df:	48 89 84 24 70 1a 00 	mov    %rax,0x1a70(%rsp)
   949e6:	00 
   949e7:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   949ec:	48 89 84 24 78 1a 00 	mov    %rax,0x1a78(%rsp)
   949f3:	00 
   949f4:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   949f9:	48 89 84 24 80 1a 00 	mov    %rax,0x1a80(%rsp)
   94a00:	00 
   94a01:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   94a06:	48 89 84 24 88 1a 00 	mov    %rax,0x1a88(%rsp)
   94a0d:	00 
   94a0e:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   94a13:	48 89 84 24 90 1a 00 	mov    %rax,0x1a90(%rsp)
   94a1a:	00 
   94a1b:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   94a20:	48 89 84 24 98 1a 00 	mov    %rax,0x1a98(%rsp)
   94a27:	00 
   94a28:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   94a2d:	48 89 84 24 a0 1a 00 	mov    %rax,0x1aa0(%rsp)
   94a34:	00 
   94a35:	48 8d bc 24 58 1a 00 	lea    0x1a58(%rsp),%rdi
   94a3c:	00 
   94a3d:	48 8d b4 24 68 1a 00 	lea    0x1a68(%rsp),%rsi
   94a44:	00 
   94a45:	48 8d 94 24 78 1a 00 	lea    0x1a78(%rsp),%rdx
   94a4c:	00 
   94a4d:	48 8d 8c 24 88 1a 00 	lea    0x1a88(%rsp),%rcx
   94a54:	00 
   94a55:	4c 8d 84 24 98 1a 00 	lea    0x1a98(%rsp),%r8
   94a5c:	00 
   94a5d:	e8 8e 08 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   94a62:	48 8b 84 24 58 1a 00 	mov    0x1a58(%rsp),%rax
   94a69:	00 
   94a6a:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   94a6f:	48 8b 84 24 60 1a 00 	mov    0x1a60(%rsp),%rax
   94a76:	00 
   94a77:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   94a7c:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   94a81:	48 89 84 24 b8 1a 00 	mov    %rax,0x1ab8(%rsp)
   94a88:	00 
   94a89:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   94a8e:	48 89 84 24 c0 1a 00 	mov    %rax,0x1ac0(%rsp)
   94a95:	00 
   94a96:	48 8d bc 24 d8 1a 00 	lea    0x1ad8(%rsp),%rdi
   94a9d:	00 
   94a9e:	48 8d 35 5f 23 f8 ff 	lea    -0x7dca1(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   94aa5:	ba 00 01 00 00       	mov    $0x100,%edx
   94aaa:	e8 41 84 07 00       	call   10cef0 <memcpy@plt>
   94aaf:	48 8b 84 24 b8 1b 00 	mov    0x1bb8(%rsp),%rax
   94ab6:	00 
   94ab7:	48 89 84 24 c8 1a 00 	mov    %rax,0x1ac8(%rsp)
   94abe:	00 
   94abf:	48 8b 84 24 c0 1b 00 	mov    0x1bc0(%rsp),%rax
   94ac6:	00 
   94ac7:	48 89 84 24 d0 1a 00 	mov    %rax,0x1ad0(%rsp)
   94ace:	00 
   94acf:	8b b4 24 b8 1a 00 00 	mov    0x1ab8(%rsp),%esi
   94ad6:	03 b4 24 c8 1a 00 00 	add    0x1ac8(%rsp),%esi
   94add:	8b 94 24 bc 1a 00 00 	mov    0x1abc(%rsp),%edx
   94ae4:	03 94 24 cc 1a 00 00 	add    0x1acc(%rsp),%edx
   94aeb:	8b 8c 24 c0 1a 00 00 	mov    0x1ac0(%rsp),%ecx
   94af2:	03 8c 24 d0 1a 00 00 	add    0x1ad0(%rsp),%ecx
   94af9:	8b 84 24 c4 1a 00 00 	mov    0x1ac4(%rsp),%eax
   94b00:	03 84 24 d4 1a 00 00 	add    0x1ad4(%rsp),%eax
   94b07:	89 b4 24 a8 1a 00 00 	mov    %esi,0x1aa8(%rsp)
   94b0e:	89 94 24 ac 1a 00 00 	mov    %edx,0x1aac(%rsp)
   94b15:	89 8c 24 b0 1a 00 00 	mov    %ecx,0x1ab0(%rsp)
   94b1c:	89 84 24 b4 1a 00 00 	mov    %eax,0x1ab4(%rsp)
   94b23:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   94b28:	48 89 84 24 e8 1b 00 	mov    %rax,0x1be8(%rsp)
   94b2f:	00 
   94b30:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   94b35:	48 89 84 24 f0 1b 00 	mov    %rax,0x1bf0(%rsp)
   94b3c:	00 
   94b3d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   94b42:	48 89 84 24 f8 1b 00 	mov    %rax,0x1bf8(%rsp)
   94b49:	00 
   94b4a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   94b4f:	48 89 84 24 00 1c 00 	mov    %rax,0x1c00(%rsp)
   94b56:	00 
   94b57:	48 8b 84 24 a8 1a 00 	mov    0x1aa8(%rsp),%rax
   94b5e:	00 
   94b5f:	48 89 84 24 d8 20 00 	mov    %rax,0x20d8(%rsp)
   94b66:	00 
   94b67:	48 8b 84 24 b0 1a 00 	mov    0x1ab0(%rsp),%rax
   94b6e:	00 
   94b6f:	48 89 84 24 e0 20 00 	mov    %rax,0x20e0(%rsp)
   94b76:	00 
   94b77:	48 8d bc 24 d8 1b 00 	lea    0x1bd8(%rsp),%rdi
   94b7e:	00 
   94b7f:	48 8d b4 24 e8 1b 00 	lea    0x1be8(%rsp),%rsi
   94b86:	00 
   94b87:	48 8d 94 24 f8 1b 00 	lea    0x1bf8(%rsp),%rdx
   94b8e:	00 
   94b8f:	48 8d 8c 24 d8 20 00 	lea    0x20d8(%rsp),%rcx
   94b96:	00 
   94b97:	e8 44 d7 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   94b9c:	48 8b 84 24 d8 1b 00 	mov    0x1bd8(%rsp),%rax
   94ba3:	00 
   94ba4:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   94ba9:	48 8b 84 24 e0 1b 00 	mov    0x1be0(%rsp),%rax
   94bb0:	00 
   94bb1:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   94bb6:	48 8b 84 24 a8 1a 00 	mov    0x1aa8(%rsp),%rax
   94bbd:	00 
   94bbe:	48 89 84 24 e8 20 00 	mov    %rax,0x20e8(%rsp)
   94bc5:	00 
   94bc6:	48 8b 84 24 b0 1a 00 	mov    0x1ab0(%rsp),%rax
   94bcd:	00 
   94bce:	48 89 84 24 f0 20 00 	mov    %rax,0x20f0(%rsp)
   94bd5:	00 
   94bd6:	48 8d bc 24 08 1c 00 	lea    0x1c08(%rsp),%rdi
   94bdd:	00 
   94bde:	48 8d b4 24 e8 20 00 	lea    0x20e8(%rsp),%rsi
   94be5:	00 
   94be6:	e8 d5 d6 ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   94beb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   94bf0:	48 89 84 24 28 1c 00 	mov    %rax,0x1c28(%rsp)
   94bf7:	00 
   94bf8:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   94bfd:	48 89 84 24 30 1c 00 	mov    %rax,0x1c30(%rsp)
   94c04:	00 
   94c05:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   94c0a:	48 89 84 24 38 1c 00 	mov    %rax,0x1c38(%rsp)
   94c11:	00 
   94c12:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   94c17:	48 89 84 24 40 1c 00 	mov    %rax,0x1c40(%rsp)
   94c1e:	00 
   94c1f:	48 8b 84 24 08 1c 00 	mov    0x1c08(%rsp),%rax
   94c26:	00 
   94c27:	48 89 84 24 f8 20 00 	mov    %rax,0x20f8(%rsp)
   94c2e:	00 
   94c2f:	48 8b 84 24 10 1c 00 	mov    0x1c10(%rsp),%rax
   94c36:	00 
   94c37:	48 89 84 24 00 21 00 	mov    %rax,0x2100(%rsp)
   94c3e:	00 
   94c3f:	48 8d bc 24 18 1c 00 	lea    0x1c18(%rsp),%rdi
   94c46:	00 
   94c47:	48 8d b4 24 28 1c 00 	lea    0x1c28(%rsp),%rsi
   94c4e:	00 
   94c4f:	48 8d 94 24 38 1c 00 	lea    0x1c38(%rsp),%rdx
   94c56:	00 
   94c57:	48 8d 8c 24 f8 20 00 	lea    0x20f8(%rsp),%rcx
   94c5e:	00 
   94c5f:	e8 7c d6 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   94c64:	48 8b 84 24 18 1c 00 	mov    0x1c18(%rsp),%rax
   94c6b:	00 
   94c6c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   94c71:	48 8b 84 24 20 1c 00 	mov    0x1c20(%rsp),%rax
   94c78:	00 
   94c79:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   94c7e:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   94c83:	48 89 84 24 58 1c 00 	mov    %rax,0x1c58(%rsp)
   94c8a:	00 
   94c8b:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   94c90:	48 89 84 24 60 1c 00 	mov    %rax,0x1c60(%rsp)
   94c97:	00 
   94c98:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   94c9d:	48 89 84 24 68 1c 00 	mov    %rax,0x1c68(%rsp)
   94ca4:	00 
   94ca5:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   94caa:	48 89 84 24 70 1c 00 	mov    %rax,0x1c70(%rsp)
   94cb1:	00 
   94cb2:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   94cb7:	48 89 84 24 78 1c 00 	mov    %rax,0x1c78(%rsp)
   94cbe:	00 
   94cbf:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   94cc4:	48 89 84 24 80 1c 00 	mov    %rax,0x1c80(%rsp)
   94ccb:	00 
   94ccc:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   94cd1:	48 89 84 24 88 1c 00 	mov    %rax,0x1c88(%rsp)
   94cd8:	00 
   94cd9:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   94cde:	48 89 84 24 90 1c 00 	mov    %rax,0x1c90(%rsp)
   94ce5:	00 
   94ce6:	48 8d bc 24 48 1c 00 	lea    0x1c48(%rsp),%rdi
   94ced:	00 
   94cee:	48 8d b4 24 58 1c 00 	lea    0x1c58(%rsp),%rsi
   94cf5:	00 
   94cf6:	48 8d 94 24 68 1c 00 	lea    0x1c68(%rsp),%rdx
   94cfd:	00 
   94cfe:	48 8d 8c 24 78 1c 00 	lea    0x1c78(%rsp),%rcx
   94d05:	00 
   94d06:	4c 8d 84 24 88 1c 00 	lea    0x1c88(%rsp),%r8
   94d0d:	00 
   94d0e:	e8 dd 05 00 00       	call   952f0 <sha2::sha256::soft::schedule>
   94d13:	48 8b 84 24 48 1c 00 	mov    0x1c48(%rsp),%rax
   94d1a:	00 
   94d1b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   94d20:	48 8b 84 24 50 1c 00 	mov    0x1c50(%rsp),%rax
   94d27:	00 
   94d28:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   94d2d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   94d32:	48 89 84 24 a8 1c 00 	mov    %rax,0x1ca8(%rsp)
   94d39:	00 
   94d3a:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   94d3f:	48 89 84 24 b0 1c 00 	mov    %rax,0x1cb0(%rsp)
   94d46:	00 
   94d47:	48 8d bc 24 c8 1c 00 	lea    0x1cc8(%rsp),%rdi
   94d4e:	00 
   94d4f:	48 8d 35 ae 20 f8 ff 	lea    -0x7df52(%rip),%rsi        # 16e04 <__abi_tag+0x16b08>
   94d56:	ba 00 01 00 00       	mov    $0x100,%edx
   94d5b:	e8 90 81 07 00       	call   10cef0 <memcpy@plt>
   94d60:	48 8b 84 24 b8 1d 00 	mov    0x1db8(%rsp),%rax
   94d67:	00 
   94d68:	48 89 84 24 b8 1c 00 	mov    %rax,0x1cb8(%rsp)
   94d6f:	00 
   94d70:	48 8b 84 24 c0 1d 00 	mov    0x1dc0(%rsp),%rax
   94d77:	00 
   94d78:	48 89 84 24 c0 1c 00 	mov    %rax,0x1cc0(%rsp)
   94d7f:	00 
   94d80:	8b b4 24 a8 1c 00 00 	mov    0x1ca8(%rsp),%esi
   94d87:	03 b4 24 b8 1c 00 00 	add    0x1cb8(%rsp),%esi
   94d8e:	8b 94 24 ac 1c 00 00 	mov    0x1cac(%rsp),%edx
   94d95:	03 94 24 bc 1c 00 00 	add    0x1cbc(%rsp),%edx
   94d9c:	8b 8c 24 b0 1c 00 00 	mov    0x1cb0(%rsp),%ecx
   94da3:	03 8c 24 c0 1c 00 00 	add    0x1cc0(%rsp),%ecx
   94daa:	8b 84 24 b4 1c 00 00 	mov    0x1cb4(%rsp),%eax
   94db1:	03 84 24 c4 1c 00 00 	add    0x1cc4(%rsp),%eax
   94db8:	89 b4 24 98 1c 00 00 	mov    %esi,0x1c98(%rsp)
   94dbf:	89 94 24 9c 1c 00 00 	mov    %edx,0x1c9c(%rsp)
   94dc6:	89 8c 24 a0 1c 00 00 	mov    %ecx,0x1ca0(%rsp)
   94dcd:	89 84 24 a4 1c 00 00 	mov    %eax,0x1ca4(%rsp)
   94dd4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   94dd9:	48 89 84 24 d8 1d 00 	mov    %rax,0x1dd8(%rsp)
   94de0:	00 
   94de1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   94de6:	48 89 84 24 e0 1d 00 	mov    %rax,0x1de0(%rsp)
   94ded:	00 
   94dee:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   94df3:	48 89 84 24 e8 1d 00 	mov    %rax,0x1de8(%rsp)
   94dfa:	00 
   94dfb:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   94e00:	48 89 84 24 f0 1d 00 	mov    %rax,0x1df0(%rsp)
   94e07:	00 
   94e08:	48 8b 84 24 98 1c 00 	mov    0x1c98(%rsp),%rax
   94e0f:	00 
   94e10:	48 89 84 24 08 21 00 	mov    %rax,0x2108(%rsp)
   94e17:	00 
   94e18:	48 8b 84 24 a0 1c 00 	mov    0x1ca0(%rsp),%rax
   94e1f:	00 
   94e20:	48 89 84 24 10 21 00 	mov    %rax,0x2110(%rsp)
   94e27:	00 
   94e28:	48 8d bc 24 c8 1d 00 	lea    0x1dc8(%rsp),%rdi
   94e2f:	00 
   94e30:	48 8d b4 24 d8 1d 00 	lea    0x1dd8(%rsp),%rsi
   94e37:	00 
   94e38:	48 8d 94 24 e8 1d 00 	lea    0x1de8(%rsp),%rdx
   94e3f:	00 
   94e40:	48 8d 8c 24 08 21 00 	lea    0x2108(%rsp),%rcx
   94e47:	00 
   94e48:	e8 93 d4 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   94e4d:	48 8b 84 24 c8 1d 00 	mov    0x1dc8(%rsp),%rax
   94e54:	00 
   94e55:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   94e5a:	48 8b 84 24 d0 1d 00 	mov    0x1dd0(%rsp),%rax
   94e61:	00 
   94e62:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   94e67:	48 8b 84 24 98 1c 00 	mov    0x1c98(%rsp),%rax
   94e6e:	00 
   94e6f:	48 89 84 24 18 21 00 	mov    %rax,0x2118(%rsp)
   94e76:	00 
   94e77:	48 8b 84 24 a0 1c 00 	mov    0x1ca0(%rsp),%rax
   94e7e:	00 
   94e7f:	48 89 84 24 20 21 00 	mov    %rax,0x2120(%rsp)
   94e86:	00 
   94e87:	48 8d bc 24 f8 1d 00 	lea    0x1df8(%rsp),%rdi
   94e8e:	00 
   94e8f:	48 8d b4 24 18 21 00 	lea    0x2118(%rsp),%rsi
   94e96:	00 
   94e97:	e8 24 d4 ff ff       	call   922c0 <sha2::sha256::soft::sha256swap>
   94e9c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   94ea1:	48 89 84 24 18 1e 00 	mov    %rax,0x1e18(%rsp)
   94ea8:	00 
   94ea9:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   94eae:	48 89 84 24 20 1e 00 	mov    %rax,0x1e20(%rsp)
   94eb5:	00 
   94eb6:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   94ebb:	48 89 84 24 28 1e 00 	mov    %rax,0x1e28(%rsp)
   94ec2:	00 
   94ec3:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   94ec8:	48 89 84 24 30 1e 00 	mov    %rax,0x1e30(%rsp)
   94ecf:	00 
   94ed0:	48 8b 84 24 f8 1d 00 	mov    0x1df8(%rsp),%rax
   94ed7:	00 
   94ed8:	48 89 84 24 28 21 00 	mov    %rax,0x2128(%rsp)
   94edf:	00 
   94ee0:	48 8b 84 24 00 1e 00 	mov    0x1e00(%rsp),%rax
   94ee7:	00 
   94ee8:	48 89 84 24 30 21 00 	mov    %rax,0x2130(%rsp)
   94eef:	00 
   94ef0:	48 8d bc 24 08 1e 00 	lea    0x1e08(%rsp),%rdi
   94ef7:	00 
   94ef8:	48 8d b4 24 18 1e 00 	lea    0x1e18(%rsp),%rsi
   94eff:	00 
   94f00:	48 8d 94 24 28 1e 00 	lea    0x1e28(%rsp),%rdx
   94f07:	00 
   94f08:	48 8d 8c 24 28 21 00 	lea    0x2128(%rsp),%rcx
   94f0f:	00 
   94f10:	e8 cb d3 ff ff       	call   922e0 <sha2::sha256::soft::sha256_digest_round_x2>
   94f15:	48 8b 3c 24          	mov    (%rsp),%rdi
   94f19:	48 8b 84 24 08 1e 00 	mov    0x1e08(%rsp),%rax
   94f20:	00 
   94f21:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   94f26:	48 8b 84 24 10 1e 00 	mov    0x1e10(%rsp),%rax
   94f2d:	00 
   94f2e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   94f33:	44 8b 5c 24 08       	mov    0x8(%rsp),%r11d
   94f38:	44 8b 54 24 0c       	mov    0xc(%rsp),%r10d
   94f3d:	8b 74 24 10          	mov    0x10(%rsp),%esi
   94f41:	8b 54 24 14          	mov    0x14(%rsp),%edx
   94f45:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
   94f4a:	44 8b 44 24 1c       	mov    0x1c(%rsp),%r8d
   94f4f:	8b 4c 24 20          	mov    0x20(%rsp),%ecx
   94f53:	8b 44 24 24          	mov    0x24(%rsp),%eax
   94f57:	44 03 1f             	add    (%rdi),%r11d
   94f5a:	44 89 1f             	mov    %r11d,(%rdi)
   94f5d:	44 03 57 04          	add    0x4(%rdi),%r10d
   94f61:	44 89 57 04          	mov    %r10d,0x4(%rdi)
   94f65:	44 03 4f 08          	add    0x8(%rdi),%r9d
   94f69:	44 89 4f 08          	mov    %r9d,0x8(%rdi)
   94f6d:	44 03 47 0c          	add    0xc(%rdi),%r8d
   94f71:	44 89 47 0c          	mov    %r8d,0xc(%rdi)
   94f75:	03 77 10             	add    0x10(%rdi),%esi
   94f78:	89 77 10             	mov    %esi,0x10(%rdi)
   94f7b:	03 57 14             	add    0x14(%rdi),%edx
   94f7e:	89 57 14             	mov    %edx,0x14(%rdi)
   94f81:	03 4f 18             	add    0x18(%rdi),%ecx
   94f84:	89 4f 18             	mov    %ecx,0x18(%rdi)
   94f87:	03 47 1c             	add    0x1c(%rdi),%eax
   94f8a:	89 47 1c             	mov    %eax,0x1c(%rdi)
   94f8d:	48 81 c4 38 21 00 00 	add    $0x2138,%rsp
   94f94:	c3                   	ret
   94f95:	cc                   	int3
   94f96:	cc                   	int3
   94f97:	cc                   	int3
   94f98:	cc                   	int3
   94f99:	cc                   	int3
   94f9a:	cc                   	int3
   94f9b:	cc                   	int3
   94f9c:	cc                   	int3
   94f9d:	cc                   	int3
   94f9e:	cc                   	int3
   94f9f:	cc                   	int3

0000000000094fa0 <sha2::sha256::soft::compress>:
   94fa0:	48 81 ec 28 02 00 00 	sub    $0x228,%rsp
   94fa7:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
   94fac:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
   94fb1:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   94fb6:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
   94fbb:	31 f6                	xor    %esi,%esi
   94fbd:	ba 40 00 00 00       	mov    $0x40,%edx
   94fc2:	e8 49 7f 07 00       	call   10cf10 <memset@plt>
   94fc7:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   94fcc:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
   94fd1:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   94fd6:	48 8b 08             	mov    (%rax),%rcx
   94fd9:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   94fde:	48 8b 48 08          	mov    0x8(%rax),%rcx
   94fe2:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
   94fe9:	00 
   94fea:	48 8b 48 10          	mov    0x10(%rax),%rcx
   94fee:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
   94ff5:	00 
   94ff6:	48 8b 40 18          	mov    0x18(%rax),%rax
   94ffa:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   95001:	00 
   95002:	ff 15 f0 26 08 00    	call   *0x826f0(%rip)        # 1176f8 <_DYNAMIC+0xb58>
   95008:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
   9500f:	00 
   95010:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
   95017:	00 
   95018:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   9501f:	00 
   95020:	ff 15 da 26 08 00    	call   *0x826da(%rip)        # 117700 <_DYNAMIC+0xb60>
   95026:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   9502d:	00 
   9502e:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
   95035:	00 
   95036:	b8 01 00 00 00       	mov    $0x1,%eax
   9503b:	31 c9                	xor    %ecx,%ecx
   9503d:	48 83 fa 00          	cmp    $0x0,%rdx
   95041:	48 0f 44 c1          	cmove  %rcx,%rax
   95045:	48 a9 01 00 00 00    	test   $0x1,%rax
   9504b:	0f 84 9d 00 00 00    	je     950ee <sha2::sha256::soft::compress+0x14e>
   95051:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   95058:	00 
   95059:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   9505e:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
   95063:	be 10 00 00 00       	mov    $0x10,%esi
   95068:	ff 15 7a 26 08 00    	call   *0x8267a(%rip)        # 1176e8 <_DYNAMIC+0xb48>
   9506e:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   95073:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   95078:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   9507d:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
   95084:	00 
   95085:	ba 40 00 00 00       	mov    $0x40,%edx
   9508a:	b9 04 00 00 00       	mov    $0x4,%ecx
   9508f:	4c 8d 05 da c3 07 00 	lea    0x7c3da(%rip),%r8        # 111470 <__frame_dummy_init_array_entry+0x3510>
   95096:	ff 15 3c 26 08 00    	call   *0x8263c(%rip)        # 1176d8 <_DYNAMIC+0xb38>
   9509c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   950a1:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   950a6:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
   950ad:	00 
   950ae:	48 8d 8c 24 40 01 00 	lea    0x140(%rsp),%rcx
   950b5:	00 
   950b6:	ff 15 04 26 08 00    	call   *0x82604(%rip)        # 1176c0 <_DYNAMIC+0xb20>
   950bc:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   950c3:	00 
   950c4:	48 8d b4 24 f8 00 00 	lea    0xf8(%rsp),%rsi
   950cb:	00 
   950cc:	ff 15 36 26 08 00    	call   *0x82636(%rip)        # 117708 <_DYNAMIC+0xb68>
   950d2:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   950d9:	00 
   950da:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
   950e1:	00 
   950e2:	ba 48 00 00 00       	mov    $0x48,%edx
   950e7:	e8 04 7e 07 00       	call   10cef0 <memcpy@plt>
   950ec:	eb 79                	jmp    95167 <sha2::sha256::soft::compress+0x1c7>
   950ee:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   950f3:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
   950f8:	48 89 8c 24 d8 01 00 	mov    %rcx,0x1d8(%rsp)
   950ff:	00 
   95100:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
   95107:	00 
   95108:	48 89 8c 24 e0 01 00 	mov    %rcx,0x1e0(%rsp)
   9510f:	00 
   95110:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   95117:	00 
   95118:	48 89 8c 24 e8 01 00 	mov    %rcx,0x1e8(%rsp)
   9511f:	00 
   95120:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
   95127:	00 
   95128:	48 89 8c 24 f0 01 00 	mov    %rcx,0x1f0(%rsp)
   9512f:	00 
   95130:	48 8b 8c 24 d8 01 00 	mov    0x1d8(%rsp),%rcx
   95137:	00 
   95138:	48 89 08             	mov    %rcx,(%rax)
   9513b:	48 8b 8c 24 e0 01 00 	mov    0x1e0(%rsp),%rcx
   95142:	00 
   95143:	48 89 48 08          	mov    %rcx,0x8(%rax)
   95147:	48 8b 8c 24 e8 01 00 	mov    0x1e8(%rsp),%rcx
   9514e:	00 
   9514f:	48 89 48 10          	mov    %rcx,0x10(%rax)
   95153:	48 8b 8c 24 f0 01 00 	mov    0x1f0(%rsp),%rcx
   9515a:	00 
   9515b:	48 89 48 18          	mov    %rcx,0x18(%rax)
   9515f:	48 81 c4 28 02 00 00 	add    $0x228,%rsp
   95166:	c3                   	ret
   95167:	48 8d bc 24 b0 01 00 	lea    0x1b0(%rsp),%rdi
   9516e:	00 
   9516f:	48 8d b4 24 68 01 00 	lea    0x168(%rsp),%rsi
   95176:	00 
   95177:	ff 15 93 25 08 00    	call   *0x82593(%rip)        # 117710 <_DYNAMIC+0xb70>
   9517d:	48 8b 94 24 b0 01 00 	mov    0x1b0(%rsp),%rdx
   95184:	00 
   95185:	b8 01 00 00 00       	mov    $0x1,%eax
   9518a:	31 c9                	xor    %ecx,%ecx
   9518c:	48 83 fa 00          	cmp    $0x0,%rdx
   95190:	48 0f 44 c1          	cmove  %rcx,%rax
   95194:	48 a9 01 00 00 00    	test   $0x1,%rax
   9519a:	0f 84 2f 01 00 00    	je     952cf <sha2::sha256::soft::compress+0x32f>
   951a0:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
   951a7:	00 
   951a8:	48 89 04 24          	mov    %rax,(%rsp)
   951ac:	48 8b bc 24 b8 01 00 	mov    0x1b8(%rsp),%rdi
   951b3:	00 
   951b4:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   951bb:	00 
   951bc:	48 8b 05 55 25 08 00 	mov    0x82555(%rip),%rax        # 117718 <_DYNAMIC+0xb78>
   951c3:	ff d0                	call   *%rax
   951c5:	89 c1                	mov    %eax,%ecx
   951c7:	89 8c 24 f8 01 00 00 	mov    %ecx,0x1f8(%rsp)
   951ce:	48 c1 e8 20          	shr    $0x20,%rax
   951d2:	88 84 24 fc 01 00 00 	mov    %al,0x1fc(%rsp)
   951d9:	8a 84 24 fc 01 00 00 	mov    0x1fc(%rsp),%al
   951e0:	88 84 24 d4 01 00 00 	mov    %al,0x1d4(%rsp)
   951e7:	8b 84 24 f8 01 00 00 	mov    0x1f8(%rsp),%eax
   951ee:	89 84 24 d0 01 00 00 	mov    %eax,0x1d0(%rsp)
   951f5:	8a 84 24 d4 01 00 00 	mov    0x1d4(%rsp),%al
   951fc:	88 84 24 04 02 00 00 	mov    %al,0x204(%rsp)
   95203:	8b 84 24 d0 01 00 00 	mov    0x1d0(%rsp),%eax
   9520a:	89 84 24 00 02 00 00 	mov    %eax,0x200(%rsp)
   95211:	8b 84 24 00 02 00 00 	mov    0x200(%rsp),%eax
   95218:	8a 8c 24 04 02 00 00 	mov    0x204(%rsp),%cl
   9521f:	88 8c 24 1c 02 00 00 	mov    %cl,0x21c(%rsp)
   95226:	89 84 24 18 02 00 00 	mov    %eax,0x218(%rsp)
   9522d:	8b 84 24 18 02 00 00 	mov    0x218(%rsp),%eax
   95234:	89 84 24 13 02 00 00 	mov    %eax,0x213(%rsp)
   9523b:	8a 84 24 1c 02 00 00 	mov    0x21c(%rsp),%al
   95242:	88 84 24 17 02 00 00 	mov    %al,0x217(%rsp)
   95249:	8a 84 24 13 02 00 00 	mov    0x213(%rsp),%al
   95250:	a8 01                	test   $0x1,%al
   95252:	75 02                	jne    95256 <sha2::sha256::soft::compress+0x2b6>
   95254:	eb 28                	jmp    9527e <sha2::sha256::soft::compress+0x2de>
   95256:	48 8d 3d 79 1b f8 ff 	lea    -0x7e487(%rip),%rdi        # 16dd6 <__abi_tag+0x16ada>
   9525d:	be 2b 00 00 00       	mov    $0x2b,%esi
   95262:	48 8d 94 24 27 02 00 	lea    0x227(%rsp),%rdx
   95269:	00 
   9526a:	48 8d 0d c7 c1 07 00 	lea    0x7c1c7(%rip),%rcx        # 111438 <__frame_dummy_init_array_entry+0x34d8>
   95271:	4c 8d 05 10 c2 07 00 	lea    0x7c210(%rip),%r8        # 111488 <__frame_dummy_init_array_entry+0x3528>
   95278:	ff 15 22 1d 08 00    	call   *0x81d22(%rip)        # 116fa0 <_DYNAMIC+0x400>
   9527e:	8b 84 24 14 02 00 00 	mov    0x214(%rsp),%eax
   95285:	89 84 24 23 02 00 00 	mov    %eax,0x223(%rsp)
   9528c:	8b 84 24 23 02 00 00 	mov    0x223(%rsp),%eax
   95293:	89 84 24 08 02 00 00 	mov    %eax,0x208(%rsp)
   9529a:	8b 84 24 08 02 00 00 	mov    0x208(%rsp),%eax
   952a1:	89 84 24 cc 01 00 00 	mov    %eax,0x1cc(%rsp)
   952a8:	8b 84 24 cc 01 00 00 	mov    0x1cc(%rsp),%eax
   952af:	89 84 24 0c 02 00 00 	mov    %eax,0x20c(%rsp)
   952b6:	8b bc 24 0c 02 00 00 	mov    0x20c(%rsp),%edi
   952bd:	e8 4e cd ff ff       	call   92010 <<u32>::from_be_bytes>
   952c2:	89 c1                	mov    %eax,%ecx
   952c4:	48 8b 04 24          	mov    (%rsp),%rax
   952c8:	89 08                	mov    %ecx,(%rax)
   952ca:	e9 98 fe ff ff       	jmp    95167 <sha2::sha256::soft::compress+0x1c7>
   952cf:	48 8d 7c 24 78       	lea    0x78(%rsp),%rdi
   952d4:	48 8d 74 24 38       	lea    0x38(%rsp),%rsi
   952d9:	e8 32 d3 ff ff       	call   92610 <sha2::sha256::soft::sha256_digest_block_u32>
   952de:	e9 35 fd ff ff       	jmp    95018 <sha2::sha256::soft::compress+0x78>
   952e3:	cc                   	int3
   952e4:	cc                   	int3
   952e5:	cc                   	int3
   952e6:	cc                   	int3
   952e7:	cc                   	int3
   952e8:	cc                   	int3
   952e9:	cc                   	int3
   952ea:	cc                   	int3
   952eb:	cc                   	int3
   952ec:	cc                   	int3
   952ed:	cc                   	int3
   952ee:	cc                   	int3
   952ef:	cc                   	int3

00000000000952f0 <sha2::sha256::soft::schedule>:
   952f0:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
   952f7:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
   952fc:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
   95301:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
   95306:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
   9530b:	48 8b 06             	mov    (%rsi),%rax
   9530e:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   95313:	48 8b 46 08          	mov    0x8(%rsi),%rax
   95317:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   9531c:	48 8b 02             	mov    (%rdx),%rax
   9531f:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   95324:	48 8b 42 08          	mov    0x8(%rdx),%rax
   95328:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   9532d:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
   95332:	48 8d 74 24 58       	lea    0x58(%rsp),%rsi
   95337:	48 8d 54 24 68       	lea    0x68(%rsp),%rdx
   9533c:	e8 7f cd ff ff       	call   920c0 <sha2::sha256::soft::sha256msg1>
   95341:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   95346:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
   9534b:	48 8b 01             	mov    (%rcx),%rax
   9534e:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   95353:	48 8b 41 08          	mov    0x8(%rcx),%rax
   95357:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   9535e:	00 
   9535f:	49 8b 00             	mov    (%r8),%rax
   95362:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   95369:	00 
   9536a:	49 8b 40 08          	mov    0x8(%r8),%rax
   9536e:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   95375:	00 
   95376:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
   9537b:	48 8d 74 24 78       	lea    0x78(%rsp),%rsi
   95380:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   95387:	00 
   95388:	e8 13 cd ff ff       	call   920a0 <sha2::sha256::soft::sha256load>
   9538d:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
   95392:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   95397:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   9539c:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
   953a3:	00 
   953a4:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   953a9:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   953b0:	00 
   953b1:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   953b6:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   953bd:	00 
   953be:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   953c3:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   953ca:	00 
   953cb:	8b b4 24 98 00 00 00 	mov    0x98(%rsp),%esi
   953d2:	03 b4 24 a8 00 00 00 	add    0xa8(%rsp),%esi
   953d9:	8b 94 24 9c 00 00 00 	mov    0x9c(%rsp),%edx
   953e0:	03 94 24 ac 00 00 00 	add    0xac(%rsp),%edx
   953e7:	8b 8c 24 a0 00 00 00 	mov    0xa0(%rsp),%ecx
   953ee:	03 8c 24 b0 00 00 00 	add    0xb0(%rsp),%ecx
   953f5:	8b 84 24 a4 00 00 00 	mov    0xa4(%rsp),%eax
   953fc:	03 84 24 b4 00 00 00 	add    0xb4(%rsp),%eax
   95403:	89 74 24 48          	mov    %esi,0x48(%rsp)
   95407:	89 54 24 4c          	mov    %edx,0x4c(%rsp)
   9540b:	89 4c 24 50          	mov    %ecx,0x50(%rsp)
   9540f:	89 44 24 54          	mov    %eax,0x54(%rsp)
   95413:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   95418:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   9541f:	00 
   95420:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   95425:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   9542c:	00 
   9542d:	49 8b 00             	mov    (%r8),%rax
   95430:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
   95437:	00 
   95438:	49 8b 40 08          	mov    0x8(%r8),%rax
   9543c:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   95443:	00 
   95444:	48 8d b4 24 b8 00 00 	lea    0xb8(%rsp),%rsi
   9544b:	00 
   9544c:	48 8d 94 24 c8 00 00 	lea    0xc8(%rsp),%rdx
   95453:	00 
   95454:	e8 17 cd ff ff       	call   92170 <sha2::sha256::soft::sha256msg2>
   95459:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   9545e:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
   95465:	c3                   	ret
   95466:	cc                   	int3
   95467:	cc                   	int3
   95468:	cc                   	int3
   95469:	cc                   	int3
   9546a:	cc                   	int3
   9546b:	cc                   	int3
   9546c:	cc                   	int3
   9546d:	cc                   	int3
   9546e:	cc                   	int3
   9546f:	cc                   	int3

0000000000095560 <sha2::sha256::soft::sha256msg1::sigma0x4>:
   95560:	48 81 ec 80 00 00 00 	sub    $0x80,%rsp
   95567:	48 89 f8             	mov    %rdi,%rax
   9556a:	48 8b 0e             	mov    (%rsi),%rcx
   9556d:	48 89 0c 24          	mov    %rcx,(%rsp)
   95571:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   95575:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
   9557a:	44 8b 0c 24          	mov    (%rsp),%r9d
   9557e:	41 c1 e9 07          	shr    $0x7,%r9d
   95582:	44 8b 44 24 04       	mov    0x4(%rsp),%r8d
   95587:	41 c1 e8 07          	shr    $0x7,%r8d
   9558b:	8b 54 24 08          	mov    0x8(%rsp),%edx
   9558f:	c1 ea 07             	shr    $0x7,%edx
   95592:	8b 4c 24 0c          	mov    0xc(%rsp),%ecx
   95596:	c1 e9 07             	shr    $0x7,%ecx
   95599:	44 89 4c 24 90       	mov    %r9d,-0x70(%rsp)
   9559e:	44 89 44 24 94       	mov    %r8d,-0x6c(%rsp)
   955a3:	89 54 24 98          	mov    %edx,-0x68(%rsp)
   955a7:	89 4c 24 9c          	mov    %ecx,-0x64(%rsp)
   955ab:	48 8b 0e             	mov    (%rsi),%rcx
   955ae:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   955b3:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   955b7:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
   955bc:	44 8b 4c 24 10       	mov    0x10(%rsp),%r9d
   955c1:	41 c1 e1 19          	shl    $0x19,%r9d
   955c5:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
   955ca:	41 c1 e0 19          	shl    $0x19,%r8d
   955ce:	8b 54 24 18          	mov    0x18(%rsp),%edx
   955d2:	c1 e2 19             	shl    $0x19,%edx
   955d5:	8b 4c 24 1c          	mov    0x1c(%rsp),%ecx
   955d9:	c1 e1 19             	shl    $0x19,%ecx
   955dc:	44 89 4c 24 a0       	mov    %r9d,-0x60(%rsp)
   955e1:	44 89 44 24 a4       	mov    %r8d,-0x5c(%rsp)
   955e6:	89 54 24 a8          	mov    %edx,-0x58(%rsp)
   955ea:	89 4c 24 ac          	mov    %ecx,-0x54(%rsp)
   955ee:	44 8b 4c 24 90       	mov    -0x70(%rsp),%r9d
   955f3:	44 0b 4c 24 a0       	or     -0x60(%rsp),%r9d
   955f8:	44 8b 44 24 94       	mov    -0x6c(%rsp),%r8d
   955fd:	44 0b 44 24 a4       	or     -0x5c(%rsp),%r8d
   95602:	8b 54 24 98          	mov    -0x68(%rsp),%edx
   95606:	0b 54 24 a8          	or     -0x58(%rsp),%edx
   9560a:	8b 4c 24 9c          	mov    -0x64(%rsp),%ecx
   9560e:	0b 4c 24 ac          	or     -0x54(%rsp),%ecx
   95612:	44 89 4c 24 80       	mov    %r9d,-0x80(%rsp)
   95617:	44 89 44 24 84       	mov    %r8d,-0x7c(%rsp)
   9561c:	89 54 24 88          	mov    %edx,-0x78(%rsp)
   95620:	89 4c 24 8c          	mov    %ecx,-0x74(%rsp)
   95624:	48 8b 0e             	mov    (%rsi),%rcx
   95627:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   9562c:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   95630:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
   95635:	44 8b 4c 24 20       	mov    0x20(%rsp),%r9d
   9563a:	41 c1 e9 12          	shr    $0x12,%r9d
   9563e:	44 8b 44 24 24       	mov    0x24(%rsp),%r8d
   95643:	41 c1 e8 12          	shr    $0x12,%r8d
   95647:	8b 54 24 28          	mov    0x28(%rsp),%edx
   9564b:	c1 ea 12             	shr    $0x12,%edx
   9564e:	8b 4c 24 2c          	mov    0x2c(%rsp),%ecx
   95652:	c1 e9 12             	shr    $0x12,%ecx
   95655:	44 89 4c 24 c0       	mov    %r9d,-0x40(%rsp)
   9565a:	44 89 44 24 c4       	mov    %r8d,-0x3c(%rsp)
   9565f:	89 54 24 c8          	mov    %edx,-0x38(%rsp)
   95663:	89 4c 24 cc          	mov    %ecx,-0x34(%rsp)
   95667:	48 8b 0e             	mov    (%rsi),%rcx
   9566a:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   9566f:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   95673:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
   95678:	44 8b 4c 24 30       	mov    0x30(%rsp),%r9d
   9567d:	41 c1 e1 0e          	shl    $0xe,%r9d
   95681:	44 8b 44 24 34       	mov    0x34(%rsp),%r8d
   95686:	41 c1 e0 0e          	shl    $0xe,%r8d
   9568a:	8b 54 24 38          	mov    0x38(%rsp),%edx
   9568e:	c1 e2 0e             	shl    $0xe,%edx
   95691:	8b 4c 24 3c          	mov    0x3c(%rsp),%ecx
   95695:	c1 e1 0e             	shl    $0xe,%ecx
   95698:	44 89 4c 24 d0       	mov    %r9d,-0x30(%rsp)
   9569d:	44 89 44 24 d4       	mov    %r8d,-0x2c(%rsp)
   956a2:	89 54 24 d8          	mov    %edx,-0x28(%rsp)
   956a6:	89 4c 24 dc          	mov    %ecx,-0x24(%rsp)
   956aa:	44 8b 4c 24 c0       	mov    -0x40(%rsp),%r9d
   956af:	44 0b 4c 24 d0       	or     -0x30(%rsp),%r9d
   956b4:	44 8b 44 24 c4       	mov    -0x3c(%rsp),%r8d
   956b9:	44 0b 44 24 d4       	or     -0x2c(%rsp),%r8d
   956be:	8b 54 24 c8          	mov    -0x38(%rsp),%edx
   956c2:	0b 54 24 d8          	or     -0x28(%rsp),%edx
   956c6:	8b 4c 24 cc          	mov    -0x34(%rsp),%ecx
   956ca:	0b 4c 24 dc          	or     -0x24(%rsp),%ecx
   956ce:	44 89 4c 24 b0       	mov    %r9d,-0x50(%rsp)
   956d3:	44 89 44 24 b4       	mov    %r8d,-0x4c(%rsp)
   956d8:	89 54 24 b8          	mov    %edx,-0x48(%rsp)
   956dc:	89 4c 24 bc          	mov    %ecx,-0x44(%rsp)
   956e0:	48 8b 0e             	mov    (%rsi),%rcx
   956e3:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
   956e8:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   956ec:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   956f1:	44 8b 44 24 40       	mov    0x40(%rsp),%r8d
   956f6:	41 c1 e8 03          	shr    $0x3,%r8d
   956fa:	8b 74 24 44          	mov    0x44(%rsp),%esi
   956fe:	c1 ee 03             	shr    $0x3,%esi
   95701:	8b 54 24 48          	mov    0x48(%rsp),%edx
   95705:	c1 ea 03             	shr    $0x3,%edx
   95708:	8b 4c 24 4c          	mov    0x4c(%rsp),%ecx
   9570c:	c1 e9 03             	shr    $0x3,%ecx
   9570f:	44 89 44 24 e0       	mov    %r8d,-0x20(%rsp)
   95714:	89 74 24 e4          	mov    %esi,-0x1c(%rsp)
   95718:	89 54 24 e8          	mov    %edx,-0x18(%rsp)
   9571c:	89 4c 24 ec          	mov    %ecx,-0x14(%rsp)
   95720:	48 8b 4c 24 80       	mov    -0x80(%rsp),%rcx
   95725:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   9572a:	48 8b 4c 24 88       	mov    -0x78(%rsp),%rcx
   9572f:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
   95734:	48 8b 4c 24 b0       	mov    -0x50(%rsp),%rcx
   95739:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   9573e:	48 8b 4c 24 b8       	mov    -0x48(%rsp),%rcx
   95743:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
   95748:	44 8b 44 24 50       	mov    0x50(%rsp),%r8d
   9574d:	44 33 44 24 60       	xor    0x60(%rsp),%r8d
   95752:	8b 74 24 54          	mov    0x54(%rsp),%esi
   95756:	33 74 24 64          	xor    0x64(%rsp),%esi
   9575a:	8b 54 24 58          	mov    0x58(%rsp),%edx
   9575e:	33 54 24 68          	xor    0x68(%rsp),%edx
   95762:	8b 4c 24 5c          	mov    0x5c(%rsp),%ecx
   95766:	33 4c 24 6c          	xor    0x6c(%rsp),%ecx
   9576a:	44 89 44 24 f0       	mov    %r8d,-0x10(%rsp)
   9576f:	89 74 24 f4          	mov    %esi,-0xc(%rsp)
   95773:	89 54 24 f8          	mov    %edx,-0x8(%rsp)
   95777:	89 4c 24 fc          	mov    %ecx,-0x4(%rsp)
   9577b:	48 8b 4c 24 e0       	mov    -0x20(%rsp),%rcx
   95780:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   95785:	48 8b 4c 24 e8       	mov    -0x18(%rsp),%rcx
   9578a:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
   9578f:	44 8b 44 24 f0       	mov    -0x10(%rsp),%r8d
   95794:	44 33 44 24 70       	xor    0x70(%rsp),%r8d
   95799:	8b 74 24 f4          	mov    -0xc(%rsp),%esi
   9579d:	33 74 24 74          	xor    0x74(%rsp),%esi
   957a1:	8b 54 24 f8          	mov    -0x8(%rsp),%edx
   957a5:	33 54 24 78          	xor    0x78(%rsp),%edx
   957a9:	8b 4c 24 fc          	mov    -0x4(%rsp),%ecx
   957ad:	33 4c 24 7c          	xor    0x7c(%rsp),%ecx
   957b1:	44 89 07             	mov    %r8d,(%rdi)
   957b4:	89 77 04             	mov    %esi,0x4(%rdi)
   957b7:	89 57 08             	mov    %edx,0x8(%rdi)
   957ba:	89 4f 0c             	mov    %ecx,0xc(%rdi)
   957bd:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
   957c4:	c3                   	ret
   957c5:	cc                   	int3
   957c6:	cc                   	int3
   957c7:	cc                   	int3
   957c8:	cc                   	int3
   957c9:	cc                   	int3
   957ca:	cc                   	int3
   957cb:	cc                   	int3
   957cc:	cc                   	int3
   957cd:	cc                   	int3
   957ce:	cc                   	int3
   957cf:	cc                   	int3

