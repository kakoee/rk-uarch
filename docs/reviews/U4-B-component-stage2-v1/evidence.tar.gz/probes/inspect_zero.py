from validation.component.consistent_carriers import zero_hop_control
from validation.component.arithmetic import edge_after
j,r=zero_hop_control()
print(j.freq_hz)
for c in r['observations']['clocks']['records']:
 if c['n_cycles'] and edge_after(getattr(j.freq_hz,c['domain']),c['grant_ps'],c['n_cycles'])!=c['completion_ps']:print(c)
