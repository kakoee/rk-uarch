import json,runpy
from pathlib import Path
m=json.loads(Path('docs/reviews/U4-A-component-stage2-v1/combined-postimages.json').read_text())
f=runpy.run_path('docs/reviews/U4-B-component-stage2-v1/freeze_selection.py')['freeze']
s=f(m)
print(s['selection_hash'],len(s['cases']))
