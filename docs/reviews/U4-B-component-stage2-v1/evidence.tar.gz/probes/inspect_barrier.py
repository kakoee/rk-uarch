from validation.component.synthetic_carrier import synthetic_job
j=synthetic_job('D13-barrier')
print(j.freq_hz)
print(j.mapped_point.task_graph.jobs)
print(j.mapped_point.task_graph.dependencies)
