from validation.component.consistent_carriers import activity,control,seal
from uarch_contract.mapped import validate_result
j,r=control('D08')
a,b=activity(r,'r0:out-a'),activity(r,'r1:out-a')
a['predecessors']=[dict(activity_id=b['activity_id'],relation='resource')]
b['predecessors']=[dict(activity_id=a['activity_id'],relation='resource')]
try:
 validate_result(seal(r),j)
except ValueError as e:
 print(str(e)); assert str(e).startswith('AttributionMismatch:')
else:raise AssertionError('unsafe cycle accepted')
validate_result(control('D08')[1],j)
