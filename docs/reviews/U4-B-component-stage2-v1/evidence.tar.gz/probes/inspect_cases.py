import json
from validation.component.synthetic_carrier import synthetic_job
for name in ['D14','D13-hop','C05-A-carrier']:
 j=synthetic_job(name)
 print(name,json.dumps(j.mapped_point.task_graph.model_dump(mode='json'),indent=1))
