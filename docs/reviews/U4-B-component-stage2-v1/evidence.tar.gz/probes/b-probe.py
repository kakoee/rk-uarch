import json
from uarch_contract.mapped import validate_result
from validation.component.observations_v2 import check_v2
from validation.component.consistent_carriers import attack, EXPECTED
out={}
for name in ('M1','M2','M3','M4a','M4b','V1','V2','port_overlap','port_reverse'):
 j,r=attack(name)
 row={}
 for layer,call in [('carrier',lambda:validate_result(r,j)),('checker',lambda:check_v2(j.model_dump(mode='json'),r,EXPECTED))]:
  try:call();row[layer]='ACCEPT'
  except ValueError as e:row[layer]=str(e)
 out[name]=row
print(json.dumps(out,indent=2))
