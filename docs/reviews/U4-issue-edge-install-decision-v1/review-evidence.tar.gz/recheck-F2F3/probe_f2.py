"""Reviewer F2 classifier probes (stdlib + B's restriction.py by path)."""
import copy, hashlib, importlib.util, json, sys
from pathlib import Path
spec = importlib.util.spec_from_file_location("r", Path(sys.argv[1])); r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
cases = dict(a.split("=", 1) for a in sys.argv[2:])
def show(name, raw):
    out = r.classify(raw); print(f"{name:34s} {hashlib.sha256(raw).hexdigest()[:12]} {out['status']:24s} {out.get('reproducer') or out.get('reason','')}")
for name, path in cases.items():
    show(name, Path(path).read_bytes())
ww = json.loads(Path(cases["ww0-v1"]).read_text())
v = copy.deepcopy(ww); v["admission"]["case_id"] += "-variant"; show("ww0-v1 variant (new digest)", json.dumps(v).encode())
m = copy.deepcopy(ww)  # write/write split across engines 0 and 1, reads on 2 and 3: one request per engine
for t, e in zip([t for t in m["mapped_point"]["task_graph"]["jobs"] if t["kind"] == "dma"], (0, 1, 2, 3)): t["dma_engine_id"] = e
show("ww0-v1 one request per engine", json.dumps(m).encode())
