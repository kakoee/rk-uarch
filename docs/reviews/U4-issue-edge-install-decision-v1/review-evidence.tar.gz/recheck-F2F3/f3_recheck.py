"""F3 recheck: disconnect ONLY the capacity-check call, run the behavioral regression and both
consumers, restore exact bytes (hash-verified) and rerun.

Usage: python -I f3_recheck.py MUT PRISTINE OUT.json VALID_JOB VALID_RESULT A1B_RESULT
"""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

mut, pristine = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
out = Path(sys.argv[3]).resolve()
job, valid, a1b = (str(Path(a).resolve()) for a in sys.argv[4:7])
PY = "/home/jjaff/AI-infra-simulation/rk-uarch/.venv/bin/python"
TOOLS = Path("/tmp/claude-1000/-home-jjaff-AI-infra-simulation-rk-uarch/31125e8a-4bee-4954-93ba-9ae149f3831c/scratchpad/tools")
MI = "contract/uarch_contract/mapped_issue.py"
TEST = "contract/tests/mapped/test_component_capacity_integration_v3.py"
CALL = "    validate_reservation_capacity(requests, lasts, opportunities, limit)\n"
EXPECTED_PRISTINE = "b645aa77fe4e3ed35b8bf05bcc747e211b4ff9436a4ee2518569bb837c848afa"


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run_tests(tag):
    p = subprocess.run([PY, "-I", str(TOOLS / "runner.py"), str(mut), "pytest", "-q", "-rf", TEST],
                       capture_output=True, text=True, timeout=300)
    (out.parent / f"{out.stem}-{tag}-pytest.log").write_text(p.stdout + p.stderr)
    lines = p.stdout.splitlines()
    return dict(exit=p.returncode,
                summary=next((x for x in reversed(lines) if " passed" in x or " failed" in x), ""),
                failures=[x for x in lines if x.startswith("FAILED") or "DID NOT RAISE" in x][:4])


def run_consumers(tag):
    log = out.parent / f"{out.stem}-{tag}-consumers.json"
    p = subprocess.run([PY, "-I", str(TOOLS / "runner.py"), str(mut), "script", str(TOOLS / "consume.py"),
                        str(mut), str(log), f"sr2-valid={job}:{valid}", f"A1b={job}:{a1b}"],
                       capture_output=True, text=True, timeout=300)
    assert p.returncode == 0, p.stderr[-1500:]
    return [(c["case"], c["structural"][:70], c["independent"][:70]) for c in json.loads(log.read_text())["cases"]]


target = mut / MI
original = (pristine / MI).read_bytes()
assert sha(pristine / MI) == EXPECTED_PRISTINE and target.read_bytes() == original
assert original.decode().count(CALL) == 1
rec = dict(file=MI, pristine_sha256=EXPECTED_PRISTINE, removed=CALL, test=TEST, test_sha256=sha(mut / TEST))
rec["baseline_tests"] = run_tests("baseline")
rec["baseline_consumers"] = run_consumers("baseline")
target.write_text(original.decode().replace(CALL, ""))
rec["mutant_sha256"] = sha(target)
try:
    rec["mutant_tests"] = run_tests("mutant")
    rec["mutant_consumers"] = run_consumers("mutant")
finally:
    target.write_bytes(original)
rec["restored_sha256"] = sha(target)
assert rec["restored_sha256"] == EXPECTED_PRISTINE
rec["restored_tests"] = run_tests("restored")
rec["restored_consumers"] = run_consumers("restored")
out.write_text(json.dumps(rec, indent=1) + "\n")
for phase in ("baseline", "mutant", "restored"):
    t = rec[f"{phase}_tests"]
    print(f"{phase:9s} tests exit={t['exit']} {t['summary']} {t['failures']}")
    for c in rec[f"{phase}_consumers"]:
        print(f"{phase:9s} {c[0]:10s} structural={c[1]:62s} independent={c[2]}")
