import json, sys, hashlib
from uarch_contract.hashing import canonical_json
fix = json.load(open(sys.argv[1])); raw = open(sys.argv[2], "rb").read(); native = json.loads(raw)["result"]
print("fixture result == reviewer native sr2-v3 result (parsed):", fix == native)
print("canonical wrapper of fixture == reviewer native wrapper bytes:", canonical_json({"outcome": "success", "result": fix}).encode() == raw)
