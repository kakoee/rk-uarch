from validation.component.transient_carrier import transient_control, transient_attack
from validation.component.consistent_carriers import EXPECTED
from validation.component.observations_v2 import check_v2
from uarch_contract.mapped import validate_result
for name, args in [('control',None),('early',('allocate_ps',0)),('late',('free_ps',2735000)),('earlyfree',('free_ps',1641000))]:
 j,r=transient_control() if args is None else transient_attack(*args)
 for layer,fn in [('structural',lambda:validate_result(r,j)),('checker',lambda:check_v2(j.model_dump(mode='json'),r,EXPECTED))]:
  try:fn();print(name,layer,'ACCEPT')
  except Exception as e:print(name,layer,type(e).__name__,str(e))
