import importlib.util,json,pathlib,hashlib,subprocess,sys,time,shutil
N=pathlib.Path(pathlib.Path('/tmp/u4-c2r-location').read_text());P=N/'receipts';V=N/'variants/comparator';V.mkdir()
for src,name in [('/tmp/u4-c2-compare.py','reverted.py'),('/tmp/u4-c2r-comparator.py','restored.py')]:shutil.copyfile(src,V/name)
script='''import importlib.util,json,sys,pathlib
N=pathlib.Path(sys.argv[1]);path=pathlib.Path(sys.argv[2]);s=importlib.util.spec_from_file_location('subject',path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
v=[json.loads(x) for x in (N/'vectors/vectors.jsonl').read_bytes().split(b'\\n')[:-1]]
a=[json.loads(x) for x in (N/'receipts/baseline-debug-vectors.stdout').read_bytes().split(b'\\n')[:-1]]
rules=json.loads((N/'vectors/refusals.json').read_text());i=next(i for i,x in enumerate(v) if x['family']=='duplicates')
tests=[('empty',[],[]),('reordered',v[:2],a[:2][::-1]),('wrong-layer',v[i:i+1],[dict(a[i],layer='transport',error='unrelated')]),('wrong-reason',v[i:i+1],[dict(a[i],error='unrelated')])]
results=[]
for name,vs,acts in tests:
 try:
  r=m.compare(vs,acts,rules) if hasattr(m,'records') else m.compare(vs,acts)
  rejected=r['mismatch_count']>0
 except ValueError:rejected=True
 results.append({'name':name,'rejected':rejected})
r=m.compare(v[:2],a[:2],rules) if hasattr(m,'records') else m.compare(v[:2],a[:2]);assert r['mismatch_count']==0
print(json.dumps({'controls':results,'positive_pass':True}))
sys.exit(0 if all(x['rejected'] for x in results) else 1)
'''
(V/'exercise.py').write_text(script)
for version,code in [('reverted',1),('restored',0)]:
 name='host-comparator-'+version;argv=[sys.executable,'-I','-S','-B',str(V/'exercise.py'),str(N),str(V/f'{version}.py')];p=subprocess.run(argv,env={'PATH':'/usr/bin:/bin'},capture_output=True)
 for ext,b in [('stdout',p.stdout),('stderr',p.stderr)]:(P/f'{name}.{ext}').write_bytes(b)
 commands=json.loads((P/'commands.json').read_text());commands.append({'name':name,'argv':argv,'environment':{'PATH':'/usr/bin:/bin'},'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'network':'host pure Python, no network API or subprocess inside exercise','source_sha256':hashlib.sha256((V/f'{version}.py').read_bytes()).hexdigest()});(P/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 assert p.returncode==code,p.stderr.decode();print(name,p.returncode,p.stdout.decode())
