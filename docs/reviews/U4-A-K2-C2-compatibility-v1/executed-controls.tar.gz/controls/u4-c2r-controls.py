import importlib.util,json,pathlib,gzip,time,ast,copy
N=pathlib.Path(pathlib.Path('/tmp/u4-c2r-location').read_text());R=pathlib.Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
new=module('new','/tmp/u4-c2r-comparator.py');old=module('old','/tmp/u4-c2-compare.py')
v=new.records((N/'vectors/vectors.jsonl').read_bytes());a=new.records(gzip.decompress((R/'docs/reviews/U4-A-K2-C2-probes-v1/outcomes-debug.jsonl.gz').read_bytes()))
rules=json.loads((N/'vectors/refusals.json').read_bytes())
controls=[]
def reject(name,vs,acts):
 try:result=new.compare(vs,acts,rules)
 except (ValueError,KeyError,TypeError,UnicodeError):pass
 else:assert result['mismatch_count']>0,name
 controls.append(name)
for name,vs,acts in [('empty',[],[]),('missing',v[:1],[]),('duplicate-output',v[:1],a[:1]*2),('extra',v[:1],a[:2]),('reordered',v[:2],a[:2][::-1]),('duplicate-selection',v[:1]*2,a[:1]*2),('wrong-id',v[:1],[dict(a[0],id='foreign')])]:reject(name,vs,acts)
for name,changes in [('wrong-bytes',{'canonical':'x'}),('wrong-hash',{'sha256':'0'*64}),('foreign-key',{'extra':1}),('missing-canonical',{'canonical':None}),('bad-status',{'status':'other'}),('malformed-refusal',{'status':'refuse','layer':'carrier'}),('wrong-refusal',{'status':'refuse','layer':'transport','error':'unrelated'})]:reject(name,v[:1],[dict(a[0],**changes)])
i=next(i for i,x in enumerate(v) if x['family']=='duplicates')
for name,changes in [('wrong-layer',{'layer':'transport','error':'unrelated'}),('wrong-reason',{'error':'unrelated'})]:
 acts=[dict(a[i],**changes)];assert old.compare(v[i:i+1],acts)['mismatch_count']==0;reject(name,v[i:i+1],acts)
for name,raw in [('empty-bytes',b''),('no-LF',b'{}'),('blank',b'{}\n\n'),('bad-json',b'{\n'),('duplicate-key',b'{"id":"a","id":"a"}\n'),('scalar-output',b'1\n'),('missing-id',b'{}\n'),('null-id',b'{"id":null}\n'),('nonfinite',b'{"id":"a","x":NaN}\n'),('invalid-utf8',b'{"id":"\xff"}\n'),('CRLF',b'{"id":"a"}\r\n')]:
 try:new.records(raw)
 except (ValueError,UnicodeError):controls.append(name)
 else:raise AssertionError(name)
assert old.compare([],[])['mismatch_count']==0
assert old.compare(v[:2],a[:2][::-1])['mismatch_count']==0
assert new.compare(v[:2],a[:2],rules)['mismatch_count']==0
assert new.compare(v[i:i+1],a[i:i+1],rules)['mismatch_count']==0
# Apply B's unchanged baseline reason mapping to the saved baseline; separate from revised rules.
t=ast.parse((R/'docs/reviews/U4-B-K2-C2-reconciliation-v1/review_outputs.py').read_text())
ns={};exec(compile(ast.Module(body=[x for x in t.body if isinstance(x,ast.FunctionDef) and x.name in ['validate_selection','expected_rust_refusal','compare']],type_ignores=[]),'B-baseline-comparison','exec'),dict(sha=new.sha,**ns),ns)
# Function globals must share the same mapping.
ns={'sha':new.sha};exec(compile(ast.Module(body=[x for x in t.body if isinstance(x,ast.FunctionDef) and x.name in ['validate_selection','expected_rust_refusal','compare']],type_ignores=[]),'B-baseline-comparison','exec'),ns)
bad,refs=ns['compare'](v,a);assert len(bad)==10
(N/'receipts/host-controls-before.json').write_text(json.dumps({'time_ns':time.time_ns(),'controls':controls,'count':len(controls),'positive_restored':True,'baseline_gaps_reproduced':['empty','reordered','wrong-refusal-layer','wrong-refusal-reason'],'saved_baseline_inherited':{'count':len(v),'mismatches':bad,'refusals':len(refs)},'not_native_execution':True},indent=2)+'\n')
print('HOST controls',len(controls),'baseline failures',bad)
