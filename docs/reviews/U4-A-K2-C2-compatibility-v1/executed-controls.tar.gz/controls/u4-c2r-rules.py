import ast,json,pathlib,re,time,math,hashlib
N=pathlib.Path(pathlib.Path('/tmp/u4-c2r-location').read_text());R=pathlib.Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
t=ast.parse((R/'docs/reviews/U4-B-K2-C2-reconciliation-v1/review_outputs.py').read_text())
exec(compile(ast.Module(body=[x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='expected_rust_refusal'],type_ignores=[]),'B-reviewed-refusals','exec'))
def integer(v):return 'IntegerToken' if type(v) is not int else 'IntegerRange'
def ratio(v):
 if type(v) is not dict or set(v)!={'numerator','denominator'}:return 'RationalFields'
 for k in ['numerator','denominator']:
  if type(v[k]) is not int or not 0<=v[k]<2**128:return integer(v[k])
 return 'InvalidRatio'
def rule(v):
 op=v['op']; ident=v['id']; family=v['family']
 layer='carrier';reason=None;condition=''
 if op in ['u128','rational','leaf','sourced','json-float']:
  try:d=json.loads(bytes.fromhex(v['hex']))
  except Exception:d=None
  # Duplicate input keys are rejected before typed dispatch.
  pairs=[]
  try:
   def pair(items):
    if len(dict(items))!=len(items):pairs.append(True)
    return dict(items)
   json.loads(bytes.fromhex(v['hex']),object_pairs_hook=pair)
  except Exception:pass
  if pairs:layer,reason='strict-json','DuplicateJsonKey'
  elif op=='u128':reason=integer(d)
  elif op=='rational':reason=ratio(d)
  elif op=='leaf':
   if type(d) is not dict or set(d)!={'path','value'} or type(d.get('path')) is not str or not d['path'].strip():reason='LeafFields'
   elif isinstance(d['value'],dict):reason=ratio(d['value'])
   elif isinstance(d['value'],float):reason='IntegerToken'
   else:reason='LeafScalar'
  elif op=='json-float':reason='JsonFloatFinite' if type(d) in [int,float] else 'JsonFloatType'
  elif op=='sourced':
   if 'extra' in d:reason='unknown field `extra`'
   elif 'value' not in d:reason='missing field `value`'
   elif d['value'] is None or type(d['value']) in [dict,list]:reason='LegacyFloatType'
   elif type(d['value']) is str:
    try:f=float(d['value'].replace('_',''));reason='LegacyFloatFinite' if not math.isfinite(f) else 'LegacyFloatSyntax'
    except ValueError:reason='LegacyFloatSyntax'
   else:reason='SourcedValue rules'
   if family=='A-boundary-extension' and ident.endswith('sourced-rules'):reason='SourcedValue rules'
 else:
  if family.startswith('B-') and op=='marker':layer,reason='strict-json','ReservedNumericMarker'
  else:layer,reason=expected_rust_refusal(v)
 # Exact stable classes; unchanged serde diagnostics have specific reviewed prefix + location.
 pattern=re.escape(reason)
 if reason in ['DuplicateJsonKey']:pattern+=r'(?: at line \d+ column \d+)?'
 elif reason.startswith(('unknown field','missing field')):pattern+=r'(?:, expected [^\n]+)? at line \d+ column \d+'
 elif reason in ['expected value','invalid number','unexpected end of hex escape','lone leading surrogate']:pattern+=r'(?: in hex escape)? at line \d+ column \d+'
 elif reason=='invalid utf-8':pattern+=r' sequence of \d+ bytes from index \d+'
 return {'layer':layer,'reason_class':reason,'error_pattern':pattern,'condition':{'op':op,'input_sha256':hashlib.sha256(bytes.fromhex(v.get('hex',''))).hexdigest(),'Python_layer':v['expected'].get('layer')},'mapping':'failed token/type, bounds, exact fields, reduced ratio, finite conversion, duplicate/marker, encoding or identity condition; not arbitrary error'}
rules={}
for p in sorted((N/'vectors').glob('*.jsonl')):
 for v in map(json.loads,p.read_bytes().split(b'\n')[:-1]):
  if v['expected']['status']=='refuse':rules[v['id']]=rule(v)
(N/'vectors/refusals.json').write_text(json.dumps(rules,indent=2)+'\n')
(N/'receipts/refusal-freeze.json').write_text(json.dumps({'time_ns':time.time_ns(),'sha256':hashlib.sha256((N/'vectors/refusals.json').read_bytes()).hexdigest(),'count':len(rules),'before_corrected_source_and_execution':True,'historical_vectors_edited':False},indent=2)+'\n')
print('FROZEN refusal rules',len(rules))
