from pathlib import Path
import hashlib,json,time
N=Path(Path('/tmp/u4-c2r-location').read_text());R=Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a');S=N/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs'
tests=Path('/tmp/u4-c2r-unit-tests.rs').read_text()
(N/'receipts/unit-tests-before-source.rs').write_text(tests)
(N/'receipts/unit-tests-freeze.json').write_text(json.dumps({'time_ns':time.time_ns(),'sha256':hashlib.sha256(tests.encode()).hexdigest(),'before_corrected_source':True})+'\n')
s=(R/'docs/reviews/U4-A-K2-C2-probes-v1/probe.rs').read_text()
a=s.index('#[derive(Serialize, Deserialize)]\n#[serde(untagged)]');b=s.index('#[derive(Serialize, Deserialize)]\n#[serde(rename_all',a)
s=s[:a]+s[b:]
a=s.index('fn typed<');b=s.index('fn process(',a)
s=s[:a]+Path('/tmp/u4-c2r-helpers.rs').read_text()+'\n'+s[b:]
s=s.replace('struct Sourced {\n    value: f64,','struct Sourced {\n    #[serde(deserialize_with = "legacy_float")]\n    value: f64,')
s=s.replace('let mut v = parse(s)', '''// Only typed integer-bearing carriers normalize the lexical integer -0.
    // The scanner never rewrites text inside JSON strings or decimal/exponent tokens.
    let normalized = normalize_integer_zero(s);
    let s = if matches!(op, "u128" | "rational" | "leaf") { normalized.as_str() } else { s };
    let mut v = parse(s)''')
a=s.index('        "u128" =>');b=s.index('        "sourced" =>',a)
s=s[:a]+'''        "u128" => { integer_u128(&v).map_err(|e| fail("carrier", e))?; v }
        "rational" => { rational_value(&v).map_err(|e| fail("carrier", e))?; v }
        "leaf" => { leaf_value(&v).map_err(|e| fail("carrier", e))?; v }
        "json-float" => {
            let n = v.as_number().ok_or_else(|| fail("carrier", "JsonFloatType".into()))?;
            let f = n.to_string().parse::<f64>().map_err(|_| fail("carrier", "JsonFloatFinite".into()))?;
            let n = Number::from_f64(f).ok_or_else(|| fail("carrier", "JsonFloatFinite".into()))?;
            Value::Number(n)
        }
'''+s[b:]
S.write_text(s+tests)
print('corrected source prepared after frozen tests')
