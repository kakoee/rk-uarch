// Token-preserving dispatch uses the strict parser's arbitrary-precision Number;
// no untagged serde Content or float intermediate participates in strict integers.
fn integer_text(v: &Value) -> Result<String, String> {
    let Value::Number(n) = v else { return Err("IntegerToken".into()); };
    let token = n.to_string();
    if token.contains(['.', 'e', 'E']) { return Err("IntegerToken".into()); }
    Ok(token)
}
fn integer_u128(v: &Value) -> Result<u128, String> {
    integer_text(v)?.parse::<u128>().map_err(|_| "IntegerRange".into())
}
fn rational_value(v: &Value) -> Result<(), String> {
    let o = v.as_object().ok_or("RationalFields")?;
    if o.len()!=2 || !o.contains_key("numerator") || !o.contains_key("denominator") {return Err("RationalFields".into());}
    Rational{numerator:integer_u128(&o["numerator"])?,denominator:integer_u128(&o["denominator"])?}.check()
}
fn leaf_value(v: &Value) -> Result<(), String> {
    let o = v.as_object().ok_or("LeafFields")?;
    if o.len()!=2 || !o.contains_key("value") || !o.get("path").and_then(Value::as_str).is_some_and(|s| !s.trim().is_empty()) {return Err("LeafFields".into());}
    match &o["value"] {
        Value::Object(_) => rational_value(&o["value"]),
        Value::Number(_) => integer_text(&o["value"]).map(|_| ()),
        Value::Bool(_) | Value::String(_) | Value::Null => Ok(()),
        Value::Array(_) => Err("LeafScalar".into()),
    }
}
fn normalize_integer_zero(s: &str) -> String {
    let bytes=s.as_bytes(); let mut out=Vec::with_capacity(bytes.len()); let mut i=0;
    let mut quoted=false; let mut escaped=false;
    while i<bytes.len() {
        let b=bytes[i];
        if quoted {
            out.push(b);
            if escaped {escaped=false;} else if b==b'\\' {escaped=true;} else if b==b'"' {quoted=false;}
            i+=1; continue;
        }
        if b==b'"' {quoted=true;}
        let before=i==0 || matches!(bytes[i-1],b' '|b'\t'|b'\r'|b'\n'|b'['|b':'|b',');
        let after=i+2==bytes.len() || bytes.get(i+2).is_some_and(|c| matches!(c,b' '|b'\t'|b'\r'|b'\n'|b']'|b'}'|b','));
        if b==b'-' && bytes.get(i+1)==Some(&b'0') && before && after {out.push(b'0');i+=2;} else {out.push(b);i+=1;}
    }
    String::from_utf8(out).expect("only ASCII minus removed from UTF-8")
}
// Installed Pydantic legacy float conversion is field-local. The frozen Python
// boundaries establish trimming and underscore behavior; it is not Python float().
fn legacy_float<'de,D: Deserializer<'de>>(d:D)->Result<f64,D::Error> {
    let Strict(v)=Strict::deserialize(d)?;
    let f=match v {
        Value::Bool(b)=> if b {1.0} else {0.0},
        Value::Number(n)=>n.to_string().parse::<f64>().map_err(|_| de::Error::custom("LegacyFloatSyntax"))?,
        Value::String(s)=>{
            let s=s.trim();
            if s.starts_with('_') || s.ends_with('_') || s.contains("__") {return Err(de::Error::custom("LegacyFloatSyntax"));}
            s.replace('_',"").parse::<f64>().map_err(|_| de::Error::custom("LegacyFloatSyntax"))?
        },
        _=>return Err(de::Error::custom("LegacyFloatType")),
    };
    if !f.is_finite() {return Err(de::Error::custom("LegacyFloatFinite"));}
    Ok(f)
}
