import importlib.util,json,pathlib,gzip
spec=importlib.util.spec_from_file_location('runner','/tmp/u4-c2r-run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
report={}
for mode in ['debug','release']:
 for dataset in ['vectors','supplement','B-extension','A-extension']:
  p=r.run('baseline-'+mode+'-'+dataset,['/target/baseline/'+mode+'/c2-probe'],stdin=(r.N/'vectors'/f'{dataset}.jsonl').read_bytes());assert p.returncode==0
  if dataset in ['vectors','supplement']:
   f='outcomes-debug.jsonl.gz' if dataset=='vectors' else 'identity-supplement-outcomes.jsonl.gz'
   assert p.stdout==gzip.decompress((r.R/'docs/reviews/U4-A-K2-C2-probes-v1'/f).read_bytes())
  vs=list(map(json.loads,(r.N/'vectors'/f'{dataset}.jsonl').read_bytes().split(b'\n')[:-1]));acts=list(map(json.loads,p.stdout.split(b'\n')[:-1]))
  bad=[v['id'] for v,a in zip(vs,acts,strict=True) if any(a.get(k)!=value for k,value in v['expected'].items() if k in ['status','canonical','sha256'])]
  report[mode+'-'+dataset]={'count':len(vs),'value_or_status_mismatches':bad,'refusal_reason_not_accepted_by_this_diagnostic':True}
(r.P/'baseline-rerun.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:len(v['value_or_status_mismatches']) for k,v in report.items()})
