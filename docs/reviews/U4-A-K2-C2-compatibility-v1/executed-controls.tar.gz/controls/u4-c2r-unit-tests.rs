
#[cfg(test)]
mod compatibility_tests {
    use super::*;
    fn result(op: &str, input: &str) -> Result<Value, (String, String)> {
        process(&json!({"op":op,"hex":hex(input.as_bytes())}))
    }
    #[test]
    fn explicit_leaf_rational_and_unbounded_integer() {
        for token in ["340282366920938463463374607431768211456", "-170141183460469231731687303715884105729"] {
            let raw = format!(r#"{{"path":"x","value":{token}}}"#);
            assert_eq!(result("leaf", &raw).unwrap()["canonical"],raw);
        }
        assert_eq!(result("leaf",r#"{"path":"x","value":{"numerator":1,"denominator":2}}"#).unwrap()["canonical"],r#"{"path":"x","value":{"denominator":2,"numerator":1}}"#);
        for value in ["true", "false", "null", r#""1""#] {
            let raw = format!(r#"{{"path":"x","value":{value}}}"#);
            assert_eq!(result("leaf",&raw).unwrap()["canonical"],raw);
        }
    }
    #[test]
    fn rational_refusal_conditions() {
        for (raw, layer, reason) in [
            (r#"{"numerator":2,"denominator":4}"#,"carrier","InvalidRatio"),
            (r#"{"numerator":0,"denominator":2}"#,"carrier","InvalidRatio"),
            (r#"{"numerator":1,"denominator":0}"#,"carrier","InvalidRatio"),
            (r#"{"numerator":1,"denominator":1,"extra":0}"#,"carrier","RationalFields"),
            (r#"{"numerator":1}"#,"carrier","RationalFields"),
            (r#"{"numerator":true,"denominator":1}"#,"carrier","IntegerToken"),
            (r#"{"numerator":340282366920938463463374607431768211456,"denominator":1}"#,"carrier","IntegerRange"),
        ] {
            assert_eq!(result("rational",raw).unwrap_err(),(layer.into(),reason.into()));
        }
        let (layer,error)=result("leaf",r#"{"path":"x","value":{"numerator":1,"denominator":1,"denominator":1}}"#).unwrap_err();
        assert_eq!(layer,"strict-json");assert!(error.starts_with("DuplicateJsonKey"));
    }
    #[test]
    fn lexical_integer_zero_only() {
        assert_eq!(result("u128","-0").unwrap()["canonical"],"0");
        assert_eq!(result("rational",r#"{"numerator":-0,"denominator":1}"#).unwrap()["canonical"],r#"{"denominator":1,"numerator":0}"#);
        assert_eq!(result("leaf",r#"{"path":"-0","value":"-0"}"#).unwrap()["canonical"],r#"{"path":"-0","value":"-0"}"#);
        for token in ["-0.0","1e0","true",r#""-0""#] {assert_eq!(result("u128",token).unwrap_err(),("carrier".into(),"IntegerToken".into()));}
        assert_eq!(result("rational",r#"{"numerator":1,"denominator":-0}"#).unwrap_err(),("carrier".into(),"InvalidRatio".into()));
    }
    #[test]
    fn legacy_float_local_compatibility() {
        for (token,canonical_value) in [("false","0.0"),("true","1.0"),(r#"" 1_.0 ""#,"1.0"),(r#""1e_2""#,"100.0"),(r#""1_0""#,"10.0")] {
            let raw=format!(r#"{{"value":{token},"unit":"Hz","kind":"stipulation","rationale":"test"}}"#);
            let got=result("sourced",&raw).unwrap();
            assert!(got["canonical"].as_str().unwrap().ends_with(&format!("\"value\":{canonical_value}}}")));
        }
        for token in [r#""1__0""#,r#""NaN""#,"null","{}"] {
            let raw=format!(r#"{{"value":{token},"unit":"Hz","kind":"stipulation","rationale":"test"}}"#);
            assert!(result("sourced",&raw).is_err());
        }
    }
    #[test]
    fn strict_float_and_leaf_stay_distinct() {
        for token in ["true",r#""1.0""#,"null"] {assert_eq!(result("json-float",token).unwrap_err(),("carrier".into(),"JsonFloatType".into()));}
        assert_eq!(result("json-float","1").unwrap()["canonical"],"1.0");
        assert_eq!(result("leaf",r#"{"path":"x","value":1.0}"#).unwrap_err(),("carrier".into(),"IntegerToken".into()));
    }
    #[test]
    fn marker_guard_precedes_leaf_dispatch() {
        let (layer,error)=result("leaf",r#"{"path":"x","value":{"\u0024serde_json::private::Number":"1"}}"#).unwrap_err();
        assert_eq!(layer,"strict-json");assert_eq!(error,"ReservedNumericMarker");
    }
}
