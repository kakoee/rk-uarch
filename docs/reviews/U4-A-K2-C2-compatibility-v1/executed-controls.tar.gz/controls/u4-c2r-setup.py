from pathlib import Path
s=Path('/tmp/u4-c2-setup.py').read_text()
s=s.replace("prefix='u4-k2-c2.'", "prefix='u4-k2-c2r.'").replace('/tmp/u4-c2-location','/tmp/u4-c2r-location')
s=s.replace("source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()", "publication=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()\nsource='ce732f5bedccdde629edcf278fa76ea772d0ea82'\nreconciliation=json.loads((R/'docs/reviews/U4-K2-C2-followup-release-v1/reconciliation.json').read_text())\nfor p,h in reconciliation['bindings'].items(): assert sha(R/p)==h")
s=s.replace("pathlib.Path('/tmp/u4-k2-c1-precise.styffox_')]", "pathlib.Path('/tmp/u4-k2-c1-precise.styffox_'),pathlib.Path('/tmp/u4-k2-c2.75eyx6ab')]")
s=s[:s.index("argv=base+['/bin/sh'")] + '''write('inputs.json',{'source_commit':source,'publication_start':publication,'scratch':str(N),'image':oldpre['expected_image'],'tools_reverified':True,'readonly_cache':True,'cache_files_verified':len(actual),'reconciliation':reconciliation,'approval':receipt,'reference_archive_sha256':sha(N/'receipts/reference.tar')})
O=R/'docs/reviews/U4-A-K2-C2-probes-v1'
shutil.copyfile(O/'probe.rs',N/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs')
for f in ['rustc-wrapper.sh','linker.sh']:shutil.copy2(pathlib.Path('/tmp/u4-k2-c2.75eyx6ab/controls')/f,N/'controls'/f)
import gzip
for src,dst in [('vectors.jsonl.gz','vectors.jsonl'),('identity-supplement.jsonl.gz','supplement.jsonl')]: (N/'vectors'/dst).write_bytes(gzip.decompress((O/src).read_bytes()))
write('copied-before.json',{'cache':inv(N/'cache'),'vectors':inv(N/'vectors')})
print(N,flush=True)
'''
exec(compile(s,'separate-setup','exec'))
