# ruff: noqa: E402
import sys, pathlib, json, hashlib, time, ast
N=pathlib.Path(pathlib.Path('/tmp/u4-c2r-location').read_text())
R=pathlib.Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
sys.path[:0]=[str(N/'reference/contract'),str(R/'.venv/lib/python3.12/site-packages')]
import pydantic
from pydantic import TypeAdapter,Field
from typing import Annotated
from uarch_contract import hashing as h, mapped as m
from uarch_contract.common import JsonFloat
from uarch_contract.sourced import SourcedValue
import struct
U128=TypeAdapter(Annotated[int,Field(strict=True,ge=0,lt=2**128)])
def sha(b):return hashlib.sha256(b).hexdigest()
tree=ast.parse((R/'docs/reviews/U4-B-K2-C2-reconciliation-v1/derive.py').read_text())
exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='expected'],type_ignores=[]),'B-reviewed-expected','exec'))
B=json.loads((R/'docs/reviews/U4-B-K2-C2-reconciliation-v1/B-expectations.json').read_text())
for v in B:assert expected(v)==v['expected'],v['id']
rows=[]
def add(op,s,label):
 row={'id':f'A-ext:{len(rows):04d}:{label}','family':'A-boundary-extension','op':op,'hex':s.encode().hex()};row['expected']=expected(row);rows.append(row)
strings=['',' ','+1','-0','-0.0','.5','1.','+1e-2','1E+2','01','1_0','1__0','_1','1_','1_.0','1._0','1e_2','1_e2','1e+_2','1_2.3_4e5_6',' 1.0 ','\t\r\n1.0\v\f','\u00a01.0\u00a0','\u20031.0\u2003','\u00851.0\u0085','\x1c1.0\x1c','１２','١٢','1\x00','0x10','NaN','nan','+NaN','inf','-inf','Infinity','-Infinity','1e999','-1e999','1e-999','-1e-999','5e-324','2.2250738585072014e-308','1.7976931348623157e308','1.7976931348623159e308','0.1000000000000000055511151231257827021181583404541015625','9007199254740993','1_000_000.0','1 0','++1','--1','+','.', '1e','1e+','1e-','1,0']
for s in strings:add('sourced',json.dumps({'value':s,'unit':'Hz','kind':'stipulation','rationale':'extension'}),'legacy-string')
for v in [True,False,None,{},[],0,-1,2**128, -(2**128),1.0]:add('sourced',json.dumps({'value':v,'unit':'Hz','kind':'stipulation','rationale':'extension'}),'legacy-value')
for tok in ['-0','-0.0','1e0','true','"-0"','null',str(2**128),str(-(2**127)-1),'9'*300,'-'+'9'*300]:
 add('leaf','{"path":"x","value":'+tok+'}','leaf-scalar')
 add('u128',tok,'strict-integer')
for tok in ['-0','-0.0','1e0','true','"-0"',str(2**128)]:
 for field in ['numerator','denominator']:
  s='{"numerator":'+(tok if field=='numerator' else '1')+',"denominator":'+(tok if field=='denominator' else '1')+'}'
  add('rational',s,'rational-'+field);add('leaf','{"path":"x","value":'+s+'}','leaf-rational-'+field)
for s in ['{}','{"path":"x"}','{"path":"x","value":[]}','{"path":" ","value":1}','{"path":false,"value":1}','{"path":"x","value":1,"extra":0}','{"path":"x","value":{"numerator":1}}','{"path":"x","value":{"numerator":1,"denominator":1,"denominator":1}}','{"path":"-0","value":"-0"}']:
 add('leaf',s,'leaf-shape')
for tok in ['true','"1"','null','{}','[]','1','1.0','-0','-0.0','1e0','1e999']:
 add('json-float',tok,'strict-json-float')
for v in [{'value':'1','unit':'Hz','provenance':'stub'}, {'value':'1','unit':'Hz','provenance':'measured','source':'s'}, {'value':'1','unit':'Hz'}, {'value':'1','unit':' ','provenance':'stub'}, {'value':'1','unit':'Hz','kind':'stipulation'}, {'value':'1','unit':'Hz','kind':'stipulation','rationale':'r','source':'s'}, {'value':'1','unit':'Hz','provenance':'stub','rationale':'r'}, {'value':'1','unit':'Hz','kind':'other'}]:add('sourced',json.dumps(v),'sourced-rules')
for name,data in [('B-extension.jsonl',B),('A-extension.jsonl',rows)]: (N/'vectors'/name).write_text(''.join(json.dumps(v,ensure_ascii=True,separators=(',',':'))+'\n' for v in data))
origins={name:{'path':mod.__file__,'sha256':sha(pathlib.Path(mod.__file__).read_bytes())} for name,mod in sys.modules.items() if (name.startswith('uarch_contract') or name in ['pydantic','pydantic_core']) and getattr(mod,'__file__',None)}
assert all(str(N/'reference/contract') in v['path'] for k,v in origins.items() if k.startswith('uarch_contract'))
freeze={'time_ns':time.time_ns(),'reference':'ce732f5bedccdde629edcf278fa76ea772d0ea82','python':sys.version,'executable':sys.executable,'executable_sha256':sha(pathlib.Path(sys.executable).read_bytes()),'pydantic':pydantic.__version__,'origins':origins,'vectors':{p.name:{'sha256':sha(p.read_bytes()),'count':len(p.read_bytes().split(b'\n'))-1} for p in sorted((N/'vectors').glob('*.jsonl'))},'B52_rederived_exact':True,'original_vectors_unchanged':True,'no_corrected_native_execution_yet':True}
(N/'receipts/extension-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
for row in rows[:len(strings)]:print(repr(json.loads(bytes.fromhex(row['hex']))['value']),row['expected'])
print('FROZEN',freeze['vectors'])
