import hashlib,json,pathlib,shutil,subprocess,tempfile,time
R=pathlib.Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a')
A=R/'docs/reviews/U4-A-K2-C1-precise-v1'
N=pathlib.Path(tempfile.mkdtemp(prefix='u4-k2-c2.')); pathlib.Path('/tmp/u4-c2-location').write_text(str(N))
for d in ['reference','workspace/native/crates/uarch-engine/src/bin','cache','target','receipts','controls','docker-config','vectors']:(N/d).mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inv(root):return {str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in sorted(root.rglob('*')) if p.is_file()}
def write(n,d):(N/'receipts'/n).write_text(json.dumps(d,indent=2)+'\n')
accept=R/'docs/reviews/U4-K2-approved-C2-release-v1/acceptance.json'; receipt=json.loads(accept.read_text())
for p,h in receipt['approved_files_sha256'].items():assert sha(R/p)==h
for f,h in {'candidate.Cargo.lock':'cbe9a580e0c6209abdb34be23965c2fe2f75b5970819d2021c943e2e02d939be','scratch.Cargo.toml':'60299ba9498e506010a5c908ef8017beb2279d1aedab409a7fc21601d3b35ee0','cache-inventory.json':'ce219674649c7e77ce84806db559d8473a6c6a62b5bad7aa3ff0e93486f30148','metadata-full.stdout':'cf727489186faf665be42d3a7f8098c664ce775810f9a06df8fbe069a9289b41','metadata-linux.stdout':'e72003c00eeedc6278754e8e6a64b15c753a5f87f993272c794e2668526aa7e7'}.items():assert sha(A/f)==h
assert sha(R/'docs/reviews/U4-B-K2-C1-candidate-review-v1/independent-review.json')=='1bb2e09a1c4c5b0d51e6db01c7f3d3701936fcf6550554b08050ba46a022a02f'
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
oldroots=[pathlib.Path('/tmp/u4-k2-c1.zq99i8mm'),pathlib.Path('/tmp/u4-k2-c1-precise.styffox_')]
write('preserved-before.private.json',{str(p):inv(p) for p in oldroots})
cache_inv=json.loads((A/'cache-inventory.json').read_text()); C=pathlib.Path(cache_inv['private_root'])
actual=inv(C); assert set(actual)==set(cache_inv['files'])
for k,v in cache_inv['files'].items(): assert all(actual[k][x]==v[x] for x in ['sha256','bytes'])
shutil.copytree(C,N/'cache',dirs_exist_ok=True)
assert {k:{f:v[f] for f in ['sha256','bytes']} for k,v in inv(N/'cache').items()}==cache_inv['files']
archive=subprocess.check_output(['git','archive',source],cwd=R); (N/'receipts/reference.tar').write_bytes(archive)
subprocess.run(['tar','-xf',str(N/'receipts/reference.tar'),'-C',str(N/'reference')],check=True)
shutil.copyfile(N/'reference/native/Cargo.toml',N/'workspace/native/Cargo.toml')
shutil.copyfile(A/'candidate.Cargo.lock',N/'workspace/native/Cargo.lock')
shutil.copyfile(A/'scratch.Cargo.toml',N/'workspace/native/crates/uarch-engine/Cargo.toml')
commands=[]; env={'PATH':'/usr/bin:/bin','DOCKER_CONFIG':str(N/'docker-config')}
oldpre=json.loads((R/'docs/reviews/U4-A-K2-C1-resolution-v1/preflight.json').read_text())
for name,c in zip(['image-inspect','rustc','cargo','cargo-deny','rustfmt','clippy'],oldpre['commands']):
    argv=[s.replace('/tmp/u4-k2-c1.zq99i8mm',str(N)).replace(str(N)+'/cargo-home',str(N)+'/cache') for s in c['argv']]
    if '--mount' in argv:
        idx=argv.index('--mount')+1;argv[idx]+=',readonly'
    t=time.time();p=subprocess.run(argv,env=env,capture_output=True)
    for ext,b in [('stdout',p.stdout),('stderr',p.stderr)]:(N/'receipts'/f'{name}.{ext}').write_bytes(b)
    commands.append({'name':name,'argv':argv,'environment':env,'exit_code':p.returncode,'seconds':time.time()-t,'stdout_sha256':sha(N/'receipts'/f'{name}.stdout'),'stderr_sha256':sha(N/'receipts'/f'{name}.stderr'),'network':'none/local Unix socket'})
    write('commands.json',commands)
    assert p.returncode==0 and p.stdout==(A/f'{name}.stdout').read_bytes(),name
BIN='/usr/local/rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu/bin/'
base=['/usr/bin/docker','--host','unix:///var/run/docker.sock','run','--rm','--pull','never','--platform','linux/amd64','--network','none','--read-only','--user','1000:1000','--cap-drop','ALL','--security-opt','no-new-privileges','--tmpfs','/tmp','--workdir','/work/native']
for src,dst,ro in [('workspace','/work',True),('cache','/cargo-home',True),('target','/target',False),('controls','/controls',True),('vectors','/vectors',True),('receipts','/receipts',False)]:base+=['--mount',f'type=bind,src={N/src},dst={dst}'+(',readonly' if ro else '')]
base+=['--entrypoint','/usr/bin/env',oldpre['expected_image'],'-i',f'PATH={BIN}:/usr/local/cargo/bin:/usr/bin:/bin','CARGO_HOME=/cargo-home','CARGO_TARGET_DIR=/target',f'RUSTC={BIN}rustc','RUSTUP_AUTO_INSTALL=0','CARGO_NET_OFFLINE=true','CARGO_REGISTRIES_CRATES_IO_PROTOCOL=sparse','LC_ALL=C']
write('container.json',{'argv':base,'environment':env})
argv=base+['/bin/sh','-c','for name in objdump readelf nm cc ld strace sha256sum; do command -v "$name" || true; done']
p=subprocess.run(argv,env=env,capture_output=True)
(N/'receipts/tools-available.stdout').write_bytes(p.stdout);(N/'receipts/tools-available.stderr').write_bytes(p.stderr)
commands.append({'name':'tools-available','argv':argv,'environment':env,'exit_code':p.returncode,'stdout_sha256':sha(N/'receipts/tools-available.stdout'),'stderr_sha256':sha(N/'receipts/tools-available.stderr'),'network':'none'})
write('commands.json',commands)
write('inputs.json',{'approval_file':str(accept.relative_to(R)),'approval_sha256':sha(accept),'verified_approved_files':receipt['approved_files_sha256'],'source_commit':source,'reference_archive_sha256':sha(N/'receipts/reference.tar'),'historical_C1_source':'0718955cc0656e5bac4688d4696abbd547cb4186','candidate_lock_sha256':sha(A/'candidate.Cargo.lock'),'candidate_manifest_sha256':sha(A/'scratch.Cargo.toml'),'cache_files_verified':len(actual),'cache_inventory_sha256':sha(A/'cache-inventory.json'),'scratch':str(N),'image':oldpre['expected_image'],'tools_reverified':True,'readonly_cache':True})
print(N);print(p.stdout.decode())
