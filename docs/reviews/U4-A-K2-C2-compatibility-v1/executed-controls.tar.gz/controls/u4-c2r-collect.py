import pathlib,json,hashlib,shutil,subprocess,time
R=pathlib.Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-a');N=pathlib.Path(pathlib.Path('/tmp/u4-c2r-location').read_text());P=N/'receipts'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inv(root):return {str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in sorted(root.rglob('*')) if p.is_file()}
def write(name,obj):(P/name).write_text(json.dumps(obj,indent=2)+'\n')
commands=[]
for p in sorted(P.glob('*.argv')):
 env=p.with_suffix('.env');args=p.read_bytes().rstrip(b'\0').decode().split('\0');environment=dict(x.split('=',1) for x in env.read_bytes().rstrip(b'\0').decode().split('\0'))
 assert not any('no-vectorize' in a or 'target-cpu=native' in a or 'target-feature=+' in a for a in args)
 commands.append({'receipt':p.name,'argv':args,'environment':environment,'argv_sha256':sha(p),'environment_sha256':sha(env)})
write('compiler-linker-commands.json',commands)
builds=[];depinfo=[]
for root in [N/'target']+[N/'variants'/f/'target' for f in ['leaf','integer-zero','legacy-float']]:
 for mode in ['debug','release']:
  for directory in sorted((root/mode/'build').iterdir()):
   files=[]
   for p in sorted(directory.rglob('*')):
    if p.is_file():
     row={'path':str(p.relative_to(N)),'sha256':sha(p),'bytes':p.stat().st_size}
     if p.name in ['output','stderr','root-output'] or p.suffix=='.d':row['text']=p.read_text(errors='replace')
     files.append(row)
   builds.append({'mode':mode,'directory':str(directory.relative_to(N)),'files':files})
 for p in sorted(root.rglob('*.d')):depinfo.append({'path':str(p.relative_to(N)),'sha256':sha(p),'text':p.read_text()})
write('build-script-output-and-depinfo.json',{'builds':builds,'compiler_depinfo':depinfo,'limits':'Actual argv/environments, Cargo -vv build-script output and dep-info only. No exhaustive read trace, no new diagnostics tool, no final ToolInputs/BuildReceipt or authority.'})
before=json.loads((P/'preserved-before.private.json').read_text());after={root:inv(pathlib.Path(root)) for root in before};write('preserved-after.private.json',after);assert before==after
copied=json.loads((P/'copied-before.json').read_text());assert inv(N/'cache')==copied['cache']
for k,v in copied['vectors'].items():assert inv(N/'vectors')[k]==v
freeze=json.loads((P/'extension-freeze.json').read_text())
for f,v in freeze['vectors'].items():assert sha(N/'vectors'/f)==v['sha256']
assert sha(N/'vectors/refusals.json')==json.loads((P/'refusal-freeze.json').read_text())['sha256']
for root in [N/'workspace']+[N/'variants'/f/'workspace' for f in ['leaf','integer-zero','legacy-float']]:
 assert sha(root/'native/Cargo.lock')=='cbe9a580e0c6209abdb34be23965c2fe2f75b5970819d2021c943e2e02d939be'
 assert sha(root/'native/crates/uarch-engine/Cargo.toml')=='60299ba9498e506010a5c908ef8017beb2279d1aedab409a7fc21601d3b35ee0'
 assert len(list(root.rglob('*.rs')))==1
publication=json.loads((R/'docs/reviews/U4-A-K2-C1-publication-v1.json').read_text())
assert all(sha(R/p['path'])==p['sha256'] for p in publication['human_semantic_postimages'])
history={}
for folder in ['U4-A-K2-C1-resolution-v1','U4-A-K2-C1-precise-v1','U4-A-K2-C2-probes-v1','U4-B-K2-C2-reconciliation-v1']:
 path='docs/reviews/'+folder
 historical='41150f2' if folder.startswith('U4-B') else '3faa3e9'
 tree=subprocess.check_output(['git','rev-parse',historical+':'+path],cwd=R).decode().strip()
 assert subprocess.check_output(['git','rev-parse','HEAD:'+path],cwd=R).decode().strip()==tree
 subprocess.run(['git','diff','--exit-code',historical,'--',path],cwd=R,check=True)
 history[path]={'historical_commit':historical,'git_tree':tree,'unchanged':True}
units={}
for mode in ['debug','release']:
 s=(P/f'build-test-{mode}-package.stdout').read_text();names=[x.split(' ... ')[0] for x in s.splitlines() if x.startswith('test ') and ' ... ' in x];assert len(names)==12 and '12 passed; 0 failed; 0 ignored' in s;units[mode]=names
 for data in ['vectors','supplement','B-extension','A-extension']:
  assert (P/f'corrected-debug-{data}.stdout').read_bytes()==(P/f'corrected-release-{data}.stdout').read_bytes()
write('preservation.json',{'old_roots':list(before),'old_private_files':sum(map(len,before.values())),'bytes_sizes_mtimes_unchanged':True,'before_inventory_sha256':sha(P/'preserved-before.private.json'),'after_inventory_sha256':sha(P/'preserved-after.private.json'),'copied_cache_entries_unchanged':len(copied['cache']),'source_files':inv(N/'workspace'),'history':history,'human_postimages':publication['human_semantic_postimages'],'live_lock_sha256':sha(R/'native/Cargo.lock'),'original_vectors_and_supplement_unchanged':True,'frozen_extensions_and_refusals_unchanged':True})
write('summary.json',{'status':'bounded standalone compatibility cases pass; coordinator/B review pending','datasets':freeze['vectors'],'modes':['debug','release'],'corrected_results_identical_between_modes':True,'unit_names':units,'binary_sha256':{mode:sha(N/'target'/mode/'c2-probe') for mode in ['debug','release']},'source_sha256':sha(N/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs'),'observed_baseline_status_value_failures':{'original':10,'supplement':0,'B':14,'A_extension':47},'corrected_mismatches':0,'host_negative_controls':27,'native_reversion_mismatches_per_mode':{f:json.loads((P/'reversions.json').read_text())[f]['debug']['reverted']['mismatch_count'] for f in ['leaf','integer-zero','legacy-float']},'compiler_link_records':len(commands),'build_directories':len(builds),'depinfo_files':len(depinfo),'exhaustive_reads':False,'SIMD_investigation_resumed':False,'flags_unchanged':True,'public_K2':False,'C3':False,'qualification':False,'U0024':'deferred'})
for p in pathlib.Path('/tmp').glob('u4-c2r-*.py'):shutil.copyfile(p,N/'controls'/p.name)
for p in pathlib.Path('/tmp').glob('u4-c2r-*.rs'):shutil.copyfile(p,N/'controls'/p.name)
for f in ['setup','compare']:shutil.copyfile(f'/tmp/u4-c2-{f}.py',N/'controls'/f'inherited-{f}.py')
shutil.copyfile('/tmp/u4-c2r-derive.log',P/'python-derivation.log')
write('host-errors.json',[{'stage':'first read under default sandbox','result':'bubblewrap unsupported WSL mount; retried the same authorized read with escalation; no mount/security/infrastructure change.'},{'stage':'refusal freeze preparation','result':'Initial mapping retained; before native correction execution allowed serde location suffix for field-visitor errors. No semantic reason/layer widened and no result-driven expectation edit.'},{'stage':'native reversion units','result':'Six intentional exit 101 unit-test regressions; actual diagnostics retained.'},{'stage':'host comparator reversion','result':'Intentional exit 1 proves four old comparator gaps; restored comparator exit 0.'}])
write('private-inventory.json',{'root':str(N),'receipts':inv(P),'controls':inv(N/'controls'),'targets':{str(root.relative_to(N)):inv(root) for root in [N/'target']+[N/'variants'/f/'target' for f in ['leaf','integer-zero','legacy-float']]}})
print(json.dumps(json.loads((P/'summary.json').read_text()),indent=2))
