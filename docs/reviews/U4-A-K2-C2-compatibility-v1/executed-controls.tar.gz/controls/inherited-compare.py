"""Compare frozen C2 expectations without treating refusal layers as identical."""
import collections


def compare(vectors, actual):
    expected_ids = [v['id'] for v in vectors]
    actual_ids = [a['id'] for a in actual]
    if len(set(actual_ids)) != len(actual_ids) or collections.Counter(expected_ids) != collections.Counter(actual_ids):
        raise ValueError('missing, extra, duplicate or empty selection')
    observed = {a['id']: a for a in actual}
    mismatches = []
    layers = []
    counts = collections.Counter()
    for vector in vectors:
        got = observed[vector['id']]
        want = vector['expected']
        counts[vector['family']] += 1
        same = want['status'] == got['status']
        if same and want['status'] == 'ok':
            same = want['sha256'] == got.get('sha256')
            if 'canonical' in want:
                same = same and want['canonical'] == got.get('canonical')
        if not same:
            mismatches.append({'id': vector['id'], 'family': vector['family'], 'op': vector['op'], 'expected': want, 'actual': got})
        if want['status'] == got['status'] == 'refuse':
            layers.append({'id': vector['id'], 'python_layer': want['layer'], 'rust_layer': got['layer'], 'python_error': want['error_type'], 'rust_error': got['error']})
    return {'count': len(vectors), 'families': dict(counts), 'mismatch_count': len(mismatches), 'mismatches': mismatches, 'refusal_layers': layers}
