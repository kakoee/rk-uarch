"""Discriminating scratch reversions; every source and target is independent."""
import importlib.util,pathlib,json,shutil,hashlib,time,subprocess

def load(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
r=load('runner','/tmp/u4-c2r-run.py');c=load('comparator','/tmp/u4-c2r-comparator.py')
N=r.N;P=r.P;R=r.R;source=N/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs'
correct=source.read_text();baseline=(R/'docs/reviews/U4-A-K2-C2-probes-v1/probe.rs').read_text();rules=json.loads((N/'vectors/refusals.json').read_bytes())
vs=[]
for name in ['vectors','supplement','B-extension','A-extension']:vs+=c.records((N/'vectors'/f'{name}.jsonl').read_bytes())
variants={}
a=baseline.index('#[derive(Serialize, Deserialize)]\n#[serde(untagged)]');b=baseline.index('#[derive(Serialize, Deserialize)]\n#[serde(rename_all',a)
leaf=correct.replace('#[derive(Serialize, Deserialize)]\n#[serde(rename_all',baseline[a:b]+'#[derive(Serialize, Deserialize)]\n#[serde(rename_all',1)
a=leaf.index('        "leaf" =>');b=leaf.index('        "json-float" =>',a)
x=baseline.index('        "leaf" =>');y=baseline.index('        "sourced" =>',x)
variants['leaf']=leaf[:a]+baseline[x:y]+leaf[b:]
variants['integer-zero']=correct.replace('let normalized = normalize_integer_zero(s);','let normalized = s.to_owned();')
variants['legacy-float']=correct.replace('    #[serde(deserialize_with = "legacy_float")]\n','')
assert all(v!=correct for v in variants.values())
# Freeze literal reversion sources/selections before compiling any variant.
plan={}
for family,s in variants.items():
 V=N/'variants'/family;(V/'workspace').mkdir(parents=True);shutil.copytree(N/'workspace',V/'workspace',dirs_exist_ok=True);(V/'target').mkdir()
 (V/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs').write_text(s)
 if family=='leaf':selection=[v for v in vs if v['op']=='leaf']
 elif family=='integer-zero':selection=[v for v in vs if v['op'] in ['u128','rational','leaf'] and b'-0' in bytes.fromhex(v['hex'])]
 else:selection=[v for v in vs if v['op']=='sourced']
 raw=''.join(json.dumps(v,separators=(',',':'))+'\n' for v in selection).encode();(V/'selection.jsonl').write_bytes(raw)
 plan[family]={'source_sha256':hashlib.sha256(s.encode()).hexdigest(),'selection_sha256':hashlib.sha256(raw).hexdigest(),'count':len(selection),'corrected_source_sha256':r.sha(source),'workspace':str(V/'workspace'),'target':str(V/'target')}
(P/'reversion-plan.json').write_text(json.dumps({'time_ns':time.time_ns(),'variants':plan},indent=2)+'\n')

def variant_run(name,args,V,extra=(),stdin=None):
 cfg=json.loads((P/'container.json').read_text());argv=[x.replace('src='+str(N/'workspace')+',','src='+str(V/'workspace')+',').replace('src='+str(N/'target')+',','src='+str(V/'target')+',') for x in cfg['argv']]+list(extra)+list(args)
 if stdin is not None:argv.insert(argv.index('--rm')+1,'-i')
 start=time.time();p=subprocess.run(argv,env=cfg['environment'],capture_output=True,input=stdin)
 for ext,data in [('stdout',p.stdout),('stderr',p.stderr)]:(P/f'{name}.{ext}').write_bytes(data)
 commands=json.loads((P/'commands.json').read_text());commands.append({'name':name,'argv':argv,'environment':cfg['environment'],'exit_code':p.returncode,'seconds':time.time()-start,'stdout_sha256':r.sha(P/f'{name}.stdout'),'stderr_sha256':r.sha(P/f'{name}.stderr'),'stdin_sha256':hashlib.sha256(stdin).hexdigest() if stdin is not None else None,'network':'none','source_sha256':r.sha(V/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs'),'lock_sha256_after':r.sha(V/'workspace/native/Cargo.lock')});(P/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(name,p.returncode,flush=True);return p
reports={}
for family in variants:
 V=N/'variants'/family;raw=(V/'selection.jsonl').read_bytes();selection=c.records(raw)
 reports[family]={}
 for mode in ['debug','release']:
  tag='revert-'+family+'-'+mode;flags=['--release'] if mode=='release' else []
  env=['RUSTFLAGS=-C debuginfo=1 -C linker=/controls/linker.sh','RUSTC_WRAPPER=/controls/rustc-wrapper.sh','C2_RUN_TAG='+tag]
  p=variant_run(tag+'-build',[r.BIN+'cargo','rustc','--locked','--offline','-p','uarch-engine','--bin','c2-probe','-vv','--message-format=json',*flags,'--','-C','link-arg=-Wl,-Map=/receipts/'+tag+'.map'],V,env);assert p.returncode==0,p.stderr.decode()[-3000:]
  p=variant_run(tag+'-unit',[r.BIN+'cargo','test','--locked','--offline','-p','uarch-engine','--bin','c2-probe','-vv',*flags],V,env[:-1]+['C2_RUN_TAG='+tag+'-unit']);assert p.returncode==101
  assert b'12 tests' in p.stdout and b'FAILED' in p.stdout
  p=variant_run(tag+'-execute',['/target/'+mode+'/c2-probe'],V,stdin=raw);assert p.returncode==0
  result=c.compare(selection,c.records(p.stdout),rules);assert result['mismatch_count']>0
  positive_bad=[m['id'] for m in result['mismatches'] if m['expected']['status']=='ok'];assert positive_bad
  # Restored source/target remain untouched; run the exact same selection.
  p=r.run('restored-'+family+'-'+mode,['/target/'+mode+'/c2-probe'],stdin=raw);assert p.returncode==0
  restored=c.compare(selection,c.records(p.stdout),rules);assert restored['mismatch_count']==0
  reports[family][mode]={'reverted':result,'restored':restored,'positive_regressions':positive_bad,'reverted_binary_sha256':r.sha(V/'target'/mode/'c2-probe'),'restored_binary_sha256':r.sha(N/'target'/mode/'c2-probe')}
(P/'reversions.json').write_text(json.dumps(reports,indent=2)+'\n')
assert source.read_text()==correct
print({f:{m:r['reverted']['mismatch_count'] for m,r in ms.items()} for f,ms in reports.items()})
