import importlib.util,json,sys,pathlib
N=pathlib.Path(sys.argv[1]);path=pathlib.Path(sys.argv[2]);s=importlib.util.spec_from_file_location('subject',path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
v=[json.loads(x) for x in (N/'vectors/vectors.jsonl').read_bytes().split(b'\n')[:-1]]
a=[json.loads(x) for x in (N/'receipts/baseline-debug-vectors.stdout').read_bytes().split(b'\n')[:-1]]
rules=json.loads((N/'vectors/refusals.json').read_text());i=next(i for i,x in enumerate(v) if x['family']=='duplicates')
tests=[('empty',[],[]),('reordered',v[:2],a[:2][::-1]),('wrong-layer',v[i:i+1],[dict(a[i],layer='transport',error='unrelated')]),('wrong-reason',v[i:i+1],[dict(a[i],error='unrelated')])]
results=[]
for name,vs,acts in tests:
 try:
  r=m.compare(vs,acts,rules) if hasattr(m,'records') else m.compare(vs,acts)
  rejected=r['mismatch_count']>0
 except ValueError:rejected=True
 results.append({'name':name,'rejected':rejected})
r=m.compare(v[:2],a[:2],rules) if hasattr(m,'records') else m.compare(v[:2],a[:2]);assert r['mismatch_count']==0
print(json.dumps({'controls':results,'positive_pass':True}))
sys.exit(0 if all(x['rejected'] for x in results) else 1)
