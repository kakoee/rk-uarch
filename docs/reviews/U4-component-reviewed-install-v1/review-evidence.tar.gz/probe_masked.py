"""Reviewer probe: consistent (all joined fields forged together) /2 forgeries.

Each case is resealed; joined fields (events, queues, resource rows, busy union, critical
records, attribution) are updated together so only the targeted semantic law can refuse.
Run on the candidate (expect refusals) and on private single-guard mutants.
"""

import json
import runpy
from copy import deepcopy
from pathlib import Path

from uarch_contract.hashing import content_hash
from uarch_contract.mapped import validate_result

from validation.component.observations_v2 import check_v2

F = runpy.run_path(str(Path("docs/reviews/U4-B-component-joins-v2/synthetic_carrier.py")))
CONTRACT = dict(unrepresented=["SYNTHETIC-unit-carrier-only"])


def seal(r):
    r["result_hash"] = content_hash(r, exclude=("result_hash",))
    return r


def verdict(j, r):
    try:
        validate_result(r, j)
    except ValueError as exc:
        return "refused by validate_result: " + str(exc)[:80]
    try:
        check_v2(j.model_dump(mode="json"), r, CONTRACT)
    except ValueError as exc:
        return "refused by check_v2: " + str(exc)[:80]
    return "accepted"


def act(r, key):
    return next(a for a in r["observations"]["activities"]["records"] if a["activity_id"] == key)


def union(intervals):
    total, end = 0, 0
    for s, e in sorted(intervals):
        total += max(0, e - max(s, end))
        end = max(end, e)
    return total


def rebusy(r):
    rows = r["observations"]["resource_intervals"]["records"]
    for b in r["busy_time_ps"]:
        b["busy_time_ps"] = union(
            (x["start_ps"], x["end_ps"]) for x in rows if x["owner_id"] == b["owner_id"]
        )


out = {}
# M1 (B workings: "A correct makespan with DRAM alignment relabelled NoC must fail"):
# D10 response-NoC alignment relabelled memory, with critical record and attribution moved too.
j = F["synthetic_job"]("D10-read")
r = F["synthetic_result"](j)
out["control D10"] = verdict(j, seal(deepcopy(r)))
a = act(r, "back-a")
a["category"] = "memory"
for c in r["observations"]["critical_path"]["records"]:
    if c["activity_id"] == "back-a":
        c["category"] = "memory"
        r["attribution_ps"]["noc"] -= c["end_ps"] - c["start_ps"]
        r["attribution_ps"]["memory"] += c["end_ps"] - c["start_ps"]
out["M1 D10 alignment category noc->memory (consistent)"] = verdict(j, seal(r))

# M2: D01 request-NoC service attributed to dma_port:0 instead of its router, with events,
# resource row, queue rows, busy union and critical limiting resource moved consistently.
j = F["synthetic_job"]()
r = F["synthetic_result"](j)
owners = {o.resource: o.owner_id for o in j.owners}
port, router = owners["dma_port:0"], owners["router:0:0:0"]
a = act(r, "out")
a["owner_id"] = port
for e in r["observations"]["events"]["records"]:
    if e["observation_ordinal"] in (a["dispatch_ordinal"], a["completion_ordinal"]):
        e["target_id"] = port
for x in r["observations"]["resource_intervals"]["records"]:
    if x["activity_id"] == "out":
        x["owner_id"] = x["limiting_resource_id"] = port
for q in r["observations"]["queue_membership"]["records"]:
    if q["activity_id"] == "out":
        q["owner_id"] = port
        q["queue_id"] = f"activity:request_noc:{port}"
for c in r["observations"]["critical_path"]["records"]:
    if c["activity_id"] == "out":
        c["limiting_resource_id"] = port
rebusy(r)
out["M2 D01 request hop owned by dma_port:0 (consistent)"] = verdict(j, seal(r))

# M3: D08 off-chain r01 response alignment with no causal predecessor at start 54250.
j = F["synthetic_job"]("D08")
r = F["synthetic_port_pair"](j)
act(r, "r1:back-a")["predecessors"] = []
out["M3 D08 off-chain activity with no tight cause"] = verdict(j, seal(r))
# M4: D01 channel service declared non-occupying (no resource row), then given a wrong
# service end 54500 (law: 52000 + 159744/71 -> 54250). The response alignment absorbs the
# difference (still ends at the 55000 NoC edge), so every downstream time is unchanged.
j = F["synthetic_job"]()
r = F["synthetic_result"](j)
ch, ba = act(r, "channel"), act(r, "back-a")
r["observations"]["resource_intervals"]["records"] = [
    x for x in r["observations"]["resource_intervals"]["records"] if x["activity_id"] != "channel"
]
ch["occupies_resource"] = False
out["M4a D01 channel service non-occupying, correct times"] = verdict(
    j, seal(rebusy(r) or deepcopy(r))
)
ch["end_ps"] = 54500
ba["ready_ps"] = ba["start_ps"] = 54500
for e in r["observations"]["events"]["records"]:
    if e["observation_ordinal"] in (ch["completion_ordinal"], ba["dispatch_ordinal"]):
        e["t_ps"] = 54500
for q in r["observations"]["queue_membership"]["records"]:
    if (
        q["item_id"] == ch["request_id"]
        and q["queue_id"].startswith("channel_service:")
        and q["population"] == "service"
    ):
        q["leave_ps"] = 54500
    if q["activity_id"] == "back-a":
        if q["population"] == "waiting":
            q["enter_ps"] = q["leave_ps"] = 54500
        else:
            q["enter_ps"] = 54500
for t in r["observations"]["transfers"]["records"]:
    if t["boundary_id"] == "dram":
        t["leave_ps"] = 54500
    if t["boundary_id"] == "response_noc":
        t["enter_ps"] = 54500
for c in r["observations"]["clocks"]["records"]:
    if c["activity_id"] == "back-a":
        c["grant_ps"] = 54500
crit = r["observations"]["critical_path"]["records"]
for c in crit:
    if c["activity_id"] == "channel":
        c["end_ps"] = 54500
    if c["activity_id"] == "back-a":
        c["start_ps"] = 54500
r["attribution_ps"]["memory"] += 250
r["attribution_ps"]["noc"] -= 250
rebusy(r)
out["M4b D01 non-occupying channel with WRONG service end 54500"] = verdict(j, seal(r))
print(json.dumps(out, indent=1))
