"""F5 recheck probe (export root = cwd): independent law and full diff of B's D01 carriers.

Builds the valid and forged D01 carriers exactly as the new test states (B's control and
synchronize helpers), then checks them with reviewer-owned arithmetic and a field diff:
* lawful response end = next 1 GHz NoC edge >= 55000 plus four cycles (own edge search);
* forged end 58500, n_cycles still 4, clock completion joined to 58500;
* receiving port alignment 58500 -> its own lawful core edge 59000; port service unchanged;
* every other activity, job, request, count and the makespan unchanged;
* structural validate_result admits the forgery; check_v2 refuses with exactly
  "mechanism duration". Synthetic unit carriers only; never native evidence.
"""

import json  # noqa: I001 - candidate-only validation modules are absent on main
from copy import deepcopy
from fractions import Fraction
from math import ceil

from uarch_contract.mapped import validate_result

from validation.component.consistent_carriers import EXPECTED, activity, control, synchronize
from validation.component.observations_v2 import check_v2


def edge(hz: int, at: int, cycles: int = 0) -> int:
    k = 0
    while ceil(Fraction(k * 10**12, hz)) < at:
        k += 1
    return ceil(Fraction((k + cycles) * 10**12, hz))


def layers(job, result):
    out = {}
    try:
        validate_result(deepcopy(result), job)
        out["validate_result"] = "accepted"
    except Exception as exc:  # noqa: BLE001
        out["validate_result"] = f"refused {type(exc).__name__}: {exc}"
    try:
        check_v2(job.model_dump(mode="json"), deepcopy(result), EXPECTED)
        out["check_v2"] = "accepted"
    except Exception as exc:  # noqa: BLE001
        out["check_v2"] = f"refused {type(exc).__name__}: {exc}"
    return out


job, valid = control("D01")
forged = deepcopy(valid)
activity(forged, "back")["end_ps"] = 58500
activity(forged, "port-a").update(ready_ps=58500, start_ps=58500)
forged = synchronize(forged)
noc, core = job.freq_hz.noc, job.freq_hz.core
back_v, back_f = activity(valid, "back"), activity(forged, "back")
graph = job.mapped_point.task_graph
fragment = next(
    f
    for t in graph.jobs
    if t.kind == "dma"
    for f in t.fragments
    if f.request_id == back_v["request_id"]
)
route = next(r for r in graph.routes if r.id == fragment.route_id)
hops = len(route.core_ids) - 1
latency = int(job.workload_closure.hardware_spec.nocs[0].router_latency_cycles.value)
cycles = hops * latency
lawful = edge(noc, back_v["start_ps"], cycles)
clock_f = next(c for c in forged["observations"]["clocks"]["records"] if c["activity_id"] == "back")
acts_v = {a["activity_id"]: a for a in valid["observations"]["activities"]["records"]}
acts_f = {a["activity_id"]: a for a in forged["observations"]["activities"]["records"]}
changed = sorted(
    k
    for k in acts_v
    if {x: y for x, y in acts_v[k].items() if "ordinal" not in x}
    != {x: y for x, y in acts_f[k].items() if "ordinal" not in x}
)
report = dict(
    hz=dict(noc=noc, core=core),
    valid_back=(back_v["start_ps"], back_v["end_ps"]),
    lawful_end_ps=lawful,
    forged_back=(back_f["start_ps"], back_f["end_ps"]),
    forged_clock=(clock_f["grant_ps"], clock_f["n_cycles"], clock_f["completion_ps"]),
    forged_port_alignment=(
        activity(forged, "port-a")["ready_ps"],
        activity(forged, "port-a")["end_ps"],
    ),
    lawful_port_alignment_end=edge(core, 58500, 0),
    activities_changed_except_ordinals=changed,
    port_service_unchanged=activity(forged, "port") == activity(valid, "port"),
    makespan=(valid["duration_ps"], forged["duration_ps"]),
    counts_work_traffic_unchanged=all(
        forged[k] == valid[k] for k in ("counts", "work_counts", "traffic_counts", "per_op")
    ),
    jobs_dma_unchanged=all(
        forged["observations"][t] == valid["observations"][t] for t in ("jobs", "dma")
    ),
    attribution=(valid["attribution_ps"], forged["attribution_ps"]),
    valid_layers=layers(job, valid),
    forged_layers=layers(job, forged),
)
report["law_checks"] = dict(
    lawful_end_is_59000=lawful == 59000,
    forged_end_differs_from_law=back_f["end_ps"] != lawful,
    n_cycles_truthful=clock_f["n_cycles"] == cycles,
    exact_refusal=report["forged_layers"]["check_v2"] == "refused CheckFailure: mechanism duration",
    structural_admission=report["forged_layers"]["validate_result"] == "accepted",
)
print(json.dumps(report, indent=1))
