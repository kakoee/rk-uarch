"""F5 recheck: remove ONLY check_v2's `mechanism duration` guard in a private export.

usage: python -I single_guard_f5.py <private_export> <runner.py> <probe_dir>
Runs, with the guard removed: the two new tests (-v), the reviewer recheck probe, the
reviewer's unchanged Stage 3 F5 probe and B's old masked duration test. Restores exact
bytes (SHA256 asserted), then reruns the new tests and the recheck probe. Classifies each
pytest failure: DID NOT RAISE = unsafe acceptance; regex mismatch = alternative refusal.
"""

import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root, runner, probes = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
rel = "validation/component/observations_v2.py"
EXPECTED_SHA = "dd9c049b2fb2f28e2b6cbba04e5b3b627a6e7e4dbfcf3cbaf305969587915d62"
NEW = "validation/component/test_f5_mechanism_duration.py"
OLD = (
    "validation/component/test_consistent_observations.py::"
    "test_mechanism_and_field_forgery[duration-mechanism duration]"
)
path = root / rel
original = path.read_bytes()
assert hashlib.sha256(original).hexdigest() == EXPECTED_SHA
src = original.decode()
fn = next(
    n for n in ast.walk(ast.parse(src)) if isinstance(n, ast.FunctionDef) and n.name == "check_v2"
)
sites = [
    n
    for n in ast.walk(fn)
    if isinstance(n, ast.Call)
    and isinstance(n.func, ast.Name)
    and n.func.id == "need"
    and n.args
    and isinstance(n.args[-1], ast.Constant)
    and n.args[-1].value == "mechanism duration"
]
assert len(sites) == 1, len(sites)
site = sites[0]
lines = src.splitlines(keepends=True)
line = lines[site.lineno - 1]
assert line[site.col_offset : site.col_offset + 5] == "need("
lines[site.lineno - 1] = (
    line[: site.col_offset] + "(lambda *_a, **_k: None)(" + line[site.col_offset + 5 :]
)
mutant = "".join(lines)
assert sum(a != b for a, b in zip(src.splitlines(), mutant.splitlines(), strict=True)) == 1


def run(*args: str) -> tuple[int, str]:
    p = subprocess.run(
        [sys.executable, "-I", runner, str(root), *args],
        capture_output=True,
        text=True,
        timeout=600,
    )
    return p.returncode, p.stdout


def classify(text: str, code: int) -> str:
    if code == 0:
        return "passed"
    if "DID NOT RAISE" in text:
        return "failed: DID NOT RAISE (unsafe acceptance)"
    if "Regex pattern did not match" in text:
        return "failed: alternative refusal (regex mismatch)"
    return "failed: other"


def probe(name: str) -> dict:
    code, text = run("script", str(probes / name))
    body = text[: text.index("REVIEW-ORIGINS")]
    return dict(
        exit=code,
        result=json.loads(body),
        origins_ok='"live_modules": []' in text and str(root) in text,
    )


record: dict = dict(
    guard_line=site.lineno,
    guard_source=line.strip(),
    original_sha256=EXPECTED_SHA,
    mutant_sha256=hashlib.sha256(mutant.encode()).hexdigest(),
    changed_lines=1,
)
try:
    path.write_text(mutant)
    code, text = run("pytest", "-v", "-p", "no:randomly", NEW)
    record["removed_new_tests"] = dict(
        exit=code,
        nodes=[
            x for x in text.splitlines() if "::test_d01" in x and ("PASSED" in x or "FAILED" in x)
        ],
        failure_kind=classify(text, code),
        did_not_raise_line=[x.strip() for x in text.splitlines() if "DID NOT RAISE" in x][:2],
    )
    record["removed_recheck_probe"] = probe("probe_f5_recheck.py")
    record["removed_stage3_probe"] = probe("stage3_probe_f5_duration.py")
    code, text = run("pytest", "-q", "-p", "no:randomly", OLD)
    record["removed_old_masked_test"] = dict(exit=code, failure_kind=classify(text, code))
finally:
    path.write_bytes(original)
record["restored_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
record["restored_exact_bytes"] = record["restored_sha256"] == EXPECTED_SHA
code, text = run("pytest", "-q", "-p", "no:randomly", NEW)
record["restored_new_tests"] = dict(
    exit=code, summary=[x for x in text.splitlines() if " passed" in x or " failed" in x][-1:]
)
record["restored_recheck_probe"] = probe("probe_f5_recheck.py")
print(json.dumps(record, indent=1))
