"""Reviewer scalar re-derivation (no project imports). Reads only the fixture's hardware numbers.

Edges are enumerated as ceil(k * 1e12 / hz) by direct search, not by any project helper.
Asserts B's observation-workings and the accumulator/arithmetic literals in the selection.
"""

import json
import sys
from fractions import Fraction
from math import ceil
from pathlib import Path

hw = json.loads(
    Path(
        sys.argv[1] if len(sys.argv) > 1 else "contract/fixtures/mapped/component.json"
    ).read_text()
)["hardware_spec"]
v = lambda x: int(x["value"])  # noqa: E731
core = hw["cores"]["core_type"]
dram = hw["memory"]["dram"]
t = dram["timing"]
RATE = v(core["matrix_engine"]["operand_bytes_per_cycle"])  # 1024 B/cycle
ACC = v(core["matrix_engine"]["accumulator_bytes"])  # 262144 B
HOP = v(hw["nocs"][0]["router_latency_cycles"])  # 2 cycles
LAT = v(t["t_cl_cycles"]) + v(t["t_rcd_cycles"]) + v(t["t_rp_cycles"])  # 48 cycles
BW = Fraction(v(dram["bw_bytes_per_s"]), v(dram["channels"])) * Fraction(
    v(t["t_refi_cycles"]) - v(t["t_rfc_cycles"]), v(t["t_refi_cycles"])
)
SERVICE = Fraction(256 * 10**12) / BW
PORT = v(core["dma"]["bytes_per_cycle"])


def edge(hz, at, n=0):
    k = 0
    while ceil(Fraction(k * 10**12, hz)) < at:
        k += 1
    return ceil(Fraction((k + n) * 10**12, hz))


def tile(m, k, n):
    stage = ceil(Fraction(2 * m * k + 2 * k * n, RATE))
    drain = ceil(Fraction(2 * m * n, RATE))
    cycles = 32 + stage + 510 + m + drain
    return dict(
        ps=edge(10**9, 0, cycles),
        useful=2 * m * k * n,
        issued=2 * m * 256 * 256,
        read=2 * m * k + 2 * k * n,
        write=2 * m * n,
        acc=4 * m * n,
        stage=stage,
        drain=drain,
    )


checks = {}
assert SERVICE == Fraction(159744, 71)
checks["service_ps"] = str(SERVICE)
c02, c01 = tile(3, 5, 7), tile(16, 256, 256)
assert (c02["ps"], c02["useful"], c02["issued"], c02["read"], c02["write"], c02["acc"]) == (
    547000,
    210,
    393216,
    100,
    42,
    84,
)
assert (c01["ps"], c01["useful"], c01["read"], c01["write"], c01["acc"], c01["stage"]) == (
    702000,
    2097152,
    139264,
    8192,
    16384,
    136,
)
# D01 remote read core0 -> channel6 (controller 3 at core 3): two hops each way, 1 GHz.
G = 10**9
out = edge(G, 0, 2 * HOP)
lat = edge(G, out, LAT)
ch = Fraction(lat) + SERVICE
back = edge(G, edge(G, ceil(ch)), 2 * HOP)
port = edge(G, back, ceil(Fraction(256, PORT)))
assert (out, lat, ch, ceil(ch), edge(G, ceil(ch)), back, port) == (
    4000,
    52000,
    Fraction(3851744, 71),
    54250,
    55000,
    59000,
    60000,
)
assert (lat - out) + (ceil(ch) - lat) + (port - back) == 51250
assert out + (edge(G, ceil(ch)) - ceil(ch)) + (back - edge(G, ceil(ch))) == 8750
# D10 unequal clocks: core 800 MHz, noc 1.2 GHz, dram 900 MHz.
C, N, D = 800 * 10**6, 1200 * 10**6, 900 * 10**6
out = edge(N, 0, 2 * HOP)
lat_a = edge(D, out)
lat = edge(D, lat_a, LAT)
ch = Fraction(lat) + SERVICE
back_a = edge(N, ceil(ch))
back = edge(N, back_a, 2 * HOP)
port = edge(C, back, 1)
assert (out, lat_a, lat, ch, ceil(ch), back_a, back, port) == (
    3334,
    3334,
    56667,
    Fraction(4183101, 71),
    58917,
    59167,
    62500,
    63750,
)
assert (lat - lat_a) + (ceil(ch) - lat) + (port - back) == 56833
assert out + (back_a - ceil(ch)) + (back - back_a) == 6917
# C05 cold: X/W on channels 0/1 (zero hop), shared port, compute, Y write one hop.
ready = ceil(Fraction(LAT * 1000) + SERVICE)
x_port = (edge(G, ready), edge(G, ready, 1))
w_port = (x_port[1], edge(G, x_port[1], 1))
comp_end = w_port[1] + c02["ps"]
wp = edge(G, comp_end, 1)
wo = edge(G, wp, HOP)
wl = edge(G, wo, LAT)
wch = Fraction(wl) + SERVICE
wb = edge(G, edge(G, ceil(wch)), HOP)
assert (ready, x_port, w_port, comp_end, wp, wo, wl, ceil(wch), wb) == (
    50250,
    (51000, 52000),
    (52000, 53000),
    600000,
    601000,
    603000,
    651000,
    653250,
    656000,
)
memory = (
    LAT * 1000
    + (ready - LAT * 1000)
    + (x_port[0] - ready)
    + 1000
    + 1000
    + 1000
    + (wl - wo)
    + (ceil(wch) - wl)
)
noc = (wo - wp) + (edge(G, ceil(wch)) - ceil(wch)) + (wb - edge(G, ceil(wch)))
assert (memory, noc, memory + noc + c02["ps"]) == (104250, 4750, 656000)
# D04 rational carry: twelve queued 256B services on one channel from 52000.
assert Fraction(52000) + 12 * SERVICE == Fraction(5608928, 71)
assert ceil(Fraction(5608928, 71)) == 78999 and 52000 + 12 * ceil(SERVICE) == 79000
# D14 zero-hop vs wrong 1.2 GHz realignment.
assert edge(N, 61000) == 61667
# Accumulator @2 literals.
big, tail, n255 = tile(256, 256, 256), tile(1, 256, 256), tile(256, 256, 255)
assert (big["acc"], tail["acc"], n255["acc"]) == (262144, 1024, 261120)
assert big["acc"] + tail["acc"] > ACC and n255["acc"] + big["acc"] > ACC
assert big["ps"] + tail["ps"] == 1855000 and big["ps"] == 1182000
assert big["useful"] + tail["useful"] == 33685504
assert (big["read"] + tail["read"], big["write"] + tail["write"]) == (393728, 131584)
assert n255["ps"] + big["ps"] == 2364000
assert (n255["useful"] + big["useful"], n255["issued"] + big["issued"]) == (66977792, 67108864)
assert (n255["read"] + big["read"], n255["write"] + big["write"]) == (523776, 261632)
assert (2 * big["useful"], 2 * big["read"], 2 * big["write"]) == (67108864, 524288, 262144)
checks["result"] = "all re-derived literals match B workings and selection expectations"
print(json.dumps(checks))
