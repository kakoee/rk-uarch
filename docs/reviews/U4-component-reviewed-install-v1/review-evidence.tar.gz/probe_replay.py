"""Reviewer probe: @2 producer-disabled bundle/job replay and consumer refusals on @2 inputs.

Export root = cwd. The mapper module is blocked (sys.modules entry None) before loading, so
load/prepare cannot silently re-map. Production invocation with installed fixture anchors.
"""

import json
import sys
import tempfile
from copy import deepcopy
from pathlib import Path

ROOT = Path.cwd()
FIX = ROOT / "docs/reviews/U4-B-component-joins-v2/fixtures"
out = {}
# Build the @2 bundle with the mapper first, then block mapping for every replay step.
from uarch_contract.hashing import canonical_json, content_hash  # noqa: E402
from uarch_contract.mapped import MappedBundle, NativeEngineIdentity  # noqa: E402

cold = MappedBundle.model_validate(json.loads((FIX / "A2-255-256-cold.json").read_text())["bundle"])
base = json.loads((ROOT / "contract/fixtures/mapped/component.json").read_text())
# Production invocation needs the installed fixture's admission (cold, production hardware).
raw = cold.model_dump(mode="json")
raw["admission"] = base["admission"]
raw["bundle_hash"] = content_hash(raw, exclude=("bundle_hash",))
for name in list(sys.modules):
    if name.startswith("rkuarch.mapping"):
        del sys.modules[name]
sys.modules["rkuarch.mapping"] = None  # type: ignore[assignment]
sys.modules["rkuarch.mapping.component"] = None  # type: ignore[assignment]
from rkuarch.workload.component import prepare_component_job  # noqa: E402
from rkuarch.workload.mapped import (  # noqa: E402
    export_component_bundle,
    export_component_job,
    loads_component_bundle,
    loads_component_job,
)

registry = json.loads((ROOT / "contract/fixtures/mapped/registry.json").read_text())
template = json.loads((ROOT / "contract/fixtures/mapped/component-job.json").read_text())
engine = NativeEngineIdentity.model_validate(template["engine"])
args = dict(
    invocation="production",
    registry=registry,
    profile=None,
    trusted_registry_hash=registry["registry_hash"],
    trusted_profile_hash=None,
)
jobargs = dict(
    invocation="production",
    trusted_registry_hash=registry["registry_hash"],
    trusted_profile_hash=None,
    expected_engine=engine,
)
with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / "bundle.json"
    export_component_bundle(raw, path, **args)
    loaded = loads_component_bundle(path.read_bytes(), **args)
    out["@2 bundle export->load model equality (mapper blocked)"] = (
        loaded == MappedBundle.model_validate(raw)
    )
    out["@2 bundle re-export bytes identical"] = canonical_json(loaded) == canonical_json(
        MappedBundle.model_validate(raw)
    )
    out["@2 bundle policy after replay"] = loaded.mapping_policy.version
    job = prepare_component_job(
        loaded, point_hash=loaded.points[0].payload_hash, expected_engine=engine, **args
    )
    jpath = Path(tmp) / "job.json"
    export_component_job(job.model_dump(mode="json"), jpath, **{k: v for k, v in jobargs.items()})
    again = loads_component_job(jpath.read_bytes(), **jobargs)
    out["@2 job export->load equality (mapper blocked)"] = again == job
    out["@2 job twice identical hash"] = (
        prepare_component_job(
            loaded, point_hash=loaded.points[0].payload_hash, expected_engine=engine, **args
        ).job_hash
        == job.job_hash
    )


def code(fn):
    try:
        fn()
        return "success"
    except ValueError as exc:
        return str(exc).split(":", 1)[0]


def seal(r):
    for p in r["points"]:
        g = p["task_graph"]
        for key in ("buffers", "jobs", "routes"):
            g[key].sort(key=lambda x: x["id"])
        g["dependencies"].sort(key=lambda x: (x["before"], x["after"]))
        g["graph_hash"] = content_hash(g, exclude=("graph_hash",))
        p["payload_hash"] = content_hash(p, exclude=("payload_hash",))
    r["bundle_hash"] = content_hash(r, exclude=("bundle_hash",))
    return r


for fault in ("operand_access", "input", "output", "barrier"):
    bad = deepcopy(raw)
    g = bad["points"][0]["task_graph"]
    if fault == "operand_access":
        bad["scope"]["ops"][0]["operand_access"].pop("X")
    elif fault == "input":
        dma = next(j for j in g["jobs"] if j["kind"] == "dma" and j["direction"] == "read")
        dma["source"]["size_bytes"] = dma["destination"]["size_bytes"] = 2
        dma["fragments"] = dma["fragments"][:1]
        dma["fragments"][0]["payload_bytes"] = 2
    elif fault == "output":
        dma = next(j for j in g["jobs"] if j["kind"] == "dma" and j["direction"] == "write")
        g["jobs"].remove(dma)
        g["buffers"] = [x for x in g["buffers"] if x["id"] != dma["destination"]["buffer_id"]]
        next(x for x in g["buffers"] if x["id"] == dma["source"]["buffer_id"])[
            "final_consumer_ids"
        ] = []
        g["dependencies"] = [x for x in g["dependencies"] if x["after"] != dma["id"]]
    else:
        barriers = [j for j in g["jobs"] if j["kind"] == "barrier"]
        if not barriers:
            out["@2 barrier fault"] = "n/a (A2 has no dependent op barrier)"
            continue
        barriers[0]["owner_id"] = 0
    seal(bad)
    out[f"@2 consumer refusal {fault} at bundle load"] = code(
        lambda bad=bad: loads_component_bundle(canonical_json(bad), **args)
    )
print(json.dumps(out, indent=1))
