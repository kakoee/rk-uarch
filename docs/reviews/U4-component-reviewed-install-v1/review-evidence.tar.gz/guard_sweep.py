"""Reviewer guard-removal sweep (private mutant export only; exact bytes restored each time).

usage: python -I guard_sweep.py <mutant_export> <runner.py> <file> <func> <call> <tests...>
Disables one `<call>(` statement at a time inside function <func> of <file> by rewriting it
to `(lambda *_a, **_k: None)(`, runs the given tests, and records whether any test failed.
A surviving mutant means no selected test discriminates that guard.
"""

import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root, runner, rel, func, call, *tests = sys.argv[1:]
path = Path(root) / rel
original = path.read_bytes()
digest = hashlib.sha256(original).hexdigest()
source = original.decode()
tree = ast.parse(source)
target = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == func)
sites = sorted(
    {
        (n.lineno, n.col_offset)
        for n in ast.walk(target)
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == call
    }
)
lines = source.splitlines(keepends=True)
results = []
python = sys.executable
try:
    for lineno, col in sites:
        mutated = list(lines)
        line = mutated[lineno - 1]
        assert line[col : col + len(call) + 1] == call + "(", (lineno, line)
        mutated[lineno - 1] = line[:col] + "(lambda *_a, **_k: None)(" + line[col + len(call) + 1 :]
        path.write_text("".join(mutated))
        proc = subprocess.run(
            [python, "-I", runner, root, "pytest", "-q", "-x", "-p", "no:randomly", *tests],
            capture_output=True,
            text=True,
            timeout=600,
        )
        path.write_bytes(original)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
        tail = (proc.stdout.strip().splitlines() or [""])[-2]
        snippet = line.strip()[:110]
        results.append(
            dict(line=lineno, guard=snippet, killed=proc.returncode != 0, summary=tail[:120])
        )
        print(
            ("KILLED  " if proc.returncode else "SURVIVED") + f" {rel}:{lineno} {snippet}",
            flush=True,
        )
finally:
    path.write_bytes(original)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
print(
    json.dumps(
        dict(
            file=rel,
            function=func,
            restored_sha256=digest,
            tests=tests,
            mutants=len(results),
            survived=[r for r in results if not r["killed"]],
        ),
        indent=1,
    )
)
