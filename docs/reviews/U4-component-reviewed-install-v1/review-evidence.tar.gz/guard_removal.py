"""Reviewer private guard removal with exact-byte restoration and affected retest.

usage: python -I guard_removal.py <mutant_export> <runner.py> <guard-name> [tests...]
Applies ONE named textual guard removal to the mutant export, runs probe_accumulator.py and
probe_causal.py plus the given tests there, restores exact bytes (sha256 checked), then reruns
the same tests restored. Never touches the live clone or the candidate export.
"""

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MAPPED = "contract/uarch_contract/mapped.py"
GUARDS = {
    "writer": (
        MAPPED,
        "isinstance(producer, Compute) and producer.accumulator_buffer_id == buf.id",
        "True",
    ),
    "final-consumers": (
        MAPPED,
        'set(buf.final_consumer_ids) == terminal, "InvalidDependency"',
        'True, "InvalidDependency"',
    ),
    "live-alias": (MAPPED, "ends_before(a, z) or ends_before(z, a)", "True"),
    "owner": (
        MAPPED,
        'producer.core_id == buf.core_id, "InvalidResource"',
        'True, "InvalidResource"',
    ),
    "use-before-production": (
        MAPPED,
        "acc.producer_id == job.id or acc.producer_id in ancestors[job.id],",
        "True,",
    ),
    "capacity": (MAPPED, "buf.offset_bytes + buf.size_bytes <= capacity,", "True,"),
    "category-domain": (
        MAPPED,
        "require(a.category == category and a.receiving_domain == domain, "
        '"IncompleteObservations")',
        "pass",
    ),
    "activity-owner": (
        MAPPED,
        'require(resource == expected_owner, "InvalidResource", "activity owner")',
        "pass",
    ),
    "tight-cause": (
        MAPPED,
        'a.start_ps == 0 or bool(a.predecessors), "AttributionMismatch", "missing tight cause"',
        'True, "AttributionMismatch", "missing tight cause"',
    ),
    "activity-cycle": (
        MAPPED,
        'require(bool(ready), "AttributionMismatch", "activity cycle")',
        "if not ready: break",
    ),
}

root, runner, name, *tests = sys.argv[1:]
rel, before, after = GUARDS[name]
path = Path(root) / rel
original = path.read_bytes()
digest = hashlib.sha256(original).hexdigest()
body = original.decode()
assert body.count(before) == 1, (name, body.count(before))
env = dict(os.environ, REVIEW_SKIP_SWEEP="1")
py = sys.executable
record = dict(guard=name, path=rel, before=before, after=after, original_sha256=digest)


def run(argv, timeout=900):
    try:
        p = subprocess.run(argv, capture_output=True, text=True, env=env, timeout=timeout)
        return p.returncode, p.stdout
    except subprocess.TimeoutExpired as exc:
        return "timeout", (exc.stdout or b"").decode() if isinstance(exc.stdout, bytes) else (
            exc.stdout or ""
        )


def probe(script, timeout=900):
    code, text = run([py, "-I", runner, root, "script", str(HERE / script)], timeout)
    if code != 0:
        return dict(exit=code, tail=text[-400:])
    return json.loads(text[: text.index("REVIEW-ORIGINS")])


try:
    path.write_text(body.replace(before, after))
    record["mutant_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    for script in os.environ.get("REVIEW_PROBES", "probe_accumulator.py,probe_causal.py").split(
        ","
    ):
        record["removed_" + script[:-3]] = probe(script, timeout=900)
    if tests:
        code, text = run([py, "-I", runner, root, "pytest", "-q", "-p", "no:randomly", *tests])
        record["removed_tests"] = dict(
            exit=code,
            summary=[x for x in text.splitlines() if "passed" in x or "failed" in x][-1:],
            failures=[x for x in text.splitlines() if x.startswith("FAILED")][:40],
        )
finally:
    path.write_bytes(original)
    record["restored_exact_bytes"] = hashlib.sha256(path.read_bytes()).hexdigest() == digest
assert record["restored_exact_bytes"]
if tests:
    code, text = run([py, "-I", runner, root, "pytest", "-q", "-p", "no:randomly", *tests])
    record["restored_tests"] = dict(
        exit=code, summary=[x for x in text.splitlines() if "passed" in x or "failed" in x][-1:]
    )
print(json.dumps(record, indent=1, sort_keys=True))
