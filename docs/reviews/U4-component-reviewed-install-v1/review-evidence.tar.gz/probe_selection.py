"""Reviewer probe: independent inventory/admission of B's 99-cell selection (export root = cwd).

Synthetic anchors only: each input's own profile hash is supplied as the trusted anchor,
exactly as a unit test would. This confers no authority and runs no engine.
Prints one JSON object; exits nonzero on any mismatch.
"""

import collections
import hashlib
import json
import sys
from pathlib import Path

from uarch_contract.hashing import content_hash
from uarch_contract.mapped import MappedBundle, NativeTestProfile, admit

from validation.component.corpus import build, manifest

ROOT = Path.cwd()
SEL = ROOT / "docs/reviews/U4-B-component-joins-v2/execution-selection.json"
problems: list[str] = []


def code_of(fn):
    try:
        fn()
        return "success"
    except ValueError as exc:
        return str(exc).split(":", 1)[0].strip()


s = json.loads(SEL.read_text())
if s["selection_hash"] != content_hash(s, exclude=("selection_hash",)):
    problems.append("selection hash")
cases = s["cases"]
ids = [c["case_id"] for c in cases]
if len(ids) != 99 or len(set(ids)) != 99:
    problems.append("case inventory")
origins = collections.Counter(c["origin"] for c in cases)
layers = collections.Counter((c["origin"].split()[0], c["expected_layer"]) for c in cases)
for c in cases:
    for k in ("job_hash", "engine_identity", "build_identity", "authority"):
        if c.get(k) is not None:
            problems.append(f"{c['case_id']} {k} not null")
    if c["native_status"] != "not_run":
        problems.append(f"{c['case_id']} native status")
    if c.get("raw_request_sha256") is not None:
        problems.append(f"{c['case_id']} raw request present")
bundle_dups = [h for h, n in collections.Counter(c["bundle_hash"] for c in cases).items() if n > 1]
graph_dups = collections.Counter(c["graph_hash"] for c in cases)
shared_graphs = {
    h: sorted(c["case_id"] for c in cases if c["graph_hash"] == h)
    for h, n in graph_dups.items()
    if n > 1
}
historical = {x["case_id"]: x for x in manifest()["cases"]}
for c in cases:
    if c["origin"].startswith("B historical"):
        old = historical[c["case_id"]]
        if any(c[k] != v for k, v in old.items()):
            problems.append(f"{c['case_id']} historical drift")
corpus = build()
registry = corpus["registry"]
outcomes = {}
for c in cases:
    if c["origin"].startswith("B historical") and c["expected_layer"] == "profile":
        item = corpus["items"][c["case_id"]]
        got = code_of(
            lambda item=item: admit(
                item["bundle"],
                invocation="test",
                checkpoint="B",
                registry=registry,
                profile=item["profile"],
                trusted_registry_hash=registry["registry_hash"],
                trusted_profile_hash=item["profile"]["profile_hash"],
            )
        )
        outcomes[c["case_id"]] = got
        if got != "TestVariantNotAdmitted":
            problems.append(f"{c['case_id']} profile layer {got}")
    if "input_path" not in c:
        continue
    data = (ROOT / c["input_path"]).read_bytes()
    if hashlib.sha256(data).hexdigest() != c["input_sha256"]:
        problems.append(f"{c['case_id']} input bytes")
    raw = json.loads(data)
    if "bundle" in raw:
        bundle, profile = raw["bundle"], raw["profile"]
        if NativeTestProfile.model_validate(profile).profile_hash != c["profile_hash"]:
            problems.append(f"{c['case_id']} profile identity")
        if raw["expected"] != c["expected"] or content_hash(raw["expected"]) != c["expected_hash"]:
            problems.append(f"{c['case_id']} expected binding")
        got = code_of(
            lambda b=bundle, p=profile: admit(
                b,
                invocation="test",
                checkpoint="B",
                registry=registry,
                profile=p,
                trusted_registry_hash=registry["registry_hash"],
                trusted_profile_hash=p["profile_hash"],
            )
        )
    else:
        bundle = raw
        b = MappedBundle.model_validate(bundle)
        from uarch_contract.mapped import validate_resources

        got = code_of(lambda b=b: validate_resources(b, b.points[0]))
    b = MappedBundle.model_validate(bundle)
    if (b.bundle_hash, b.points[0].payload_hash, b.points[0].task_graph.graph_hash) != (
        c["bundle_hash"],
        c["point_hash"],
        c["graph_hash"],
    ):
        problems.append(f"{c['case_id']} identity")
    outcomes[c["case_id"]] = dict(
        got=got,
        expected=c["expected_public_code"],
        policy=b.mapping_policy.version,
        state=b.points[0].initial_state,
        producer=b.producer.name,
    )
    if got != c["expected_public_code"]:
        problems.append(f"{c['case_id']} outcome {got} != {c['expected_public_code']}")
fid = json.loads(
    (ROOT / "docs/reviews/U4-A-component-release-v1/fixture-identities.json").read_text()
)
for name, row in fid.items():
    c = next(x for x in cases if x["case_id"] == name)
    if (row["bundle_hash"], row["graph_hash"], row["point_hash"], row["profile_hash"]) != (
        c["bundle_hash"],
        c["graph_hash"],
        c["point_hash"],
        c["profile_hash"],
    ):
        problems.append(f"{name} A identity join")
for path, digest in s["checker_bindings"].items():
    if hashlib.sha256((ROOT / path).read_bytes()).hexdigest() != digest:
        problems.append(f"checker binding {path}")
report = dict(
    cases=len(cases),
    origins=dict(origins),
    layers={" / ".join(k): v for k, v in sorted(layers.items())},
    duplicate_bundle_hashes=bundle_dups,
    shared_graph_hashes=shared_graphs,
    input_outcomes=outcomes,
    problems=problems,
)
print(json.dumps(report, indent=1, sort_keys=True))
sys.exit(1 if problems else 0)
