"""Reviewer accumulator/mapper probe (export root = cwd). Synthetic unit anchors only.

Prints {case: outcome}. Intended to be run on the exact candidate and, unchanged, on private
guard-removal mutants to show which inputs a removed guard would actually admit.
"""

import json
import random
import runpy
from copy import deepcopy
from pathlib import Path

from uarch_contract.mapped import MappedBundle, admit, validate_resources
from uarch_contract.prepared import PreparedOp

from rkuarch.mapping.component import map_component
from rkuarch.workload.component import component_point, prepare_component_bundle
from validation.component.corpus import build, graph, materialize
from validation.component.join_inputs import reseal

ROOT = Path.cwd()
FIX = ROOT / "docs/reviews/U4-B-component-joins-v2/fixtures"
out: dict = {}


def code(fn):
    try:
        fn()
        return "success"
    except ValueError as exc:
        return str(exc).split(":", 1)[0].strip()


def resources(raw):
    b = MappedBundle.model_validate(reseal(deepcopy(raw)))
    validate_resources(b, b.points[0])
    return b


def load(name):
    return json.loads((FIX / (name + ".json")).read_text())


# 1. Selected lifetime/resource negatives: which code each produces (run also on mutants).
for name in [
    "B2-lifetime-false-writer",
    "B2-lifetime-missing-consumer",
    "B2-lifetime-no-order",
    "B2-lifetime-wrong-owner",
    "B2-resource-C04-carrier",
    "B2-resource-C06-small",
    "B2-resource-C07-hbm-1",
    "B2-resource-C07-sram-1",
]:
    item = load(name)
    reg = build()["registry"]
    out["selected " + name] = code(
        lambda item=item, reg=reg: admit(
            item["bundle"],
            invocation="test",
            checkpoint="B",
            registry=reg,
            profile=item["profile"],
            trusted_registry_hash=reg["registry_hash"],
            trusted_profile_hash=item["profile"]["profile_hash"],
        )
    )

# 2. Partial terminal-consumer set: acc read by c, d, e (d, e independent), only d declared
#    terminal, overlapping zacc produced by z after d but concurrent with e.
B = runpy.run_path(str(ROOT / "docs/reviews/U4-B-component-joins-v2/test_accumulator.py"))
mc = B["multiple_consumers"]()
out["multi-consumer control (all terminals ordered)"] = code(lambda: resources(mc))
partial = deepcopy(mc)
g = graph(partial)
next(x for x in g["buffers"] if x["id"] == "acc")["final_consumer_ids"] = ["d"]
g["dependencies"] = [dict(before=a, after=z) for a, z in [("c", "d"), ("c", "e"), ("d", "z")]]
out["A1 partial terminal set, e concurrent with zacc reuse"] = code(lambda: resources(partial))

# 3. Other lifetime attacks on the exact selected B2-C04-transient bytes.
c04 = load("B2-C04-transient")["bundle"]
out["C04 transient control"] = code(lambda: resources(c04))
for label, edit in [
    (
        "A3 z reuses acc (c's buffer) with no c->z order",
        lambda g: (
            next(j for j in g["jobs"] if j["id"] == "z").update(accumulator_buffer_id="acc"),
            g.update(dependencies=[]),
            next(b for b in g["buffers"] if b["id"] == "acc").update(final_consumer_ids=["c", "z"]),
            g.update(buffers=[b for b in g["buffers"] if b["id"] != "zacc"]),
        ),
    ),
    (
        "A4 zacc made persistent under @2 (overlaps transient acc)",
        lambda g: next(b for b in g["buffers"] if b["id"] == "zacc").update(
            producer_id=None, final_consumer_ids=[]
        ),
    ),
    (
        "A5 transient acc preloaded",
        lambda g: next(b for b in g["buffers"] if b["id"] == "acc").update(
            initial_residency="preloaded"
        ),
    ),
    (
        "A8 valid alternate placement: reversed order z->c",
        lambda g: g.update(dependencies=[dict(before="z", after="c")]),
    ),
]:
    raw = deepcopy(c04)
    edit(graph(raw))
    out[label] = code(lambda raw=raw: resources(raw))
# Same-footprint variants (B2-equal: c, z both 256x256x256, 262144B), so size cannot mask.
equal = load("B2-equal")["bundle"]
out["B2-equal control"] = code(lambda: resources(equal))
for label, deps, finals in [
    (
        "A3b z reads c's transient acc BEFORE producer c (z->c)",
        [dict(before="z", after="c")],
        ["c"],
    ),
    ("A3c z and c share c's transient acc unordered", [], ["c", "z"]),
]:
    raw = deepcopy(equal)
    g = graph(raw)
    next(j for j in g["jobs"] if j["id"] == "z")["accumulator_buffer_id"] = "acc"
    g["buffers"] = [b for b in g["buffers"] if b["id"] != "zacc"]
    next(b for b in g["buffers"] if b["id"] == "acc")["final_consumer_ids"] = finals
    g["dependencies"] = deps
    out[label] = code(lambda raw=raw: resources(raw))
alt = deepcopy(c04)
graph(alt)["dependencies"] = [dict(before="z", after="c")]
out["A8 alternate placement changes graph identity"] = (
    reseal(deepcopy(alt))["points"][0]["task_graph"]["graph_hash"]
    != reseal(deepcopy(c04))["points"][0]["task_graph"]["graph_hash"]
)

# 4. Rehashed semantic attack on the exact A2 cold mapper input: transient producer -> DMA.
a2 = load("A2-255-256-cold")
reg = build()["registry"]
bad = deepcopy(a2["bundle"])
gg = graph(bad)
dma = next(j for j in gg["jobs"] if j["kind"] == "dma")
next(b for b in gg["buffers"] if b["space"] == "accumulator")["producer_id"] = dma["id"]
reseal(bad)
args = dict(
    invocation="test", checkpoint="B", registry=reg, trusted_registry_hash=reg["registry_hash"]
)
out["A2 rehash attack under its ORIGINAL anchor"] = code(
    lambda: admit(
        bad, profile=a2["profile"], trusted_profile_hash=a2["profile"]["profile_hash"], **args
    )
)
synthetic = materialize("SYNTHETIC-review-anchor", bad, dict(outcome="success"))
out["A2 rehash attack under a new SYNTHETIC anchor"] = code(
    lambda: admit(
        synthetic["bundle"],
        profile=synthetic["profile"],
        trusted_profile_hash=synthetic["profile"]["profile_hash"],
        **args,
    )
)

# 5. Version relabel: A2 @2 bundle relabelled @1, and an @1 mapper bundle relabelled @2.
lab = deepcopy(load("A2-255-256-fixture_resident")["bundle"])
lab["mapping_policy"]["version"] = "1"
out["A6 @2 transient bundle relabelled @1"] = code(lambda: resources(lab))
base = MappedBundle.model_validate_json(
    (ROOT / "contract/fixtures/mapped/component.json").read_bytes()
)
op0 = base.scope.ops[0].model_dump(mode="json")


def ops_from(shapes, deps=None):
    result = []
    for i, (m, k, n) in enumerate(shapes):
        d = deepcopy(op0)
        d.update(id=f"q{i:02}", depends_on=[f"q{x:02}" for x in (deps or {}).get(i, [])])
        d["spec"]["dimensions"] = dict(M=m, K=k, N=n)
        result.append(PreparedOp.model_validate(d))
    return result


def bundle(ops, version, state="cold"):
    g = map_component(ops, base.hardware_spec, initial_state=state, mapping_version=version)
    p = component_point(ops, g, initial_state=state)
    return prepare_component_bundle(
        ops,
        base.hardware_spec,
        p,
        producer=base.producer,
        assumptions=base.assumptions,
        rank=base.rank,
        admission=base.admission,
        mapping_version=version,
    )


v1 = bundle(ops_from([(256, 64, 64)]), "1").model_dump(mode="json")
v1["mapping_policy"]["version"] = "2"
out["A7 @1 mapper bundle relabelled @2 (graph/point hash unchanged)"] = code(lambda: resources(v1))

# 6. @2 mapper sweep: 1..16 ops, tails, dependencies, cold/resident; independent invariants.
import os  # noqa: E402

rng = random.Random(20261016)
sweep = dict(cases=0, admitted=0, refused={}, transient_cores=0, invariant_failures=[])
for count in [] if os.environ.get("REVIEW_SKIP_SWEEP") else list(range(1, 17)) * 3:
    shapes = [
        (
            rng.choice([1, 3, 255, 256, 257, 511, 600, 1024]),
            rng.choice([1, 5, 64, 256]),
            rng.choice([1, 7, 128, 255, 256]),
        )
        for _ in range(count)
    ]
    deps = {i: sorted(rng.sample(range(i), rng.randint(0, min(2, i)))) for i in range(count)}
    # Reverse-ID dependencies so topological order differs from ID order.
    deps = {count - 1 - i: [count - 1 - x for x in v] for i, v in deps.items()}
    state = rng.choice(["cold", "fixture_resident"])
    sweep["cases"] += 1
    try:
        b = bundle(ops_from(shapes, deps), "2", state)
    except ValueError as exc:
        c = str(exc).split(":", 1)[0]
        sweep["refused"][c] = sweep["refused"].get(c, 0) + 1
        continue
    sweep["admitted"] += 1
    g = b.points[0].task_graph
    computes = [j for j in g.jobs if j.kind == "compute"]
    bufs = {x.id: x for x in g.buffers}
    edges = {(d.before, d.after) for d in g.dependencies}
    expected_tiles = sum(-(-m // 256) for m, _, _ in shapes)
    if len(computes) != expected_tiles:
        sweep["invariant_failures"].append(("tile count", count))
    for core in {c.core_id for c in computes}:
        mine = [c for c in computes if c.core_id == core]
        sizes = {4 * c.tile_extents.M * c.tile_extents.N for c in mine}
        accs = [bufs[c.accumulator_buffer_id] for c in mine]
        if len(sizes) > 1:
            sweep["transient_cores"] += 1
            ok = all(
                a.offset_bytes == 0
                and a.producer_id == c.id
                and list(a.final_consumer_ids) == [c.id]
                and a.size_bytes == 4 * c.tile_extents.M * c.tile_extents.N
                for a, c in zip(accs, mine, strict=True)
            )
            # Matrix chain order = stable topological op order (ID ties): Kahn with min-ID.
            done, order, pending = (
                set(),
                [],
                {f"q{i:02}": set(f"q{x:02}" for x in deps.get(i, [])) for i in range(count)},
            )
            while pending:
                nxt = min(k for k, v in pending.items() if v <= done)
                order.append(nxt)
                done.add(nxt)
                del pending[nxt]
            chain = sorted(mine, key=lambda c: order.index(c.op_id))
            ok &= all((a.id, z.id) in edges for a, z in zip(chain, chain[1:], strict=False))
        else:
            ok = (
                all(a.producer_id is None and not a.final_consumer_ids for a in accs)
                and len({a.id for a in accs}) == 1
            )
        if not ok:
            sweep["invariant_failures"].append(("core", count, core))
    if any(hasattr(j, "duration_ps") for j in g.jobs):
        sweep["invariant_failures"].append(("hidden duration", count))
out["@2 mapper sweep"] = sweep
print(json.dumps(out, indent=1, sort_keys=True))
