"""Reviewer lifecycle probe: support inventory delta, fixed-delay helper identity, mirrors.

usage (via tools/run.py, cwd = candidate export): probe_lifecycle.py <base_export>
Compares the pinned unpatched publication export with the patched candidate export.
"""

import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

from scripts.u2_support import inventory

cand = Path.cwd()
base = Path(sys.argv[1])
report = {}
before, after = inventory(root=base), inventory(root=cand)
delta = {
    p: (before.get(p), after.get(p))
    for p in before.keys() | after.keys()
    if before.get(p) != after.get(p)
}
report["support_selected_files"] = [len(before), len(after)]
report["support_delta"] = delta
patched = [
    "contract/schema/mapped/MappedEngineResult.json",
    "contract/uarch_contract/mapped.py",
    "docs/decisions/U0011-the-native-engine-core.md",
    "src/rkuarch/mapping/component.py",
    "src/rkuarch/workload/component.py",
]
report["patched_files_in_support_selection"] = sorted(set(patched) & set(after))


def function_source(root: Path, name: str) -> str:
    text = (root / "contract/uarch_contract/mapped.py").read_text()
    node = next(
        n for n in ast.walk(ast.parse(text)) if isinstance(n, ast.FunctionDef) and n.name == name
    )
    return ast.get_source_segment(text, node) or ""


for fn in ("validate_fixed_delay_observations", "validate_job", "admit", "canonical_owners"):
    a, b = function_source(base, fn), function_source(cand, fn)
    report[f"function {fn} byte-identical"] = (
        hashlib.sha256(a.encode()).hexdigest() == hashlib.sha256(b.encode()).hexdigest()
    )
# Schema mirror freshness on the candidate (generator --check, read-only).
proc = subprocess.run(
    [
        sys.executable,
        "-I",
        "-c",
        "import sys,runpy;sys.path[:0]=['.','src','contract'];"
        "L='/home/jjaff/AI-infra-simulation/rk-uarch/';"
        "sys.path[:]=[p for p in sys.path if not p.startswith(L) or '/.venv/' in p];"
        "sys.argv=['generate','--check'];runpy.run_module('uarch_contract.generate',run_name='__main__')",
    ],
    cwd=cand,
    capture_output=True,
    text=True,
)
report["schema_generate_check_exit"] = proc.returncode
report["schema_generate_check_tail"] = (proc.stdout + proc.stderr)[-300:]
print(json.dumps(report, indent=1, sort_keys=True))
