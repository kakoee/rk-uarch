"""Reviewer runner: execute pytest/python inside a private export with live-clone paths removed.

Usage: python -I run.py <export_root> pytest <args...>
       python -I run.py <export_root> script <path.py> <args...>
Writes no files into the export except what the invoked tests write to tmp dirs.
"""

import json
import os
import runpy
import sys

LIVE = "/home/jjaff/AI-infra-simulation/rk-uarch"
root = os.path.realpath(sys.argv[1])
mode = sys.argv[2]
rest = sys.argv[3:]

# The live .venv has an editable .pth that appends LIVE/src and LIVE/contract.
sys.path[:] = [
    p
    for p in sys.path
    if not (p == LIVE or (p.startswith(LIVE + "/") and not p.startswith(LIVE + "/.venv/")))
]
sys.path[:0] = [root, root + "/src", root + "/contract"]
os.chdir(root)
os.environ.pop("PYTHONPATH", None)
os.environ.pop("MYPYPATH", None)
sys.dont_write_bytecode = True


def origins() -> dict:
    bad, seen = [], {}
    for name, mod in sorted(sys.modules.items()):
        f = getattr(mod, "__file__", None) or ""
        if f.startswith(LIVE + "/") and "/.venv/" not in f:
            bad.append((name, f))
        if name in (
            "uarch_contract",
            "uarch_contract.mapped",
            "rkuarch",
            "rkuarch.mapping.component",
            "rkuarch.workload.component",
            "rkuarch.workload.mapped",
            "validation.component.observations_v2",
            "validation.component.checks",
        ):
            seen[name] = f
    return dict(live_modules=bad, origins=seen)


if mode == "pytest":
    import pytest

    class Origins:
        def pytest_sessionfinish(self, session, exitstatus):
            o = origins()
            print("\nREVIEW-ORIGINS " + json.dumps(o, sort_keys=True))
            assert not o["live_modules"], o["live_modules"]
            for f in o["origins"].values():
                assert f.startswith(root + "/"), f

    code = pytest.main(
        ["-c", root + "/pyproject.toml", "--rootdir", root, "-p", "no:cacheprovider", *rest],
        plugins=[Origins()],
    )
    sys.exit(int(code))
elif mode == "script":
    path = rest[0]
    sys.argv = rest
    try:
        runpy.run_path(path, run_name="__main__")
    finally:
        o = origins()
        print("REVIEW-ORIGINS " + json.dumps(o, sort_keys=True))
        assert not o["live_modules"], o["live_modules"]
else:
    raise SystemExit("mode")
