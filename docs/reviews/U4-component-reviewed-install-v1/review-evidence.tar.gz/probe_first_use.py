"""Reviewer probe: the prospective first-use consumer requires BOTH validators.

Uses B's synthetic D01 carrier (never a native result). A channel-duration fault passes the
installed validate_result alone; selection.assert_case must still refuse via check_v2.
A /1-shaped component result must be refused by validate_result itself.
"""

import json
import runpy
from copy import deepcopy
from pathlib import Path

from uarch_contract.hashing import content_hash
from uarch_contract.mapped import validate_result

from validation.component.selection import assert_case

F = runpy.run_path(str(Path("docs/reviews/U4-B-component-joins-v2/synthetic_carrier.py")))
j = F["synthetic_job"]()
good = F["synthetic_result"](j)
item = dict(
    bundle=j.workload_closure.model_dump(mode="json"),
    profile=dict(profile_hash=j.admission.profile_hash),
    expected=dict(outcome="success", duration_ps=60000),
)
contract = dict(unrepresented=["SYNTHETIC-unit-carrier-only"])
out = {}


def run(fn):
    try:
        fn()
        return "accepted"
    except Exception as exc:  # noqa: BLE001 - report the refusal class
        return f"refused {type(exc).__name__}: {str(exc)[:70]}"


out["good synthetic carrier via assert_case"] = run(
    lambda: assert_case(j, validate_result(good, j), item, contract)
)
bad = deepcopy(good)
res = next(
    x
    for x in bad["observations"]["resource_intervals"]["records"]
    if x["activity"] == "channel_service"
)
res["service_end_ps_ratio"] = dict(numerator=54250, denominator=1)
bad["result_hash"] = content_hash(bad, exclude=("result_hash",))
out["channel-duration fault: validate_result alone"] = run(lambda: validate_result(bad, j))
out["channel-duration fault: assert_case (validate_result + check_v2)"] = run(
    lambda: assert_case(j, validate_result(bad, j), item, contract)
)
copied = deepcopy(item)
copied["expected"]["duration_ps"] = 59000
out["expected literal mismatch via assert_case"] = run(
    lambda: assert_case(j, validate_result(good, j), copied, contract)
)
v1 = deepcopy(good)
v1["observations"]["format"] = "uarch-native-observations/1"
v1["result_hash"] = content_hash(v1, exclude=("result_hash",))
out["/1-format component result: validate_result"] = run(lambda: validate_result(v1, j))
print(json.dumps(out, indent=1))
