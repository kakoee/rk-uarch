"""Reviewer probe: fully resealed but false /2 records vs validate_result + check_v2.

Run with export root as cwd (candidate postimage). Uses B's published synthetic D08 carrier
(two reads on DMA engine 0, port contention) and A's zero-time shell only as inputs; every
mutation is resealed (critical path recomputed by U0011's stated tie rule, attribution and
result_hash recomputed) so content hashes cannot be what refuses it.
Prints JSON {case: "accepted" | "refused: <code>"}; nothing here is native evidence.
"""

import json
import runpy
from copy import deepcopy
from pathlib import Path

from uarch_contract.hashing import content_hash
from uarch_contract.mapped import validate_result

from validation.component.observations_v2 import check_v2

F = runpy.run_path(str(Path("docs/reviews/U4-B-component-joins-v2/synthetic_carrier.py")))
CONTRACT = dict(unrepresented=["SYNTHETIC-unit-carrier-only"])


def tie(a):
    return (a["owner_id"], a["job_id"], a["request_id"] or "", a["subphase"], a["activity_id"])


def reseal(r):
    """Recompute the canonical critical path exactly as the U0011 candidate text states."""
    acts = {a["activity_id"]: a for a in r["observations"]["activities"]["records"]}
    current = min((a for a in acts.values() if a["end_ps"] == r["duration_ps"]), key=tie)
    chain = []
    while True:
        if current["end_ps"] > current["start_ps"]:
            chain.append(current)
        if not current["predecessors"]:
            break
        current = min((acts[p["activity_id"]] for p in current["predecessors"]), key=tie)
    chain.reverse()
    crit = []
    totals = dict(compute=0, memory=0, noc=0, sync=0, overhead=0)
    previous = None
    for a in chain:
        crit.append(
            dict(
                kind="service",
                start_ps=a["start_ps"],
                end_ps=a["end_ps"],
                cause_job_id=a["job_id"],
                predecessor_id=previous,
                limiting_resource_id=a["owner_id"],
                category=a["category"],
                activity_id=a["activity_id"],
            )
        )
        totals[a["category"]] += a["end_ps"] - a["start_ps"]
        previous = a["job_id"]
    r["observations"]["critical_path"]["records"] = crit
    r["attribution_ps"] = totals
    r["result_hash"] = content_hash(r, exclude=("result_hash",))
    return r


def verdict(j, r):
    try:
        validate_result(r, j)
    except ValueError as exc:
        return "refused by validate_result: " + str(exc)[:90]
    try:
        check_v2(j.model_dump(mode="json"), r, CONTRACT)
    except ValueError as exc:
        return "refused by check_v2: " + str(exc)[:90]
    return "accepted"


def act(r, key):
    return next(a for a in r["observations"]["activities"]["records"] if a["activity_id"] == key)


j = F["synthetic_job"]("D08")
base = F["synthetic_port_pair"](j)
out = {"control: B D08 carrier as published": verdict(j, base)}
crit0 = [
    (c["activity_id"], c["category"]) for c in base["observations"]["critical_path"]["records"]
]

# V1 eligibility: r01's port service never waited for a DMA credit (issued at 0, limit 32),
# yet r00's final port service (same engine, tight at 60000) is supplied as a "credit" cause.
r = deepcopy(base)
act(r, "r1:port")["predecessors"] = sorted(
    [
        dict(activity_id="r1:port-a", relation="sequence"),
        dict(activity_id="r0:port", relation="credit"),
    ],
    key=lambda x: (x["activity_id"], x["relation"]),
)
out["V1 false credit cause added (real sequence kept)"] = verdict(j, reseal(r))

# V2 completeness+eligibility: drop r00 port alignment's real sequence cause (its own
# response hop) and name r01's response hop as a "credit" cause. Same-time MEM_RESP events
# 26/30 swap jobs so ordinals stay tight; timestamps, phases and all mechanisms unchanged.
r = deepcopy(base)
ev = {e["observation_ordinal"]: e for e in r["observations"]["events"]["records"]}
ev[26]["job_id"], ev[30]["job_id"] = ev[30]["job_id"], ev[26]["job_id"]
act(r, "r0:back")["completion_ordinal"] = 30
act(r, "r1:back")["completion_ordinal"] = 26
act(r, "r0:port-a")["predecessors"] = [dict(activity_id="r1:back", relation="credit")]
reseal(r)
crit2 = [(c["activity_id"], c["category"]) for c in r["observations"]["critical_path"]["records"]]
out["V2 real cause dropped, other request's hop named credit cause"] = verdict(j, r)
out["V2 critical path before"] = crit0
out["V2 critical path after"] = crit2

# F1 unchecked carrier fields, each resealed independently.
for label, edit in [
    (
        "F1a critical predecessor_id forged",
        lambda r: r["observations"]["critical_path"]["records"][-1].update(predecessor_id="FORGED"),
    ),
    (
        "F1b job blocking_predecessor_ids forged",
        lambda r: r["observations"]["jobs"]["records"][1].update(blocking_predecessor_ids=["r00"]),
    ),
    (
        "F1c job owner_id moved to channel:6",
        lambda r: r["observations"]["jobs"]["records"][1].update(
            owner_id=next(o.owner_id for o in j.owners if o.resource == "channel:6")
        ),
    ),
    (
        "F1d DMA_DONE event relabelled STAT_SAMPLE",
        lambda r: [
            e.update(kind="STAT_SAMPLE")
            for e in r["observations"]["events"]["records"]
            if e["kind"] == "DMA_DONE"
        ],
    ),
    (
        "F1e job release_ps moved later than ready",
        lambda r: r["observations"]["jobs"]["records"][0].update(release_ps=50000),
    ),
]:
    r = deepcopy(base)
    edit(r)
    r["result_hash"] = content_hash(r, exclude=("result_hash",))
    out[label] = verdict(j, r)

# C1 zero-duration causal cycle on A's zero-time validate_result-only shell.
A = runpy.run_path(str(Path("tests/component_proposal/test_result.py")))
aj, ar = A["synthetic"]()
acts = ar["observations"]["activities"]["records"]
x = deepcopy(acts[-1])
x["activity_id"] = "SYNTHETIC:cycle-twin"
x["predecessors"] = [dict(activity_id=acts[-1]["activity_id"], relation="sequence")]
acts[-1]["predecessors"] = [dict(activity_id="SYNTHETIC:cycle-twin", relation="sequence")]
acts.append(x)
ar["result_hash"] = content_hash(ar, exclude=("result_hash",))
try:
    validate_result(ar, aj)
    out["C1 off-chain zero-duration 2-cycle (A shell)"] = "accepted by validate_result"
except ValueError as exc:
    out["C1 off-chain zero-duration 2-cycle (A shell)"] = (
        "refused by validate_result: " + str(exc)[:80]
    )
print(json.dumps(out, indent=1))
