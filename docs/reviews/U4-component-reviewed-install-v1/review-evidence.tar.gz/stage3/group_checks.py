"""Stage 3: verify two documented checker redundancies in a private export; exact restore.

usage: python -I group_checks.py <private_export> <runner.py>
G1 (F1, B 'hidden-channel-law'): disable required occupancy + occupied row inventory +
   busy union + channel integer mechanism together; run B's M4b test and the reviewer's
   probe_stage3 M4b row (check_v2 layer).
G2 (F5 named example): disable ONLY 'mechanism duration'; run the reviewer's clock-consistent
   duration forgery (probe_f5_duration.py) and B's duration test.
"""

import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root, runner = Path(sys.argv[1]), sys.argv[2]
here = Path(__file__).resolve().parent
rel = "validation/component/observations_v2.py"
path = root / rel
original = path.read_bytes()
digest = hashlib.sha256(original).hexdigest()


def disable(details: set[str]) -> None:
    src = original.decode()
    fn = next(
        n
        for n in ast.walk(ast.parse(src))
        if isinstance(n, ast.FunctionDef) and n.name == "check_v2"
    )
    sites = sorted(
        (
            (n.lineno, n.col_offset)
            for n in ast.walk(fn)
            if isinstance(n, ast.Call)
            and isinstance(n.func, ast.Name)
            and n.func.id == "need"
            and n.args
            and isinstance(n.args[-1], ast.Constant)
            and n.args[-1].value in details
        ),
        reverse=True,
    )
    assert len(sites) == len(details), (details, sites)
    lines = src.splitlines(keepends=True)
    for lineno, col in sites:
        line = lines[lineno - 1]
        lines[lineno - 1] = line[:col] + "(lambda *_a, **_k: None)(" + line[col + 5 :]
    path.write_text("".join(lines))


def call(*args: str) -> str:
    p = subprocess.run(
        [sys.executable, "-I", runner, str(root), *args],
        capture_output=True,
        text=True,
        timeout=900,
    )
    return p.stdout


def outcome(text: str) -> str:
    if "DID NOT RAISE" in text:
        return "unsafe acceptance (DID NOT RAISE)"
    if "Regex pattern did not match" in text:
        return "alternative refusal"
    return "passed" if " passed" in text and "failed" not in text else "other"


records = {}
try:
    disable(
        {"required occupancy", "occupied row inventory", "busy union", "channel integer mechanism"}
    )
    t = call(
        "pytest",
        "-q",
        "-p",
        "no:randomly",
        "validation/component/test_consistent_observations.py::"
        "test_consistent_checker_forgery[M4b-channel integer mechanism]",
    )
    p = call("script", str(here / "probe_stage3.py"))
    probe = json.loads(p[: p.index("REVIEW-ORIGINS")])
    records["G1 hidden-channel-law group removed"] = dict(
        b_test=outcome(t), reviewer_M4b=probe["F1 M4b non-occupying channel, service end 54500"]
    )
    path.write_bytes(original)
    disable({"mechanism duration"})
    p = call("script", str(here / "probe_f5_duration.py"))
    t = call(
        "pytest",
        "-q",
        "-p",
        "no:randomly",
        "validation/component/test_consistent_observations.py::"
        "test_mechanism_and_field_forgery[duration-mechanism duration]",
    )
    records["G2 only mechanism duration removed"] = dict(
        reviewer_forgery=json.loads(p[: p.index("REVIEW-ORIGINS")]), b_test=outcome(t)
    )
finally:
    path.write_bytes(original)
records["restored_exact_bytes"] = hashlib.sha256(path.read_bytes()).hexdigest() == digest
print(json.dumps(records, indent=1))
