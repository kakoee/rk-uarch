"""Stage 3 random revert of F6 (regression activation) in a private reconstruction.

usage: python -I random_revert_f6.py <private_export> <runner.py>
Revert = remove the ten candidate test files from ordinary discovery (Stage 1 packaging).
Sentinels = two essential-guard removals whose regressions were undiscovered at Stage 1:
  A: contract `accumulator use before production` (F4; zero discovered kills at Stage 1);
  B: checker `port FIFO tie` (F9; reversed tied-ready grant otherwise accepted).
Runs the ordinarily discovered directories (no explicit test-file list) in four states and
restores exact bytes, verifying every SHA256 at the end.
"""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

root, runner = Path(sys.argv[1]), sys.argv[2]
TESTS = [
    "contract/tests/mapped/test_component_lifetimes_v2.py",
    "contract/tests/mapped/test_component_profile_v2.py",
    "contract/tests/mapped/test_component_semantics_v2.py",
    "tests/unit/test_u4_component_mapper_v2.py",
    "validation/component/test_accumulator_controls.py",
    "validation/component/test_carrier_bindings.py",
    "validation/component/test_consistent_observations.py",
    "validation/component/test_lifetime_discrimination.py",
    "validation/component/test_policy_boundaries.py",
    "validation/component/test_stage2_selection.py",
]
SENTINELS = [
    (
        "contract/uarch_contract/mapped.py",
        "acc.producer_id == job.id or acc.producer_id in ancestors[job.id],",
        "True,",
    ),
    (
        "validation/component/observations_v2.py",
        '[a["activity_id"] for a in ordered] == [a["activity_id"] for a in ready_order],',
        "True,",
    ),
]
DIRS = ["contract/tests/mapped", "tests/unit", "validation/component"]


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


saved = {t: (root / t).read_bytes() for t in TESTS}
touched = sorted({p for p, _, _ in SENTINELS})
originals = {p: (root / p).read_bytes() for p in touched}
expected = {p: hashlib.sha256(b).hexdigest() for p, b in {**saved, **originals}.items()}


def run(label: str) -> dict:
    argv = [
        sys.executable,
        "-I",
        runner,
        str(root),
        "pytest",
        "-q",
        "-p",
        "no:randomly",
        "-m",
        "not native and not nightly and not silicon",
        *DIRS,
    ]
    p = subprocess.run(argv, capture_output=True, text=True, timeout=1500)
    lines = p.stdout.splitlines()
    return dict(
        state=label,
        exit=p.returncode,
        summary=[x for x in lines if " passed" in x or " failed" in x][-1:],
        failed=[x for x in lines if x.startswith("FAILED")][:12],
        failed_count=sum(x.startswith("FAILED") for x in lines),
        origins_ok='"live_modules": []' in p.stdout,
    )


def collect() -> int:
    argv = [
        sys.executable,
        "-I",
        runner,
        str(root),
        "pytest",
        "--collect-only",
        "-q",
        "-m",
        "not native and not nightly and not silicon",
    ]
    p = subprocess.run(argv, capture_output=True, text=True, timeout=600)
    return sum(1 for x in p.stdout.splitlines() if x.split("::")[0] in TESTS)


def sentinels(on: bool) -> None:
    for p in touched:
        body = originals[p].decode()
        if on:
            for path, before, after in SENTINELS:
                if path == p:
                    assert body.count(before) == 1, before
                    body = body.replace(before, after)
        (root / p).write_text(body)


records = []
try:
    records.append(dict(state="restored candidate", candidate_nodes_in_10_files=collect()))
    for t in TESTS:
        (root / t).unlink()
    records.append(dict(state="F6 reverted", candidate_nodes_in_10_files=collect()))
    records.append(run("F6 reverted, no sentinel"))
    sentinels(True)
    records.append(run("F6 reverted + sentinel guard removals"))
    for t, data in saved.items():
        (root / t).write_bytes(data)
    records.append(run("F6 restored + sentinel guard removals"))
    sentinels(False)
finally:
    for t, data in saved.items():
        (root / t).write_bytes(data)
    for p, data in originals.items():
        (root / p).write_bytes(data)
restored = all(sha(root / p) == d for p, d in expected.items())
records.append(dict(state="exact bytes restored", ok=restored))
records.append(run("F6 restored, sentinels removed (rerun)"))
print(json.dumps(records, indent=1))
