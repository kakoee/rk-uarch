"""Stage 3: classify how a single-guard removal is detected.

Unsafe acceptance versus alternative refusal.

usage: python -I kill_kind.py <private_export> <runner.py>
For each (file, function, call, detail, test): disable that one guard call, run the named test,
classify the failure text, restore exact bytes. 'DID NOT RAISE' = unsafe acceptance witnessed;
'Regex pattern did not match' = alternative refusal (redundant defense), not an
unsafe-acceptance kill. Pass --f5-named for the Stage 1 F5 named-guard subset.
"""

import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root, runner = Path(sys.argv[1]), sys.argv[2]
V = ("contract/uarch_contract/mapped.py", "validate_component_observations", "require")
C = ("validation/component/observations_v2.py", "check_v2", "need")
X = ("validation/component/transition_checks.py", "check_transitions", "need")
S = "contract/tests/mapped/test_component_semantics_v2.py::"
O = "validation/component/test_consistent_observations.py::"  # noqa: E741
F5_NAMED = [
    (C, "phase ready transition", O + "test_waiting_ready_cannot_be_invented_under_port_blocking"),
    (C, "busy union", O + "test_mechanism_and_field_forgery[busy-busy union]"),
    (
        C,
        "channel FIFO tie",
        O + "test_transition_and_population_forgery[channel_fifo-channel FIFO tie]",
    ),
    (
        C,
        "rational channel carry/readiness",
        O + "test_mechanism_and_field_forgery[carry-rational channel carry/readiness]",
    ),
    (
        C,
        "unrepresented paths",
        O + "test_mechanism_and_field_forgery[unrepresented-unrepresented paths]",
    ),
    (
        C,
        "fidelity/null floor",
        O + "test_mechanism_and_field_forgery[null_floor-fidelity/null floor]",
    ),
    (C, "causal attribution totals", O + "test_causal_attribution_totals"),
    (
        C,
        "accumulator lifetime mechanism",
        O
        + "test_transition_and_population_forgery[allocation_lifetime-allocation access lifetime]",
    ),
]
CASES = (
    F5_NAMED
    if "--f5-named" in sys.argv
    else [
        (V, "phase occupancy", S + "test_M4_nonoccupying_channel"),
        (V, "activity category/domain", S + "test_M1_relabel[category]"),
        (V, "activity owner", S + "test_M2_owner_forgery"),
        (V, "missing tight cause", S + "test_M3_missing_off_chain_cause"),
        (V, "credit endpoints", S + "test_V1_credit_only_first_from_last"),
        (V, "sequence endpoints", S + "test_additional_consistent_structural_witnesses[sequence]"),
        (V, "job owner", S + "test_F8_resealed_fields[owner-job owner]"),
        (V, "activity event kind", S + "test_F8_resealed_fields[event-activity event kind]"),
        (
            V,
            "unrepresented critical predecessor",
            S + "test_F8_resealed_fields[critical-unrepresented critical predecessor]",
        ),
        (C, "required occupancy", O + "test_consistent_checker_forgery[M4a-required occupancy]"),
        (
            C,
            "channel integer mechanism",
            O + "test_consistent_checker_forgery[M4b-channel integer mechanism]",
        ),
        (
            C,
            "exclusive mechanism intervals",
            O + "test_consistent_checker_forgery[port_overlap-exclusive mechanism intervals]",
        ),
        (C, "port FIFO tie", O + "test_consistent_checker_forgery[port_reverse-port FIFO tie]"),
        (
            C,
            "mechanism duration",
            O + "test_mechanism_and_field_forgery[duration-mechanism duration]",
        ),
        (
            X,
            "complete eligible causes",
            O + "test_consistent_checker_forgery[V1-complete eligible causes]",
        ),
        (
            X,
            "complete eligible causes",
            O + "test_consistent_checker_forgery[V2-complete eligible causes]",
        ),
        (X, "complete eligible causes", O + "test_credit_requires_exhaustion_at_first_transition"),
        (
            X,
            "job owner binding",
            O + "test_mechanism_and_field_forgery[job_owner-job owner binding]",
        ),
        (
            X,
            "event transition binding",
            O + "test_mechanism_and_field_forgery[event-event transition binding]",
        ),
    ]
)
records = []
for (rel, func, call), detail, test in CASES:
    path = root / rel
    original = path.read_bytes()
    digest = hashlib.sha256(original).hexdigest()
    src = original.decode()
    fn = next(
        n for n in ast.walk(ast.parse(src)) if isinstance(n, ast.FunctionDef) and n.name == func
    )
    sites = [
        n
        for n in ast.walk(fn)
        if isinstance(n, ast.Call)
        and isinstance(n.func, ast.Name)
        and n.func.id == call
        and n.args
        and isinstance(n.args[-1], ast.Constant)
        and n.args[-1].value == detail
    ]
    assert len(sites) == 1, (detail, len(sites))
    lines = src.splitlines(keepends=True)
    n = sites[0]
    line = lines[n.lineno - 1]
    lines[n.lineno - 1] = (
        line[: n.col_offset] + "(lambda *_a, **_k: None)(" + line[n.col_offset + len(call) + 1 :]
    )
    try:
        path.write_text("".join(lines))
        p = subprocess.run(
            [sys.executable, "-I", runner, str(root), "pytest", "-q", "-p", "no:randomly", test],
            capture_output=True,
            text=True,
            timeout=600,
        )
    finally:
        path.write_bytes(original)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    text = p.stdout
    kind = (
        "passed (not detected)"
        if p.returncode == 0
        else "unsafe acceptance (DID NOT RAISE)"
        if "DID NOT RAISE" in text
        else "alternative refusal (regex mismatch)"
        if "Regex pattern did not match" in text
        else "other failure"
    )
    records.append(dict(guard=detail, file=rel, test=test, detection=kind))
    print(f"{kind:38} {detail:34} {test.split('::')[-1]}", flush=True)
print(json.dumps(records))
