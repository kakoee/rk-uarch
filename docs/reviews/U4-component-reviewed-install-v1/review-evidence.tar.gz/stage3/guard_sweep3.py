"""Stage 3 single-guard sweep in a private mutant export; exact bytes restored every time.

usage: python -I guard_sweep3.py <mutant_export> <runner.py> <file> <func> <call> <tests...>
Disables one `<call>(...)` site at a time inside <func> (rewritten to a no-op lambda call),
runs the given behavioural tests with -x, and records killed / survived / nonterminating.
Identity/hash tests must be deselected by the caller; they are not behavioural kills.
"""

import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

root, runner, rel, func, call, *tests = sys.argv[1:]
path = Path(root) / rel
original = path.read_bytes()
digest = hashlib.sha256(original).hexdigest()
source = original.decode()
target = next(
    n for n in ast.walk(ast.parse(source)) if isinstance(n, ast.FunctionDef) and n.name == func
)
sites = []
for n in ast.walk(target):
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == call:
        detail = n.args[-1].value if n.args and isinstance(n.args[-1], ast.Constant) else None
        sites.append((n.lineno, n.col_offset, detail))
sites.sort()
lines = source.splitlines(keepends=True)
results = []
try:
    for lineno, col, detail in sites:
        mutated = list(lines)
        line = mutated[lineno - 1]
        assert line[col : col + len(call) + 1] == call + "(", (lineno, line)
        mutated[lineno - 1] = line[:col] + "(lambda *_a, **_k: None)(" + line[col + len(call) + 1 :]
        path.write_text("".join(mutated))
        argv = [sys.executable, "-I", runner, root, "pytest", "-q", "-x", "-p", "no:randomly"]
        try:
            proc = subprocess.run([*argv, *tests], capture_output=True, text=True, timeout=240)
            status = "killed" if proc.returncode else "survived"
            failed = [x for x in proc.stdout.splitlines() if x.startswith("FAILED")][:1]
        except subprocess.TimeoutExpired:
            status, failed = "nonterminating", []
        path.write_bytes(original)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
        results.append(dict(line=lineno, detail=detail, status=status, first_failure=failed))
        print(f"{status.upper():14} {rel}:{lineno} {detail}", flush=True)
finally:
    path.write_bytes(original)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
summary = dict(
    file=rel,
    function=func,
    restored_sha256=digest,
    tests=tests,
    mutants=len(results),
    killed=sum(r["status"] == "killed" for r in results),
    survived=[r for r in results if r["status"] == "survived"],
    nonterminating=[r for r in results if r["status"] == "nonterminating"],
    results=results,
)
print("SUMMARY " + json.dumps(summary))
