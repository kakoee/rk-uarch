"""Stage 3 reviewer probe for F5's named example `mechanism duration` (Stage 1 :166).

Consistent forgery on B's accepted D01 control: the 2-hop response NoC service ends at
58500 instead of next_edge(noc, 55000, 4) = 59000; the following read-port alignment absorbs
58500->59000, so every later time, the makespan and all joined tables stay consistent.
`synchronize` copies the edited times into the clock witness (n_cycles stays 4), so the clock
binding cannot be what refuses. Prints both layers' verdicts.
"""

import json  # noqa: I001 - candidate-only validation modules are absent on main
from copy import deepcopy

from uarch_contract.mapped import validate_result

from validation.component.consistent_carriers import EXPECTED, activity, control, synchronize
from validation.component.observations_v2 import check_v2


def verdicts(j, r):
    out = {}
    for name, fn in (
        ("validate_result", lambda: validate_result(deepcopy(r), j)),
        ("check_v2", lambda: check_v2(j.model_dump(mode="json"), deepcopy(r), EXPECTED)),
    ):
        try:
            fn()
            out[name] = "accepted"
        except Exception as exc:  # noqa: BLE001
            out[name] = f"refused {type(exc).__name__}: {str(exc)[:90]}"
    return out


j, r = control("D01")
result = {"control D01": verdicts(j, r)}
activity(r, "back")["end_ps"] = 58500
activity(r, "port-a").update(ready_ps=58500, start_ps=58500)
r = synchronize(r)
clock = next(c for c in r["observations"]["clocks"]["records"] if c["activity_id"] == "back")
result["clock witness after sync"] = {
    k: clock[k] for k in ("grant_ps", "n_cycles", "completion_ps")
}
result["F5 response hop 4 cycles ends 58500 (law 59000)"] = verdicts(j, r)
print(json.dumps(result, indent=1))
