"""Stage 3 F4/F7 check: remove one lifetime guard at a time in a private export, record which
selected lifetime inputs become admitted, and run the new lifetime tests; restore exact bytes.

usage: python -I f7_unmask.py <private_export> <runner.py>
"""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

root, runner = Path(sys.argv[1]), sys.argv[2]
probe = Path(__file__).with_name("probe_stage3.py")
rel = "contract/uarch_contract/mapped.py"
GUARDS = {
    "writer": (
        "isinstance(producer, Compute) and producer.accumulator_buffer_id == buf.id",
        "True",
    ),
    "terminal-equality": (
        'set(buf.final_consumer_ids) == terminal, "InvalidDependency"',
        'True, "InvalidDependency"',
    ),
    "use-before-production": (
        "acc.producer_id == job.id or acc.producer_id in ancestors[job.id],",
        "True,",
    ),
}
TESTS = [
    "contract/tests/mapped/test_component_lifetimes_v2.py",
    "validation/component/test_lifetime_discrimination.py",
    "validation/component/test_accumulator_controls.py",
    "tests/unit/test_u4_component_mapper_v2.py",
]
path = root / rel
original = path.read_bytes()
digest = hashlib.sha256(original).hexdigest()
records = []


def call(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "-I", runner, str(root), *args],
        capture_output=True,
        text=True,
        timeout=900,
    )


try:
    for name, (before, after) in GUARDS.items():
        body = original.decode()
        assert body.count(before) == 1, name
        path.write_text(body.replace(before, after))
        p = call("script", str(probe))
        data = json.loads(p.stdout[: p.stdout.index("REVIEW-ORIGINS")])
        rows = {k: v for k, v in data.items() if k.startswith(("F7 selected", "F4 A3"))}
        t = call("pytest", "-q", "-p", "no:randomly", *TESTS)
        path.write_bytes(original)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
        restored = call("pytest", "-q", "-p", "no:randomly", *TESTS)
        records.append(
            dict(
                guard=name,
                removed_selected_outcomes=rows,
                removed_tests_failed=[x for x in t.stdout.splitlines() if x.startswith("FAILED")],
                removed_tests_summary=[x for x in t.stdout.splitlines() if "passed" in x][-1:],
                restored_summary=[x for x in restored.stdout.splitlines() if "passed" in x][-1:],
                restored_exit=restored.returncode,
            )
        )
finally:
    path.write_bytes(original)
records.append(dict(restored_exact_bytes=hashlib.sha256(path.read_bytes()).hexdigest() == digest))
print(json.dumps(records, indent=1))
