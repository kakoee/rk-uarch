"""Stage 3 reviewer probe: the original Stage 1 defects against an export (cwd = export root).

Attack edits are the reviewer's own (Stage 1 V1/V2/M1-M4/F1a-e/port/C1). B's
consistent_carriers.control/synchronize are used only to obtain an accepted control and to
copy joined values (events, rows, queues, transfers, canonical path) from the edited
activities, so content hashes and joins cannot be what refuses a forgery. Each layer is
judged separately: the installed-candidate validate_result and B's independent check_v2.
Synthetic unit carriers and anchors only; never native evidence or authority.
"""

import json  # noqa: I001 - candidate-only validation modules are absent on main
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

from uarch_contract.hashing import content_hash
from uarch_contract.mapped import MappedBundle, admit, validate_resources

from validation.component.consistent_carriers import EXPECTED, activity, control, synchronize
from validation.component.corpus import build
from validation.component.join_inputs import reseal

ROOT = Path.cwd()
out: dict[str, Any] = {}


def code(exc: BaseException) -> str:
    return f"refused {type(exc).__name__}: {str(exc)[:100]}"


def layers(j: Any, r: Any) -> dict[str, str]:
    from uarch_contract.mapped import validate_result

    from validation.component.observations_v2 import check_v2

    result = {}
    try:
        validate_result(deepcopy(r), j)
        result["validate_result"] = "accepted"
    except Exception as exc:  # noqa: BLE001 - record the refusing layer and detail
        result["validate_result"] = code(exc)
    try:
        check_v2(j.model_dump(mode="json"), deepcopy(r), EXPECTED)
        result["check_v2"] = "accepted"
    except Exception as exc:  # noqa: BLE001
        result["check_v2"] = code(exc)
    return result


def owner(j: Any, name: str) -> int:
    return next(o.owner_id for o in j.owners if o.resource == name)


def sorted_preds(r: Any) -> None:
    for a in r["observations"]["activities"]["records"]:
        a["predecessors"].sort(key=lambda p: (p["activity_id"], p["relation"]))


def run(label: str, case: str, edit: Any, after: Any = None) -> None:
    j, r = control(case)
    try:
        edit(j, r)
        sorted_preds(r)
        r = synchronize(r)
        if after is not None:
            after(j, r)
            r["result_hash"] = content_hash(r, exclude=("result_hash",))
        out[label] = layers(j, r)
    except AssertionError as exc:  # synchronizer refuses to order an event cycle
        out[label] = {"construction": "refused by synthetic event orderer: " + str(exc)}


for case in ("D01", "D08", "D10-read", "C02"):
    j, r = control(case)
    out[f"control {case}"] = layers(j, r)

# F1: occupancy bypass (Stage 1 M4a/M4b) and non-occupying overlapping ports.
run(
    "F1 M4a channel non-occupying",
    "D01",
    lambda j, r: activity(r, "channel").update(occupies_resource=False),
)


def m4b(j: Any, r: Any) -> None:
    activity(r, "channel").update(occupies_resource=False, end_ps=54500)
    activity(r, "back-a").update(ready_ps=54500, start_ps=54500)


run("F1 M4b non-occupying channel, service end 54500", "D01", m4b)


def ports(overlap_flags: bool, reverse: bool) -> Any:
    def edit(j: Any, r: Any) -> None:
        a1, p1 = activity(r, "r1:port-a"), activity(r, "r1:port")
        a1.update(
            start_ps=59000,
            end_ps=59000,
            predecessors=[dict(activity_id="r1:back", relation="sequence")],
        )
        p1.update(ready_ps=59000, start_ps=59000, end_ps=60000)
        if reverse:
            activity(r, "r0:port-a").update(
                start_ps=60000,
                end_ps=60000,
                predecessors=[dict(activity_id="r1:port", relation="resource")],
            )
            activity(r, "r0:port").update(ready_ps=60000, start_ps=60000, end_ps=61000)
            q = deepcopy(
                next(
                    x
                    for x in r["observations"]["queue_membership"]["records"]
                    if x["activity_id"] == "r0:port-a"
                )
            )
            q["population"] = "waiting"
            r["observations"]["queue_membership"]["records"].append(q)
        else:
            for name in ("r0:port", "r1:port"):
                activity(r, name)["occupies_resource"] = overlap_flags

    return edit


run("F1 ports overlap [59000,60000) both non-occupying", "D08", ports(False, False))
run("F1 ports overlap [59000,60000) both occupying", "D08", ports(True, False))
# F9: tied-ready port grant reversed (r01 before r00); makespan stays 61000.
run("F9 port grant reversed r01 then r00", "D08", ports(True, True))

# F2: Stage 1 V1/V2.
run(
    "F2 V1 false credit on r01 port service",
    "D08",
    lambda j, r: activity(r, "r1:port")["predecessors"].append(
        dict(activity_id="r0:port", relation="credit")
    ),
)
run(
    "F2 V2 real cause dropped, r01 hop as credit",
    "D08",
    lambda j, r: activity(r, "r0:port-a").update(
        predecessors=[dict(activity_id="r1:back", relation="credit")]
    ),
)
run(
    "F2 V2b real cause dropped, r01 hop as sequence",
    "D08",
    lambda j, r: activity(r, "r0:port-a").update(
        predecessors=[dict(activity_id="r1:back", relation="sequence")]
    ),
)

# F3: Stage 1 M1/M2/M3 consistent forgeries.
run(
    "F3 M1 D10 response alignment relabelled memory",
    "D10-read",
    lambda j, r: activity(r, "back-a").update(category="memory"),
)
run(
    "F3 M2 D01 request hop owned by dma_port:0",
    "D01",
    lambda j, r: activity(r, "out").update(owner_id=owner(j, "dma_port:0")),
)
run(
    "F3 M3 D08 off-chain alignment without cause",
    "D08",
    lambda j, r: activity(r, "r1:back-a").update(predecessors=[]),
)


def cycle(j: Any, r: Any) -> None:
    left, right = activity(r, "r0:out-a"), activity(r, "r1:out-a")
    left["predecessors"] = [dict(activity_id="r1:out-a", relation="credit")]
    right["predecessors"] = [dict(activity_id="r0:out-a", relation="credit")]


def cycle_raw() -> None:
    j, r = control("D08")
    cycle(j, r)
    sorted_preds(r)
    r["result_hash"] = content_hash(r, exclude=("result_hash",))
    out["F3 C1 two zero-duration alignments, mutual credit (no resync)"] = layers(j, r)


cycle_raw()

# F8: Stage 1 F1a-F1e unbound fields, each resealed after synchronization.
for label, edit in [
    (
        "F8 critical predecessor_id forged",
        lambda j, r: r["observations"]["critical_path"]["records"][-1].update(
            predecessor_id="FORGED"
        ),
    ),
    (
        "F8 job blocking_predecessor_ids forged",
        lambda j, r: r["observations"]["jobs"]["records"][1].update(
            blocking_predecessor_ids=["r00"]
        ),
    ),
    (
        "F8 job owner moved to channel:6",
        lambda j, r: r["observations"]["jobs"]["records"][1].update(owner_id=owner(j, "channel:6")),
    ),
    (
        "F8 DMA_DONE relabelled STAT_SAMPLE",
        lambda j, r: [
            e.update(kind="STAT_SAMPLE")
            for e in r["observations"]["events"]["records"]
            if e["kind"] == "DMA_DONE"
        ],
    ),
    (
        "F8 job release_ps 50000",
        lambda j, r: r["observations"]["jobs"]["records"][0].update(release_ps=50000),
    ),
]:
    run(label, "D08", lambda j, r: None, edit)


# F4/F7: equal-footprint and unmasked lifetime inputs; selected B3/B2 refusals.
def resources_code(raw: Any) -> str:
    try:
        b = MappedBundle.model_validate(reseal(deepcopy(raw)))
        validate_resources(b, b.points[0])
        return "success"
    except ValueError as exc:
        return str(exc)[:110]


fix = ROOT / "docs/reviews/U4-B-component-joins-v2/fixtures"
equal = json.loads((fix / "B2-equal.json").read_text())["bundle"]
out["F4 B2-equal control"] = resources_code(equal)
for label, deps, finals in [
    ("F4 A3b z reads c's acc before producer c", [dict(before="z", after="c")], ["c"]),
    ("F4 A3c z and c share c's acc unordered", [], ["c", "z"]),
]:
    raw = deepcopy(equal)
    g = raw["points"][0]["task_graph"]
    next(x for x in g["jobs"] if x["id"] == "z")["accumulator_buffer_id"] = "acc"
    g["buffers"] = [x for x in g["buffers"] if x["id"] != "zacc"]
    next(x for x in g["buffers"] if x["id"] == "acc")["final_consumer_ids"] = finals
    g["dependencies"] = deps
    out[label] = resources_code(raw)
sel = json.loads(
    (ROOT / "docs/reviews/U4-B-component-stage2-v1/execution-selection.json").read_text()
)
reg = build()["registry"]
for row in sel["cases"]:
    if not (row["case_id"].startswith("B3-") or row["case_id"].startswith("B2-lifetime")):
        continue
    item = json.loads((ROOT / row["input_path"]).read_text())
    try:
        admit(
            item["bundle"],
            invocation="test",
            checkpoint="B",
            registry=reg,
            profile=item["profile"],
            trusted_registry_hash=reg["registry_hash"],
            trusted_profile_hash=item["profile"]["profile_hash"],
        )
        got = "success"
    except ValueError as exc:
        got = str(exc)[:110]
    out[f"F7 selected {row['case_id']}"] = dict(expected=row["expected_public_code"], got=got)


# F11: legacy profile/1 promise versus proposed profile/2 binding (reviewer's own D08 item).
def profile_case(versioned: bool, relabel: bool, anchor_old: bool = False) -> str:
    c = build()
    item = deepcopy(c["items"]["D08"])
    old_anchor = item["profile"]["profile_hash"]
    if versioned:
        p = item["profile"]
        p["format"] = "uarch-native-test-profile/2"
        for e in p["entries"]:
            e["mapping_policy"] = deepcopy(item["bundle"]["mapping_policy"])
        p["profile_hash"] = content_hash(p, exclude=("profile_hash",))
        item["bundle"]["admission"]["profile_hash"] = p["profile_hash"]
        reseal(item["bundle"])
    if relabel:
        item["bundle"]["mapping_policy"]["version"] = "2"
        reseal(item["bundle"])
    try:
        admit(
            item["bundle"],
            invocation="test",
            checkpoint="B",
            registry=c["registry"],
            profile=item["profile"],
            trusted_registry_hash=c["registry"]["registry_hash"],
            trusted_profile_hash=old_anchor if anchor_old else item["profile"]["profile_hash"],
        )
        return "success"
    except Exception as exc:  # noqa: BLE001
        return f"{type(exc).__name__}: {str(exc)[:100]}"


out["F11 profile/1 exact"] = profile_case(False, False)
out["F11 profile/1 @1->@2 relabel (legacy promise)"] = profile_case(False, True)
out["F11 profile/2 exact"] = profile_case(True, False)
out["F11 profile/2 @1->@2 relabel"] = profile_case(True, True)
out["F11 profile/2 bytes under old profile/1 anchor"] = profile_case(True, False, True)
json.dump(out, sys.stdout, indent=1, sort_keys=True)
print()
