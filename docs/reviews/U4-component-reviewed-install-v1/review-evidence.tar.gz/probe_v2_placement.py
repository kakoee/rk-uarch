"""Reviewer probe: @2 placement differs from @1 even with no heterogeneous core.

Two uniform 256x256x256 ops where "a" depends on "b" (dependency order != ID order).
No transient accumulator and no new edge appear, yet SRAM/HBM offsets change because @2
allocates in topological rather than ID order. (Channel striping is reported separately;
it only changes when buffer sizes are not multiples of 8 x 256 B.)
"""

import json
from copy import deepcopy
from pathlib import Path

from uarch_contract.mapped import MappedBundle
from uarch_contract.prepared import PreparedOp

from rkuarch.mapping.component import map_component

base = MappedBundle.model_validate_json(
    Path("contract/fixtures/mapped/component.json").read_bytes()
)
op0 = base.scope.ops[0].model_dump(mode="json")
ops = []
for name, deps in (("a", ["b"]), ("b", [])):
    d = deepcopy(op0)
    d.update(id=name, depends_on=deps)
    d["spec"]["dimensions"] = dict(M=256, K=256, N=256)
    ops.append(PreparedOp.model_validate(d))
g1 = map_component(ops, base.hardware_spec, mapping_version="1")
g2 = map_component(ops, base.hardware_spec, mapping_version="2")
o1 = {b.id: b.offset_bytes for b in g1.buffers}
o2 = {b.id: b.offset_bytes for b in g2.buffers}
e1 = {(d.before, d.after) for d in g1.dependencies}
e2 = {(d.before, d.after) for d in g2.dependencies}
c1 = {f.request_id: f.channel_id for j in g1.jobs if j.kind == "dma" for f in j.fragments}
c2 = {f.request_id: f.channel_id for j in g2.jobs if j.kind == "dma" for f in j.fragments}
print(
    json.dumps(
        dict(
            same_graph_hash=g1.graph_hash == g2.graph_hash,
            transient_accumulators=[
                b.id for b in g2.buffers if b.space == "accumulator" and b.producer_id
            ],
            added_edges=sorted(e2 - e1),
            buffers_with_different_offsets=sum(o1[k] != o2[k] for k in o1),
            fragments_with_different_channel=sum(c1[k] != c2[k] for k in c1),
        ),
        indent=1,
    )
)
