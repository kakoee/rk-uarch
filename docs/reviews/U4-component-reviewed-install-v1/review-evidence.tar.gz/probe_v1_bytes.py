"""Reviewer probe: default @1 mapper graph bytes on a fixed deterministic op set.

Run unchanged in the unpatched publication export and in the candidate export; diff output.
"""

import json
import random
from copy import deepcopy
from pathlib import Path

from uarch_contract.hashing import canonical_json, content_hash
from uarch_contract.mapped import MappedBundle
from uarch_contract.prepared import PreparedOp

from rkuarch.mapping.component import map_component

base = MappedBundle.model_validate_json(
    Path("contract/fixtures/mapped/component.json").read_bytes()
)
op0 = base.scope.ops[0].model_dump(mode="json")
rng = random.Random(7)
rows = {}
for case in range(40):
    count = 1 + case % 16
    ops = []
    for i in range(count):
        d = deepcopy(op0)
        deps = sorted(rng.sample(range(i), rng.randint(0, min(2, i)))) if i else []
        # Reverse IDs so dependency order differs from ID order.
        d.update(id=f"q{count - 1 - i:02}", depends_on=[f"q{count - 1 - x:02}" for x in deps])
        d["spec"]["dimensions"] = dict(
            M=rng.choice([1, 3, 255, 256, 600, 1024]),
            K=rng.choice([5, 256]),
            N=rng.choice([7, 255, 256]),
        )
        ops.append(PreparedOp.model_validate(d))
    for state in ("cold", "fixture_resident"):
        try:
            g = map_component(ops, base.hardware_spec, initial_state=state)
            rows[f"{case}-{state}"] = content_hash(json.loads(canonical_json(g)))
        except ValueError as exc:
            rows[f"{case}-{state}"] = "refused " + str(exc).split(":", 1)[0]
for case in range(40):
    count = 1 + case % 16
    m, k, n = (
        rng.choice([1, 3, 255, 256, 600, 1024]),
        rng.choice([5, 256]),
        rng.choice([7, 255, 256]),
    )
    ops = []
    for i in range(count):
        d = deepcopy(op0)
        deps = sorted(rng.sample(range(i), rng.randint(0, min(2, i)))) if i else []
        d.update(id=f"q{count - 1 - i:02}", depends_on=[f"q{count - 1 - x:02}" for x in deps])
        d["spec"]["dimensions"] = dict(M=m, K=k, N=n)
        ops.append(PreparedOp.model_validate(d))
    for state in ("cold", "fixture_resident"):
        try:
            g = map_component(ops, base.hardware_spec, initial_state=state)
            rows[f"uniform-{case}-{state}"] = content_hash(json.loads(canonical_json(g)))
        except ValueError as exc:
            rows[f"uniform-{case}-{state}"] = "refused " + str(exc).split(":", 1)[0]
rows["installed fixture ops"] = content_hash(
    json.loads(canonical_json(map_component(base.scope.ops, base.hardware_spec)))
)
print(json.dumps(rows, indent=0, sort_keys=True))
