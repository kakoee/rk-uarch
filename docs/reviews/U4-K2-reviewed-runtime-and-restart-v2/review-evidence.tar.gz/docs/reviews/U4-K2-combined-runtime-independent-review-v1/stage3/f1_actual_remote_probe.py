"""Stage 3 F1 probe against the ACTUAL expected remote (read-only), via B's production path.

usage: f1_actual_remote_probe.py PACKAGE LOCAL_ONLY_COMMIT DECOY_REPO
Hostile Git state is placed in os.environ BEFORE observation; the production view must
ignore it. LOCAL_ONLY_COMMIT exists only in a reviewer scratch clone (never pushed).
No push, credential, settings change or authority. Publication is not consent.
"""

import json
import os
import sys
from pathlib import Path

package, local_only, decoy = sys.argv[1:4]
sys.path.insert(0, package)
import bindings as b  # noqa: E402
import prepare  # noqa: E402
import publication  # noqa: E402

for module in (b, prepare, publication):
    assert Path(module.__file__).resolve().parent == Path(package).resolve()
HELPER = "0c4afcfa0ab314724afa869ac2d5736a22fb0e89"
OLD_HELPER = "2664c97bbf603843d756f78dd8d0d3e91762953c"
report = {"label": "actual remote, read-only; hostile inherited Git environment present"}
hostile = {
    "GIT_DIR": str(Path(decoy) / ".git"),
    "GIT_WORK_TREE": decoy,
    "GIT_OBJECT_DIRECTORY": str(Path(decoy) / ".git/objects"),
    "GIT_CONFIG_COUNT": "1",
    "GIT_CONFIG_KEY_0": "url." + str(Path(decoy).resolve()) + "/.insteadOf",
    "GIT_CONFIG_VALUE_0": "https://github.com/kakoee/rk-uarch.git",
    "HOME": decoy,
    "XDG_CONFIG_HOME": decoy,
}
os.environ.update(hostile)
report["hostile_env_keys"] = sorted(hostile)
try:
    prepare.published(Path("/unused"), HELPER, b.PACKAGE + "candidate.json")
    report["no_context_read"] = "ACCEPTED (defect)"
except ValueError as error:
    report["no_context_read"] = "refused: " + str(error)
with publication.observe() as view:
    report["observed_main"] = view.main
    report["simulated_remote"] = view.simulated
    c, data = prepare.checked_bundle(Path("/unused"), HELPER)  # tools + policy texts vs HERE
    report["checked_bundle_candidate_sha256"] = b.digest(data)
    report["checked_bundle_tools_and_policy_exact"] = True
    old = prepare.published(Path("/unused"), OLD_HELPER, "docs/reviews/U4-B-K2-combined-runtime-v1/candidate.json")
    report["reviewed_candidate_sha256"] = b.digest(old)
    for label, commit, path in [
        ("unpushed_local_commit", local_only, b.DECISION),
        ("path_traversal", HELPER, "../etc/passwd"),
    ]:
        try:
            prepare.published(Path("/unused"), commit, path)
            report[label] = "ACCEPTED (defect)"
        except ValueError as error:
            report[label] = "refused: " + str(error)
    receipt = view.receipt()
report["receipt_reads"] = receipt["reads"]
report["receipt_flags"] = {k: receipt[k] for k in ("simulated_remote", "replacement_objects_disabled",
                                                  "inherited_git_config_used", "remote")}
print(json.dumps(report, indent=2, sort_keys=True))
