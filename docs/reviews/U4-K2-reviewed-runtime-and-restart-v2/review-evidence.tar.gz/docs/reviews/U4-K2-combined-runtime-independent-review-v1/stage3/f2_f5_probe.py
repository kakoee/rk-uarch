"""Stage 3 probes: original F2 exploit vs corrected launcher; F5 shadow inside the container.

usage: f2_f5_probe.py PACKAGE PAYLOAD_ROOT WORK_DIR
F2: the Stage 1 synthetic exploit (labelled NOT A CAMPAIGN), unchanged, against launch.run.
F5: a private composition preflight (accepted image, native/process creation blocked by the
runtime's own preflight guard, selectors absent) whose program first places a byte-different
copy of resource_limits.py earlier on sys.path, inside container tmpfs.
"""

import json
import sys
from pathlib import Path

package, payload, work = sys.argv[1:4]
sys.path.insert(0, package)
import bindings as b  # noqa: E402
import launch  # noqa: E402

assert Path(launch.__file__).resolve().parent == Path(package).resolve()
report = {"label": "synthetic F2 inputs; private F5 composition; no native/authority"}

# F2 — Stage 1 exploit bytes, unchanged.
binding = {"synthetic": "not a runtime binding"}
output = Path(work) / "f2-exploit"
output.mkdir()
(output / "campaign.json").write_bytes(b.encoded({"runtime_binding": binding,
                                                  "synthetic": "NOT A CAMPAIGN"}))
(output / "campaign-launch.json").write_bytes(b.encoded({"complete": False, "exit_code": -9,
                                                         "stop_reason": "outer deadline"}))
(output / "campaign-failure.json").write_bytes(b.encoded({"complete": False}))
marker = Path(work) / "f2-process-started"
fixture = ["/bin/sh", "-c", f'[ "$0" = kill ] && exit 0; : > {marker}; exit 0', "fixture"]
try:
    launch.run(fixture, "replay", output, binding)
    report["f2_original_exploit"] = {"refused": False}
except ValueError as error:
    report["f2_original_exploit"] = {"refused": True, "reason": str(error)}
report["f2_original_exploit"].update(
    process_started=marker.exists(),
    replay_stdout_created=(output / "replay.stdout").exists(),
    replay_launch_receipt_created=(output / "replay-launch.json").exists(),
)

# F5 — real earlier-path helper shadow inside the accepted container.
c = json.loads((Path(package) / "candidate.json").read_bytes())
data = (Path(package) / "candidate.json").read_bytes()
out = Path(work) / "f5-shadow"
argv = launch.command("preflight", out, c)
argv = [x.replace(str(b.NEW), payload) for x in argv]
argv[-1] = (
    "import sys,pathlib;p=pathlib.Path('/tmp/shadow');p.mkdir();"
    "(p/'resource_limits.py').write_bytes(pathlib.Path('/combined/resource_limits.py')"
    ".read_bytes()+b'# reviewer byte-different shadow\\n');"
    "sys.path.insert(0,'/tmp/shadow');sys.path.insert(1,'/combined');"
    "import runtime_entry as r;r.main('private-preflight')"
)
try:
    launch.run(argv, "preflight", out, {"private_test": True, **b.identity(data)})
    report["f5_container_shadow"] = {"refused": False}
except ValueError as error:
    stderr = (out / "preflight.stderr").read_text()
    report["f5_container_shadow"] = {
        "refused": True,
        "outer": str(error),
        "inner_reason": [ln for ln in stderr.splitlines() if "Error" in ln][-1:],
        "preflight_json_written": (out / "preflight.json").exists(),
    }
print(json.dumps(report, indent=2, sort_keys=True))
