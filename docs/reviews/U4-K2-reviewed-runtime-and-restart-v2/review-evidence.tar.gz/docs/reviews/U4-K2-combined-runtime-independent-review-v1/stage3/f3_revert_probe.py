"""Stage 3 random-revert probe for F3 (selected by secrets.randbelow(6) == 2).

usage: f3_revert_probe.py PACKAGE_COPY RECEIPT [RECEIPT...]
Each RECEIPT is a PRIVATE diagnostic preflight.json (unsealed UID1000 payload). The probe
edits only the two self-declared fields the Stage 1 finding named (status, private_test)
and asks check_preflight whether the result is production preflight evidence.
Exit 0 = every edited diagnostic refused (correction effective); exit 1 = some accepted.
"""

import json
import sys
from pathlib import Path

package, receipts = sys.argv[1], sys.argv[2:]
sys.path.insert(0, package)
import bindings as b  # noqa: E402

assert Path(b.__file__).resolve().parent == Path(package).resolve()
candidate = (Path(package) / "candidate.json").read_bytes()
results = []
for path in receipts:
    pf = json.loads(Path(path).read_bytes())
    assert pf["private_test"] is True and pf["status"] == "private-composition-passed"
    edited = {**pf, "status": "combined-runtime-import-preflight-passed", "private_test": False}
    try:
        b.check_preflight(edited, candidate, pf["publication"])
        results.append({"receipt": Path(path).name, "outcome": "ACCEPTED as production evidence"})
    except ValueError as error:
        results.append({"receipt": Path(path).name, "outcome": "refused: " + str(error)})
print(json.dumps({"bindings_sha256": b.digest(Path(b.__file__).read_bytes()), "results": results}))
sys.exit(0 if all(r["outcome"].startswith("refused") for r in results) else 1)
