# U4 K2 combined runtime — fresh independent review (Stage 1)

Reviewer: a fresh session that authored none of the A, B or coordinator code in scope.
Scope: [reviewer prompt](../U4-component-next-wave-v1/reviewer.md), U-REVIEW Stage 1, applied to
the completed combined-runtime package. This review is evidence, not approval. It does not
replace final per-lane U4 reviews, human decisions, the 798-call campaign or its replay.
Nothing was installed, placed, approved, built, published or committed. No native engine
process ran. Author files, earlier review bytes and the case ledger were not changed.

## Target (verified before testing)

| Pin | Value | Check |
| --- | --- | --- |
| Package commit | `cbb0313e13abc0ca99311df323a0c64f4f7886c1` (tree `829a62b6…`) | exists; descends from main `490d90b` |
| Helper publication | `2664c97bbf603843d756f78dd8d0d3e91762953c` | ancestor of `cbb0313` |
| Candidate | `candidate.json` sha256 `932fe281…f06f9ee1` | matches at both commits |
| Tools/patch | `bindings.py`, `launch.py`, `prepare.py`, `runtime_entry.py`, addendum, unapplied patch | byte-identical at `2664c97` and `cbb0313` |
| A patches | runner/hardware-rule/host-session at `d9a22f0` | sha256 and `24fa368` preimages match `inputs.json` |
| B helper | combined patch `9f3595ab…`; `parallel_entrypoint.py` postimage `f96d6c7c…` | match |
| Native | source `24fa368…`, image `sha256:e9f69f41…` | image present locally |

`2664c97..cbb0313` changes only documentation and evidence (a README identity paragraph and
the `PUB=` pin in the procedure); the approval question is unchanged. The objects came from a
private, no-hardlink copy of the B clone; neither worker clone was modified. All work used
private exports in a scratch directory. Details are in
[results/identities-and-checks.json](results/identities-and-checks.json).

## Executed by this reviewer

| Check | Result |
| --- | --- |
| `prepare.py payload` at `2664c97`, accepted CPython 3.12.14 (`f7c6210e…`), `-I -S -B`, `env -i` | 39 files, 0 mismatches vs candidate; `publication.json` binds `2664c97` + `932fe281…` |
| 31-file closure provenance | 28 byte-identical at `24fa368` and `d9a22f0`; 3 are exact A postimages |
| Package guard tests, explicit `-c pytest.ini`/`--rootdir`, `python -I -S`, venv site only | **33 passed**; no `rkuarch`/`uarch_contract` module imported; `bindings` from the private export |
| CI-form mypy on the composed runtime tree (`24fa368` + 3 A patches), `PYTHONPATH`/`MYPYPATH` unset | no issues in 86 + 33 files; patched modules resolved from the private tree |
| Ruff check / format on the package at `cbb0313` | all checks passed; 8 files formatted |
| Genuine session + saved-output join (Q1/Q2), accepted image, original security flags, process creation denied | [results/reuse-exact.json](results/reuse-exact.json) |
| Request-guard removal (per-response validation replaced by a response cache) | [results/reuse-guard-removed.json](results/reuse-guard-removed.json) |
| Origin-guard removal in `bindings.origins` | only `test_project_origin_positive_and_foreign` fails (`DID NOT RAISE ValueError`, `test_packaging.py:76`); exact bytes restored (`148edf8f…`); 33 pass again |
| Hardware-rule differential, canonical vs runtime copy (Q3) | [results/hardware-rule-differential.json](results/hardware-rule-differential.json) |
| Publication trust, receipt gates and launcher polling (Q5/Q6) | findings F1–F4 below |
| Preservation | stopped run (362 entries) and sealed deployment (5,324 entries) identical before/after; new root absent ([results/preservation.json](results/preservation.json)) |

**Labels.** The join used the stopped run's **saved genuine debug-0 output** for `K06-00`
(and `K06-04` as a foreign output). It was fed through a replaced `runner._exchange`, and an
audit hook denied every process-creation event. It is a Python saved-output replay, not a
native run or a new campaign slot. Its payload was a UID1000 private copy checked with
`sealed=False`. B's `perform_case` was called directly in the parent, so no worker fork was
involved. The host launcher probes use a local `/bin/sh` process fixture writing through B's
exact `Store`; they are not container or native positives.

## Findings

Owners follow CODEOWNERS lanes: the package and scheduler are B; the request and session code
is A. Severity reflects consequence for the approved sequence. None claims a runtime
correctness failure in the native or validation path.

### F1 — `published()` does not authenticate publication and inherits Git state · B · Medium · BLOCKING before decision/binding rendering

`prepare.py:17-28` (used by `prepare.py:142-143`, `prepare.py:208` and `launch.py:117`) treats
"`git merge-base --is-ancestor <commit> refs/remotes/origin/main` in the caller's clone" as
publication. It then reads the blob with the caller's full environment and replace refs. The
README (lines 77–80) and the procedure present this as an independent check of the human
decision and coordinator placement. The original `deployment.publication_blob` at least set
`GIT_CONFIG_NOSYSTEM`/`GIT_CONFIG_GLOBAL`; this helper drops even that.

Reproducer: [probes/publication_trust_probe.py](probes/publication_trust_probe.py) on
private clones ([results/publication-trust.json](results/publication-trust.json)):
1. An **unpushed** local commit carrying a decision-shaped record (marked as a reviewer
   fabrication), with `refs/remotes/origin/main` moved locally, is returned by `published()`
   and passes `check_decision`.
2. `git replace 2664c97… <substitute>` makes `published(repo, "2664c97…", …)` return the
   **substituted bytes for the real published commit ID**. `--no-replace-objects` returns
   the real bytes. A human who checks that the commit ID exists on GitHub would be satisfied
   while the tool reads other content.
3. An inherited `GIT_DIR` makes `published(repo=<clone>, …)` read a different repository.

The procedure's `env -u` list does not clear `GIT_*`. Root placement by the human remains the
real gate, but the package's only machine check that a decision is genuine is satisfiable by
any UID1000 actor in the checkout. That is the self-signed replacement approval the prompt
excludes.

Necessary regression: Git runs with a fixed minimal environment and `--no-replace-objects`.
Tests show that (a) a replace ref, (b) inherited `GIT_DIR`/`GIT_*` and (c) a commit absent
from the actually observed remote main are each refused or explicitly unsupported. For (c),
also see policy choice H1. Accepting unknown extra fields in the decision is part of F6.

### F2 — Replay admission relies on `campaign.json` alone · B · Medium · BLOCKING before replay

`launch.py:127-135` admits replay when `campaign.json` exists, its `runtime_binding` matches
and `replays.json` is absent. `runtime_entry.py:240-241` checks only the binding. Neither
consults `campaign-launch.json` (exit code, `complete`, `stop_reason`),
`campaign-operational.json` or `campaign-failure.json`. A campaign whose outer launch was
recorded incomplete can therefore be replayed and acquire a complete-looking `replays.json`.
For example: an outer deadline, a poll failure (F4) or a daemon error after the scheduler
wrote `campaign.json` but before the container exited. The prompt requires full
snapshots/exit status, not `campaign.json` alone.

Reproducer: [probes/receipt_gate_probe.py](probes/receipt_gate_probe.py) builds a synthetic
output (labelled "NOT A CAMPAIGN") with a matching `campaign.json`, `campaign-launch.json`
`{complete: false, exit_code: -9}` and a `campaign-failure.json`. `launch.run(…, "replay", …)`
launches and records `replay-launch.json complete: true`
([results/receipt-gates.json](results/receipt-gates.json)).

Necessary regression: replay refuses before launch unless the same output holds a complete,
exit-0 `campaign-launch.json` with the same `runtime_binding`, a `campaign-operational.json`
and no `campaign-failure.json`. The container side repeats the receipt checks it can see.

### F3 — Preflight receipt states production root and immutability as constants · B · Low · NON-BLOCKING

`runtime_entry.py:229-230` writes `"root": str(b.NEW)` and `"immutable_mounts_checked": True`
unconditionally. `bindings.check_preflight` (`bindings.py:130-133`) treats both as evidence of
an actual immutable-root preflight. B's own
[evidence/private-preflight.json](../U4-B-K2-combined-runtime-v1/evidence/private-preflight.json)
came from a UID1000 `/tmp` payload checked with `sealed=False`, yet it states the production
root and `immutable_mounts_checked: true`. Flipping only the two self-declared fields `status`
and `private_test` makes `check_preflight` accept it
([results/receipt-gates.json](results/receipt-gates.json)). The coordinator's placement
reconciliation is the real control, but the receipt mislabels a diagnostic as an observation.

Necessary regression: the root and seal fields come from observation, for example bind
sources from `/proc/self/mountinfo` and the sealed inventory result. A private run's receipt
must then fail `check_preflight` even with those two fields edited. Alternatively, rename the
fields as declared expectations and stop using them as discriminators.

### F4 — Host launcher polling races `Store`'s transient files and kills the run · B · Low · NON-BLOCKING (fail-safe)

`launch.py:153-160` (inherited from `U4-B-K2-parallel-first-use-v1/launch.py:113-120`) lists
the live receipt tree and evaluates `p.is_file()` then `p.stat()`. `Store.publish`
(`parallel_core.py:68-80`) creates and removes `.budget-*` and `.pending-*` files in that tree.
If a removal lands between those two calls, `FileNotFoundError` is caught as a stop reason and
the container is SIGKILLed. Natural occurrence is rare.

Reproducer: [probes/launcher_poll_race.py](probes/launcher_poll_race.py) runs the unmodified
`launch.run()` with a process fixture
([results/launcher-poll-race.json](results/launcher-poll-race.json)). With deterministic
ordering (`is_file()` → concurrent unlink → `stat()`), it records
`stop_reason: FileNotFoundError`, `exit_code: -9`, `complete: false`. Under natural stress
with 16 forked writers using B's exact `Store`, no occurrence was observed in the runs listed
in that file. The probability for a real campaign is unmeasured. The failure is safe (no false
acceptance), but it can end the single approved campaign and require a new output.

Necessary regression: a vanished entry during polling is tolerated (or transient names are
excluded) without weakening the symlink and budget checks; the deterministic interleaving
test must pass.

### F5 — Preflight origin evidence narrowed to project modules · B · Low · NON-BLOCKING

`runtime_entry.py:231` records `b.origins(...)`, which keeps only `rkuarch`/`uarch_contract`
(`bindings.py:109`): 31 entries. The original sealed preflight recorded every module origin
(207, including `deployment` and `first_use_checks`). In the runtime, `/site`, `/project/*`,
the audit directory and `/campaign` precede `/combined` on `sys.path`, and helper module
origins (`bindings`, `parallel_*`, `resource_limits`, `entrypoint`, `deployment`,
`first_use_checks`) are neither checked nor recorded. My genuine join recorded them, and all
currently resolve to the intended files, so there is no present shadowing. The gap is latent:
an "extra import file" in an earlier path entry would go unreported.

Necessary regression: the preflight records all module origins and requires each helper name
to resolve to its bound file. A shadowing module placed earlier on the path must be refused.

### F6 — Decision `reply` must be literal `"yes"`; extra decision fields are ignored · B · Low · NON-BLOCKING

`bindings.py:149-153` and `186-189` require `reply == "yes"`. The procedure
(`decision-and-procedure.md:32-36`) says the coordinator records the "actual `reply`" and "the
genuine response only". A genuine "Yes, approved" cannot pass unless it is normalized, which
conflicts with the procedure. `check_decision` also ignores unknown fields (the fabricated
record in F1 carried an extra field), so recorded conditions would not affect the result.

Necessary regression: keep the verbatim reply separately from a normalized `accepted: true`
(or state the exact literal in the approval question), require the exact decision field set,
and test both.

No A or coordinator findings. A's request and session code behaved as claimed in every probe
I ran (see Q1–Q3).

## Human policy choices (not technical defects)

- **H1 — Meaning of "published".** Whether publication must be confirmed against the actual
  remote (and by whom: the human, at render time, against a remote-observed main SHA) or stays
  an explicit trusted premise. F1's hygiene fixes are needed either way. If it stays a premise,
  the README and procedure should say a local clone's refs are not proof.
- **H2 — Where the coexistence rule lives.** The addendum is consistent with U0002's selected
  policy: the altered copy is not claimed current, and generator, oracle and producer code
  cannot be imported from the 31-file closure. Javid may still want U0002 to cross-reference
  this bounded U0011 runtime copy, since U0002 ends "No runtime currentness waiver … is
  claimed."
- **H3 — Retry after operational failure.** A failed replay cannot be re-run into the same
  campaign output (`replay.stdout` is opened exclusively), and the addendum approves one
  restart. Decide whether an operational failure of campaign or replay (for example F4) needs
  a new decision or whether a bounded retry policy is pre-approved.
- **H4 — Deadlines.** The outer launcher deadline (7,200 s, from container start) equals the
  plan's inner processing cap (7,200 s, processing only). The outer one therefore governs.
  This is acceptable if intended; the historical rates suggest a far shorter campaign.

## Answers to review questions

1. **Request reuse — holds.** One genuine `resolution_session` for both modes (52.6 s), driving
   B's real `perform_case` with A's `admitted_case` and B's independent checker: clean gives 6
   fresh transport calls and 6 checked receipts. A foreign genuine **2nd** response is refused
   (`ProtocolViolation`, cause `ResultBindingMismatch`) after 1 checked success. A rehashed
   busy-drift **6th** response is refused (`IncompleteObservations`) after 5. Transport
   receipts for the failed slots are preserved. Replacing per-response validation with a
   response cache makes both corruptions pass (6/6 checked), so my probe fails for the
   intended reason. The packaging guard independently refuses that mutated runtime
   (`payload bytes: …runner.py`). Nested caller mutation, mode/authority drift, PID/expiry and
   reentrancy are inherited A controls (`tests-final/final_controls.py`), not rerun here.
2. **Startup reuse — holds within its premises.** Construction runs once. `select()` rehashes
   every observed file and compares the exact selector bytes. Each emitted binding is
   materialized from owned canonical bytes. `open_executable()` rehashes the ELF on every
   call. B's 14 bound-read faults are inherited, not rerun. The README correctly lists "no
   concurrent privileged attacker" as a premise. The addendum's last sentence ("stops the
   sequence before native execution") describes sequence steps; a root mutation during the
   campaign is detected only by post-campaign snapshots.
3. **Hardware rule — holds.** Canonical vs runtime copy: identical outcomes on 5,247 paths
   (54 rules; including Arabic-Indic digits, `\n`, empty and 10k-character inputs), on 7
   invalid input types (same exception types and messages), and on value edits, front
   reorder, deletion, global rebinding and a non-string key. The cache stays at 128 with 454
   live rules and remains correct. Source identity changes (`98b1b06d…`) while outputs do
   not. The proposed runtime-copy treatment is coherent; see H2.
4. **Scheduler — holds by code and inherited evidence, not executed here.** 133 cases × 2
   modes × 3 repetitions, with case contexts entered inside `perform_case` after fork and no
   nested pool. The adapter's monkeypatches (`Store`, `verify_helpers`, `verify_release`,
   `input_snapshot`, `common`) resolve through module globals in `campaign()`, so they take
   effect. `run_workers` with `admitted_case` in forked workers, discovery, cleanup and the
   780/18 outcome split were not executed (full campaign out of scope).
5. **Deployment identity — mostly holds; see F1, F3, F5.** Exactly 39 payload files; separate
   `/project` imports; the original `/candidate` validated by `verify_bytes` and the resolver;
   no `/candidate/src` on the path; no old seven-file overlay; both identities in receipts.
   The `docker_argv` positional edits (`argv[-2:]`, index 4, `argv[:3]` for kill) match the
   original sealed helper. The human placement script is `set -euC`, non-clobbering, and
   checks hashes per file.
6. **Campaign and replay — see F2, F4.** The original replay controls run unchanged through
   `BASE.replay`; the launcher and runtime expose no quick profile; B's checks.json separates
   executed from inherited work. Fault controls ran on `942eae9`, a comment-only difference
   from the final runtime that B disclosed.

## Observations (no change requested)

- O1: B's per-slot check validates the returned `result` object, not the slot's stdout bytes.
  With A's per-response validation removed, corrupted responses passed per slot and only
  the final six-way comparison would catch them. In the real runtime, A's canonical byte
  equality covers this. A cheap `canonical(result) == out` check in `perform_case` would add
  defence in depth.
- O2: B's composition-controls evidence is for subject `942eae9`, not the helper pin, as
  checks.json states; my payload hashes differ from it only in `runtime_entry.py`,
  `candidate.json` and `publication.json`.

## Not executed (coverage gaps)

Actual immutable-root placement and real preflight (`sealed=True` inside the container);
`launch.verify()` for any action; the `prepare placement`/`binding` stages (they need real
publications); the runtime's campaign and replay actions, including `BoundStore` on a real
`campaign.json`; forked workers and resource discovery; the full 798-call campaign and replay;
B's 14 bound-read faults and 10 guard removals; A's lifetime/mutation matrix; remote CI. No
native positive exists in this review.

## Files

[probes/](probes/) holds the reviewer scripts. [results/](results/) holds bounded outputs.
Fabricated records exist only in private scratch clones and outputs, and each is marked
"REVIEWER PROBE"/"NOT A CAMPAIGN". This report is left unstaged for coordinator preservation.
Stage 3 returns to this session after the authors answer every finding.

---

## Stage 3 adjudication — 2026-10-16 (PDT)

Same independent session as Stage 1; I authored none of the corrections. Scope: U-REVIEW
Stage 3 on B's response only. No new numbered findings are raised here.

**Subject (verified before execution, from private exports with a sanitized Git environment
and replacement objects disabled).** Response commit `e2649edf3ad99816d7879d7dc81e2646e4a09975`
(tree `a9ba3f2b…`), helper commit `0c4afcfa0ab314724afa869ac2d5736a22fb0e89`, package
`docs/reviews/U4-B-K2-combined-runtime-stage2-v1/`, candidate `ecc0dfaf…a98664c9b81`, response
README `7dd1a0c8…6cf6d94174`. `cbb0313` is an ancestor of the helper commit, which is an
ancestor of the response. Candidate, code, tools, tests and policy bytes are identical at
the helper and response commits; the response adds only evidence, `checks.json`,
`inputs.json` and `publication.json`. The payload has 40 files:

- the 31 project files, unchanged from the prior candidate;
- seven helpers, of which `parallel_entrypoint.py`, `parallel_core.py`, `resource_limits.py`
  and `parallel-policy.json` are unchanged, and `bindings.py`, `runtime_entry.py` and the new
  `receipt_checks.py` equal the package bytes;
- two records.

The three auxiliary helper pins match the sealed originals. No `docs/decisions/`,
`contract/`, golden, native or third-party file changed. The Stage 1 report matched 18,864
bytes / `6949858e…`. Receipts are in [stage3/results.json](stage3/results.json).

**Disclosure about my own files.** After the Stage 1 handoff, at 17:43 −0700 on 2026-10-16, I
rewrote `results/launcher-poll-race.json` in place to add the completed fourth stress run.
That was after B's checks (17:35–17:39) and after the coordinator manifest pinned the
1,212-byte "pending" version. For Stage 3 I rebuilt the exact pinned bytes (`18cef85e…`,
hash-verified) and restored them. The completed run is recorded separately in
[stage3/stage1-stress-completion.json](stage3/stage1-stress-completion.json): four natural
runs, 82,652 publications, no failure. It is not used to adjudicate F4.

### Checks executed

| Check | Result |
| --- | --- |
| Final suite, `reproduce.md` form (explicit `-c pytest.ini`, `--rootdir`, env unset) | **77 passed** |
| Same suite, stricter `python -I -S` with origin report | 77 passed; no `rkuarch`/`uarch_contract` import on the host; helpers from the private export; `deployment` from the sealed original |
| Tests-first: 8 selected regressions against the original `cbb0313` code | 8 failed, 0 collection/import errors |
| B's essential-guard harness (7 groups, both F2 boundaries) | each corrected 0 / removed 1 / restored 0; patch and source hashes identical to B's evidence |
| Private container composition, run once (accepted image, process creation blocked, selectors absent) | 40 files; positive/restored exit 0; seven expected refusals exit 1; payload matches the candidate and B's remote postimages 40/40 |
| F1 against the actual remote, read-only ([stage3/f1-actual-remote.json](stage3/f1-actual-remote.json)) | see F1 below |
| F2 exploit and in-container F5 shadow ([stage3/f2_f5_probe.py](stage3/f2_f5_probe.py)) | see F2 and F5 below |
| Protected patches in a disposable copy | both apply to the recorded preimages and yield the recorded postimages |
| Ruff check (tracked export); format check and scoped mypy (11 package files) | pass; the scoped mypy is not a full strict project typecheck |
| Preservation | stopped run (362 entries) and sealed deployment (5,324) identical before/after; v2 root absent; no containers left; worker clones clean |

The composition was needed because F3's mount and inode observations and F5's helper origins
only exist inside the container. The actual-remote read was needed because B's tests use
fixture remotes for every F1 negative.

### Random revert

`secrets.randbelow(6)` selected index 2, **F3** (recorded in
[stage3/results.json](stage3/results.json)). My independent revert, distinct from B's guard
patch, restores the pre-correction semantics: the declared `expected_deployment_root` is
accepted in place of the observed seal, inventory and mount-source checks
([stage3/f3-revert.diff](stage3/f3-revert.diff)). [stage3/f3_revert_probe.py](stage3/f3_revert_probe.py)
edits only `status` and `private_test` on two **real private diagnostic receipts**: my fresh
composition receipt and B's evidence receipt.

- **Corrected** (`d386db5b…`): both refused with `observed production seal required`; B's three
  F3 tests pass.
- **Reverted** (`af58c7da…`): both **accepted as production evidence**, so the probe fails for
  the intended reason. B's two F3 tests also fail, but with `KeyError`, not on an acceptance
  assertion (see O-S3-2).
- **Restored** to exact bytes (`d386db5b…`): both refused again; B's three F3 tests pass.

### Row dispositions (all B, all APPLIED IN PROPOSAL)

| Row | (a) row | (c) fails without it | Adjudication |
| --- | --- | --- | --- |
| F1 | yes | yes | **Accepted.** All reads go through a fresh bare object store fetched from the exact expected remote, with a fixed environment, `--no-replace-objects`, no inherited config and no offline fallback. Against the **actual** GitHub remote, with hostile `GIT_DIR`/`GIT_OBJECT_DIRECTORY`/`GIT_CONFIG_*`/`HOME` inherited: observed main `95839665…`; `checked_bundle` returned candidate `ecc0dfaf…` with tools and policy texts byte-identical to the package; the reviewed `932fe281…` candidate was read; an unpushed, marked local commit, path traversal and a no-context read were all refused; the decoy repository was unchanged. Fixture-remote negatives (B's tests) are kept separate from this actual observation. Publication is correctly described as not consent. |
| F2 | yes | yes (host and runtime) | **Accepted.** Host `launch.run` and `runtime_entry` share `replay_admission`, which runs before replay process creation and before resolution or transport. It requires launch, operational, resource, worker and snapshot receipts that agree with each other, exit 0, exact 798/780/18 outcomes and no failure receipt. My unchanged Stage 1 exploit is refused (`campaign failure receipt forbids replay`) without starting a process or creating replay stdout or a launch receipt. B's labelled 798-slot receipt-shape fixture admits, and 13 fault variants refuse. The container-side gate is exercised only structurally (limitation). |
| F3 | yes | yes (random revert) | **Accepted.** Receipts now separate `expected_deployment_root` from observed mountinfo bind sources and the inode seal and inventory. My fresh private receipt honestly reports scratch-path sources, `seal_check_enforced: false` and uid 1000, and editing the two flags no longer yields production evidence. The README correctly states that JSON is not host attestation and that coordinator reconciliation, human placement and the absence of a privileged attacker remain premises. |
| F4 | yes | yes | **Accepted.** `receipt_bytes` does one `lstat` per entry and tolerates only `FileNotFoundError`; persistent bytes are still counted, and symlinks, unexpected inodes and `PermissionError` refuse. The deterministic `Store` pending-file disappearance during the real poll loop passes corrected and fails reverted. No soak was needed. See O-S3-1 on how the reverted failure surfaces. |
| F5 | yes | yes | **Accepted.** All module origins are recorded with an explicit file, built-in, frozen or no-file kind (204/52/18/2 in the private run; no count is pinned). `helper_origins` checks each of the nine bound helper paths and hashes, and equals the candidate's `helper_imports` in the container. In the accepted container, a byte-different `resource_limits.py` placed earlier on `sys.path` is refused (`helper origin: resource_limits`) before any `preflight.json` is written. |
| F6 | yes | yes | **Accepted.** Exact v2 field set; `reply_verbatim` is kept untouched, with a separate `accepted` boolean, `disposition=accepted-unconditional`, `conditions=[]` and decision/policy/amendment/candidate joins. Affirmative variants are preserved byte-for-byte; conditional, rejected, missing, extra, wrong-identity, empty and non-boolean records refuse. The procedure and approval question match the code. Every approval-shaped record in tests is synthetic. |

(b) does not apply: nothing was rejected or deferred. The H1–H4 text, the U0011 addendum and
the U0002 cross-reference are consistent with the coordinator's proposed choices and remain
PROPOSED. Current behaviour is stop-on-failure (fresh output only; replay refuses if
`replays.json` exists); no retry authority exists. U0024 is unchanged.

### Observations (not findings; for coordinator triage)

- **O-S3-1:** F4's baseline and guard-removal failures surface as `ValueError: duplicate
  receipt…`. The test's global `Popen` patch re-enters `Store` when the launcher runs its kill
  branch (`launch.py:167` in the traceback). The race is what causes it, but patching only the
  first `Popen` would make the assertion direct.
- **O-S3-2:** B's F3 fixtures (a synthetic preflight without `expected_deployment_root`, and
  the old-format receipt) cannot detect a revert to "declared root as evidence" by
  acceptance; they fail on `KeyError`. Adding a real private receipt to the F3 regression,
  as my probe does, would close that gap.
- **O-S3-3:** `check_preflight` requires the mountinfo `source_root` to equal
  `NEW/<suffix>`. That holds only when the deployment path's filesystem is mounted at `/` on
  the Docker host, which is true here. Otherwise the real preflight fails closed, which is
  safe; confirm during actual placement.
- **O-S3-4:** Each `observe()` fetches main over HTTPS and refuses if main moves between
  `ls-remote` and `fetch`. That is correct, but on an active main a render can fail
  operationally.

### Limitations

Not executed: actual immutable placement and preflight; a real decision or placement
publication and selector binding; `launch.verify()` on a placed root; the runtime replay
gate with real receipts inside a container; authority resolution; any native execution; the
798-call campaign and replay; B's 14 bound-read faults; A's matrices (inherited with pins);
hosted CI. The GitHub observation is a point-in-time, read-only check under TLS/DNS trust.

### Verdict

**ACCEPTED.** Every row has a response, nothing was rejected or deferred, and each applied
correction has a test that fails without it. No row is at fault. This concerns B's software
response only. It is not human policy approval, installation, placement or preflight,
campaign or replay completion, K2 or component qualification, final U4 review or sprint
closure.
