"""Reviewer probe: host launcher receipt polling vs Store's transient atomic files.

HOST PROCESS FIXTURE ONLY. No container, authority or native engine. Uses the package's
unmodified launch.run() and B's exact parallel_core.Store bytes; the "container" is a
local /bin/sh process whose children publish receipts the way case workers do.

usage: launcher_poll_race.py PACKAGE_DIR PARALLEL_DIR OUT_DIR MODE [SECONDS] [WORKERS]
MODE: interleave (deterministic is_file()->unlink->stat ordering) | stress (natural race)
"""

import hashlib
import json
import pathlib
import sys
import time

package, parallel, out, mode = sys.argv[1:5]
seconds = float(sys.argv[5]) if len(sys.argv) > 5 else 120
workers = int(sys.argv[6]) if len(sys.argv) > 6 else 16
sys.path[:0] = [package]
import bindings as b  # noqa: E402
import launch  # noqa: E402

core = pathlib.Path(parallel) / "parallel_core.py"
assert "sha256:" + hashlib.sha256(core.read_bytes()).hexdigest() == (
    "sha256:bbe3746760753c388ac1fa3f3420016f008281a1014638863320e073e15348b1"
), "exact B parallel_core bytes"
output = pathlib.Path(out)
writer = pathlib.Path(__file__).resolve().parent / "receipt_writer.py"
script = (
    '[ "$0" = kill ] && exit 0; exec /usr/bin/python3 -I '
    + str(writer)
    + " "
    + parallel
    + " "
    + str(output)
    + " "
    + mode
    + " "
    + str(seconds)
    + " "
    + str(workers)
)
argv = ["/bin/sh", "-c", script, "fixture"]
if mode == "interleave":
    real_is_file = pathlib.Path.is_file

    def is_file_then_concurrent_unlink(self):
        answer = real_is_file(self)
        if answer and self.name.startswith(".pending-"):
            self.unlink()  # the worker's link()+unlink() lands between is_file() and stat()
        return answer

    pathlib.Path.is_file = is_file_then_concurrent_unlink
started = time.monotonic()
try:
    launch.run(argv, "campaign", output, {"fixture": "host process; not a binding"})
    raised = None
except ValueError as error:
    raised = str(error)
receipt = json.loads((output / "campaign-launch.json").read_bytes())
report = {
    "mode": mode,
    "seconds_requested": seconds,
    "workers": workers,
    "elapsed": time.monotonic() - started,
    "launch_raised": raised,
    "stop_reason": receipt["stop_reason"],
    "exit_code": receipt["exit_code"],
    "complete": receipt["complete"],
    "published_files": sum(1 for p in output.rglob("*.json") if "calls" in p.parts),
    "label": "host process fixture; no container/native/authority",
}
print(json.dumps(report, indent=2))
