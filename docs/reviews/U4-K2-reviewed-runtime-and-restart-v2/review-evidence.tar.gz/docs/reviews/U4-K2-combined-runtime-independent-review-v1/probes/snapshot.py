"""Content+metadata snapshot of a tree (read-only). Usage: snapshot.py ROOT"""
import hashlib, json, os, sys
root = sys.argv[1]
rows = {}
for d, dirs, files in os.walk(root):
    dirs.sort()
    for n in sorted(dirs + files):
        p = os.path.join(d, n); st = os.lstat(p)
        row = [st.st_mode, st.st_uid, st.st_size, st.st_ino, int(st.st_mtime_ns)]
        if os.path.isfile(p) and not os.path.islink(p):
            row.append(hashlib.sha256(open(p, 'rb').read()).hexdigest())
        rows[os.path.relpath(p, root)] = row
data = json.dumps(rows, sort_keys=True).encode()
print(json.dumps({"root": root, "entries": len(rows), "sha256": hashlib.sha256(data).hexdigest()}))
