"""Fixture 'container': forked children publish receipts through B's exact Store."""

import multiprocessing
import os
import sys
import time
from pathlib import Path

parallel, out, mode, seconds, workers = sys.argv[1:6]
sys.path.insert(0, parallel)
from parallel_core import Store  # noqa: E402

root = Path(out)
store = Store(root, 2 * 1024**3)


def worker(index):
    deadline = time.monotonic() + float(seconds)
    n = 0
    while time.monotonic() < deadline and n < 4000:
        payload = os.urandom(2048)
        store.blob(payload)
        store.json(f"calls/w{index}-{n}.json", {"worker": index, "n": n})
        n += 1
        time.sleep(0.002)


if mode == "interleave":
    # One publication whose temporary is observed by the launcher, then idle.
    store.json("calls/first.json", {"n": 0})
    (root / "calls" / ".pending-fixture").write_bytes(b"temporary")
    time.sleep(30)
else:
    ctx = multiprocessing.get_context("fork")
    procs = [ctx.Process(target=worker, args=(i,)) for i in range(int(workers))]
    for p in procs:
        p.start()
    for p in procs:
        p.join()
