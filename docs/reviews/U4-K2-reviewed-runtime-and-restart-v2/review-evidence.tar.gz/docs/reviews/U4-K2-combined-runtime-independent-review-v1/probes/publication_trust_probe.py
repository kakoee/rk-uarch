"""Reviewer probe: what prepare.published() actually authenticates. PRIVATE CLONES ONLY.

Every decision-shaped record below is a reviewer FABRICATION carrying an explicit
'reviewer_probe' marker. Nothing is rendered into a placement script, placed or executed.

usage: publication_trust_probe.py PACKAGE_DIR PRIVATE_CLONE DECOY_CLONE
"""

import json
import os
import subprocess
import sys
from pathlib import Path

package, clone, decoy = sys.argv[1:4]
sys.path[:0] = [package]
import bindings as b  # noqa: E402
import prepare  # noqa: E402

PUB = "2664c97bbf603843d756f78dd8d0d3e91762953c"
CAND = b.PACKAGE + "candidate.json"
GIT_ENV = {"PATH": "/usr/bin:/bin", "HOME": os.environ.get("HOME", "/nonexistent"),
           "GIT_AUTHOR_NAME": "probe", "GIT_AUTHOR_EMAIL": "probe@invalid",
           "GIT_COMMITTER_NAME": "probe", "GIT_COMMITTER_EMAIL": "probe@invalid"}


def git(*args, repo=clone, data=None):
    return subprocess.run(["git", *args], cwd=repo, env=GIT_ENV, input=data,
                          capture_output=True, check=True).stdout


real = git("show", PUB + ":" + CAND)
data = real
publication = {"helper_commit": PUB, "candidate_hash": b.digest(data)}
report = {"label": "private clones; fabricated records are marked and never placed"}


def commit_with(path, content, parent):
    """Commit `content` at `path` on top of `parent` without touching any worktree."""
    blob = git("hash-object", "-w", "--stdin", data=content).decode().strip()
    index = Path(clone) / ".git" / "probe-index"
    env = {**GIT_ENV, "GIT_INDEX_FILE": str(index)}
    subprocess.run(["git", "read-tree", parent], cwd=clone, env=env, check=True)
    subprocess.run(["git", "update-index", "--add", "--cacheinfo", f"100644,{blob},{path}"],
                   cwd=clone, env=env, check=True)
    tree = subprocess.run(["git", "write-tree"], cwd=clone, env=env, capture_output=True,
                          check=True).stdout.decode().strip()
    index.unlink()
    return git("commit-tree", tree, "-p", parent, "-m", "REVIEWER PROBE - NOT PUBLISHED",
               data=b"").decode().strip()


# 1. Local-only commit + locally moved remote-tracking ref is treated as "published".
fabricated = b.encoded({
    "format": "uarch-k2-combined-human-decision/1",
    "accepted_by": "Javid (@jjaffari)",
    "reply": "yes",
    "scope": "isolated-protected-runtime-placement-preflight-and-798-call-restart",
    "amendment_hash": json.loads(data)["amendment_hash"],
    "binding": b.identity(data),
    "publication": publication,
    "reviewer_probe": "FABRICATED BY REVIEWER - NOT A HUMAN DECISION",
})
main = git("rev-parse", "refs/remotes/origin/main").decode().strip()
local = commit_with(b.DECISION, fabricated, main)
git("update-ref", "refs/remotes/origin/main", local)
raw = prepare.published(Path(clone), local, b.DECISION)
b.check_decision(json.loads(raw), data, publication)
report["local_only_commit_accepted_as_published"] = {
    "commit": local, "pushed": False, "check_decision": "passed"}
git("update-ref", "refs/remotes/origin/main", main)  # restore

# 2. Replace object: same real published commit id, substituted bytes.
altered = real.replace(b'"status": "proposal-only-no-execution-authority"',
                       b'"status": "REVIEWER-SUBSTITUTED"')
assert altered != real
substitute = commit_with(CAND, altered, PUB)
git("replace", PUB, substitute)
seen = prepare.published(Path(clone), PUB, CAND)
plain = subprocess.run(["git", "--no-replace-objects", "show", PUB + ":" + CAND], cwd=clone,
                       env=GIT_ENV, capture_output=True, check=True).stdout
report["replace_ref_same_commit_id"] = {
    "commit": PUB,
    "published_returned_substitute": seen == altered,
    "no_replace_objects_returns_real": plain == real,
}
git("replace", "-d", PUB)  # restore

# 3. Inherited GIT_DIR silently retargets cwd=repo to another repository.
decoy_commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=decoy, env=GIT_ENV,
                              capture_output=True, check=True).stdout.decode().strip()
os.environ["GIT_DIR"] = str(Path(decoy) / ".git")
try:
    seen = prepare.published(Path(clone), decoy_commit, "DECOY.txt")
    report["inherited_GIT_DIR"] = {"read_from_decoy": seen == b"decoy repository\n",
                                   "repo_argument": clone}
finally:
    del os.environ["GIT_DIR"]
assert git("rev-parse", "refs/remotes/origin/main").decode().strip() == main
assert not git("replace", "-l")
print(json.dumps(report, indent=2))
