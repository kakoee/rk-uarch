"""Reviewer probe: canonical vs runtime-copy hardware_unit_rule behaviour.

usage: hardware_rule_probe.py SITE CONTRACT_ROOT  -> JSON on stdout
Run once per contract root (canonical 24fa368, composed runtime copy) in separate
isolated processes, then diff. Live-edit checks mutate this process's module only.
"""

import json
import random
import sys

site, contract = sys.argv[1:3]
sys.path[:0] = [site, contract]
import uarch_contract.hardware as hw  # noqa: E402

rules = hw.HARDWARE_UNIT_RULES


def outcome(path):
    try:
        return ["ok", list(hw.hardware_unit_rule(path))]
    except Exception as error:  # compare exact type and message
        return ["err", type(error).__name__, str(error)]


corpus = []
rng = random.Random(20261016)
for pattern in rules:
    for index in ["0", "7", "12", "01", "١", "-1", "", " 1", "1\n"]:
        for wild in ["x", "a.b", "", "\n", "é", "x\ny"]:
            corpus.append(pattern.replace("[]", "[" + index + "]").replace("*", wild))
    corpus += [pattern, pattern + "\n", "\n" + pattern, pattern + ".", pattern.upper(), pattern[:-1]]
corpus += ["", ".", "*", "[]", "\x00", "a" * 10000, "clock_domains..freq_hz"]
for _ in range(2000):
    corpus.append("".join(rng.choice("ab.[]*019_\n é") for _ in range(rng.randint(0, 24))))
invalid = [None, 1, 1.5, b"clock_domains.core.freq_hz", ["x"], ("x",), {"x": 1}]

report = {
    "rule_count": len(rules),
    "rules_type": type(rules).__name__,
    "corpus": len(corpus),
    "results": [outcome(p) for p in corpus],
    "invalid": [outcome(p) for p in invalid],
}

# Live edits: value change, front insertion (reorder), deletion, rebinding, non-str key.
first = next(iter(rules))
probe = first.replace("[]", "[3]").replace("*", "z")
saved = dict(rules)
live = {}
rules[first] = ("edited-label",)
live["value_edit"] = outcome(probe)
rules.clear()
rules.update({"*": ("front-wildcard",)})
rules.update(saved)
live["front_insert_reorder"] = outcome(probe)
del rules["*"]
del rules[first]
live["deleted"] = outcome(probe)
rules.clear()
rules.update(saved)
hw.HARDWARE_UNIT_RULES = {first: ("rebound",)}
live["rebound_global"] = outcome(probe)
hw.HARDWARE_UNIT_RULES = rules
rules[123] = ("int-key",)  # type: ignore[index]
live["non_str_key_unmatched_path"] = outcome("no.such.rule")
del rules[123]  # type: ignore[arg-type]
live["restored"] = outcome(probe)
cache = getattr(hw, "_compiled_hardware_unit_rule", None)
if cache is not None:
    for i in range(400):
        rules[f"synthetic.rule{i}.x"] = (f"u{i}",)
    live["many_rules_last"] = outcome("synthetic.rule399.x")
    live["many_rules_first_after_thrash"] = outcome(probe)
    info = cache.cache_info()
    live["cache"] = {"maxsize": info.maxsize, "currsize": info.currsize}
    for i in range(400):
        del rules[f"synthetic.rule{i}.x"]
report["live"] = live
print(json.dumps(report, sort_keys=True))
