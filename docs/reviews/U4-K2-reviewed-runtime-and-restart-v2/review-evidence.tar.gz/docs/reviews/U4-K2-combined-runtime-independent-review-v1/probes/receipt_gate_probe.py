"""Reviewer probe: preflight receipt fields, origin evidence scope, replay admission gate.

usage: receipt_gate_probe.py PACKAGE_DIR WORK_DIR
SYNTHETIC records only; labelled; none is a campaign result or authority.
"""

import json
import sys
from pathlib import Path

package, work = sys.argv[1:3]
sys.path[:0] = [package]
import bindings as b  # noqa: E402
import launch  # noqa: E402

report = {"label": "synthetic gate inputs; no container/native/authority"}
evidence = json.loads((Path(package) / "evidence/private-preflight.json").read_bytes())
data = (Path(package) / "candidate.json").read_bytes()

# C. A private /tmp UID1000 run already states the production root and immutability.
report["private_receipt_claims"] = {k: evidence[k] for k in ("root", "immutable_mounts_checked",
                                                             "status", "private_test")}
relabelled = {**evidence, "status": "combined-runtime-import-preflight-passed",
              "private_test": False}
try:
    b.check_preflight(relabelled, data, evidence["publication"])
    report["check_preflight_on_private_run_with_two_flags_flipped"] = "ACCEPTED"
except ValueError as error:
    report["check_preflight_on_private_run_with_two_flags_flipped"] = "refused: " + str(error)

# D. Origin evidence scope versus the original sealed preflight.
original = json.loads(Path("/var/lib/rkuarch/k2/candidate-04-first-use-v1/manifests/preflight.json")
                      .read_bytes())
report["origin_scope"] = {
    "original_preflight_origins": len(original["origins"]),
    "original_includes_helpers": sorted(n for n in original["origins"]
                                        if n in ("entrypoint", "deployment", "first_use_checks")),
    "new_preflight_origins": len(evidence["origins"]),
    "new_non_project": sorted(n for n in evidence["origins"]
                              if n.split(".")[0] not in ("rkuarch", "uarch_contract")),
}

# Replay admission: an incomplete campaign launch with a matching campaign.json.
binding = {"synthetic": "not a runtime binding"}
output = Path(work) / "replay-gate"
output.mkdir()
(output / "campaign.json").write_bytes(b.encoded({"runtime_binding": binding,
                                                  "synthetic": "NOT A CAMPAIGN"}))
(output / "campaign-launch.json").write_bytes(b.encoded({"complete": False, "exit_code": -9,
                                                         "stop_reason": "outer deadline"}))
(output / "campaign-failure.json").write_bytes(b.encoded({"complete": False}))
fixture = ["/bin/sh", "-c", '[ "$0" = kill ] && exit 0; exit 0', "fixture"]
try:
    launch.run(fixture, "replay", output, binding)
    replay_receipt = json.loads((output / "replay-launch.json").read_bytes())
    report["replay_after_incomplete_campaign"] = {"launched": True,
                                                  "replay_complete": replay_receipt["complete"]}
except ValueError as error:
    report["replay_after_incomplete_campaign"] = {"launched": False, "refused": str(error)}
print(json.dumps(report, indent=2))
