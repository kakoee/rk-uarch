"""Reviewer probe: later-response corruption inside the COMPOSED case scheduler.

Runs inside the accepted image as UID1000 with the original read-only mounts, the
reviewer's private (UID1000) composed payload at /project,/combined,/combined-record,
the ORIGINAL root-owned native selector, and the stopped run's saved genuine outputs
at /saved (read-only). Native transport is REPLACED by a feeder of saved genuine
bytes and every process-creation audit event is denied. Nothing here is a native run.

argv[1]: "exact" (composed payload) or "guard-removed" (private mutated runner copy).
"""

import hashlib
import json
import os
import sys
import time
import traceback
from pathlib import Path

VARIANT = sys.argv[1]
OUT = Path("/receipts")
CASE, FOREIGN = "K06-00", "K06-04"
T0 = time.monotonic()
report = {"variant": VARIANT, "native_calls": 0, "label": "saved genuine outputs; transport blocked"}


def sha(data):
    return "sha256:" + hashlib.sha256(data).hexdigest()


def saved_stream(case_id):
    row = json.loads(Path(f"/saved/calls/debug-0-{case_id}.json").read_bytes())
    streams = {}
    for field in ("request", "stdout", "stderr"):
        data = (Path("/saved") / row[field]).read_bytes()
        assert sha(data) == row[field + "_hash"], "saved stream drift"
        streams[field] = data
    assert row["status"] == 0
    return streams


try:
    # Same final sys.path order runtime_entry.common() produces (+ /combined last).
    sys.path[:0] = [
        "/site",
        "/project/src",
        "/project/contract",
        "/candidate/docs/reviews/U4-B-K2-construction-audit-v1",
        "/campaign",
        "/combined",
    ]
    import entrypoint as base

    sys.meta_path.insert(0, base.NoProducers())
    import bindings
    import parallel_entrypoint as pe
    from deployment import slots
    from first_use_checks import check_real_result
    from parallel_core import Store
    from uarch_contract.hashing import canonical_json, content_hash
    from uarch_contract.mapped import MappedEngineJob

    from rkuarch.engines.native import host, runner

    origins = {
        n: m.__file__
        for n, m in list(sys.modules.items())
        if n.split(".")[0] in ("rkuarch", "uarch_contract")
    }
    assert origins and all(f.startswith("/project/") for f in origins.values()), origins
    report["project_origins"] = len(origins)
    report["helper_origins"] = {
        n: sys.modules[n].__file__
        for n in (
            "bindings",
            "entrypoint",
            "deployment",
            "first_use_checks",
            "parallel_entrypoint",
            "parallel_core",
            "resource_limits",
        )
    }
    if VARIANT == "exact":
        bindings.check_payload("/project", "/combined", "/combined-record", sealed=False)
        report["payload_check"] = "passed (sealed=False; UID1000 private copy)"
    else:
        try:
            bindings.check_payload("/project", "/combined", "/combined-record", sealed=False)
            report["payload_check"] = "UNEXPECTEDLY PASSED"
        except ValueError as error:
            report["payload_check"] = "refused: " + str(error)

    def deny(event, args):
        if event in (
            "subprocess.Popen",
            "os.exec",
            "os.posix_spawn",
            "os.system",
            "os.fork",
            "os.forkpty",
            "os.spawn",
        ):
            raise RuntimeError("probe: process creation denied: " + event)

    sys.addaudithook(deny)

    plan = json.loads(Path("/campaign/campaign-plan.json").read_bytes())
    cases = {c["case_id"]: c for c in plan["case_membership"]}
    assert cases[CASE]["outcome"] == "success"
    context = (None, plan, slots(plan), host, runner, canonical_json, content_hash,
               MappedEngineJob, check_real_result)
    answers = base.read_json(
        base.ROOT / "docs/reviews/U4-A-K2-construction-v1/corpus/expectations.json"
    )
    genuine, foreign = saved_stream(CASE), saved_stream(FOREIGN)
    assert genuine["request"] == (base.ROOT / cases[CASE]["file"]["path"]).read_bytes()
    raw = json.loads(genuine["stdout"])
    raw["busy_time_ps"][0]["busy_time_ps"] += 1
    raw["result_hash"] = content_hash(raw, exclude=("result_hash",))
    rehashed_busy = canonical_json(raw).encode()
    scenarios = {
        "clean": {},
        "foreign-genuine-2nd": {1: foreign["stdout"]},
        "rehashed-busy-drift-6th": {5: rehashed_busy},
    }
    original_exchange = runner._exchange
    started = time.monotonic()
    with pe.resolve_campaign_hosts(base, plan, host) as hosts:
        report["genuine_session_seconds"] = time.monotonic() - started
        report["hosts"] = {m: h.executable.byte_hash for m, h in hosts.items()}
        for name, faults in scenarios.items():
            store_root = OUT / name
            store_root.mkdir()
            store = Store(store_root, plan["receipt_budget_bytes"])
            pe.STATE = (base, context, hosts, cases, answers, store)
            fed = []

            def feeder(fd, request, limits, fed=fed, faults=faults):
                index = len(fed)
                fed.append(sha(request))
                assert request == genuine["request"], "request drift"
                assert os.fstat(fd).st_size > 0, "verified ELF descriptor"
                return faults.get(index, genuine["stdout"]), genuine["stderr"], 0

            runner._exchange = feeder
            t = time.monotonic()
            try:
                result = pe.perform_case(CASE)
                outcome = {"completed": True, "slots": result["slots"]}
            except BaseException as error:  # record exact refusal and its cause
                outcome = {
                    "completed": False,
                    "type": type(error).__name__,
                    "message": str(error),
                    "cause": repr(error.__cause__),
                }
            finally:
                runner._exchange = original_exchange
                pe.STATE = None
            outcome["feeder_calls"] = len(fed)
            outcome["checked_receipts"] = sorted(p.name for p in (store_root / "calls").iterdir()) \
                if (store_root / "calls").exists() else []
            outcome["transport_receipts"] = sorted(
                p.name for p in (store_root / "transport").iterdir()
            ) if (store_root / "transport").exists() else []
            outcome["seconds"] = time.monotonic() - t
            report[name] = outcome
    report["total_seconds"] = time.monotonic() - T0
    # Discriminating expectations (the probe's own regression assertions).
    expect = {
        "clean": (True, 6, 6),
        "foreign-genuine-2nd": (False, 2, 1),
        "rehashed-busy-drift-6th": (False, 6, 5),
    }
    failures = []
    for name, (completed, calls, checked) in expect.items():
        o = report[name]
        if (o["completed"], o["feeder_calls"], len(o["checked_receipts"])) != (
            completed,
            calls,
            checked,
        ):
            failures.append(f"{name}: expected completed={completed} calls={calls} "
                            f"checked={checked}; observed {o['completed']} "
                            f"{o['feeder_calls']} {len(o['checked_receipts'])}")
        if not completed and o.get("type") != "ProtocolViolation":
            failures.append(f"{name}: expected ProtocolViolation, observed {o.get('type')}")
    report["probe_failures"] = failures
    report["probe_passed"] = not failures
except BaseException:
    report["setup_error"] = traceback.format_exc()
    report["probe_passed"] = False
(OUT / "probe-report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(json.dumps({"probe_passed": report["probe_passed"]}))
sys.exit(0 if report["probe_passed"] else 1)
