"""Host side: original sealed docker_argv + read-only reviewer mounts; bounded and reaped.

usage: run_container_probe.py PAYLOAD_ROOT OUTPUT VARIANT
"""

import importlib.util
import json
import subprocess
import sys
import uuid
from pathlib import Path

OLD = Path("/var/lib/rkuarch/k2/candidate-04-first-use-v1")
PROBES = Path(__file__).resolve().parent
payload, output, variant = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
spec = importlib.util.spec_from_file_location("original_deployment", OLD / "campaign/deployment.py")
deployment = importlib.util.module_from_spec(spec)
spec.loader.exec_module(deployment)
output.mkdir()
argv = deployment.docker_argv("campaign", output, True)  # selector mount; action replaced below
extra = []
for src, dst in [
    (payload / "project", "/project"),
    (payload / "helpers", "/combined"),
    (payload / "record", "/combined-record"),
    (Path("/tmp/u4-k2-approved-campaign"), "/saved"),
    (PROBES, "/probe"),
]:
    extra += ["--mount", f"type=bind,src={src},dst={dst},readonly,bind-propagation=rprivate"]
i = argv.index("--entrypoint")
argv[i:i] = extra
argv[-2:] = ["/probe/request_reuse_probe.py", variant]
name = "u4-k2-review-probe-" + uuid.uuid4().hex
argv[4:4] = ["--name", name]
(output.parent / (output.name + "-argv.json")).write_text(json.dumps(argv, indent=2) + "\n")
try:
    proc = subprocess.run(argv, capture_output=True, timeout=1200, env={"PATH": "/usr/bin:/bin"})
    code = proc.returncode
    (output.parent / (output.name + ".stdout")).write_bytes(proc.stdout)
    (output.parent / (output.name + ".stderr")).write_bytes(proc.stderr)
except subprocess.TimeoutExpired:
    subprocess.run(argv[:3] + ["kill", "--signal", "KILL", name], check=False)
    code = "timeout"
print(json.dumps({"variant": variant, "exit": code}))
