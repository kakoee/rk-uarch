"""Explicitly authorized standalone c2-probe reproduction; no engine source."""
import pathlib,json,hashlib,subprocess,time
R=pathlib.Path(__file__).resolve().parent;P=R/'subject/docs/reviews/U4-A-K2-C2-compatibility-v1'
ORIGINAL='/tmp/u4-k2-c2r.s0udc3ig';CMDS=json.loads((P/'commands.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def run(name,template,stdin=None,replace=None,expect=0):
 old=next(c for c in CMDS if c['name']==template)
 argv=[a.replace(ORIGINAL,str(R)) for a in old['argv']]
 if replace:argv=[replace(a) for a in argv]
 env={k:v.replace(ORIGINAL,str(R)) for k,v in old['environment'].items()}
 if 'run' in argv:
  assert argv[argv.index('--network')+1]=='none' and argv[argv.index('--pull')+1]=='never'
  assert '--read-only' in argv and '--cap-drop' in argv
  assert not any('diagnostic' in a or 'strace' in a or 'no-vectorize' in a for a in argv)
 t=time.time_ns();r=subprocess.run(argv,env=env,input=stdin,capture_output=True)
 for ext,b in [('stdout',r.stdout),('stderr',r.stderr)]:(R/'receipts'/f'{name}.{ext}').write_bytes(b)
 rec={'name':name,'template':template,'argv':argv,'environment':env,'started_ns':t,'finished_ns':time.time_ns(),'exit_code':r.returncode,'stdin_sha256':None if stdin is None else sha(stdin),'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'stdout_equals_A':sha(r.stdout)==old['stdout_sha256'],'stderr_equals_A':sha(r.stderr)==old['stderr_sha256']}
 out=R/'output/commands.json';cs=json.loads(out.read_text()) if out.exists() else [];cs.append(rec);out.write_text(json.dumps(cs,indent=2)+'\n')
 print(name,r.returncode,round((time.time_ns()-t)/1e9,3),flush=True)
 assert r.returncode==expect,r.stderr.decode(errors='replace')[-5000:]
 return r
if __name__=='__main__':
 expected={'native/Cargo.lock','native/Cargo.toml','native/crates/uarch-engine/Cargo.toml','native/crates/uarch-engine/src/bin/c2-probe.rs'}
 assert {str(p.relative_to(R/'workspace')) for p in (R/'workspace').rglob('*') if p.is_file()}==expected
 assert sha((R/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs').read_bytes())=='90d7b36df0aac589ff01f360fe294641586ac1406651b697bb4e97068dc84695'
 for name in ['image-inspect','rustc','cargo','probe-metadata']:
  result=run(name,name)
  if name=='probe-metadata':
   got=json.loads(result.stdout);accepted=json.loads((P.parent/'U4-A-K2-C1-precise-v1/metadata-full.stdout').read_text());assert got['resolve']==accepted['resolve'];assert len(got['packages'])==36
   root=next(x for x in got['packages'] if x['name']=='uarch-engine');assert len(root['targets'])==1 and root['targets'][0]['name']=='c2-probe' and root['targets'][0]['kind']==['bin']
   for pkg in got['packages']:
    old=next(x for x in accepted['packages'] if x['id']==pkg['id']);assert pkg['features']==old['features'] and pkg['dependencies']==old['dependencies']
 for mode in ['debug','release']:
  run('build-'+mode+'-package','build-'+mode+'-package')
  run('build-test-'+mode+'-package','build-test-'+mode+'-package')
  binary=R/'target'/mode/'c2-probe';assert sha(binary.read_bytes())==json.loads((P/'summary.json').read_text())['binary_sha256'][mode]
  for ds in ['vectors','supplement','B-extension','A-extension']:
   run('corrected-'+mode+'-'+ds,'corrected-'+mode+'-'+ds,stdin=(R/'vectors'/f'{ds}.jsonl').read_bytes())
  run('independent-'+mode,'corrected-'+mode+'-vectors',stdin=(R/'vectors/independent.jsonl').read_bytes())
 print('all standalone corrected reproductions finished',flush=True)
