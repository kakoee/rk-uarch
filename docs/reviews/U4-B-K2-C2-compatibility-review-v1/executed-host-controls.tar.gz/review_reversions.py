"""Verify saved three-family evidence and scratch patch restoration; no native execution."""
import pathlib,json,tarfile,hashlib,subprocess,importlib.util,gzip,time
R=pathlib.Path(__file__).resolve().parent;P=R/'subject/docs/reviews/U4-A-K2-C2-compatibility-v1'
spec=importlib.util.spec_from_file_location('compare',P/'compare.py');cmp=importlib.util.module_from_spec(spec);spec.loader.exec_module(cmp)
with tarfile.open(P/'executed-controls.tar.gz') as t:controls={m.name:t.extractfile(m).read() for m in t.getmembers()}
with tarfile.open(P/'command-outputs.tar.gz') as t:outputs={m.name:t.extractfile(m).read() for m in t.getmembers()}
mp=json.loads((P/'command-output-map.json').read_text())
def raw(n):return outputs[mp[n+'.stdout']['member']]
allrows={}
for name in ['vectors','supplement','B-extension','A-extension']:
 for row in cmp.records((R/'vectors'/f'{name}.jsonl').read_bytes()):allrows[row['id']]=row
rules=json.loads((P/'refusals.json').read_text());reports={}
for family in ['leaf','integer-zero','legacy-float']:
 rows=cmp.records(controls[f'variants/{family}/selection.jsonl']);assert rows and len({v['id'] for v in rows})==len(rows)
 for row in rows:assert row==allrows[row['id']]
 patchroot=R/'reversion-patch-check'/family;patchroot.mkdir(parents=True,exist_ok=True)
 f=patchroot/'probe.rs';f.write_bytes((P/'probe.rs').read_bytes())
 for reverse in [False,True,False]:
  argv=['patch','--batch','-p1','-i',str(P/'reversions'/f'{family}.patch')]+(['-R'] if reverse else [])
  c=subprocess.run(argv,cwd=patchroot,capture_output=True);assert c.returncode==0,c.stderr
  expected=(P/'probe.rs').read_bytes() if reverse else controls[f'variants/{family}/workspace/native/crates/uarch-engine/src/bin/c2-probe.rs']
  assert f.read_bytes()==expected
 reports[family]={'selected':len(rows),'selection_sha256':hashlib.sha256(controls[f'variants/{family}/selection.jsonl']).hexdigest(),'scratch_patch_forward_reverse_forward':True,'modes':{}}
 for mode in ['debug','release']:
  got=cmp.compare(rows,cmp.records(raw(f'revert-{family}-{mode}-execute')),rules)
  restored=cmp.compare(rows,cmp.records(raw(f'restored-{family}-{mode}')),rules)
  pos=[v['id'] for v in got['mismatches'] if v['expected']['status']=='ok'];assert pos and restored['mismatch_count']==0
  unit=raw(f'revert-{family}-{mode}-unit').decode();names=[x.split(' ... ')[0] for x in unit.splitlines() if x.startswith('test ') and ' ... ' in x];assert len(names)==len(set(names))==12
  reports[family]['modes'][mode]={'saved_mismatches':got['mismatch_count'],'expected_positive_failures':pos,'restored_mismatches':restored['mismatch_count'],'saved_unit_names':names}
 # Final source restoration in scratch; does not claim a rebuilt restored executable.
 f.write_bytes((P/'probe.rs').read_bytes());assert hashlib.sha256(f.read_bytes()).hexdigest()=='90d7b36df0aac589ff01f360fe294641586ac1406651b697bb4e97068dc84695'
 reports[family]['scratch_final_source_restored']=True
freeze={}
for name in ['extension-freeze.json','refusal-freeze.json','unit-tests-freeze.json','build-inputs.json']:
 d=json.loads((P/name).read_text());freeze[name]=d.get('time_ns',d.get('timestamp_ns'))
assert max(freeze[x] for x in freeze if x!='build-inputs.json')<freeze['build-inputs.json']
a=pathlib.Path('/tmp/u4-k2-c2r.s0udc3ig');mtimes={n:(a/'receipts'/n).stat().st_mtime_ns for n in ['build-debug-package.stdout','build-test-debug-package.stdout','corrected-debug-vectors.stdout','build-release-package.stdout','corrected-release-vectors.stdout']};assert min(mtimes.values())>freeze['build-inputs.json']
report={'families':reports,'freeze_timestamps':freeze,'actual_saved_output_mtimes':mtimes,'chronology_limit':'Recorded local ordering, not external timestamp attestation','new_native_execution':False,'restored_sources_in_private_scratch':True,'author_executions_inherited_not_rerun':True}
(R/'output/reversion-audit.json').write_text(json.dumps(report,indent=2)+'\n');print({k:{'selected':v['selected'],'mismatches':v['modes']['debug']['saved_mismatches'],'positive_failures':len(v['modes']['debug']['expected_positive_failures'])} for k,v in reports.items()})
