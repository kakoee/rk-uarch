"""Classify frozen refusal conditions from pinned Python, not native error outputs."""
import sys,pathlib,json,hashlib,math,struct,re,time,tarfile
R=pathlib.Path(__file__).resolve().parent;P=R/'subject/docs/reviews/U4-A-K2-C2-compatibility-v1'
sys.path[:0]=[str(R/'reference/contract'),'/home/jjaff/AI-infra-simulation/rk-uarch/.venv/lib/python3.12/site-packages']
from pydantic import TypeAdapter,ValidationError
from uarch_contract import hashing as h
from uarch_contract.sourced import SourcedValue
rules=json.loads((R/'vectors/refusals.json').read_text())
def ratio(d):
 if not isinstance(d,dict) or set(d)!={'numerator','denominator'}:return 'RationalFields'
 for k in ['numerator','denominator']:
  if type(d[k]) is not int:return 'IntegerToken'
  if not 0<=d[k]<2**128:return 'IntegerRange'
 assert d['denominator']==0 or math.gcd(d['numerator'],d['denominator'])!=1
 return 'InvalidRatio'
def classify(row):
 op=row['op'];raw=bytes.fromhex(row.get('hex',''));layer='carrier';detail=[]
 if op=='float':assert not math.isfinite(struct.unpack('>d',bytes.fromhex(row['bits']))[0]);return 'canonical','nonfinite f64',[]
 try:s=raw.decode('utf-8')
 except UnicodeDecodeError:return 'utf8','invalid utf-8',[]
 duplicate=[]
 def pairs(items):
  if len(dict(items))!=len(items):duplicate.append(True)
  return dict(items)
 try:d=json.loads(s,object_pairs_hook=pairs)
 except Exception:
  raise AssertionError(('unexpected syntax not manually covered',row['id']))
 if duplicate:return 'strict-json','DuplicateJsonKey',[]
 if op=='marker':return 'strict-json','ReservedNumericMarker',['intentional protocol guard; Python JSON object alone is not a refusal']
 if op=='identity':
  try:h.verify_identity(d,row['field'])
  except Exception as e:return 'identity','ArtifactHashMismatch',[type(e).__name__]
  raise AssertionError('identity unexpectedly valid')
 if op=='canonical':
  if s in ['NaN','Infinity']:return 'strict-json','expected value',[]
  if s=='-Infinity':return 'strict-json','invalid number',[]
  if s=='1e999':return 'canonical','nonfinite f64',[]
  if '\\ud800' in s:return 'strict-json','unexpected end of hex escape',['Python can parse lone surrogate then fails UTF-8 encoding']
  if '\\udfff' in s:return 'strict-json','lone leading surrogate',['Python can parse lone surrogate then fails UTF-8 encoding']
  raise AssertionError(row['id'])
 if op=='u128':return layer,'IntegerToken' if type(d) is not int else 'IntegerRange',[]
 if op=='rational':return layer,ratio(d),[]
 if op=='leaf':
  if not isinstance(d,dict) or set(d)!={'path','value'} or not isinstance(d.get('path'),str) or not d['path'].strip():return layer,'LeafFields',[]
  v=d['value']
  if isinstance(v,dict):return layer,ratio(v),[]
  return layer,'IntegerToken' if isinstance(v,float) else 'LeafScalar',[]
 if op=='json-float':return layer,'JsonFloatFinite' if type(d) in (int,float) else 'JsonFloatType',[]
 if op=='sourced':
  try:SourcedValue.model_validate(d)
  except ValidationError as e:detail=[{'loc':x['loc'],'type':x['type'],'msg':x['msg']} for x in e.errors()]
  else:raise AssertionError('expected refusal valid')
  if 'extra' in d:return layer,'unknown field `extra`',detail
  if 'value' not in d:return layer,'missing field `value`',detail
  v=d['value']
  if type(v) in (dict,list) or v is None:return layer,'LegacyFloatType',detail
  try:f=TypeAdapter(float).validate_python(v)
  except ValidationError:return layer,'LegacyFloatSyntax',detail
  if not math.isfinite(f):return layer,'LegacyFloatFinite',detail
  return layer,'SourcedValue rules',detail
 raise AssertionError(op)
reports=[]
for fn in ['vectors','supplement','B-extension','A-extension']:
 for row in map(json.loads,(R/'vectors'/f'{fn}.jsonl').read_bytes().split(b'\n')[:-1]):
  if row['expected']['status']!='refuse':continue
  layer,reason,detail=classify(row);rule=rules[row['id']]
  assert rule['condition']['input_sha256']==hashlib.sha256(bytes.fromhex(row.get('hex',''))).hexdigest()
  assert (layer,reason)==(rule['layer'],rule['reason_class']),(row['id'],layer,reason,rule)
  reports.append({'id':row['id'],'layer':layer,'reason_class':reason,'reference_details':detail})
# Inspect exact initial-to-final rule changes; no reason/layer/input change allowed.
with tarfile.open(P/'executed-controls.tar.gz') as tar:initial=json.loads(tar.extractfile('receipts/refusals-initial.json').read())
changed=[]
for name,rule in rules.items():
 old=initial[name]
 if rule!=old:
  assert {k:v for k,v in rule.items() if k!='error_pattern'}=={k:v for k,v in old.items() if k!='error_pattern'}
  assert rule['error_pattern']==old['error_pattern']+r'(?: at line \d+ column \d+)?'
  changed.append(name)
(R/'output/refusal-audit.json').write_text(json.dumps({'count':len(reports),'reports':reports,'initial_to_final_suffix_only':changed,'rules_sha256':hashlib.sha256((R/'vectors/refusals.json').read_bytes()).hexdigest(),'basis':'Python model errors and literal failed conditions, without native output','timestamp_ns':time.time_ns()},indent=2)+'\n')
print('Independently matched',len(reports),'rules;',len(changed),'suffix-only refinements')
