import pathlib,hashlib,json,shutil,gzip,subprocess,time
R=pathlib.Path(__file__).resolve().parent
P=R/'subject/docs/reviews/U4-A-K2-C2-compatibility-v1';BASE=P.parent/'U4-A-K2-C2-probes-v1'
A=pathlib.Path('/tmp/u4-k2-c2r.s0udc3ig')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inv(root):return {str(p.relative_to(root)):{'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in sorted(root.rglob('*')) if p.is_file()}
old=inv(A);(R/'original-A-before.json').write_text(json.dumps(old,sort_keys=True));print('A original files',len(old),flush=True)
for n,d in json.loads((P/'inventory.json').read_text()).items():assert sha(P/n)==d['sha256']
for n,d in json.loads((P.parent/'U4-K2-C2-compatibility-reconciliation-v1/receipt.json').read_text())['bindings'].items() if (P.parent/'U4-K2-C2-compatibility-reconciliation-v1/receipt.json').exists() else []:assert sha(R/'subject'/n)==d
for dest,src in [('native/Cargo.lock','accepted.Cargo.lock'),('native/Cargo.toml','workspace.Cargo.toml'),('native/crates/uarch-engine/Cargo.toml','probe.Cargo.toml'),('native/crates/uarch-engine/src/bin/c2-probe.rs','probe.rs')]:
 f=R/'workspace'/dest;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(P/src,f)
# Exact patch forward/reverse on a distinct single-file scratch, never the baseline evidence.
p=R/'patch-check';p.mkdir();shutil.copy2(BASE/'probe.rs',p/'probe.rs')
for reverse in [False,True,False]:
 cmd=['patch','--batch','-p1','-i',str(P/'probe.patch')]+(['-R'] if reverse else [])
 c=subprocess.run(cmd,cwd=p,capture_output=True,text=True);assert c.returncode==0,c.stderr
 assert (p/'probe.rs').read_bytes()==(BASE/'probe.rs' if reverse else P/'probe.rs').read_bytes()
expected=json.loads((A/'receipts/copied-before.json').read_text())['cache'];actual=inv(A/'cache');assert actual==expected
shutil.copytree(A/'cache',R/'cache',dirs_exist_ok=True);assert inv(R/'cache')==expected
for n in ['rustc-wrapper.sh','linker.sh']:shutil.copy2(A/'controls'/n,R/'controls'/n)
for name,src in [('vectors.jsonl',BASE/'vectors.jsonl.gz'),('supplement.jsonl',BASE/'identity-supplement.jsonl.gz'),('B-extension.jsonl',P/'B-extension.jsonl.gz'),('A-extension.jsonl',P/'A-extension.jsonl.gz')]:
 (R/'vectors'/name).write_bytes(gzip.decompress(src.read_bytes()))
shutil.copy2(P/'refusals.json',R/'vectors/refusals.json')
(R/'output/setup.json').write_text(json.dumps({'review_subject':'923face8359e6f7ac017c560d9af207509f173b5','original_A_files':len(old),'cache_entries_verified':len(actual),'cache_snapshot_sha256':hashlib.sha256(json.dumps(actual,sort_keys=True).encode()).hexdigest(),'workspace':inv(R/'workspace'),'vectors':inv(R/'vectors'),'patch_forward_reverse_forward':True,'private_import_root':str(R/'reference'),'timestamp_ns':time.time_ns()},indent=2)+'\n')
print('setup complete',len(actual),'cache entries',flush=True)
