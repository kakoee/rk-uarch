"""Compare newly executed outputs, preserving independently frozen counterexamples."""
import pathlib,json,hashlib,re,importlib.util
R=pathlib.Path(__file__).resolve().parent;P=R/'subject/docs/reviews/U4-A-K2-C2-compatibility-v1'
s=importlib.util.spec_from_file_location('compare',P/'compare.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
rules=json.loads((P/'refusals.json').read_text());report={'new_native_execution':True,'modes':{},'independent':{}}
for mode in ['debug','release']:
 ds={}
 for name in ['vectors','supplement','B-extension','A-extension']:
  rows=c.records((R/'vectors'/f'{name}.jsonl').read_bytes());raw=(R/'receipts'/f'corrected-{mode}-{name}.stdout').read_bytes()
  out=c.records(raw);result=c.compare(rows,out,rules);assert result['mismatch_count']==0
  assert raw==(R/'receipts'/f'corrected-debug-{name}.stdout').read_bytes()
  ds[name]={'count':result['count'],'mismatches':0,'refusals':len(result['refusals']),'stdout_sha256':c.sha(raw)}
 unit=(R/'receipts'/f'build-test-{mode}-package.stdout').read_text();names=[x for x in unit.splitlines() if x.startswith('test ') and ' ... ' in x]
 assert len(names)==len(set(names))==12 and all(x.endswith(' ... ok') for x in names)
 report['modes'][mode]={'datasets':ds,'unit_results':names,'binary_sha256':c.sha((R/'target'/mode/'c2-probe').read_bytes())}
 rows=c.records((R/'vectors/independent.jsonl').read_bytes());raw=(R/'receipts'/f'independent-{mode}.stdout').read_bytes();out=c.records(raw)
 assert raw==(R/'receipts/independent-debug.stdout').read_bytes();assert [x['id'] for x in rows]==[x['id'] for x in out]
 bad=[];frozen_reason_checks=0
 for v,a in zip(rows,out,strict=True):
  if a['status']=='ok':
   assert set(a)=={'id','status','canonical','sha256'} and c.sha(a['canonical'].encode())==a['sha256']
  else:assert set(a)=={'id','status','layer','error'} and a['layer'] in {'carrier','strict-json'} and a['error']
  if v['expected']['status']!=a['status'] or a['status']=='ok' and any(v['expected'].get(k)!=a[k] for k in ('canonical','sha256')):bad.append({'input':v,'actual':a})
  if 'expected_native_refusal' in v:
   layer,error=v['expected_native_refusal'];assert a['status']=='refuse' and a['layer']==layer and re.fullmatch(re.escape(error)+r'(?: at line \d+ column \d+)?',a['error']);frozen_reason_checks+=1
 assert [x['input']['id'] for x in bad]==['B2:legacy:blank-control-unit','B2:legacy:blank-control-rationale']
 report['independent'][mode]={'count':len(rows),'matching_status_and_values':len(rows)-len(bad),'mismatches':bad,'frozen_native_reason_checks':frozen_reason_checks,'remaining_refusals':'Observed reasons separately preserved; not retroactively frozen','stdout_sha256':c.sha(raw)}
commands=json.loads((R/'output/commands.json').read_text());freeze=json.loads((R/'output/python-derivation.json').read_text());assert min(x['started_ns'] for x in commands)>freeze['timestamp_ns']
report['independent_freeze_before_all_B_native_commands']=True
(R/'output/native-review.json').write_text(json.dumps(report,indent=2)+'\n')
print({m:{'full':sum(x['count'] for x in r['datasets'].values()),'unit':len(r['unit_results'])} for m,r in report['modes'].items()});print('Independent: 64/66 status/value agreement; 2 preserved blank-field counterexamples per mode')
