"""Host-only saved-output audit and comparator reversion/restoration controls."""
import pathlib,json,hashlib,importlib.util,tarfile,gzip,copy
R=pathlib.Path(__file__).resolve().parent;P=R/'subject/docs/reviews/U4-A-K2-C2-compatibility-v1'
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
new=load(P/'compare.py','reviewed_compare');old=load(R/'controls/inherited-compare.py','historical_compare')
rules=json.loads((R/'vectors/refusals.json').read_text());mapping=json.loads((P/'command-output-map.json').read_text())
with tarfile.open(P/'command-outputs.tar.gz') as tar:outputs={m.name:tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
def actual(name):return new.records(outputs[mapping[name+'.stdout']['member']])
checked={};rows={}
for mode in ['debug','release']:
 for ds in ['vectors','supplement','B-extension','A-extension']:
  vectors=new.records((R/'vectors'/f'{ds}.jsonl').read_bytes());out=actual('corrected-'+mode+'-'+ds)
  assert [r['id'] for r in out]==[r['id'] for r in vectors]
  for v,a in zip(vectors,out,strict=True):
   assert a['status']==v['expected']['status']
   if a['status']=='ok':
    for k in ['canonical','sha256']:
     if k in v['expected']:assert a[k]==v['expected'][k]
    if 'canonical' in a:assert hashlib.sha256(a['canonical'].encode()).hexdigest()==a['sha256']
   else:assert a['layer']==rules[v['id']]['layer']
  checked[mode+'-'+ds]={'count':len(out),'refusals':sum(a['status']=='refuse' for a in out),'independent_saved_value_recount':True,'author_comparator_mismatches':new.compare(vectors,out,rules)['mismatch_count']}
  rows[ds]=vectors
positive=rows['vectors'][:2];good=actual('corrected-debug-vectors')[:2]
i=next(i for i,v in enumerate(rows['vectors']) if v['family']=='duplicates');refrow=rows['vectors'][i:i+1];refout=actual('corrected-debug-vectors')[i:i+1]
cases=[('empty',[],[]),('reordered',positive,good[::-1]),('wrong-layer',refrow,[dict(refout[0],layer='transport')]),('wrong-reason',refrow,[dict(refout[0],error='unrelated')])]
results=[]
for name,v,a in cases:
 assert old.compare(v,a)['mismatch_count']==0
 try:r=new.compare(v,a,rules)
 except (ValueError,KeyError,TypeError):rejected=True
 else:rejected=r['mismatch_count']>0
 assert rejected
 results.append({'case':name,'old_accepts':True,'corrected_refuses':True})
assert new.compare(positive,good,rules)['mismatch_count']==0
assert new.compare(refrow,refout,rules)['mismatch_count']==0
# Independent additional shapes/framing/value controls beyond the saved 27.
extras=[]
for name,raw in [('escaped-duplicate',b'{"id":"x","\\u0069d":"x"}\n'),('empty-id',b'{"id":""}\n')]:
 try:new.records(raw)
 except ValueError:extras.append(name)
 else:raise AssertionError(name)
bad=copy.deepcopy(good[:1]);bad[0]['canonical']='different';bad[0]['sha256']=hashlib.sha256(b'different').hexdigest();assert new.compare(positive[:1],bad,rules)['mismatch_count']==1;extras.append('wrong-bytes-with-consistent-hash')
x='a\u2028b';c=json.dumps(x,ensure_ascii=False,separators=(',',':'));v=[{'id':'line-separator','op':'canonical','expected':{'status':'ok','canonical':c,'sha256':hashlib.sha256(c.encode()).hexdigest()}}];a=[{'id':'line-separator',**v[0]['expected']}]
stream=(json.dumps(a[0],ensure_ascii=False)+'\n').encode();assert new.compare(v,new.records(stream),{})['mismatch_count']==0
out={'saved_output_recount':checked,'scratch_comparator_reversion_restoration':results,'restored_positive':True,'additional_refusals':extras,'U2028_is_not_byte_LF_positive':True,'new_native_execution':False,'author_verifier_27_controls_executed_separately':True}
(R/'output/comparator-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
