"""B standalone probe-only scratch reversions; no production engine source."""
import pathlib,json,tarfile,shutil,subprocess,importlib.util
from run_review import R,P,run,sha
s=importlib.util.spec_from_file_location('comparison',P/'compare.py');cmp=importlib.util.module_from_spec(s);s.loader.exec_module(cmp)
rules=json.loads((P/'refusals.json').read_text())
with tarfile.open(P/'executed-controls.tar.gz') as t:contents={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
report={}
for family in ['leaf','integer-zero','legacy-float']:
 root=R/'variants'/family;root.mkdir(parents=True,exist_ok=True)
 shutil.copytree(R/'workspace',root/'workspace');(root/'target').mkdir()
 f=root/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs'
 variant=contents[f'variants/{family}/workspace/native/crates/uarch-engine/src/bin/c2-probe.rs'];f.write_bytes(variant)
 assert len([p for p in (root/'workspace').rglob('*') if p.is_file()])==4
 raw=contents[f'variants/{family}/selection.jsonl'];(root/'selection.jsonl').write_bytes(raw);rows=cmp.records(raw)
 report[family]={'selection_sha256':sha(raw),'source_sha256':sha(variant),'modes':{}}
 for mode in ['debug','release']:
  stem=f'revert-{family}-{mode}'
  run(stem+'-build',stem+'-build')
  u=run(stem+'-unit',stem+'-unit',expect=101)
  names=[x for x in u.stdout.decode().splitlines() if x.startswith('test ') and ' ... ' in x];assert len(names)==12
  a=run(stem+'-execute',stem+'-execute',stdin=raw)
  bad=cmp.compare(rows,cmp.records(a.stdout),rules);positives=[x['id'] for x in bad['mismatches'] if x['expected']['status']=='ok'];assert positives
  good=run(f'restored-{family}-{mode}',f'restored-{family}-{mode}',stdin=raw)
  restored=cmp.compare(rows,cmp.records(good.stdout),rules);assert restored['mismatch_count']==0
  report[family]['modes'][mode]={'count':len(rows),'mismatches':bad['mismatch_count'],'expected_positive_failures':positives,'unit_exit':u.returncode,'unit_results':names,'restored_mismatches':0,'variant_binary_sha256':sha((root/'target'/mode/'c2-probe').read_bytes())}
 # Return each scratch source to corrected bytes after observing the exact reverted binary.
 f.write_bytes((P/'probe.rs').read_bytes());assert sha(f.read_bytes())==sha((R/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs').read_bytes())
 report[family]['final_scratch_source_sha256']=sha(f.read_bytes())
for mode in ['debug','release']:
 assert sha((R/'target'/mode/'c2-probe').read_bytes())==json.loads((P/'summary.json').read_text())['binary_sha256'][mode]
(R/'output/native-faults.json').write_text(json.dumps(report,indent=2)+'\n')
print('three families independently reproduced and scratch source restored',flush=True)
