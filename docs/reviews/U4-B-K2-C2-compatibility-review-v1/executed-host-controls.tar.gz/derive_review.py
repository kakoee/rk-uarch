"""Independent pinned-Pydantic derivation; no native code or output is read."""
import sys,pathlib,ast,json,hashlib,time,struct
R=pathlib.Path(__file__).resolve().parent
sys.path[:0]=[str(R/'reference/contract'),'/home/jjaff/AI-infra-simulation/rk-uarch/.venv/lib/python3.12/site-packages']
import pydantic
from pydantic import Field,TypeAdapter,ValidationError
from typing import Annotated
from uarch_contract import hashing as h,mapped as m
from uarch_contract.common import JsonFloat
from uarch_contract.sourced import SourcedValue
assert pydantic.__version__=='2.13.5'
U128=TypeAdapter(Annotated[int,Field(strict=True,ge=0,lt=2**128)])
def sha(b):return hashlib.sha256(b).hexdigest()
# The function is B's historical independent reference, extracted without its old writes.
b=R/'subject/docs/reviews/U4-B-K2-C2-reconciliation-v1/derive.py'
t=ast.parse(b.read_text());node=next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name=='expected')
exec(compile(ast.Module(body=[node],type_ignores=[]),'B-41150f2-expected','exec'))
checks={}
for p in sorted((R/'vectors').glob('*.jsonl')):
 rows=[json.loads(x) for x in p.read_bytes().split(b'\n')[:-1]]
 for row in rows:
  got=expected(row);assert all(row['expected'][k]==v for k,v in got.items()),(row['id'],got,row['expected'])
 checks[p.name]={'count':len(rows),'sha256':sha(p.read_bytes())}
rows=[]
def add(label,op,raw,reason=None):
 row={'id':'B2:'+label,'family':'B-independent-'+label.split(':')[0],'op':op,'hex':raw.encode().hex()}
 row['expected']=expected(row)
 if reason is not None:row['expected_native_refusal']=reason
 rows.append(row)
def leaf(label,value,reason=None):add('leaf:'+label,'leaf','{"path":"independent","value":'+value+'}',reason)
for label,token in [('zero-ratio','{"numerator":0,"denominator":1}'),('upper-ratio','{"numerator":340282366920938463463374607431768211455,"denominator":340282366920938463463374607431768211454}'),('large-positive',str(2**256+19)),('large-negative',str(-(2**256+19))),('true','true'),('false','false'),('text','"false"'),('null','null')]:leaf(label,token)
for label,token,reason in [('not-reduced','{"numerator":6,"denominator":9}','InvalidRatio'),('zero-not-reduced','{"numerator":0,"denominator":3}','InvalidRatio'),('negative','{"numerator":-1,"denominator":2}','IntegerRange'),('overflow','{"numerator":1,"denominator":340282366920938463463374607431768211456}','IntegerRange'),('unknown','{"numerator":1,"denominator":2,"x":0}','RationalFields'),('float','1e0','IntegerToken'),('array','[]','LeafScalar'),('string-ratio','{"numerator":"1","denominator":2}','IntegerToken')]:leaf(label,token,['carrier',reason])
leaf('duplicate-escaped','{"numerator":1,"denominator":2,"deno\\u006dinator":2}',['strict-json','DuplicateJsonKey'])
leaf('marker-escaped','{"\\u0024serde_json::private::Number":"12"}',['strict-json','ReservedNumericMarker'])
for label,raw in [('bare','-0'),('space',' \t-0\r\n'),('decimal','-0.0'),('exponent','-0e0'),('quoted','"-0"'),('leading-zero','-00'),('leading-digit','-01'),('adjacent','0-0'),('array','[-0]'),('suffix','-0 true'),('unfinished','-0.')]:add('zero:'+label,'u128',raw)
for label,raw in [('text','{"path":"\\\"-0\\\\","value":"-0"}'),('mixed','{"path":"minus -0","value":-0}'),('ratio','{"path":"-0","value":{"numerator":-0,"denominator":1}}')]:add('zero:'+label,'leaf',raw)
add('zero:denominator','rational','{"numerator":1,"denominator":-0}',['carrier','InvalidRatio'])
for i,s in enumerate(['-_1','+_1','1e_+2','1e_-2','1_.','._5','1e+_02','0_0.5','\u202f.5\u202f','\u001c.5\u001c','1_\t0','1__e2','_1.0','1.0_','n_a_n','i_n_f']):
 raw=json.dumps({'value':s,'unit':'Hz','kind':'stipulation','rationale':'independent'},ensure_ascii=True)
 add('legacy:string-'+str(i),'sourced',raw)
for label,obj in [('default-stub',{'value':False,'unit':'Hz','provenance':'stub'}),('measured',{'value':'1_.0','unit':'Hz','provenance':'measured','source':'independent'}),('missing-provenance',{'value':'1','unit':'Hz'}),('stub-source',{'value':'1','unit':'Hz','provenance':'stub','source':''}),('stipulation-date',{'value':'1','unit':'Hz','kind':'stipulation','rationale':'r','date':'2020'}),('blank-control-unit',{'value':'1','unit':'\u001c','provenance':'stub'}),('blank-control-rationale',{'value':'1','unit':'Hz','kind':'stipulation','rationale':'\u001c'})]:add('legacy:'+label,'sourced',json.dumps(obj))
for label,tok in [('bool','false'),('text','"1_.0"'),('null','null'),('decimal','1.0'),('integer','1')]:
 add('isolation:float-'+label,'json-float',tok)
 leaf('isolation-'+label,tok)
# No Rust outputs have been examined. Freeze both positive and negative expectations now.
raw=b''.join((json.dumps(x,ensure_ascii=True,separators=(',',':'))+'\n').encode() for x in rows)
(R/'vectors/independent.jsonl').write_bytes(raw)
origins={n:{'path':v.__file__,'sha256':sha(pathlib.Path(v.__file__).read_bytes())} for n,v in sys.modules.items() if (n.startswith('uarch_contract') or n in ['pydantic','pydantic_core']) and getattr(v,'__file__',None)}
assert all(str(R/'reference/contract') in v['path'] for n,v in origins.items() if n.startswith('uarch_contract'))
assert not any(n=='rkuarch' or n.startswith('rkuarch.') or n=='rk' for n in sys.modules)
(R/'output/python-derivation.json').write_text(json.dumps({'timestamp_ns':time.time_ns(),'reference_commit':'ce732f5bedccdde629edcf278fa76ea772d0ea82','pydantic':pydantic.__version__,'python':sys.version,'origins':origins,'all_four_corpora_rederived':checks,'independent_count':len(rows),'independent_sha256':sha(raw),'positive':sum(x['expected']['status']=='ok' for x in rows),'negative':sum(x['expected']['status']=='refuse' for x in rows),'basis':'Pinned models and B historical expected function; no Python float() substitute for Sourced.value; no Rust output read'},indent=2)+'\n')
print('Rederived',checks,'independent',len(rows))
for x in rows:
 if x['id'].startswith('B2:legacy:'):print(x['id'],bytes.fromhex(x['hex']).decode(),x['expected'])
