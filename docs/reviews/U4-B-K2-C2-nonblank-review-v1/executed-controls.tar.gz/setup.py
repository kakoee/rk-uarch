import pathlib,tempfile,subprocess,tarfile,io,json,hashlib,shutil,gzip,time
B=pathlib.Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-b');R=pathlib.Path(tempfile.mkdtemp(prefix='u4-b-c2b-review.'));pathlib.Path('/tmp/u4-b-c2b-current-path').write_text(str(R))
A=pathlib.Path('/tmp/u4-k2-c2b.khaj67gd')
def sha(b):return hashlib.sha256(b).hexdigest()
def inv(root):return {str(p.relative_to(root)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in sorted(root.rglob('*')) if p.is_file()}
for name in ['subject','reference','workspace','cache','controls','vectors','target','receipts','output','docker-config','patch-check','reversion']: (R/name).mkdir()
for name,pin in [('subject','c678dedd47e639f7e7f0ac55f48a8775fe524708'),('reference','ce732f5bedccdde629edcf278fa76ea772d0ea82')]:
 raw=subprocess.check_output(['git','archive',pin],cwd=B)
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(R/name,filter='data')
P=R/'subject/docs/reviews/U4-A-K2-C2-nonblank-v1';PREV=P.parent/'U4-A-K2-C2-compatibility-v1';BASE=P.parent/'U4-A-K2-C2-probes-v1'
receipt=json.loads((B/'docs/reviews/U4-K2-C2-nonblank-reconciliation-v1/receipt.json').read_text())
for name,h in receipt['bindings'].items():assert sha((P/name).read_bytes())==h
for name,d in json.loads((P/'inventory.json').read_text()).items():assert sha((P/name).read_bytes())==d['sha256']
assert (P/'compare.py').read_bytes()==(PREV/'compare.py').read_bytes()
original=inv(A);(R/'original-A-before.json').write_text(json.dumps(original,sort_keys=True))
expected_cache=json.loads((A/'receipts/copied-before.json').read_text())['cache'];assert inv(A/'cache')==expected_cache
shutil.copytree(A/'cache',R/'cache',dirs_exist_ok=True);assert inv(R/'cache')==expected_cache
for dest,src in [('native/Cargo.lock','accepted.Cargo.lock'),('native/Cargo.toml','workspace.Cargo.toml'),('native/crates/uarch-engine/Cargo.toml','probe.Cargo.toml')]:
 f=R/'workspace'/dest;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(PREV/src,f)
f=R/'workspace/native/crates/uarch-engine/src/bin/c2-probe.rs';f.parent.mkdir(parents=True);shutil.copy2(P/'probe.rs',f)
with tarfile.open(P/'executed-controls.tar.gz') as t:
 contents={m.name:t.extractfile(m).read() for m in t if m.isfile()}
for name in ['rustc-wrapper.sh','linker.sh']:
 raw=contents['controls/'+name];assert raw==(A/'controls'/name).read_bytes();(R/'controls'/name).write_bytes(raw);(R/'controls'/name).chmod(0o755)
# Inspect these exact scripts before any native calls; stored but not run here.
(R/'controls/reverted-probe.rs').write_bytes(contents['receipts/reverted-probe.rs'])
for name,src in [('vectors',BASE/'vectors.jsonl.gz'),('supplement',BASE/'identity-supplement.jsonl.gz'),('B-extension',PREV/'B-extension.jsonl.gz'),('A-extension',PREV/'A-extension.jsonl.gz'),('focused',P/'focused.jsonl.gz')]: (R/'vectors'/f'{name}.jsonl').write_bytes(gzip.decompress(src.read_bytes()))
shutil.copy2(P.parent/'U4-B-K2-C2-compatibility-review-v1/independent.jsonl',R/'vectors/B-independent.jsonl')
selection=(R/'vectors/B-independent.jsonl').read_bytes()+(R/'vectors/focused.jsonl').read_bytes();assert selection==contents['reversion/selection.jsonl'];(R/'reversion/selection.jsonl').write_bytes(selection)
for patch,pre,post in [('probe.patch',PREV/'probe.rs',P/'probe.rs'),('revert.patch',P/'probe.rs',R/'controls/reverted-probe.rs')]:
 f=R/'patch-check/probe.rs';f.write_bytes(pre.read_bytes())
 for reverse in [False,True,False]:
  c=subprocess.run(['git','apply','--unidiff-zero','--unsafe-paths',str(P/patch)]+(['--reverse'] if reverse else []),cwd=R/'patch-check',capture_output=True);assert c.returncode==0,c.stderr;assert f.read_bytes()==(pre if reverse else post).read_bytes()
 f.write_bytes(pre.read_bytes())
summary=json.loads((P/'summary.json').read_text())
for name,d in summary['datasets'].items():assert sha((R/'vectors'/name).read_bytes())==d['sha256']
report={'starting_head':'81bab62112469f4b32d1b28fc2076caa5815eece','integrated_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=B).decode().strip(),'review_subject':receipt['subject_commit'],'coordinator_bindings':receipt['bindings'],'private_root':str(R),'original_A_root':str(A),'original_A_files':len(original),'cache_count':len(expected_cache),'cache_inventory_sha256':sha(json.dumps(expected_cache,sort_keys=True).encode()),'workspace':inv(R/'workspace'),'vectors':inv(R/'vectors'),'patch_forward_reverse_forward':True,'comparator_unchanged':True,'timestamp_ns':time.time_ns()}
(R/'output/setup.json').write_text(json.dumps(report,indent=2)+'\n');shutil.copy2('/tmp/u4-b-nonblank-setup.py',R/'setup.py');print(R,len(original),len(expected_cache),flush=True)
