"""Collect B-owned small receipts and verify preservation after standalone execution."""
import pathlib,json,hashlib,tarfile,io,shutil,time,importlib.util
R=pathlib.Path(__file__).resolve().parent;P=R/'subject/docs/reviews/U4-A-K2-C2-nonblank-v1';B=pathlib.Path('/home/jjaff/AI-infra-simulation/rk-uarch-u4-b');D=B/'docs/reviews/U4-B-K2-C2-nonblank-review-v1';A=pathlib.Path('/tmp/u4-k2-c2b.khaj67gd')
def sha(b):return hashlib.sha256(b).hexdigest()
def inv(root):return {str(p.relative_to(root)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in sorted(root.rglob('*')) if p.is_file()}
original=json.loads((R/'original-A-before.json').read_text());assert inv(A)==original
cache=json.loads((A/'receipts/copied-before.json').read_text())['cache'];assert inv(R/'cache')==cache
setup=json.loads((R/'output/setup.json').read_text());assert inv(R/'workspace')==setup['workspace']
for name,record in setup['vectors'].items():assert sha((R/'vectors'/name).read_bytes())==record['sha256']
source=(P/'probe.rs').read_bytes();assert (R/'reversion/workspace/native/crates/uarch-engine/src/bin/c2-probe.rs').read_bytes()==source
native=json.loads((R/'output/native-review.json').read_text());commands=json.loads((R/'output/commands.json').read_text());python=json.loads((R/'output/python-review.json').read_text());assert len(commands)==32 and min(c['started_ns'] for c in commands)>python['time_ns']
for mode in ['debug','release']:
 assert sha((R/'target'/mode/'c2-probe').read_bytes())==sha((R/'reversion/target'/mode/'c2-probe').read_bytes())==native['modes'][mode]['binary_sha256']
# Guard the actual blank refusal against an unrelated error; preserve the positive path.
s=importlib.util.spec_from_file_location('compare',P/'compare.py');cmp=importlib.util.module_from_spec(s);s.loader.exec_module(cmp)
rules=json.loads((P.parent/'U4-A-K2-C2-compatibility-v1/refusals.json').read_text());rules.update(json.loads((P/'new-refusals.json').read_text()))
rows=cmp.records((R/'vectors/B-independent.jsonl').read_bytes());actual=cmp.records((R/'receipts/corrected-debug-B-independent.stdout').read_bytes())
index=next(i for i,v in enumerate(rows) if v['id']=='B2:legacy:blank-control-unit');row=rows[index];out=actual[index];controls=[]
for layer,error in [('transport','unrelated'),('carrier','LegacyFloatSyntax')]:
 bad=dict(out,layer=layer,error=error);assert cmp.compare([row],[bad],rules)['mismatch_count']==1;controls.append({'layer':layer,'error':error,'rejected':True})
assert cmp.compare([row],[out],rules)['mismatch_count']==0
positive=next(i for i,v in enumerate(rows) if v['expected']['status']=='ok');assert cmp.compare([rows[positive]],[actual[positive]],rules)['mismatch_count']==0
# Historical corrected outputs and all positive records remain exact.
oldjson=json.loads((P.parent/'U4-B-K2-C2-compatibility-review-v1/native-review.json').read_text());unchanged={}
for mode in ['debug','release']:
 for ds in ['vectors','supplement','B-extension','A-extension']:
  raw=(R/'receipts'/f'corrected-{mode}-{ds}.stdout').read_bytes();assert sha(raw)==oldjson['modes'][mode]['datasets'][ds]['stdout_sha256'];unchanged[mode+'-'+ds]=sha(raw)
D.mkdir()
for name in ['setup','python-review','commands','native-review']:shutil.copy2(R/'output'/f'{name}.json',D/f'{name}.json')
for name in ['python-review.log','native-run.log','author-verifier.log']:shutil.copy2(R/'receipts'/name,D/name)
with tarfile.open(P/'command-outputs.tar.gz') as t:author={sha(t.extractfile(m).read()):m.name for m in t if m.isfile()}
owned={};output_map={}
for c in commands:
 for ext in ['stdout','stderr']:
  name=c['name']+'.'+ext;raw=(R/'receipts'/name).read_bytes();h=sha(raw);assert h==c[ext+'_sha256']
  if h in author:binding={'archive':'../U4-A-K2-C2-nonblank-v1/command-outputs.tar.gz','member':author[h]}
  else:binding={'archive':'command-outputs.tar.gz','member':'sha256/'+h};owned[binding['member']]=raw
  output_map[name]={'sha256':h,'bytes':len(raw),**binding}
with tarfile.open(D/'command-outputs.tar.gz','w:gz') as t:
 for name,raw in sorted(owned.items()):m=tarfile.TarInfo(name);m.size=len(raw);m.mtime=0;t.addfile(m,io.BytesIO(raw))
(D/'command-output-map.json').write_text(json.dumps(output_map,indent=2)+'\n')
index={}
with tarfile.open(D/'executed-controls.tar.gz','w:gz') as t:
 for name in ['setup.py','derive.py','run.py','collect.py']:
  raw=(R/name).read_bytes();m=tarfile.TarInfo(name);m.size=len(raw);m.mtime=0;t.addfile(m,io.BytesIO(raw));index[name]={'sha256':sha(raw),'bytes':len(raw)}
(D/'executed-controls-index.json').write_text(json.dumps(index,indent=2)+'\n')
report={'time_ns':time.time_ns(),'original_private_root':str(A),'original_files_unchanged':len(original),'bytes_sizes_mtimes_unchanged':True,'original_snapshot_sha256':sha((R/'original-A-before.json').read_bytes()),'readonly_copied_cache_entries_unchanged':len(cache),'workspace_four_files_unchanged':True,'vectors_unchanged':True,'restored_source_sha256':sha(source),'restored_binary_sha256':{m:native['modes'][m]['binary_sha256'] for m in ['debug','release']},'historical_21159_outputs_unchanged':unchanged,'wrong_refusal_controls':controls,'positive_and_legitimate_refusal_restored':True,'no_original_evidence_writable_mount':True,'new_command_count':len(commands),'expectations_and_35_fault_predictions_precede_new_native':True,'diagnostic_payload_used':False,'new_native_vectors':0}
(D/'preservation.json').write_text(json.dumps(report,indent=2)+'\n');print('Collected',len(commands),'commands;',len(original),'original files;',len(cache),'cache entries preserved')
