"""Only the explicitly authorized four-file standalone c2-probe target is constructed."""
import pathlib,json,hashlib,subprocess,time,shutil,importlib.util
R=pathlib.Path(__file__).resolve().parent;P=R/'subject/docs/reviews/U4-A-K2-C2-nonblank-v1';A='/tmp/u4-k2-c2b.khaj67gd'
CMDS=json.loads((P/'commands.json').read_text());SUMMARY=json.loads((P/'summary.json').read_text())
s=importlib.util.spec_from_file_location('reviewed_compare',P/'compare.py');cmp=importlib.util.module_from_spec(s);s.loader.exec_module(cmp)
rules=json.loads((P.parent/'U4-A-K2-C2-compatibility-v1/refusals.json').read_text());rules.update(json.loads((P/'new-refusals.json').read_text()))
def sha(b):return hashlib.sha256(b).hexdigest()
def guard(root,source):
 expected=json.loads((P/'starting-source.json').read_text())['workspace_files'].copy();expected['native/crates/uarch-engine/src/bin/c2-probe.rs']=sha(source)
 actual={str(p.relative_to(root)):sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()};assert actual==expected and len(actual)==4
 return actual
def run(name,stdin=None,expect=0):
 old=next(c for c in CMDS if c['name']==name);argv=[a.replace(A,str(R)) for a in old['argv']];env={k:v.replace(A,str(R)) for k,v in old['environment'].items()}
 if 'run' in argv:
  assert argv[argv.index('--network')+1]=='none' and argv[argv.index('--pull')+1]=='never' and argv[argv.index('--user')+1]=='1000:1000'
  assert '--read-only' in argv and 'ALL'==argv[argv.index('--cap-drop')+1] and 'no-new-privileges' in argv
  assert not any('diagnostic' in a or 'strace' in a or 'no-vectorize' in a for a in argv)
  assert 'sha256:e9f69f41498334be985ed4d25973fe3fa3f6519e58c73e6a7b8397d871fa0523' in argv
 t=time.time_ns();c=subprocess.run(argv,env=env,input=stdin,capture_output=True)
 for ext,b in [('stdout',c.stdout),('stderr',c.stderr)]:(R/'receipts'/f'{name}.{ext}').write_bytes(b)
 receipt={'name':name,'argv':argv,'environment':env,'started_ns':t,'finished_ns':time.time_ns(),'exit_code':c.returncode,'stdin_sha256':None if stdin is None else sha(stdin),'stdout_sha256':sha(c.stdout),'stderr_sha256':sha(c.stderr),'stdout_equals_A':sha(c.stdout)==old['stdout_sha256']}
 path=R/'output/commands.json';items=json.loads(path.read_text()) if path.exists() else [];items.append(receipt);path.write_text(json.dumps(items,indent=2)+'\n')
 print(name,c.returncode,round((time.time_ns()-t)/1e9,3),flush=True);assert c.returncode==expect,c.stderr.decode(errors='replace')[-4000:]
 return c
def units(c,positive):
 lines=[x for x in c.stdout.decode().splitlines() if x.startswith('test ') and ' ... ' in x];names=[x.split(' ... ')[0] for x in lines]
 assert len(names)==len(set(names))==17 and set(names)==set(SUMMARY['unit_names']['debug'])
 if positive:assert all(x.endswith(' ... ok') for x in lines)
 else:assert any(x.endswith(' ... FAILED') for x in lines)
 return lines
source=(P/'probe.rs').read_bytes();guard(R/'workspace',source)
for name in ['image-inspect','rustc','cargo','probe-metadata']:
 result=run(name)
 C1=P.parent/'U4-A-K2-C1-precise-v1'
 if name!='probe-metadata':assert result.stdout==(C1/(name+'.stdout')).read_bytes()
 else:
  got=json.loads(result.stdout);accepted=json.loads((C1/'metadata-full.stdout').read_text());assert got['resolve']==accepted['resolve'] and len(got['packages'])==36
  root=next(p for p in got['packages'] if p['name']=='uarch-engine');assert len(root['targets'])==1 and root['targets'][0]['kind']==['bin'] and root['targets'][0]['name']=='c2-probe'
  for p in got['packages']:
   old=next(x for x in accepted['packages'] if x['id']==p['id']);assert p['dependencies']==old['dependencies'] and p['features']==old['features']
report={'modes':{},'phases':{}}
for mode in ['debug','release']:
 run('build-'+mode+'-package');u=units(run('build-test-'+mode+'-package'),True)
 binary=R/'target'/mode/'c2-probe';assert sha(binary.read_bytes())==SUMMARY['binary_sha256'][mode]
 datasets={}
 for ds in ['vectors','supplement','B-extension','A-extension','B-independent','focused']:
  raw=(R/'vectors'/f'{ds}.jsonl').read_bytes();c=run(f'corrected-{mode}-{ds}',raw);rows=cmp.records(raw);got=cmp.compare(rows,cmp.records(c.stdout),rules)
  assert got['mismatch_count']==0;datasets[ds]={'count':got['count'],'refusals':len(got['refusals']),'mismatches':0,'stdout_sha256':sha(c.stdout)}
  if mode=='release':assert c.stdout==(R/'receipts'/f'corrected-debug-{ds}.stdout').read_bytes()
 assert sum(x['count'] for x in datasets.values())==21694 and sum(x['refusals'] for x in datasets.values())==417
 report['modes'][mode]={'binary_sha256':sha(binary.read_bytes()),'unit_results':u,'datasets':datasets}
# Revert only the one predicate in a separate verified four-file workspace.
shutil.copytree(R/'workspace',R/'reversion/workspace');(R/'reversion/target').mkdir()
f=R/'reversion/workspace/native/crates/uarch-engine/src/bin/c2-probe.rs';variant=(R/'controls/reverted-probe.rs').read_bytes();f.write_bytes(variant)
assert sha(variant)==json.loads((P/'reversion-plan.json').read_text())['reverted_source_sha256']
raw=(R/'reversion/selection.jsonl').read_bytes();rows=cmp.records(raw);assert len(rows)==535
predicted=json.loads((R/'output/python-review.json').read_text())['predicted_wrong_acceptances']
for phase in ['reverted','restored']:
 if phase=='restored':f.write_bytes(source)
 guard(R/'reversion/workspace',variant if phase=='reverted' else source)
 for mode in ['debug','release']:
  stem=phase+'-'+mode;run(stem+'-build');u=units(run(stem+'-unit',expect=101 if phase=='reverted' else 0),phase=='restored')
  c=run(stem+'-selection',raw);got=cmp.compare(rows,cmp.records(c.stdout),rules)
  actual=cmp.records(c.stdout);positive=0
  for row,out in zip(rows,actual,strict=True):
   if row['expected']['status']=='ok':
    assert all(out[k]==row['expected'][k] for k in ['status','canonical','sha256']);positive+=1
  if phase=='reverted':
   assert got['mismatch_count']==35 and set(x['id'] for x in got['mismatches'])==set(predicted)
   assert all(x['expected']['status']=='refuse' and x['actual']['status']=='ok' for x in got['mismatches'])
  else:assert got['mismatch_count']==0
  binary=R/'reversion/target'/mode/'c2-probe';digest=sha(binary.read_bytes())
  if phase=='restored':assert digest==SUMMARY['binary_sha256'][mode]
  else:
   saved=R/'reversion'/f'saved-fault-{mode}';shutil.copy2(binary,saved);assert sha(saved.read_bytes())==digest
  report['phases'][stem]={'source_sha256':sha(f.read_bytes()),'binary_sha256':digest,'unit_results':u,'selection_count':len(rows),'positive_controls':positive,'mismatches':got['mismatches'],'mismatch_count':got['mismatch_count']}
guard(R/'workspace',source);guard(R/'reversion/workspace',source)
for mode in ['debug','release']:assert sha((R/'target'/mode/'c2-probe').read_bytes())==SUMMARY['binary_sha256'][mode]
report['all_35_faults_predicted_before_native']=True;report['restored_binary_hashes_equal_corrected']=True
(R/'output/native-review.json').write_text(json.dumps(report,indent=2)+'\n');print('All corrected, predicate-only reverted and rebuilt restored controls completed',flush=True)
