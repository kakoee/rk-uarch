"""Independent pinned Python nonblank review; no native outputs are read."""
import sys,pathlib,json,ast,hashlib,struct,unicodedata,time,math,re
R=pathlib.Path(__file__).resolve().parent;P=R/'subject/docs/reviews/U4-A-K2-C2-nonblank-v1'
sys.path[:0]=[str(R/'reference/contract'),'/home/jjaff/AI-infra-simulation/rk-uarch/.venv/lib/python3.12/site-packages']
import pydantic
from pydantic import Field,TypeAdapter
from typing import Annotated
from uarch_contract import hashing as h,mapped as m
from uarch_contract.common import JsonFloat
from uarch_contract.sourced import SourcedValue
assert pydantic.__version__=='2.13.5'
U128=TypeAdapter(Annotated[int,Field(strict=True,ge=0,lt=2**128)])
def sha(b):return hashlib.sha256(b).hexdigest()
b=R/'subject/docs/reviews/U4-B-K2-C2-reconciliation-v1/derive.py';node=next(x for x in ast.parse(b.read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='expected');exec(compile(ast.Module(body=[node],type_ignores=[]),'B-41150f2-expected','exec'))
blank=[cp for cp in range(0x110000) if not chr(cp).strip()]
literal=list(range(9,14))+list(range(28,33))+[133,160,5760]+list(range(8192,8203))+[8232,8233,8239,8287,12288]
assert blank==literal and len(blank)==29 and unicodedata.unidata_version=='15.0.0'
blankraw=''.join(f'{cp:08x}\n' for cp in blank).encode();assert sha(blankraw)=='96d09d55259e60e1198f7f067eeac357f6581d3700497cf942886cb74a8bdbac'
checks={};allrows=[]
for path in sorted((R/'vectors').glob('*.jsonl')):
 rows=[json.loads(x) for x in path.read_bytes()[:-1].split(b'\n')]
 for row in rows:
  got=expected(row);assert all(row['expected'][k]==v for k,v in got.items()),(row['id'],got,row['expected'])
 checks[path.name]={'count':len(rows),'sha256':sha(path.read_bytes()),'refusals':sum(x['expected']['status']=='refuse' for x in rows)};allrows.extend(rows)
assert len(allrows)==21694
focused=[x for x in allrows if x['family']=='A-nonblank-focused'];assert len(focused)==469
# Independent literal rules, using actual pinned Pydantic only for legacy value conversion.
# This is a small carrier predicate, not a scheduler or implementation of canonicalization.
def valid(obj,blank_set):
 if set(obj)-{'value','unit','kind','provenance','source','date','rationale'}:return False
 try:val=TypeAdapter(float).validate_python(obj['value'])
 except Exception:return False
 if not math.isfinite(val) or not isinstance(obj.get('unit'),str):return False
 def nonblank(s):return isinstance(s,str) and any(ord(c) not in blank_set for c in s)
 if not nonblank(obj['unit']):return False
 for field in ['source','date','rationale']:
  if obj.get(field) is not None and not isinstance(obj[field],str):return False
 kind=obj.get('kind','claim');prov=obj.get('provenance')
 if kind=='stipulation':return all(obj.get(k) is None for k in ['source','date','provenance']) and nonblank(obj.get('rationale'))
 if kind!='claim' or obj.get('rationale') is not None or prov not in ['stub','measured','spec_derived','estimated']:return False
 return obj.get('source') is None if prov=='stub' else nonblank(obj.get('source'))
new=set(blank);old=new-set(range(28,32));predicted=[];preserved=0;coverage={}
for row in allrows:
 if row['op']!='sourced':continue
 obj=h.strict_json_loads(bytes.fromhex(row['hex']))
 # Limit literal conditions to the focused set and unchanged B66 Sourced cases.
 if row['id'].startswith(('A-blank:','B2:')):
  assert valid(obj,new)==(row['expected']['status']=='ok'),row['id']
  if valid(obj,old) and not valid(obj,new):predicted.append(row['id'])
 if row['expected']['status']=='ok':
  out=json.loads(row['expected']['canonical'])
  for field in ['unit','rationale','source']:
   if field in obj:assert out[field]==obj[field];preserved+=1
for field in ['unit','rationale','source']:
 coverage[field]={}
 for cp in blank:
  matches=[]
  for row in focused:
   obj=json.loads(bytes.fromhex(row['hex']))
   if field=='rationale' and obj.get('kind')!='stipulation':continue
   if field=='source' and obj.get('provenance') not in ['measured','spec_derived','estimated']:continue
   text=obj.get(field)
   if text in [chr(cp),chr(cp)+' \t'+chr(cp),chr(cp)+'X'+chr(cp)]:matches.append(row['id'])
  assert len(matches)>=3,(field,cp,matches);coverage[field][f'U+{cp:04X}']=matches
assert len(predicted)==35 and sum(x.startswith('B2:') for x in predicted)==2
# Independently classify the focused Sourced refusal reasons before native runs.
rules=json.loads((P/'new-refusals.json').read_text());classified={}
for row in focused:
 if row['expected']['status']=='ok':continue
 obj=json.loads(bytes.fromhex(row['hex']));reason='SourcedValue rules'
 if 'unit' not in obj:reason='missing field `unit`'
 elif obj['unit'] is None:reason='invalid type: null, expected a string'
 else:
  try:v=TypeAdapter(float).validate_python(obj['value'])
  except Exception:reason='LegacyFloatSyntax' if isinstance(obj['value'],str) else 'LegacyFloatType'
  else:
   if not math.isfinite(v):reason='LegacyFloatFinite'
 rule=rules[row['id']];assert rule['layer']=='carrier' and re.fullmatch(rule['error_pattern'],reason), (row['id'],reason,rule)
 assert rule['condition']['input_sha256']==sha(bytes.fromhex(row['hex']));classified[row['id']]=reason
assert len(classified)==221
# Other predicates must remain distinct: Python-only observations, not public Rust parity.
isolation=[]
for cp in [28,29,30,31,32,133,8203]:
 ch=chr(cp);obj={'path':ch,'value':1}
 try:m.NumericLeaf.model_validate(obj);leaf=True
 except Exception:leaf=False
 try:TypeAdapter(float).validate_python(ch+'.5'+ch);numeric=True
 except Exception:numeric=False
 isolation.append({'codepoint':cp,'strip_empty':not ch.strip(),'NumericLeaf_path_accepts':leaf,'legacy_numeric_padding_accepts':numeric})
for x in isolation[:4]:assert x['strip_empty'] and x['NumericLeaf_path_accepts'] and not x['legacy_numeric_padding_accepts']
# Remove exactly the reviewed additions/replacements: all other source bytes must match.
source=(P/'probe.rs').read_text();oldsource=(P.parent/'U4-A-K2-C2-compatibility-v1/probe.rs').read_text()
without=source[:source.index('\n#[cfg(test)]\nmod nonblank_tests')]
a=without.index('// Pinned CPython');b=without.index('fn process',a);without=without[:a]+without[b:]
without=without.replace('sourced_nonblank(&t.unit)','!t.unit.trim().is_empty()').replace('sourced_nonblank(s)','!s.trim().is_empty()')
assert without==oldsource
origins={n:{'path':v.__file__,'sha256':sha(pathlib.Path(v.__file__).read_bytes())} for n,v in sys.modules.items() if (n.startswith('uarch_contract') or n in ['pydantic','pydantic_core']) and getattr(v,'__file__',None)}
assert all(str(R/'reference/contract') in v['path'] for n,v in origins.items() if n.startswith('uarch_contract'))
prior=json.loads((P/'python-freeze.json').read_text())['origins'];assert all(prior[n]['sha256']==v['sha256'] for n,v in origins.items())
assert not any(n=='rk' or n.startswith('rk.') or n=='rkuarch' or n.startswith('rkuarch.') for n in sys.modules)
report={'time_ns':time.time_ns(),'python':sys.version,'python_executable_sha256':sha(pathlib.Path(sys.executable).read_bytes()),'pydantic':pydantic.__version__,'unicode':unicodedata.unidata_version,'reference_commit':'ce732f5bedccdde629edcf278fa76ea772d0ea82','origins':origins,'codepoints_scanned':0x110000,'strip_empty_codepoints':blank,'blank_encoding_sha256':sha(blankraw),'datasets':checks,'three_field_blank_coverage':coverage,'preserved_text_assertions':preserved,'predicted_wrong_acceptances':predicted,'focused_refusal_classifications':classified,'other_predicates_Python_only':isolation,'all_other_source_bytes_unchanged':True,'new_native_vectors':0,'expectation_basis':'Existing frozen corpus bytes independently rederived. Fault IDs predicted from literal before/after nonblank sets before B native runs; no native outputs read.'}
(R/'output/python-review.json').write_text(json.dumps(report,indent=2)+'\n');print('Re-derived 21694 rows; 29 blank characters; 221 focused refusal classes; predicted 35 wrong acceptances. No new native vectors.')
