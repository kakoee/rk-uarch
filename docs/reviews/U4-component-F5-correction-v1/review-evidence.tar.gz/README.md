# U4 component candidate — fresh independent review, Stage 1

Reviewer: a fresh session that did not author A's mapper/proposal, B's checkers/corpus or
the coordinator's pin. Scope is [reviewer.md](../U4-component-release-review-v1/reviewer.md):
the published component mapper/assembly/replay, B's corpus/checkers, and A's exact five-file
proposal. The optimized K2 runtime/deployment and its stopped campaign are out of scope.
This is evidence, not a verdict. It grants no acceptance, installation, release or closure.
Nothing was installed, no native code was built or run, and no host was contacted.

Severity labels used below:

* **BLOCKING (D1)**: resolve before the exact five-file candidate is accepted or installed.
* **BLOCKING (first use)**: resolve before B's bound checker/selection is relied on at native
  first use. Does not by itself block D1.
* **NON-BLOCKING**: record and decide; no gate.

## Reconstruction (verified)

| Item | Result |
| --- | --- |
| Target `df3cde61…` | exists; B handoff `fd0a60b3…` and patch base `2f48beeb…` are ancestors |
| `combined.patch` SHA256 | `3106fba9…a9b3b9`, matches |
| Five preimages in a `git archive` export of the target | all match `postimages.json`; the five files are byte-identical at base, target and HEAD |
| Apply in a private copy only | all five postimages match |
| A tests | `test_candidate.py.txt` and `test_result.py.txt` copied to `tests/component_proposal/` in the export |
| Coordinator's four B test bindings | SHA256 match `checks.json` |
| Module origins | every run asserted `rkuarch`, `uarch_contract`, `validation.component` came from the export. The live `.venv` has an editable `.pth` that adds the live `src`/`contract`; [review_runner.py](review_runner.py) strips those entries and fails on any live module |
| Static checks | `PYTHONPATH`/`MYPYPATH` unset; caches in scratch; `mypy -v` parsed the export's `mapped.py` |
| Live clone | unchanged except this new, uncommitted directory |

Raw logs and mutant copies stay in the session scratchpad. [receipts.json](receipts.json) records
each command, its exit status and the log SHA256.

## Checks executed

| Check | Result |
| --- | --- |
| A's recorded combined selection (mapper, loader, `contract/tests/mapped`, `validation/component`, A proposal tests, B tests), `-m "not native"` | **361 passed**, 2 skipped (named missing human workings H-L1-DMA-01/H-L1-GEMM-01), 1 native deselected. A recorded 353; the delta is B's later additions on main |
| Coordinator's 38-test selection | 38 passed |
| Same discoverable subset on the **unpatched** target | 256 passed, 2 skipped, 1 deselected (main is green without the patch) |
| ruff (changed and package files) · mypy `src contract/uarch_contract scripts` · mypy `--no-explicit-package-bases contract/tests` · lint-imports | pass · 88 files pass · 33 files pass · 2 contracts kept |
| Schema generator `--check` | fresh. Only `MappedEngineResult.json` changes; `/1` `Observations.json` and native K2 accounting stay `/1` |
| Selected generator support, base export vs candidate export ([probe_lifecycle.py](probe_lifecycle.py)) | 56 → 56 files, **zero path or byte delta**; none of the five patched files is in the selection. No U0002 regeneration follows |
| Fixed-delay `/1` helper and `validate_job`/`admit`/`canonical_owners` | function source byte-identical to base |
| B `freeze_inputs.py` re-run in a private copy of the candidate | the published selection and all 13 fixture files are reproduced **byte-for-byte** |
| 99-cell selection ([probe_selection.py](probe_selection.py)) | 99 unique IDs: 82 historical B (78 result, 4 profile layer), 4 A, 3 B2 positives, 2 A2, 8 resource-preflight. No duplicate input bytes; shared graph hashes are expected (same graph, different spec/point). All job/engine/build/authority/raw-request cells null, native `not_run`. Every input-backed cell reproduces its identity and expected public code under synthetic anchors; the 4 historical profile cases stop at `TestVariantNotAdmitted`; A2 identities join `fixture-identities.json`; checker bindings match |
| Scalar re-derivation, no project imports ([probe_arithmetic.py](probe_arithmetic.py)) | resident C01/C02, cold C05 (656000 = 515000+32000+104250+4750), D01, D10 unequal clocks (3334/56667/4183101⁄71/59167/62500/63750), D04 carry 5608928⁄71 → 78999 vs 79000, D14 61667, and C04/255-256/equal accumulator literals all match B's workings and the selection |
| Default `@1` mapper bytes, unpatched vs candidate ([probe_v1_bytes.py](probe_v1_bytes.py)) | 97 admitted graphs hash-identical and 64 identical `CapacityExceeded` refusals (1–16 ops, tails, reverse-ID dependencies, cold/resident) |
| `@2` mapper sweep ([probe_accumulator.py](probe_accumulator.py)) | 48/48 multi-op cases admitted. On 113 heterogeneous cores, every accumulator is exact-size at offset 0 with producer = sole terminal = its compute, and the matrix chain follows min-ID Kahn order. Single-footprint cores keep one persistent buffer; no duration fields |
| `@2` replay with the mapper import blocked ([probe_replay.py](probe_replay.py)) | bundle export → load equal and re-export identical; job export → load equal; `job_hash` stable. Operand-access, input-coverage and cold-output refusals hold on `@2` input (A2 has no barrier, so that check is n/a) |
| First-use consumer ([probe_first_use.py](probe_first_use.py)) | `selection.assert_case` → `consume` → `validate_result` then `check_v2`. A channel-duration fault passes `validate_result` alone and is refused by `assert_case`. A `/1`-shaped component result is refused by `validate_result` |

## Findings

### F1 — BLOCKING (D1 and first use) — occupancy is unconstrained, so channel and port laws can be skipped

Nothing binds `occupies_resource` to the service subphases that must occupy. `validate_result`
forces only alignment, `dram_latency` and `ack` to be non-occupying
(`contract/uarch_contract/mapped.py:1392-1401`, postimage). The rational-ratio rule
`mapped.py:1484` applies only to resource rows that exist. The U0011 postimage
(`docs/decisions/U0011-the-native-engine-core.md:434-436,453-457`) says busy intervals are
"only" occupied activities, but never names which services occupy. In `check_v2`:

* `channel_service` has no phase spec (`validation/component/observations_v2.py:134`) and is skipped in the clocked loop (`:151-155`).
* The rational duration, FIFO tie and carry are checked only while iterating channel **resource rows** (`:216-245`).
* Port/matrix exclusivity (`:208-215`) and port eligible grant (`:246-253`) also use resource rows.

*Reproducer:* [probe_masked.py](probe_masked.py) M4a/M4b uses B's D01 carrier. It marks the
channel service non-occupying, drops its row, and sets service end 54500 (the law gives
52000+159744⁄71 → 54250). The response alignment absorbs the 250 ps, so every other time is
unchanged. After resealing, both `validate_result` and `check_v2` **accept**. This defeats the
selection's required fault "rounded channel carry". By the same code path, a non-occupying port
removes D08's exclusivity/contention check. I did not build that second carrier.

*Proposed regression:*
* **A:** state in U0011, and require in `validate_component_observations`, the occupancy of every service subphase: `compute_*`, `read_port`/`write_port` and `channel_service` occupy; the NoC-hop convention is made explicit.
* **B:** apply the channel and port laws to activities selected by subphase and owner, independent of resource rows.
* Tests: M4b refuses, and a D08 variant with a non-occupying, overlapping port refuses.

*Owner:* A (text and validator), B (checker), coordinator (new selection revision, because `checker_bindings` change). *Class:* software defect.

### F2 — BLOCKING (first use) — causal eligibility and completeness are not verified

The U0011 postimage (`:477-485`) requires each supplied predecessor to be "a legal actual
cause", says zero-length links "cannot be dropped", and says the "independent checker must
verify candidate completeness and actual blocker eligibility". The selection lists
"wrong causal predecessor" as a required fault. `check_v2` walks only the chosen chain and
checks tightness (`observations_v2.py:330-358`). `validate_result` accepts a `credit` link from
**any** same-engine activity that ends at the successor's start (`mapped.py:1444-1451`).

*Reproducer:* [probe_causal.py](probe_causal.py), on B's D08 carrier, fully resealed:

* **V1:** adds r00's port service as a `credit` cause of r01's port service. r01 issued at 0 under a limit of 32 and never waited for a credit. **Accepted.**
* **V2:** drops r00 port-alignment's real `sequence` cause and names r01's response hop as a `credit` cause. Two same-time `MEM_RESP` events swap jobs; no timestamp changes. The canonical critical path moves from `r0:out…r0:back` to `r1:out…r1:back` (another request on channel 7). **Accepted** by both validators.

*Proposed regression:*
* **B:** derive each activity's eligible tight causes from transitions. Sequence means the previous subphase of the same request/job. Dependency means a declared predecessor's completion. Resource means the previous occupant ending at the grant. Credit means a request's first activity, released by a same-engine completion while at `max_outstanding`.
* Require the supplied set to equal the eligible set.
* **A (optional structural tightening):** allow `credit` only on a request's first activity, from another request's final activity.
* V1 and V2 become refusals.

*Owner:* B, with A for the structural rule; coordinator for the selection revision. *Class:* software defect.

### F3 — BLOCKING (D1) — essential `/2` validator guards have no discriminating regression

A private sweep disabled one `require(...)` at a time in `validate_component_observations` and
ran A's `test_result`, B's `test_carrier` and `contract/tests/mapped`
([guard_sweep.py](guard_sweep.py)). **37 of 46** removals failed no test. The fault tests use
unpinned `pytest.raises(ValueError)` (A `test_result.py.txt:275`; B `test_carrier.py:93`) and
edit one field, so a later join masks the removed guard. A's "cycle" fault
(`test_result.py.txt:273-274`) is a self-link, refused by the self-link check
(`mapped.py:1416-1420`); it never reaches the cycle guard.

Four guards are each the **sole** defence against a consistent forgery. With the guard removed
and all 126 tests still passing, the forgery passes both `validate_result` and `check_v2`
([guard_removal.py](guard_removal.py) with [probe_masked.py](probe_masked.py) and
[probe_causal.py](probe_causal.py)):

| Guard (postimage line) | Forgery that is then accepted |
| --- | --- |
| category/domain `:1391` | M1: D10 response alignment relabelled memory, with critical record and attribution moved. This is B's own "DRAM alignment relabelled NoC must fail" |
| activity owner `:1376` | M2: D01 request hop owned by `dma_port:0`, with events, queue, resource row, busy time and critical record moved |
| missing tight cause `:1412-1413` | M3: off-chain D08 activity at 54250 with no cause |
| activity cycle `:1460` | C1: zero-duration two-activity cycle on A's shell |

Exact bytes were restored after each removal and the tests re-passed.

*Proposed regression:* a per-guard table of consistent forgeries (M1–M3, C1 included), each
pinned to its code and detail, placed in ordinary CI. *Owner:* A (`validate_result` tests), B
(carrier forgeries). *Class:* test defect in the D1 validator.

### F4 — BLOCKING (D1) — essential `@2` lifetime guards lack unsafe-admission regressions

Private removals in the export, with exact restore and retest
([guard_removal.py](guard_removal.py), [probe_accumulator.py](probe_accumulator.py)):

* **"accumulator use before production" (`mapped.py:2072-2077`):** removing it fails **zero** A/B tests. My same-footprint B2-equal variants are refused today and admitted without the guard:
  * A3b: z consumes c's transient accumulator before producer c.
  * A3c: z and c share it unordered.

  (A3 from C04 is masked by the exact-size check.)
* **Final-consumer equality (`:2087-2091`):** removal is caught only through code mismatches (A `last_use`; B `missing_consumer`/`false_consumer` become `LiveBufferAlias`). The unsafe case, A1, is admitted without the guard. In A1, `acc` is read by c, d and e; only d is declared terminal; `zacc` reuses the same bytes after d while e can still be running. A1 is in no test or selected input.

Removing the writer, live-alias, owner or capacity guard is caught by existing tests. Removing
the writer, live-alias or capacity guard admits its targeted invalid input. The owner guard is
redundant with the compute-side core/size check.

*Proposed regression:* add A1, A3b and A3c as refusal tests pinned to `InvalidDependency` and
their detail strings. *Owner:* A (`test_candidate`), B (`test_accumulator`). *Class:* test defect.

### F5 — BLOCKING (first use) — `check_v2` guards are mostly undiscriminated

Excluding `test_join_selection.py` (it hash-binds `observations_v2.py`, so any edit fails it),
B's behavioural tests kill only **5 of 55** single-guard removals in `check_v2`: lines
170, 172, 268, 399 and 438. Final count is in [receipts.json](receipts.json). Survivors include:

* mechanism duration `:166`, phase ready transition `:196`
* channel FIFO tie and carry `:236-244`, port grant `:253`, busy union `:255`
* accumulator lifetime mechanism `:481-491`
* causal partition `:337-358`
* unrepresented paths and C1/null floor `:531-536`

[restoration.json](../U4-B-component-joins-v2/restoration.json) evidences 5 guards, one of them
in `phase_laws.py`. *Proposed regression:* one consistent-forgery fault per guard, pinned to its
`CheckFailure` detail. *Owner:* B. *Class:* test defect in the first-use checker.

### F6 — BLOCKING (D1) — installing the five files activates no `@2`/`/2` regression

With the five-file patch alone, no default-discoverable test (`testpaths = tests, contract/tests,
validation`) exercises:

* `map_component(mapping_version="2")`
* `@2` admission
* `validate_component_observations`
* `check_v2` on a parsed carrier

A's tests are `.py.txt`; B's live under `docs/reviews/`, and `test_carrier.py` loads
`synthetic_carrier.py` as a sibling file. `validation/component/test_join_inputs.py` checks only
arithmetic and the old C04 refusal. [next-decision.md](../U4-component-release-review-v1/next-decision.md)
already names this. The pinned candidate does not yet contain the final test paths and bytes.

*Proposed:* the installation package lists exact discoverable test paths and hashes, including
the regressions from F1–F5, and runs them on the installed tree. Moving tests does not change
the 99-cell selection, because `checker_bindings` contain no test files. *Owner:* coordinator
with A/B. *Class:* packaging (human placement choice).

### F7 — NON-BLOCKING — two selected lifetime negatives are masked

With the target guard removed:

* `B2-lifetime-false-writer` and `B2-lifetime-missing-consumer` still refuse, now with `LiveBufferAlias`. They are not admitted.
* `B2-lifetime-wrong-owner`'s target guard is redundant: removing it yields `CapacityExceeded` from the compute-side check.
* `no-order` and the four capacity negatives are admitted when their guard is removed. They are unmasked.

So native discrimination of writer and terminal-set rules rests on exact error-code equality and
refusal order. *Proposed:* add unmasked selected negatives (B's disjoint 84 B writer control; A1
partial terminal set) in a selection revision. *Owner:* B, coordinator.

### F8 — NON-BLOCKING — `/2` carries unvalidated fields

Each of these, forged and resealed, passes both validators ([probe_causal.py](probe_causal.py) F1a–F1e):

* critical `predecessor_id`
* job `blocking_predecessor_ids`
* job `owner_id` (any valid owner)
* job `release_ps` (later than ready)
* event `kind` (`DMA_DONE` → `STAT_SAMPLE`)

The `/1` path binds the first two (`mapped.py:1796,1823`). *Proposed:* in `/2`, bind these
fields (canonical job owner, predecessor = previous chain job, event kind per subphase
transition) or require null/empty. *Owner:* A (contract), B (checker).

### F9 — NON-BLOCKING (by inspection) — port arbitration order is not checked

`check_v2` verifies the channel FIFO tie (`observations_v2.py:227-240`). For ports it checks only
"no idle gap" (`:246-253`). Granting equally ready requests in either order passes. D08's literal
`complete_ps` would catch a swap there. `A2-255-256-cold`, which has heavy port contention and no
timing literal, would not. Not executed. *Owner:* B.

### F10 — NON-BLOCKING — `@2` moves operand placement even without mixed footprints

[probe_v2_placement.py](probe_v2_placement.py): two uniform 256³ ops where `a` depends on `b`.
There is no transient accumulator and no new edge, yet 14 buffers move offset under `@2`. The
mapper allocates SRAM/HBM in topological rather than ID order (`mapping/component.py:94-104`).
The U0011 postimage (`:415-419`) describes only the accumulator and edge strategy. *Proposed:*
state this in U0011, or keep ID-order allocation and apply topological order to edges only.
*Owner:* A.

### F11 — NON-BLOCKING (human choice) — policy version is outside the test-profile anchor

Profile entries bind graph and point hashes, not `mapping_policy`. An `@1` mapper bundle
relabelled `@2` keeps those hashes and validates (`A7` in [probe_accumulator.py](probe_accumulator.py)).
It is inert today: without producer metadata the validation is identical. *Decide:* whether
profiles or points should bind the policy version. *Owner:* coordinator/human, A.

## Confirmed without finding

**1 — Mapper and admission:**
* 1–16 ops with tails and coverage; explicit buffers, routes, striped fragments and dependencies; no hidden durations.
* Producer-disabled replay of bundle and job.
* Rehashed attack layering on exact A2 bytes: `TestVariantNotAdmitted` under the original anchor; `InvalidDependency` under a new synthetic anchor.
* A valid alternate placement (z→c) is admitted and changes graph identity.

**2 — Accumulator `@2`:**
* Writer/core, terminal set, live alias and capacity behave as stated.
* `@1` historical producer metadata is inert. Default `@1` bytes are unchanged.
* The C04 historical `CapacityExceeded` and 1855000 ps are preserved.
* `@2` relabelled to `@1` refuses `UnsupportedMapping`.
* Mixed 255/256 and equal-footprint arithmetic re-derived.

**3 — Observation `/2`:**
* All of B's worked phase numbers re-derive independently.
* Zero-hop and zero-duration activities stay represented.
* Alignment and DRAM latency never occupy.

**4 — Division of responsibility.** `validate_result` performs structural joins: activity owner, category and domain; event ordinals; tight and typed links; cycle; occupied-row join; queue bindings; clock joins; canonical path. `check_v2` performs the mechanism laws: inventories, cycle counts and edges, rational channel, FIFO, port grant, busy union, queue populations, transfers, allocation lifetimes, the causal chain, null floor and C1. First use requires both (see Checks). Nulls are typed: `u_c0_duration_ps`, `energy_pj` and the other unrepresented diagnostics are `None`, and `check_v2` pins at-most-C1 and the exact unrepresented list.

**7 — Lifecycle:** support delta zero; schema fresh; fixed-delay helper isolated.

## Negative authority — future release requirements (item 5, not demanded now)

The proposal in [negative-authority.md](../U4-A-component-release-v1/negative-authority.md)
keeps the four layers distinct: profile refusal, Python preflight, Rust refusal and synthetic
unit anchor. It adds no caller bypass. For its scoped release:

1. Authenticate the selection through host/build trust, not repository bytes. Entries are sorted and unique, every field is required, and `dispatch_permitted=false`.
2. Freeze the eight negatives' raw request SHA256 (all null now) with the Rust refusal vocabulary.
3. Compare refusal codes exactly, in the native-checklist order. This is load-bearing because of F7.
4. Never write a result or receipt for a successful or partial run under the selection. Record zero dispatched jobs.
5. Do not route negatives through `invocation="production"`. It admits any production-hardware cold component bundle without a profile (`mapped.py:1907-1913`), so it would only exercise Python preflight.

## Human choices (not defects)

* F6 test placement.
* F11 version binding.
* The `@2` serialization order (topological, ID ties) can be slower than FIFO-ready in cold cases. It is explicit and versioned.
* Persistent shared scratch relies on whole-tile matrix ownership. This is consistent with U0011's "distinct overlapping allocations" scope.
* The NoC-hop occupancy convention (part of F1).
* Acceptance of D3's transport mechanism.

## Missing future execution (not defects)

* No native build or run. All 99 cells are `not_run`, with null engine/build/host/job/raw-request.
* Six-way debug/release replays are not run.
* Human H-L1-DMA-01 and H-L1-GEMM-01 workings remain named skips. They are not reviewer defects and are not verified here.
* `A2-255-256-cold` has count literals only, with no independent timing literal.

## Coordinator confirmations

* D1 changes the runner/host Python import closure through `mapped.py`. No approved K2 record in `docs/reviews/U4-K2-approved-*` pins the base `mapped.py` digest. Confirm the active K2 runtime authority is unaffected or explicitly rebound before installation. Out of scope here.
* Inherited, not rerun: A's 84 later affected passes; B's 279/126; B's peer audit of runtime import closures and 22 native files; strict vendor currentness.

## Files

* [review_runner.py](review_runner.py): isolated runner.
* Probes:
  * [probe_selection.py](probe_selection.py)
  * [probe_arithmetic.py](probe_arithmetic.py)
  * [probe_accumulator.py](probe_accumulator.py)
  * [probe_causal.py](probe_causal.py)
  * [probe_masked.py](probe_masked.py)
  * [probe_replay.py](probe_replay.py)
  * [probe_first_use.py](probe_first_use.py)
  * [probe_lifecycle.py](probe_lifecycle.py)
  * [probe_v1_bytes.py](probe_v1_bytes.py)
  * [probe_v2_placement.py](probe_v2_placement.py)
* Private mutation tools: [guard_removal.py](guard_removal.py), [guard_sweep.py](guard_sweep.py).
* [receipts.json](receipts.json): commands, exits and log hashes.

Probes run with the export root as cwd, for example:
`.venv/bin/python -I review_runner.py <export> script <probe.py>`.
They write nothing into the export. The mutation tools edit only the mutant export given to
them and verify exact-byte restoration.

Stage 2: the original authors answer F1–F11. Stage 3 is the same reviewer: rows, reasons and
tests, with one random revert and no new findings.


---

## Stage 3 adjudication — 2026-10-17

Same Stage 1 reviewer; I did not author any correction. This is U-REVIEW Stage 3 only: rows,
reasons and tests, one random revert, no new findings. Nothing here accepts semantics,
grants installation, or substitutes for human or native evidence. Evidence is in
[stage3/](stage3/); [stage3/receipts.json](stage3/receipts.json) lists every command, log
hash and script hash.

**Subject adjudicated.** A response `941e882d…`, B response `9678d492…`. The combined
unapplied patch `81b81c6c…2bdebe3` was applied privately to `git archive` of preparation base
`414a94c3…` (tree `4524cfe7…`). Verified: manifest `5d1010aa…`; 23 preimages and 23
postimages; nine activation inputs plus the `first-use-bindings.json` sidecar; selection
`sha256:4b9e73cf…bbc0` recomputed (106 cases), file `a8b94f0d…`. The 23 preimages and
nine inputs are identical at behavioural base `7b972d0`. The live U0011 is not used. It now
carries the installed K2 coexistence clauses, so a later installation must reconcile both
text streams.

### Executed vs inherited

**Executed by me, export-only origins confirmed in every counted run:**
* **The inherited affected command, run once:** 488 passed. 2 skipped: actual H-L1-DMA-01 and H-L1-GEMM-01 workings are absent; these are named skips, not verification. 1 native first-use test deselected. This is my separate run of A's command. It is not additive with A's single inherited 488.
* **Discovery:** 233 candidate nodes across all 11 candidate test paths, with no skips.
* **[probe_stage3.py](stage3/probe_stage3.py):** my own Stage 1 forgeries, run on B's accepted controls. B's `synchronize` is used only to copy joined fields. Each forgery runs twice: on the candidate, and on a pre-correction copy that differs only by the Stage 1 `mapped.py` and the archived Stage 1 `observations_v2.py`.
* **Single-guard sweeps** ([guard_sweep3.py](stage3/guard_sweep3.py)), with the hash-binding identity tests excluded:
  * validator: 59 removals, 53 killed;
  * `check_v2`: 69 removals, 28 killed;
  * `check_transitions`: 11 removals, 6 killed.
* **Detection-kind classification** ([kill_kind.py](stage3/kill_kind.py)), separating unsafe acceptance from alternative refusal.
* **Grouped-redundancy checks** ([group_checks.py](stage3/group_checks.py)).
* **Lifetime unmasking** ([f7_unmask.py](stage3/f7_unmask.py)).
* **The random revert.**

**Inherited, not rerun:**
* A's static, schema, lint, import and vendor checks.
* The 56-file zero-delta support audit.
* B's 33 checker and 4 lifetime experiments; A's 6 focused mutations.
* The shared 488-pass run and its retained logs (one A execution).
* Stage 1 mapper, replay and arithmetic results. The mapper and assembly postimages are unchanged since Stage 1.

My unchanged Stage 1 `probe_causal` and `probe_masked` now fail their own controls. The old doc carriers lack endpoint event kinds. Those refusals are **not** counted.

### (a) Rows — every F1–F11 has a disposition

| Row | A / B disposition | Correction or deferral | Owner |
| --- | --- | --- | --- |
| F1 | APPLIED / APPLIED | Declared-phase occupancy. Channel/port laws taken from declared services, not rows. NoC hop occupancy proposed as non-contending bookkeeping | A (text, validator), B (checker) |
| F2 | APPLIED / APPLIED | Structural endpoint rules; checker requires the complete eligible-cause set | A, B |
| F3 | APPLIED (shared) | Guard matrix (42 essential, 17 dispositioned); M1–M3 and C1 tests | A (matrix), B (carriers) |
| F4 | APPLIED / APPLIED | A1, A3b, A3c refusal tests with controls | A, B |
| F5 | (B) / APPLIED | Guard-to-invariant matrix; 33 grouped experiments | B |
| F6 | APPLIED / APPLIED | 11 test paths and helpers in the 23-file candidate | A, B |
| F7 | APPLIED / APPLIED | Four unmasked B3 negatives and three controls; B2 masked rows kept as refusal-order controls | B |
| F8 | APPLIED / APPLIED | Job/event fields bound; `/2` legacy scalars null or empty | A, B |
| F9 | APPLIED / APPLIED | Port FIFO tie (ready, engine, request) | B |
| F10 | APPLIED / APPLIED | U0011 discloses topological operand placement, plus a behaviour test | A |
| F11 | PREPARED, human choice DEFERRED / preparation APPLIED, choice PENDING | profile/2 proposed; P1 alternative bounded | coordinator/human, A |

No row disappears through cross-reference: A's and B's tables each carry F1–F11.

### (b) Rejections and deferrals

Nothing is REJECTED. F11's deferral is precise and honest:
* The legacy profile/1 promise is stated as graph/point-only. My own D08 relabel @1→@2 is still admitted under profile/1. Profile/2 refuses it at `profile mapping policy`, admits the exact policy, and refuses the edited profile/2 bytes under the old anchor.
* The new B3 fixtures keep profile/1.
* The text says to remove the profile/2 additions if P1 is chosen.

Nothing in the response presents profile/1 as binding policy. The NoC convention and the exact `/2` semantics are labelled proposals. I grant neither.

### (c) Applied corrections have discriminating regressions

Pre-correction (pre) versus candidate (cand), from my probe:
* **Controls:** D01, D08, D10, C02 are accepted by both layers in both copies.
* **F1:** M4a, M4b and non-occupying overlapping ports: pre accepted by both layers; cand refused by both (`phase occupancy`; `required occupancy` / `channel integer mechanism` / `exclusive mechanism intervals`).
* **F2:** V1 and V2: pre accepted by both; cand refused (`credit endpoints`; `complete eligible causes`). B's structurally eligible false credit passes `validate_result` by design and is refused only by `check_v2`, which shows the checker is independent.
* **F3:** M1, M2, M3: pre accepted by `check_v2`; cand refused by both layers. C1, a genuine two-node zero-duration cycle, is refused in both. The cycle pass is a redundant early and termination defence; the ordinal rules alone also refuse it.
* **F8:** all five resealed field forgeries: pre accepted by both; cand refused by both, at the intended details.
* **F9:** reversed tied-ready port grants with makespan unchanged: pre accepted; cand refused by `check_v2` at `port FIFO tie`. Port arbitration is the checker's job, so `validate_result` accepting it is correct.

Single-guard removals, classified:
* **Validator guards:** each of `phase occupancy`, `activity category/domain`, `activity owner`, `missing tight cause`, `credit endpoints`, `sequence endpoints`, `job owner`, `activity event kind` and `unrepresented critical predecessor` produces **DID NOT RAISE** in its named test.
* **Validator sweep survivors:** the five survivors plus the non-terminating cycle guard are exactly A's dispositioned redundant/unreachable/termination guards (A02, A12, A18, A20, A26, A57).
* **Checker guards with unsafe acceptance on single removal:** `port FIFO tie`, `complete eligible causes` (V1, V2), `job owner binding`, `event transition binding`, `phase ready transition`, `busy union`, `channel FIFO tie`, `rational channel carry/readiness`, `unrepresented paths`, `fidelity/null floor`, `causal attribution totals`.
* **Grouped channel law:** removing B's whole group admits M4b in `check_v2`, while `validate_result` still refuses it. The grouping is true.

Other rows:
* **F4/F7:**
  * Removing the writer guard admits B3-false-writer-disjoint; 5 tests fail, including the new B3 test.
  * Removing terminal equality admits B3-terminal-partial-A1; 5 fail, including the A1 and B3 tests.
  * Removing use-before-production admits A3b, A3c and both B3 use-before cases; 4 new tests fail, where Stage 1 had zero.
  * The B2 masked rows keep their documented historical refusal order (writer and terminal removals → `LiveBufferAlias`).
  * Exact restore after each; 67 passed.
* **F6:** random revert below.
* **F10:** my unchanged Stage 1 placement probe still shows 14 moved offsets, no transient accumulator and no added edge. The text now discloses this and a behaviour test pins it. The text itself is documentation and is not behaviour-testable.

**Random revert.** The draw is recorded in [stage3/logs/random_draw.json](stage3/logs/random_draw.json): OS CSPRNG `randbelow(10)` over F1–F10, the rows APPLIED by both lanes, with F11 excluded as deferred. It returned index 5 → **F6**.

I reverted F6 privately by removing the 10 new candidate test files from discovery, back to Stage 1 packaging. As sentinels I disabled two essential guards whose regressions were undiscovered at Stage 1: A's use-before-production and B's port FIFO tie. I then ran the ordinarily discovered `contract/tests/mapped`, `tests/unit` and `validation/component` ([random_revert_f6.py](stage3/random_revert_f6.py)):

| State | Candidate nodes | Result |
| --- | --- | --- |
| Restored candidate | 232 in the 10 files | not run |
| F6 reverted | 0 | 1102 passed |
| F6 reverted + sentinels | 0 | 1102 passed — both defects undetected |
| F6 restored + sentinels | 232 | 6 failed: 5 behavioural (A3b, A3c, B3 A3b/A3c, `port_reverse`) and 1 identity test (`test_stage2_selection`, not counted) |
| Exact bytes restored, rerun | 232 | 1334 passed |

**F5 is at fault.** B dispositions `mechanism duration` — a guard I named in Stage 1 F5 — as "jointly defended by duration and clock witness". B's only duration test forges `n_cycles=2` against declared one-cycle work, so the clock binding refuses it first. My clock-consistent forgery ([probe_f5_duration.py](stage3/probe_f5_duration.py)) works like this:
* The D01 two-hop response hop ends at 58500, where the 4-cycle law gives 59000.
* `n_cycles` stays truthful at 4. The clock completion matches the forged end.
* The port alignment absorbs the 500 ps, so nothing downstream moves.

The candidate refuses it only at `mechanism duration`. With **only** that guard removed, both `validate_result` and `check_v2` **accept** it, and B's test catches the removal only by alternative refusal ([group_checks.json](stage3/logs/group_checks.json)). The redundancy claim is false for consistent forgeries, and this essential guard has no unsafe-acceptance regression.

Needed (B): a clock-consistent duration forgery pinned to `mechanism duration` that yields DID NOT RAISE when only that guard is removed, and a corrected disposition. Alternatively, make the clock binding check completion against the cycle law, and test each defence separately.

### Out-of-scope observations for coordinator triage (not findings)

* **O1:** eight new checker sub-guards appear in B's `final_guards` with no invariant group, disposition or experiment, and each survives single removal: `complete request inventory`, `occupied row binding`, `nonclocked request binding`, `ordinary queue inventory`, `actual nonzero-start cause`, `job dependency readiness`, `job transition endpoints`, `event endpoint inventory`. Their parent corrections (F1, F2, F8) do have failing regressions, so the response is acceptable at row level for those findings. B's "covers … by semantic invariant" overstates the list.
* **O2:** `accumulator lifetime mechanism` passes undetected on single removal. B's grouped control uses C02's persistent accumulator, whose one compute spans the whole run. No `/2` synthetic carrier exercises `check_v2`'s transient @2 lifetime branch. I did not demonstrate an unsafe forgery here.
* **O3:** the random revert ran `tests/unit` (983 tests) in four states. That is bounded but heavier than necessary. It was not the full suite.

### Verdict

**NOT ACCEPTED.** Row at fault: **F5** (owner B), for the reason above only.

Rows F1–F4 and F6–F11 meet checks (a)–(c). The F6 random revert passed.

This concerns the software/preparation response only. Human choices remain separate: the NoC convention, the exact `/2` semantics, and F11 P1/P2. Also separate are protected installation, U0011 reconciliation, H-L1-GEMM-01 and H-L1-DMA-01, future native identities and first-use authority, component execution, U0024 qualifications, and U4 closure.
