#!/bin/sh
exec /usr/bin/docker run --pull never --name u4-stage2-baseline-0841c8a3c5534829b7fa19e34715af64 --network none --read-only --pids-limit 16 --memory 64m --entrypoint /bin/sleep sha256:e9f69f41498334be985ed4d25973fe3fa3f6519e58c73e6a7b8397d871fa0523 10
